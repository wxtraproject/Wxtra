WXTRA v38 - Ana Sayfa Yeniden Tasarım

Ana sayfa soldaki seçilen premium tasarıma göre sıfırdan düzenlendi:
- Yeni WXTRA üst barı, arama ve bildirim simgeleri
- Senin İçin / Popüler / Yeni / Ruh Hâli / Keşfet sekmeleri
- Daha büyük Günün Önerisi hero kartı
- Popüler Şu An ve Senin Ruh Hâlin için tam simetrik 2 sütunlu kartlar
- Yeni / Öne Çıkanlar için yatay kaydırmalı kartlar
- Kartlarda beğeni ve görüntülenme göstergeleri
- Kart başlıkları kaldırıldı; görsel alanı büyütüldü
- Ekran genişliğine göre iki sütun otomatik eşit bölünüyor; yarım kart sorunu yok

Not: Bu çalışma WXTRA v37 kaynakları üzerinden hazırlanmıştır. Yerel ortamda Gradle komutu bulunmadığından burada APK derlemesi yapılamadı; GitHub Actions ile normal build kontrolü yapılmalıdır.
