# WXTRA Architecture — Clean Start

The app is intentionally split into a UI-first phase and a server phase.

## Phase 1 — local
`MainActivity.kt` owns the initial Compose navigation and local demo catalog. No API URL, HTTP request, token, or server dependency is used by the app.

## Phase 2 — data layer
Create repository/interfaces for wallpapers, categories, account, favorites and collections. The UI should consume interfaces rather than HTTP directly.

## Phase 3 — server
Only after the local app is stable, add the API implementation and switch the repository implementation. API configuration should come from BuildConfig/environment, never from hardcoded production credentials.
