# WXTRA Sunucu Güncellemesi

Bu patch, mevcut WXTRA API'ye uygulamanın güncel duvar kâğıtlarını internet üzerinden okuyabilmesi için güvenli bir görsel servis endpoint'i ekler.

## Kurulum

Sunucuya bu `server_patch` klasörünü kopyalayıp şu komutu çalıştır:

```bash
chmod +x install_admin_security.sh
sudo ./install_admin_security.sh
```

Script:
- admin yazma işlemlerini korur ve kullanıcı adı/şifre ile admin girişini doğrular,
- - 50 MB'a kadar yükleme desteği açar,
- Maven ile build eder ve `wxtra-api` servisini yeniden başlatır.

Android uygulaması katalog ve kategorileri açılışta ve yaklaşık 5 dakikada bir yeniler. Yeni görsel veya kategori eklemek için APK yeniden oluşturulmaz.

Admin giriş varsayılanı: `admin / WXTRA@2026`. Kategoriler PUT ile düzenlenebilir.

Not: Görsel dosya endpointi mevcut `ApiController` içinde zaten varsa ikinci controller eklenmez; böylece çakışan mapping oluşmaz.
