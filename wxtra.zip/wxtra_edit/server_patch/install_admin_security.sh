#!/usr/bin/env bash
set -euo pipefail

SERVER_DIR="/opt/wxtra/wxtra_work/server"
PKG_DIR="$SERVER_DIR/src/main/java/com/wextra/api"
RES_DIR="$SERVER_DIR/src/main/resources"

if [[ ! -d "$SERVER_DIR" ]]; then
  echo "Server directory not found: $SERVER_DIR" >&2
  exit 1
fi

mkdir -p "$PKG_DIR" "$RES_DIR"
cp "$(dirname "$0")/src/main/java/com/wextra/api/AdminSecurityFilter.java" "$PKG_DIR/AdminSecurityFilter.java"
cp "$(dirname "$0")/src/main/java/com/wextra/api/AdminAuthController.java" "$PKG_DIR/AdminAuthController.java"
cp "$(dirname "$0")/src/main/java/com/wextra/api/CategoryAdminController.java" "$PKG_DIR/CategoryAdminController.java"
cp "$(dirname "$0")/src/main/java/com/wextra/api/GoogleAuthController.java" "$PKG_DIR/GoogleAuthController.java"

PROP="$RES_DIR/application.properties"
TOKEN_LINE='wxtra.admin.token=WXTRA_ADMIN_2026_583921'
USER_LINE='wxtra.admin.username=admin'
PASS_LINE='wxtra.admin.password=WXTRA@2026'
GOOGLE_CLIENT_LINE='wxtra.google.web-client-id=YOUR_WEB_CLIENT_ID.apps.googleusercontent.com'
if grep -qxF "$TOKEN_LINE" "$PROP" 2>/dev/null; then
  :
elif grep -q '^wxtra\.admin\.token=' "$PROP" 2>/dev/null; then
  sed -i 's/^wxtra\.admin\.token=.*/wxtra.admin.token=WXTRA_ADMIN_2026_583921/' "$PROP"
else
  printf '\n%s\n' "$TOKEN_LINE" >> "$PROP"
fi

SPRING_UPLOAD_1='spring.servlet.multipart.max-file-size=50MB'
SPRING_UPLOAD_2='spring.servlet.multipart.max-request-size=50MB'
for LINE in "$USER_LINE" "$PASS_LINE" "$GOOGLE_CLIENT_LINE"; do
  KEY="${LINE%%=*}"
  if grep -q "^${KEY}=" "$PROP" 2>/dev/null; then
    sed -i "s#^${KEY}=.*#${LINE}#" "$PROP"
  else
    printf '%s\n' "$LINE" >> "$PROP"
  fi
done

for LINE in "$SPRING_UPLOAD_1" "$SPRING_UPLOAD_2"; do
  grep -qxF "$LINE" "$PROP" 2>/dev/null || printf '%s\n' "$LINE" >> "$PROP"
done


# Google authentication user table and verifier dependencies.
SCHEMA="$RES_DIR/schema.sql"
if [[ -f "$SCHEMA" ]] && ! grep -q 'CREATE TABLE IF NOT EXISTS wxtra_users' "$SCHEMA"; then
  printf '\n' >> "$SCHEMA"
  cat "$(dirname "$0")/google-auth-schema.sql" >> "$SCHEMA"
fi

POM="$SERVER_DIR/pom.xml"
if [[ -f "$POM" ]] && ! grep -q 'google-api-client' "$POM"; then
  python3 - "$POM" <<'PY2'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
dep = """    <dependency>\n      <groupId>com.google.api-client</groupId>\n      <artifactId>google-api-client</artifactId>\n      <version>2.8.1</version>\n    </dependency>\n    <dependency>\n      <groupId>com.google.auth</groupId>\n      <artifactId>google-auth-library-oauth2-http</artifactId>\n      <version>1.51.0</version>\n    </dependency>\n"""
if '</dependencies>' in s:
    s = s.replace('</dependencies>', dep + '</dependencies>', 1)
    p.write_text(s)
PY2
fi

cd "$SERVER_DIR"
mvn clean package -DskipTests
sudo systemctl restart wxtra-api
sudo systemctl is-active --quiet wxtra-api

echo "WXTRA admin write security installed and wxtra-api restarted successfully."
