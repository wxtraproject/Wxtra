#!/usr/bin/env bash
set -euo pipefail

SERVER_DIR="/opt/wxtra/wxtra_work/server"
PKG_DIR="$SERVER_DIR/src/main/java/com/wextra/api"
RES_DIR="$SERVER_DIR/src/main/resources"

if [[ ! -d "$SERVER_DIR" ]]; then
  echo "Server directory not found: $SERVER_DIR" >&2
  exit 1
fi

mkdir -p "$PKG_DIR" "$RES_DIR"
cp "$(dirname "$0")/src/main/java/com/wextra/api/AdminSecurityFilter.java" "$PKG_DIR/AdminSecurityFilter.java"
cp "$(dirname "$0")/src/main/java/com/wextra/api/CategoryAdminController.java" "$PKG_DIR/CategoryAdminController.java"
cp "$(dirname "$0")/src/main/java/com/wextra/api/ImageFileController.java" "$PKG_DIR/ImageFileController.java"

PROP="$RES_DIR/application.properties"
TOKEN_LINE='wxtra.admin.token=WXTRA_ADMIN_2026_583921'
if grep -qxF "$TOKEN_LINE" "$PROP" 2>/dev/null; then
  :
elif grep -q '^wxtra\.admin\.token=' "$PROP" 2>/dev/null; then
  sed -i 's/^wxtra\.admin\.token=.*/wxtra.admin.token=WXTRA_ADMIN_2026_583921/' "$PROP"
else
  printf '\n%s\n' "$TOKEN_LINE" >> "$PROP"
fi

SPRING_UPLOAD_1='spring.servlet.multipart.max-file-size=50MB'
SPRING_UPLOAD_2='spring.servlet.multipart.max-request-size=50MB'
for LINE in "$SPRING_UPLOAD_1" "$SPRING_UPLOAD_2"; do
  grep -qxF "$LINE" "$PROP" 2>/dev/null || printf '%s\n' "$LINE" >> "$PROP"
done

cd "$SERVER_DIR"
mvn clean package -DskipTests
sudo systemctl restart wxtra-api
sudo systemctl is-active --quiet wxtra-api

echo "WXTRA admin write security installed and wxtra-api restarted successfully."
