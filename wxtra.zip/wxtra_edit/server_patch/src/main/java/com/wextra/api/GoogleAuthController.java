package com.wextra.api;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.Collections;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class GoogleAuthController {
    private final JdbcTemplate jdbc;
    private final GoogleIdTokenVerifier verifier;
    private static final SecureRandom RANDOM = new SecureRandom();

    public GoogleAuthController(JdbcTemplate jdbc,
                                @Value("${wxtra.google.web-client-id:}") String clientId) {
        this.jdbc = jdbc;
        if (clientId == null || clientId.isBlank()) {
            this.verifier = null;
        } else {
            this.verifier = new GoogleIdTokenVerifier.Builder(
                    new NetHttpTransport(), GsonFactory.getDefaultInstance())
                    .setAudience(Collections.singletonList(clientId))
                    .build();
        }
    }

    @PostMapping("/google")
    public ResponseEntity<?> google(@RequestBody Map<String, Object> body) {
        if (verifier == null) {
            return ResponseEntity.status(503).body(Map.of("ok", false, "error", "Google Client ID sunucuda ayarlanmadı"));
        }
        if (!Boolean.TRUE.equals(body.get("termsAccepted"))) {
            return ResponseEntity.badRequest().body(Map.of("ok", false, "error", "Kullanım koşulları kabul edilmelidir"));
        }

        String token = String.valueOf(body.getOrDefault("idToken", ""));
        if (token.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("ok", false, "error", "Google ID token eksik"));
        }

        try {
            GoogleIdToken idToken = verifier.verify(token);
            if (idToken == null) {
                return ResponseEntity.status(401).body(Map.of("ok", false, "error", "Geçersiz Google kimliği"));
            }
            GoogleIdToken.Payload p = idToken.getPayload();
            String googleId = p.getSubject();
            String email = p.getEmail();
            String name = p.get("name") != null ? String.valueOf(p.get("name")) : email;
            String picture = p.get("picture") != null ? String.valueOf(p.get("picture")) : "";
            String termsVersion = String.valueOf(body.getOrDefault("termsVersion", "1.0"));

            jdbc.update("""
                INSERT INTO wxtra_users (google_id, email, display_name, avatar_url, terms_accepted, terms_version)
                VALUES (?, ?, ?, ?, TRUE, ?)
                ON CONFLICT (google_id) DO UPDATE SET
                    email = EXCLUDED.email,
                    display_name = EXCLUDED.display_name,
                    avatar_url = EXCLUDED.avatar_url,
                    terms_accepted = TRUE,
                    terms_version = EXCLUDED.terms_version,
                    updated_at = NOW()
                """, googleId, email, name, picture, termsVersion);

            String username = jdbc.queryForObject(
                    "SELECT username FROM wxtra_users WHERE google_id = ?", String.class, googleId);
            return ResponseEntity.ok(Map.of(
                    "ok", true,
                    "googleId", googleId,
                    "email", email == null ? "" : email,
                    "name", name,
                    "username", username == null ? "wextra" : username,
                    "picture", picture,
                    "termsAccepted", true,
                    "termsVersion", termsVersion
            ));
        } catch (Exception e) {
            return ResponseEntity.status(401).body(Map.of("ok", false, "error", "Google kimlik doğrulaması başarısız"));
        }
    }
}
