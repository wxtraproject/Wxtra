package com.wextra.api;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.file.Path;

@RestController
@RequestMapping("/api/images/file")
public class ImageFileController {
    @Value("${wxtra.storage.images:/opt/wxtra/storage/images}")
    private String imageDir;

    @GetMapping("/{filename:.+}")
    public ResponseEntity<Resource> file(@PathVariable String filename) {
        if (filename.contains("..") || filename.contains("/") || filename.contains("\\")) return ResponseEntity.badRequest().build();
        Path path = Path.of(imageDir).resolve(filename).normalize();
        Path root = Path.of(imageDir).toAbsolutePath().normalize();
        if (!path.toAbsolutePath().startsWith(root)) return ResponseEntity.badRequest().build();
        FileSystemResource resource = new FileSystemResource(path);
        if (!resource.exists() || !resource.isReadable()) return ResponseEntity.notFound().build();
        MediaType type = MediaType.IMAGE_JPEG;
        String lower = filename.toLowerCase();
        if (lower.endsWith(".png")) type = MediaType.IMAGE_PNG;
        else if (lower.endsWith(".webp")) type = MediaType.parseMediaType("image/webp");
        return ResponseEntity.ok().contentType(type).body(resource);
    }
}
