package com.wextra.api;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/** Protects write operations exposed by the admin panel. */
@Component
public class AdminSecurityFilter extends OncePerRequestFilter {
    @Value("${wxtra.admin.token:}")
    private String adminToken;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        String path = request.getRequestURI();
        boolean protectedWrite = ("POST".equalsIgnoreCase(request.getMethod()) && (path.equals("/api/images/upload") || path.equals("/api/categories")))
                || ("DELETE".equalsIgnoreCase(request.getMethod()) && (path.startsWith("/api/images/") || path.startsWith("/api/categories/")));

        if (!protectedWrite) {
            filterChain.doFilter(request, response);
            return;
        }

        String supplied = request.getHeader("X-WXTRA-ADMIN");
        if (adminToken.isBlank() || supplied == null || !adminToken.equals(supplied)) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write("{\"ok\":false,\"error\":\"admin authorization required\"}");
            return;
        }

        filterChain.doFilter(request, response);
    }
}
