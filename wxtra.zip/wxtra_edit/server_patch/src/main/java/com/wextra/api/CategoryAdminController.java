package com.wextra.api;

import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/categories")
public class CategoryAdminController {
    private final JdbcTemplate jdbc;
    public CategoryAdminController(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @PostMapping
    public ResponseEntity<?> add(@RequestBody Map<String, String> body) {
        String name = body.getOrDefault("name", "").trim();
        String slug = body.getOrDefault("slug", "").trim().toLowerCase();
        if (name.isBlank() || slug.isBlank()) return ResponseEntity.badRequest().body(Map.of("ok", false, "error", "name and slug required"));
        try {
            Long id = jdbc.queryForObject("INSERT INTO wxtra_categories (name, slug) VALUES (?, ?) RETURNING id", Long.class, name, slug);
            return ResponseEntity.ok(Map.of("ok", true, "id", id, "name", name, "slug", slug));
        } catch (Exception e) {
            return ResponseEntity.status(409).body(Map.of("ok", false, "error", "category already exists or cannot be created"));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable long id) {
        Integer count = jdbc.queryForObject("SELECT COUNT(*) FROM wxtra_images WHERE category_id = ?", Integer.class, id);
        if (count != null && count > 0) return ResponseEntity.status(409).body(Map.of("ok", false, "error", "category contains " + count + " image(s)"));
        int deleted = jdbc.update("DELETE FROM wxtra_categories WHERE id = ?", id);
        if (deleted == 0) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(Map.of("ok", true, "id", id));
    }
}
