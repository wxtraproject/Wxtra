CREATE TABLE IF NOT EXISTS wxtra_users (
    id BIGSERIAL PRIMARY KEY,
    google_id VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(320),
    username VARCHAR(80) NOT NULL DEFAULT 'wextra',
    display_name VARCHAR(160),
    avatar_url TEXT,
    terms_accepted BOOLEAN NOT NULL DEFAULT FALSE,
    terms_version VARCHAR(32),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
