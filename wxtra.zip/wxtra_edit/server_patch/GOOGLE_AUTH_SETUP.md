# WXTRA Google Girişi

Bu patch, Android Credential Manager + Sign in with Google akışını ve sunucu tarafında Google ID token doğrulamasını ekler. Google güncel Android dokümantasyonunda Credential Manager kullanımını öneriyor; eski GoogleSignInClient API leri deprecated durumdadır.

## Google Cloud
1. OAuth consent screen i tamamla.
2. Android OAuth client oluştur: paket adı `com.wextra.app`, uygulamanın SHA-1 imzası.
3. Web application OAuth client oluştur ve Web Client ID değerini al.
4. Android kodundaki `WXTRA_GOOGLE_WEB_CLIENT_ID` değerine Web Client ID yi yaz.
5. Sunucuda `wxtra.google.web-client-id` aynı Web Client ID olmalı.

## Koşullar
Uygulama Google butonunu ancak Kullanım Koşulları kabul edilmişse etkinleştirir. Sunucu da `termsAccepted=true` kontrolü yapar ve sürümü `wxtra_users.terms_version` alanında saklar.

## Kurulum
`install_admin_security.sh` mevcut admin kurulumu ile birlikte Google controller ı, kullanıcı tablosunu ve Maven bağımlılıklarını ekler; ardından Maven build ve systemd restart yapar.
