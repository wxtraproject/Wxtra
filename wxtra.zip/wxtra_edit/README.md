# WXTRA

WXTRA Android wallpaper application with server-first content delivery.

## Sunucu tabanlı içerik

- Duvar kâğıtları sunucudan okunur.
- Kategoriler sunucudan okunur.
- Uygulama açılışta ve yaklaşık 5 dakikada bir katalog yeniler.
- Yeni görseller ve kategoriler için yeniden APK gerekmez.
- Admin yüklemelerinde tekli ve toplu seçim desteklenir.
- Görsel başlığı dosya adından otomatik üretilir; `_` ve `-` boşluğa çevrilir.
- Admin paneli Profil > Ayarlar > Yönetici Paneli içindedir.

## İlk admin girişi

Kullanıcı adı: `admin`
Şifre: `WXTRA@2026`

## Ubuntu sunucu

`server_patch/install_admin_security.sh` script'i mevcut Spring Boot API'ye admin yazma güvenliği, görsel servis endpoint'i ve 50 MB multipart limitini ekler.

Üretimde HTTP yerine HTTPS + reverse proxy ve sunucu taraflı kimlik doğrulama önerilir.
