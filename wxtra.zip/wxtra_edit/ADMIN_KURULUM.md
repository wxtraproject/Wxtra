# WXTRA Admin Panel — Tek Paket Kurulum

Bu paket Android uygulamasındaki gizli Admin Paneli ile mevcut Spring Boot API'nin admin yazma işlemlerini birlikte içerir.

## Android

1. Bu ZIP'i Android Studio'da açın.
2. Uygulamayı derleyin.
3. Profil ekranına girin.
4. Profil fotoğrafına 7 kez kısa aralıklarla dokunun.
5. PIN: `583921`

Panelden:
- görsel seçme
- kategori seçme
- başlık / açıklama / etiket girme
- sunucudan görselleri yenileme
- görsel silme
- görsel yükleme

## Ubuntu sunucu güvenliği

`server_patch/install_admin_security.sh` dosyasını sunucuya kopyaladıktan sonra çalıştırın. Script mevcut server projesine admin filtresini ekler, token ayarını yazar, Maven ile yeniden paketler ve servisi yeniden başlatır.

Sunucunun mevcut yolu:
`/opt/wxtra/wxtra_work/server`

Admin yazma tokenı:
`WXTRA_ADMIN_2026_583921`

Android panel aynı header'ı gönderir: `X-WXTRA-ADMIN`.

Not: Şu an API HTTP (`:8080`) üzerinden çalışıyor. İnternete açık üretim kullanımı için HTTPS + ters proxy ve daha güçlü kullanıcı/rol tabanlı kimlik doğrulama ayrıca yapılmalıdır.
