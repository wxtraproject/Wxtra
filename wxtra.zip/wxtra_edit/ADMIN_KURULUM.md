# WXTRA Admin Panel — Güvenli ve işlevsel sürüm

Bu paket mobil uygulamadaki Admin Paneli ile mevcut Spring Boot API/sunucu sistemini birlikte kullanır.

## Admin
- Kullanıcı adı + şifre sunucudan doğrulanır.
- Varsayılan hesap: `admin / WXTRA@2026`
- Ayarlar → Admin üzerinden açılır.

## Görsel yönetimi
- Toplu JPG/PNG/WebP seçimi ve yükleme
- Başlığın dosya adından otomatik alınması
- Kategori seçimi
- Açıklama ve etiket
- Sunucudan yenileme
- Görsel önizleme ve silme
- Yeni kategori ekleme
- Kategori düzenleme
- Kategori silme (içinde görsel varsa sunucu reddeder)

## Sunucu kurulumu
`server_patch/install_admin_security.sh` dosyasını sunucuya kopyalayıp çalıştırın:

```bash
chmod +x install_admin_security.sh
sudo ./install_admin_security.sh
```

Script, mevcut API'yi Maven ile derler ve `wxtra-api` servisini yeniden başlatır. Mevcut `ApiController` içindeki görsel dosya endpointine çakışan ikinci bir mapping eklemez.

**Not:** Üretimde HTTP yerine HTTPS kullanılması önerilir.
