# WXTRA Admin Panel – Visual Design

Bu görsel, mobil admin panelinin WXTRA logosundaki beyaz/lila/mor renk paletine göre hazırlanmış tasarım referansıdır.

- Koyu WXTRA arka plan
- Beyaz/lila/mor ana vurgu renkleri
- Mobil uyumlu kart yapısı
- Toplu görsel yükleme için ayrı alan
- Görsel ve kategori yönetimi odaklı yapı

Bu aşamada yalnızca görsel tasarım referansı olarak eklenmiştir; mevcut çalışan işlevler değiştirilmemiştir.
