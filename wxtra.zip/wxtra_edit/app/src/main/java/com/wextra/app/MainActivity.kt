package com.wextra.app

import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.content.ContentResolver
import android.provider.OpenableColumns
import android.net.Uri
import android.graphics.drawable.BitmapDrawable
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import java.util.Calendar
import java.net.HttpURLConnection
import java.net.URL
import java.io.BufferedInputStream
import java.io.DataOutputStream
import java.io.IOException
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.CustomCredential
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import java.security.SecureRandom
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val defaultBg = Color(0xFFF7F5FF)
private val defaultCard = Color(0xF8FFFFFF)
private val defaultCard2 = Color(0xF1F0EDFF)
private val defaultPurple = Color(0xFF7B3FF2)
private val defaultBlue = Color(0xFF6D74FF)
private var Bg by mutableStateOf(defaultBg)
private var Card by mutableStateOf(defaultCard)
private var Card2 by mutableStateOf(defaultCard2)
private var Purple by mutableStateOf(defaultPurple)
private var Blue by mutableStateOf(defaultBlue)
private var TextMain by mutableStateOf(Color(0xFF171326))
private var TextMuted by mutableStateOf(Color(0xFF706A82))
private var Accent by mutableStateOf(Brush.horizontalGradient(listOf(Color(0xFFB98BFF), Color(0xFF7B3FF2), Color(0xFFE2D5FF))))
private var appBackgroundBrush by mutableStateOf<Brush?>(null)
private var layoutMode by mutableStateOf(0)
private var appLanguage by mutableStateOf("tr")
private fun L(tr: String, en: String): String = when (appLanguage) {
    "en" -> en
    "zh" -> T(tr)
    else -> tr
}
private fun T(text: String): String {
    if (appLanguage == "tr") return text

    // Dynamic strings are translated here instead of being evaluated while the
    // top-level translation tables are initialized. This keeps the build safe
    // and makes values such as usernames/counts language-aware on every screen.
    if (appLanguage == "en") {
        when {
            text.startsWith("Bağlı hesap: ") -> return "Connected account: " + text.removePrefix("Bağlı hesap: ")
            text.startsWith("WXTRA seçkisi • Duvar kâğıdı ") -> {
                val number = text.removePrefix("WXTRA seçkisi • Duvar kâğıdı ").substringBefore(".")
                return "WXTRA selection • Wallpaper $number. Add this image to favorites or apply it to your home/lock screen."
            }
            text.matches(Regex("(\\d+) favori • Profil ayarları • (\\d+) son görüntülenen")) -> {
                val m = Regex("(\\d+) favori • Profil ayarları • (\\d+) son görüntülenen").matchEntire(text) ?: return text
                return "${m.groupValues[1]} favorites • Profile settings • ${m.groupValues[2]} recently viewed"
            }
            text.startsWith("Önbellek temizlendi • ") -> return text.replace("Önbellek temizlendi • ", "Cache cleared • ")
            text.startsWith("@") -> return text
        }
    } else {
        when {
            text.startsWith("Bağlı hesap: ") -> return "已连接账户：" + text.removePrefix("Bağlı hesap: ")
            text.startsWith("WXTRA seçkisi • Duvar kâğıdı ") -> {
                val number = text.removePrefix("WXTRA seçkisi • Duvar kâğıdı ").substringBefore(".")
                return "WXTRA 精选 • 壁纸 $number。可将此图片加入收藏，或应用到主屏幕/锁屏。"
            }
            text.matches(Regex("(\\d+) favori • Profil ayarları • (\\d+) son görüntülenen")) -> {
                val m = Regex("(\\d+) favori • Profil ayarları • (\\d+) son görüntülenen").matchEntire(text) ?: return text
                return "${m.groupValues[1]} 个收藏 • 资料设置 • ${m.groupValues[2]} 个最近浏览"
            }
            text.startsWith("Önbellek temizlendi • ") -> return text.replace("Önbellek temizlendi • ", "缓存已清除 • ")
            text.startsWith("@") -> return text
        }
    }

    return if (appLanguage == "en") mapOf(
    "GÜNÜN ÖNERİSİ" to "TODAY'S PICK", "Geceye Farklı Bak" to "See the Night Differently",
    "Her duvar, başka bir sen." to "Every wall, a different you.", "Keşfet" to "Explore",
    "Keşfet  →" to "Explore  →", "Duvar kâğıdı ara..." to "Search wallpapers...",
    "Duvar kağıdı ara…" to "Search wallpapers…", "WXTRA İLE" to "WITH WXTRA",
    "Daha Fazlasını Hisset" to "Feel More", "Senin tarzın. Senin duvarın. Senin hikayen." to "Your style. Your wall. Your story.",
    "Sıradan duvar kâğıtlarının ötesine geç." to "Go beyond ordinary wallpapers.",
    "YENİ UFUKLAR" to "NEW HORIZONS", "Farklı Dünyaları Keşfet" to "Explore Different Worlds",
    "Her ekran, yeni bir hikâye." to "Every screen, a new story.", "Keşfetmeye Başla →" to "Start Exploring →",
    "Bu Haftanın Özel Seçkisi" to "This Week's Special Picks", "WXTRA ekibinin seçtiği favoriler." to "Favorites selected by the WXTRA team.",
    "Henüz favorin yok" to "No favorites yet", "Beğendiğin duvar kâğıtları burada görünecek." to "Wallpapers you like will appear here.",
    "Sizin için özel seçildi." to "Selected especially for you.", "Özel seçki" to "Special pick",
    "Sonuç bulunamadı." to "No results found.", "WXTRA'ya hoş geldin!" to "Welcome to WXTRA!",
    "Yeni duvar kâğıtları ve koleksiyonlar burada görünecek." to "New wallpapers and collections will appear here.",
    "Sıradan duvar kâğıtlarına veda." to "Say goodbye to ordinary wallpapers.",
    "Her gün yeni bir hikâye. WXTRA, telefonunu kişiselleştirmek için seçilmiş duvar kâğıtlarını tek yerde sunar." to "A new story every day. WXTRA brings selected wallpapers together to personalize your phone.",
    "Duvar Kâğıdını Nereye Uygula?" to "Where should the wallpaper be applied?",
    "İki ekrana birden otomatik uygulanmayacak. Bir seçenek seç:" to "It will not be applied to both screens automatically. Choose one:",
    "Ana ekran" to "Home screen", "Kilit ekranı" to "Lock screen", "Ana ekran + Kilit ekranı" to "Home screen + Lock screen",
    "Güzel duvar kâğıtları, daha güzel hikâyeler." to "Beautiful wallpapers, better stories.",
    "Daha fazla özellik, daha fazla özgürlük." to "More features, more freedom.", "Yakında  ›" to "Coming soon  ›",
    "🔥  Popüler Şu An" to "🔥  Trending Now", "🔥 Popüler Şu An" to "🔥 Trending Now",
    "✨  Senin Ruh Hâlin" to "✨  Your Mood", "🎨  Senin İçin Seçtiklerimiz" to "🎨  Selected For You",
    "📈 Yükselenler" to "📈 Rising", "🎨 Tarzına Göre" to "🎨 By Style", "👑 Haftanın Seçimleri" to "👑 Weekly Picks",
    "👤 Senin İçin" to "👤 For You", "Tümünü Gör" to "See All",
    "Doğa" to "Nature", "Anime" to "Anime", "Arabalar" to "Cars", "Uzay" to "Space",
    "Sakin" to "Calm", "Enerjik" to "Energetic", "Melankolik" to "Melancholic", "Odak" to "Focus", "Mutlu" to "Happy",
    "Renkli Kuş" to "Colorful Bird", "Kırmızı Dokunuş" to "Crimson Touch", "Saklı Bahçe" to "Hidden Garden",
    "Pembe Efsane" to "Pink Legend", "Gece Sürüşü" to "Night Drive", "Doğanın İçinde" to "Into Nature",
    "Zarif Dokunuş" to "Elegant Touch", "Akış" to "Flow", "Renkli Akşamlar" to "Colorful Evenings",
    "Şehir" to "City", "Gece" to "Night", "Minimal" to "Minimal", "Sanat" to "Art", "Karanlık" to "Dark", "Renkli" to "Colorful",
    "Koleksiyonlarım" to "My Collections", "4K Ultra HD" to "4K Ultra HD", "Etkileyici Manzaralar" to "Stunning Landscapes",
    "Karanlık Mod" to "Dark Mode", "Anime Dünyası" to "Anime World", "WXTRA Hakkında" to "About WXTRA",
    "Profilim" to "My Profile", "Favorilerim" to "My Favorites", "Ayarlar" to "Settings", "Bildirimler" to "Notifications",
    "Tema Arka Planı" to "Theme Background", "Tema Yazı Rengi" to "Theme Text Color", "Tema Dizilimi" to "Theme Layout",
    "GÖRÜNÜM" to "APPEARANCE", "BİLDİRİMLER" to "NOTIFICATIONS", "UYGULAMA" to "APP", "DESTEK" to "SUPPORT", "HAKKIMDA" to "ABOUT",
    "Önbellek" to "Cache", "Temizle" to "Clear", "Ayarları varsayılana döndür" to "Reset settings to default",
    "Sıfırla" to "Reset", "Sorun bildir" to "Report a problem", "Bize ulaş" to "Contact us",
    "Gizlilik politikası" to "Privacy Policy", "Kullanım koşulları" to "Terms of Use", "Sürüm bilgisi" to "Version info",
    "WXTRA hakkında" to "About WXTRA", "Sürüm ve bilgiler" to "Version and information", "Veri ve gizlilik" to "Data and privacy",
    "Kurallar" to "Rules", "Dil" to "Language", "Türkçe" to "Turkish", "İngilizce" to "English",
    "Uygulama bildirimleri" to "App notifications", "Günlük öneri bildirimi" to "Daily wallpaper notification",
    "Kişiselleştirilmiş öneriler" to "Personalized recommendations", "Yeni duvar kâğıdı" to "New wallpaper",
    "Bize yardımcı ol" to "Help us improve", "WXTRA destek" to "WXTRA support", "Sürüm 0.1.0" to "Version 0.1.0",
    "Sıradan duvar kâğıtlarına veda." to "Say goodbye to ordinary wallpapers.",

    "Ad" to "Name", "Kullanıcı adı" to "Username", "Beğeni" to "Likes", "Koleksiyon" to "Collections", "Takipçi" to "Followers", "Takip" to "Following",
    "Favorilerim" to "My Favorites", "Koleksiyonlarım" to "My Collections", "Oluşturduklarım" to "Created", "Son Görüntülenenler" to "Recently viewed",
    "Veri ve Yedekleme" to "Data & Backup", "Hesabımı Yedekle" to "Back up my data", "Yedekten Geri Yükle" to "Restore from backup", "Profili Sıfırla" to "Reset profile",
    "Yedeklendi ✓" to "Backed up ✓", "Geri Yüklendi ✓" to "Restored ✓", "Yedekleme" to "Backup",
    "WXTRA Hakkında" to "About WXTRA",
    "Profili düzenle" to "Edit profile", "Kaydet" to "Save", "İptal" to "Cancel",
    "Profil fotoğrafını seç" to "Choose profile photo", "Hesabına giriş yap" to "Sign in to your account",
    "Hesabını bağla ve favorilerini senkronize et." to "Connect your account and sync your favorites.",
    "G  Google ile devam et" to "G  Continue with Google", "E-posta ile devam et" to "Continue with email",
    "Vazgeç" to "Cancel", "E-posta hesabı" to "Email account", "E-posta" to "Email",
    "Şifre" to "Password", "Giriş Yap" to "Sign in", "Kayıt Ol" to "Sign up",
    "Profilim" to "My Profile", "Beğeni" to "Likes", "Koleksiyon" to "Collections", "Takipçi" to "Followers", "Takip" to "Following",
    "Güzel duvar kâğıtları, daha güzel hikâyeler." to "Beautiful wallpapers, better stories.",
    "Hesap İşlemleri" to "Account", "Google ile Giriş Yap" to "Sign in with Google", "Hesabını bağla" to "Connect your account",
    "E-posta ile Giriş Yap / Kayıt Ol" to "Sign in / Sign up with email", "Kendi hesabını oluştur" to "Create your own account",
    "Hesap Bağlı" to "Account connected", "Hesabın bu cihazda aktif" to "Your account is active on this device",
    "Hesap Bilgilerini Düzenle" to "Edit account details", "Adını ve kullanıcı adını değiştir" to "Change your name and username",
    "Veri ve Yedekleme" to "Data & Backup", "Hesabımı Yedekle" to "Back up my account", "Yedeklendi ✓" to "Backed up ✓",
    "Geri Yükle" to "Restore", "Yedekten Geri Yükle" to "Restore from backup", "Geri Yüklendi ✓" to "Restored ✓",
    "Profili Sıfırla" to "Reset profile", "Diğer İşlemler" to "Other", "Bildirim ve Uygulama Ayarları" to "Notifications & App Settings",
    "Görünüm ve kişiselleştirme" to "Appearance and personalization", "Yardım ve Destek" to "Help & Support",
    "WXTRA kullanımı hakkında" to "About using WXTRA", "Çıkış Yap" to "Sign out", "Hesaptan çıkış yap" to "Sign out of your account",
    "Oluşturduklarım" to "Created", "Son Görüntülenenler" to "Recently viewed", "Hesabını bağla" to "Connect account",
    "Duvar kâğıdı ara..." to "Search wallpapers...", "Notifications" to "Notifications",
    "Bugün" to "Today", "Senin Ruh Hâlin" to "Your Mood",
    "Günün Önerisi" to "Today's Pick", "Her duvar, başka bir sen." to "Every wall, a different you.",
    "Arama" to "Search",

    "Her zevke, her ruh hâline uygun binlerce duvar kâğıdı seni bekliyor." to "Thousands of wallpapers for every taste and mood are waiting for you.",
    "Editörün Seçimi" to "Editor's Choice", "Doğanın Büyüsü" to "Magic of Nature",
    "Nefes kesen manzaralarla kendini yeniden keşfet." to "Rediscover yourself with breathtaking landscapes.",
    "Tüm Kategoriler" to "All Categories", "duvar kâğıdı" to "wallpapers",
    "Premium Kategoriler" to "Premium Categories", "Favori Kategoriler" to "Favorite Categories",
    "Özel ve eşsiz 4K+ koleksiyonlar." to "Exclusive 4K+ collections.",
    "En çok sevilenleri keşfet." to "Discover the most loved.",
    "DISCOVER MORE" to "DISCOVER MORE",
    "Soyut" to "Abstract", "Retro" to "Retro",
    "Atla" to "Skip", "Hemen Başla  →" to "Get Started  →", "Güzellik Her Yerde" to "Beauty Everywhere",
    "DUVAR KÂĞITLARI" to "WALLPAPERS", "DAHA FAZLASINI KEŞFET" to "DISCOVER MORE", "Ruh Hâli" to "Mood",
    "Nasıl hissediyorsan\nona uygun dünyayı keşfet." to "Explore a world that matches your mood.",
    "Ruh Hâlini Seç  →" to "Choose Your Mood  →", "Günün Koleksiyonu" to "Today's Collection",
    "Özenle seçilmiş\nözel duvar kâğıtları." to "Carefully selected wallpapers.", "Koleksiyona Git  →" to "Go to Collection  →",
    "Premium İçerikleri Keşfet" to "Explore Premium Content", "Özel koleksiyonlar, 4K içerikler ve daha fazlası…" to "Exclusive collections, 4K content and more…",
    "Daha Fazla  →" to "More  →", "En Yeni Duvar Kâğıtları" to "Newest Wallpapers", "Ruh Hâline Göre" to "By Mood",
    "Hızlı İşlemler" to "Quick Actions", "Cihaz ve Veri Yönetimi" to "Device & Data", "Güvenlik ve Gizlilik" to "Security & Privacy",
    "Bildirimler ve İzinler" to "Notifications & Permissions", "Hesap Yönetimi" to "Account Management", "Uygulama ve Destek" to "App & Support",
    "Gizlilik Politikası" to "Privacy Policy", "Kullanım Koşulları" to "Terms of Use", "Sürüm Bilgisi" to "Version Info",
    "Verilerin senin kontrolünde" to "Your data is in your control", "WXTRA'da veri ve gizlilik" to "Data and privacy at WXTRA",
    "Saygı, Güven, Daha Güzel Bir Dünya" to "Respect, Trust, A Better World", "Kurallarımız, daha güzel bir deneyim için" to "Our rules are here for a better experience",

    "WXTRA'ya Hoş Geldin" to "Welcome to WXTRA",
    "Dünyayı Renklendir, Senin Tarzınla" to "Color the World, Your Way",
    "Binlerce eşsiz duvar kâğıdı ile her gün yeni bir ilham." to "A new inspiration every day with thousands of unique wallpapers.",
    "Eşsiz Duvar Kâğıtları Dünyası" to "A World of Unique Wallpapers",
    "Her zevke uygun içerikler" to "Content for every taste",
    "Doğadan sanata, minimalden uzaya kadar yüksek kaliteli koleksiyonları keşfet." to "Discover high-quality collections from nature and art to minimal and space.",
    "Kategorilerle Kolay Keşfet" to "Explore Easily with Categories",
    "İstediğin tarzı kolayca bul" to "Find the style you want easily",
    "Doğa, şehir, uzay, anime, minimal ve daha fazlası tek yerde." to "Nature, city, space, anime, minimal and more in one place.",
    "Kişiselleştir" to "Personalize",
    "Kendi koleksiyonunu oluştur" to "Create your own collection",
    "Favorilerini kaydet, koleksiyonlarını oluştur ve deneyimini kendine göre şekillendir." to "Save favorites, create collections and shape your experience your way.",
    "Keşfet ve İlham Al" to "Explore and Get Inspired",
    "Dünyayı Renklendir" to "Color the World",
    "Güzellik her yerde. Şimdi kendi tarzını WXTRA ile yansıt." to "Beauty is everywhere. Express your style with WXTRA.",
    "Sağa kaydırarak devam et" to "Swipe right to continue",
    "Favorilerini Kaydet" to "Save Your Favorites",
    "Koleksiyonlarını Oluştur" to "Create Your Collections",
    "Kendine göre keşfet" to "Explore Your Way",
    "Duvar kâğıtlarını keşfet." to "Explore wallpapers.",
    "Senin İçin" to "For You",
    "Popüler" to "Popular",
    "Sınırların Ötesinde" to "Beyond the Limits",
    "Şimdi Keşfet" to "Explore Now",
    "🌿 Doğa" to "🌿 Nature",
    "🏙 Şehir" to "🏙 City",
    "🚗 Araçlar" to "🚗 Vehicles",
    "◑ Karanlık" to "◑ Dark",
    "Araçlar" to "Vehicles",
    "📁  Kategorilerde Keşfet" to "📁  Explore by Category",
    "Kategorilerde Keşfet" to "Explore by Category",
    "Canlı Duvarlar" to "Live Wallpapers",
    "Çift Ekran" to "Dual Screen",
    "🕘  En Yeni Duvar Kâğıtları" to "🕘  Newest Wallpapers",
    "❤️  Ruh Hâline Göre" to "❤️  By Mood",
    "Beğen" to "Like",
    "Görüntülenme" to "Views",
    "Daha fazlası seni bekliyor..." to "More is waiting for you...",
    "👑 Günün Seçimi" to "👑 Pick of the Day",
    "Özel olarak seçildi" to "Specially selected",
    "Doğanın en güzel tonları, şimdi ekranında." to "Nature's most beautiful tones, now on your screen.",
    "Duvar Kâğıdını Aç" to "Open Wallpaper",
    "❤️ Senin İçin" to "❤️ For You",
    "Beğenilerine göre" to "Based on your likes",
    "En çok beğenilenler" to "Most liked",
    "📈 Yükselişte" to "📈 Rising",
    "Son günlerde hızla popüler" to "Rapidly popular recently",
    "👑 Haftanın Koleksiyonu" to "👑 Collection of the Week",
    "Özel seçilmiş 24 duvar kâğıdı" to "24 specially selected wallpapers",
    "Koleksiyonu Keşfet" to "Explore Collection",
    "🎲 Rastgele Keşfet" to "🎲 Random Explore",
    "Her açılışta yeni bir sürpriz" to "A new surprise every time you open it",
    "Karıştır" to "Shuffle",
    "En yeni içerikler" to "Newest content",
    "Kullanıcıların seçtikleri" to "Selected by users",
    "Bir kategori seç" to "Choose a category",
    "🎨 Renge Göre" to "🎨 By Color",
    "Ruhuna uygun rengi seç" to "Choose a color that matches your mood",
    "Kırmızı" to "Red",
    "Yeşil" to "Green",
    "📱 Cihazına Özel" to "📱 Made for Your Device",
    "Ekranına tam oturanlar" to "Fits your screen perfectly",
    "🗓️ Günlük Seri" to "🗓️ Daily Series",
    "Her gün yeni tema" to "A new theme every day",
    "Çar · Doğa" to "Wed · Nature",
    "Paz · Özel" to "Sun · Special",
    "👀 Son Görüntülediklerin" to "👀 Recently Viewed",
    "Kaldığın yerden devam et" to "Continue where you left off",
    "Sonsuz Keşif" to "Endless Exploration",
    "Aşağı indikçe daha fazlası gelir." to "More appears as you scroll.",
    "Profilini görmek, favorilerini ve koleksiyonlarını kaydetmek için Google hesabınla devam et." to "Continue with your Google account to view your profile and save favorites and collections.",
    "Sadece bir dokunuş yeter • Profilin bu cihazda korunur" to "Just one tap • Your profile is kept on this device",
    "Google hesabı" to "Google account",
    "Hesap bağlantısı" to "Account connection",
    "Profilini ve favorilerini bu cihazda yönetebilirsin. Google hesabı bağlantısı bu sürümde yerel profil oturumu olarak tutulur." to "You can manage your profile and favorites on this device. Google account connection is kept as a local profile session in this version.",
    "Profil bilgilerin, favorilerin ve uygulama tercihlerin için yerel yedek oluşturabilirsin." to "You can create a local backup of your profile, favorites and app preferences.",
    "Verilerini güvenle yedekle" to "Back up your data safely",
    "Cihazdaki alanı görüntüle" to "View device storage",
    "Profil ve uygulama verilerini yönet" to "Manage profile and app data",
    "Yedekleme Ayarları" to "Backup Settings",
    "Otomatik yedekleme, sıklık ve geri yükleme seçenekleri" to "Automatic backup, frequency and restore options",
    "Güvenlik Merkezi" to "Security Center",
    "Hesabını ve verilerini koru" to "Protect your account and data",
    "Şifre ve Giriş" to "Password & Sign-in",
    "Hesap bağlantısını yönet" to "Manage account connection",
    "Gizlilik Ayarları" to "Privacy Settings",
    "Veri kullanımı ve gizlilik tercihleri" to "Data usage and privacy preferences",
    "Bildirim Ayarları" to "Notification Settings",
    "Hangi bildirimleri almak istediğini seç" to "Choose which notifications you want",
    "İzinleri Yönet" to "Manage Permissions",
    "Uygulama izinlerini kontrol et" to "Control app permissions",
    "Hesap Bilgileri" to "Account Information",
    "Ad, kullanıcı adı ve bağlantı" to "Name, username and connection",
    "Hesap Silme" to "Delete Account",
    "Tüm yerel profil verilerini sil" to "Delete all local profile data",
    "Yardım Merkezi" to "Help Center",
    "Sık sorulan sorular" to "Frequently asked questions",
    "Bizimle İletişime Geç" to "Contact Us",
    "Destek al, öneri gönder" to "Get support or send feedback",
    "Tema, dil ve genel ayarlar" to "Theme, language and general settings",
    "Hesabı Sil" to "Delete Account",
    "Tüm yerel profil verileri silinir" to "All local profile data will be deleted",
    "Ayarları varsayılana döndür" to "Reset settings to default",
    "Günlük yeni duvar kâğıdı" to "Daily new wallpaper",
    "Sorun Bildir" to "Report a Problem",
    "Bize yardımcı ol" to "Help us improve",
    "Bize Ulaş" to "Contact Us",
    "E-posta: destek@wxtra.app" to "Email: destek@wxtra.app",
    "Mesajında cihaz modelini ve uygulama sürümünü belirtmen sorunu daha hızlı çözmemize yardımcı olur." to "Including your device model and app version helps us solve the problem faster.",
    "Hesabını bağla ve favorilerini senkronize et." to "Connect your account and sync your favorites.",
    "E-posta hesabı" to "Email account",
    "Şifre" to "Password",
    "Giriş Yap" to "Sign In",
    "Kayıt Ol" to "Sign Up",
    "Hesap İşlemleri" to "Account Actions",
    "Google ile Giriş Yap" to "Sign in with Google",
    "E-posta ile Giriş Yap / Kayıt Ol" to "Sign in / Sign up with Email",
    "Kendi hesabını oluştur" to "Create your own account",
    "Hesabın bu cihazda aktif" to "Your account is active on this device",
    "Hesap Bilgilerini Düzenle" to "Edit Account Information",
    "Adını ve kullanıcı adını değiştir" to "Change your name and username",
    "Geri Yükle" to "Restore",
    "Diğer İşlemler" to "Other Actions",
    "WXTRA kullanımı hakkında" to "About using WXTRA",
    "Hesap Bağlı" to "Account Connected",
    "Profil Düzenle" to "Edit Profile",
    "Çince" to "Chinese",
    "Kullanıcı adı" to "Username",
    "Beğeni" to "Likes",
    "Takipçi" to "Followers",
    "Takip" to "Following",
    "Oluşturduklarım" to "Created",
    "Hesabımı Yedekle" to "Back up my data",
    "Yedekten Geri Yükle" to "Restore from backup",
    "Profili Sıfırla" to "Reset profile",
    "Geri Yüklendi ✓" to "Restored ✓",
    "Profil fotoğrafını seç" to "Choose profile photo",
    "Vazgeç" to "Cancel",
    "Sürüm ve bilgiler" to "Version and information",
    "Duvar kâğıdı ara…" to "Search wallpapers…",
    "Duvar kâğıdı ara..." to "Search wallpapers...",
    "Sağ..." to "",
    "WXTRA seçkisi  •  Telefonuna uygun" to "WXTRA selection • Made for your phone",
    "Duvar Kâğıdı Hazır ✓" to "Wallpaper Ready ✓",
    "Duvar Kâğıdı Yap" to "Set Wallpaper",
    "Neler sunuyor?" to "What it offers?",
    "WXTRA nedir?" to "What is WXTRA?",
    "WXTRA'nın amacı" to "WXTRA's purpose",
    "Zengin duvar kâğıdı koleksiyonu" to "Rich wallpaper collection",
    "Binlerce özel içerik" to "Thousands of exclusive items",
    "Her gün yeni içerik" to "New content every day",
    "Kullanıcı profili" to "User profile",
    "Sana özel deneyim" to "Personalized experience",
    "Hesap senkronizasyonu" to "Account synchronization",
    "Verilerin her zaman seninle" to "Your data stays with you",
    "Tarzını yansıt" to "Express your style",
    "Premium içerikler" to "Premium content",
    "Canlı duvar kâğıtları" to "Live wallpapers",
    "Yapay zekâ ile öneriler" to "AI-powered recommendations",
    "Topluluk ve paylaşım" to "Community and sharing",
    "Çoklu cihaz senkronizasyonu" to "Multi-device synchronization",
    "Daha fazla kişiselleştirme seçeneği" to "More personalization options",
    "Güzel bir duvar kâğıdı sadece bir görüntü değil, her gün yeniden başlayan bir ilhamdır." to "A beautiful wallpaper is more than an image; it is inspiration that starts anew every day.",
    "WXTRA tarafından sevgiyle geliştirildi." to "Made with love by WXTRA.",
    "Teşekkürler, sen bu yolculuğun bir parçasısın. 💜" to "Thank you, you are part of this journey. 💜",
    "Dünyayı Renklendir, Senin Tarzınla 💜" to "Color the World, Your Way 💜",
    "Duvar Kâğıtları" to "Wallpapers",
    "Güzellik Her Yerde" to "Beauty Everywhere",
    "Sürüm 1.0.0" to "Version 1.0.0",
        "Duvar Kâğıtları" to "Wallpapers", "Tüm hakları saklıdır." to "All rights reserved.", "Sürüm 1.0.0" to "Version 1.0.0",
    "Anasayfa" to "Home",
    "Kategori" to "Categories",
    "Profil" to "Profile",
    "Ara" to "Search",
    "Sınırları Kaldır  →" to "Remove Limits  →",
    "Günlük yeni duvar kâğıdı" to "Daily new wallpaper",
    "Aşağıdaki başlıklara dokunarak ayrıntıları görebilirsin." to "Tap the headings below to view details.",
    "VERİ GİZLİLİĞİ" to "DATA PRIVACY",
    "Son güncelleme: 8 Eylül 2026" to "Last updated: September 8, 2026",
    "KULLANIM KURALLARI" to "TERMS OF USE",
    "Aşağıdaki başlıklara dokunarak ayrıntıları açabilir ve WXTRA'yı kullanırken uyman gereken kuralları görebilirsin." to "Tap the headings below to view details and the rules you should follow when using WXTRA.",
    "Kullanım Koşulları" to "Terms of Use",
    "Hesap ve kullanıcı sorumlulukları" to "Account and User Responsibilities",
    "Duvar kâğıtlarının kullanımı" to "Wallpaper Usage",
    "Yasaklanan içerikler ve davranışlar" to "Prohibited Content and Conduct",
    "Telif hakları" to "Copyright",
    "Otomatik ve AI özelliklerinin kullanımı" to "Automated and AI Features",
    "Hesap güvenliği" to "Account Security",
    "İçerik ve hizmet sorumluluğu" to "Content and Service Responsibility",
    "Koşulların değiştirilmesi" to "Changes to the Terms",
    "Hesabın kapatılması" to "Account Closure",
    "İletişim ve destek" to "Contact and Support",
    "Hangi verileri topluyoruz?" to "What data do we collect?",
    "Verilerimi neden kullanıyoruz?" to "Why do we use my data?",
    "Hesap ve profil bilgilerim" to "My account and profile information",
    "Favoriler ve koleksiyonlar" to "Favorites and collections",
    "Veriler nerede saklanıyor?" to "Where is my data stored?",
    "Verilerimi kimler görebilir?" to "Who can see my data?",
    "Verilerimi nasıl silebilirim?" to "How can I delete my data?",
    "Güvenlik" to "Security",
    "Gizlilik talepleri ve iletişim" to "Privacy requests and contact",
    "Politika güncellemeleri" to "Policy updates",
    "WXTRA'nın mevcut sürümünde uygulama tercihleri, favoriler, son görüntülenenler ve profil bilgileri gibi uygulamayı çalıştırmak için gerekli veriler cihazın özel depolama alanında tutulabilir. Google ile giriş kullanıldığında, giriş sağlayıcısından hesabın çalışması için gerekli temel profil bilgileri alınabilir. Gereksiz hassas kişisel veriler özellikle talep edilmedikçe toplanmaz." to "In the current version of WXTRA, data needed to run the app, such as app preferences, favorites, recently viewed items and profile information, may be stored in the device's private app storage. When signing in with Google, basic profile information required for the account may be received from the identity provider. Unnecessary sensitive personal data is not collected unless specifically requested.",
    "Veriler; hesabını ve profilini yönetmek, favorilerini ve koleksiyonlarını korumak, uygulama ayarlarını hatırlamak, cihazlar arası senkronizasyonu desteklemek ve WXTRA deneyimini geliştirmek için kullanılabilir. Veriler yalnızca belirtilen amaçlar ve hizmetin çalışması için gerekli olduğu ölçüde işlenir." to "Data may be used to manage your account and profile, preserve favorites and collections, remember app settings, support synchronization between devices and improve the WXTRA experience. Data is processed only as necessary for the stated purposes and for the service to operate.",
    "Profilinde oluşturduğun ad, kullanıcı adı, profil fotoğrafı ve benzeri bilgiler kişiselleştirilmiş profil deneyimi için kullanılır. Profil bilgilerini uygulama içindeki Profilim bölümünden düzenleyebilirsin." to "Your name, username, profile photo and similar information are used to provide a personalized profile experience. You can edit profile information in the My Profile section.",
    "Favorilediğin duvar kâğıtları, koleksiyonların ve bazı kullanım tercihlerin hesabın veya cihazındaki WXTRA verileriyle ilişkilendirilebilir. Böylece uygulamayı kullandığında tercihlerin korunabilir." to "Your favorite wallpapers, collections and some usage preferences may be associated with your account or WXTRA data on your device so your preferences can be preserved.",
    "Yerel profil ve uygulama tercihleri mevcut sürümde Android'in uygulamaya özel depolama alanında tutulur. Sunucu tabanlı hesap senkronizasyonu kullanılan bölümlerde veriler, hizmetin çalışması için gerekli güvenlik ve erişim kontrolleri uygulanarak işlenir." to "Local profile and app preferences are stored in Android's app-specific storage in the current version. Where server-based account synchronization is used, data is processed with the security and access controls required for the service.",
    "Kişisel verilerin satılmaz veya iznin dışında reklam amacıyla paylaşılmaz. Hizmetin çalışması için gerekli üçüncü taraf hizmet sağlayıcıları kullanıldığında yalnızca gerekli kapsamda veri işlenebilir. Yasal bir zorunluluk olmadıkça verilerin yetkisiz kişilerle paylaşılması amaçlanmaz." to "Personal data is not sold or shared for advertising without your permission. When third-party providers are required for the service, data may be processed only to the necessary extent. Data is not intended to be shared with unauthorized people unless legally required.",
    "Profil ekranındaki hesap silme seçeneğini kullanarak cihazındaki WXTRA profil ve hesap verilerini kaldırmayı başlatabilirsin. Sunucularda tutulabilecek verilerin silinmesi için ayrıca destek ekibine talep iletilebilir. Yasal olarak saklanması gereken kayıtlar ilgili süre boyunca tutulabilir." to "You can start removing your WXTRA profile and account data from this device using the account deletion option on the profile screen. You may also contact support to request deletion of data that may be stored on servers. Records that must be retained by law may be kept for the required period.",
    "WXTRA, kişisel verileri yetkisiz erişim, kayıp veya kötüye kullanıma karşı korumak için uygun teknik ve idari önlemler kullanmayı amaçlar. Bununla birlikte internet üzerinden yapılan hiçbir veri aktarımının mutlak olarak risksiz olduğu garanti edilemez." to "WXTRA aims to use appropriate technical and administrative measures to protect personal data against unauthorized access, loss or misuse. However, no data transfer over the internet can be guaranteed to be completely risk-free.",
    "Verilerinle ilgili erişim, düzeltme, silme veya gizlilik soruların için WXTRA destek ekibine ulaşabilirsin. İletişim: destek@wxtra.app" to "For questions about accessing, correcting or deleting your data or about privacy, contact WXTRA support. Contact: destek@wxtra.app",
    "Bu Gizlilik Politikası, uygulamanın özellikleri veya veri işleme yöntemleri değiştikçe güncellenebilir. Önemli değişikliklerde kullanıcıların bilgilendirilmesi hedeflenir." to "This Privacy Policy may be updated as app features or data-processing methods change. Users will be informed of important changes.",
    "WXTRA uygulamasını indirerek, kullanarak veya hesap oluşturarak bu kullanım koşullarını kabul etmiş olursun. Bu koşullar; uygulamadaki özelliklerin, içeriklerin ve hesap hizmetlerinin kullanımına ilişkin temel kuralları açıklar. Koşulları kabul etmiyorsan WXTRA'yı kullanmamalısın." to "By downloading, using or creating an account in WXTRA, you agree to these Terms of Use. They explain the basic rules for using the app's features, content and account services. If you do not agree, you should not use WXTRA.",
    "Hesap bilgilerinin doğru ve güncel olmasından sen sorumlusun. Hesabının güvenliğini korumalı, giriş bilgilerini başkalarıyla paylaşmamalısın. Hesabın üzerinden gerçekleştirilen işlemlerden, yetkisiz kullanım fark ettiğinde WXTRA'ya bildirimde bulunman beklenir." to "You are responsible for keeping your account information accurate and current. Keep your account secure and do not share sign-in information. If you notice unauthorized use, you are expected to notify WXTRA.",
    "WXTRA'daki duvar kâğıtları yalnızca uygulamanın sunduğu kullanım izinleri kapsamında kullanılmalıdır. Bir görseli ticari amaçla yeniden satmak, başka bir içerik olarak dağıtmak veya hak sahibinin izni olmadan sahiplenmek uygun değildir. İndirme ve cihazda duvar kâğıdı olarak kullanma hakkı, görselin lisansına göre değişebilir." to "Wallpapers in WXTRA may be used only within the permissions provided by the app. Reselling an image commercially, redistributing it as other content or claiming ownership without the rights holder's permission is not permitted. Download and device-use rights may vary by image license.",
    "Favoriler ve koleksiyonlar, içerikleri kişisel kullanımın için düzenlemene yardımcı olur. Bu özellikleri kötüye kullanmamalı, başkalarının hesabına veya verilerine erişmeye çalışmamalısın." to "Favorites and collections help organize content for personal use. Do not misuse these features or attempt to access other people's accounts or data.",
    "Yasa dışı, tehdit edici, nefret veya taciz içeren, cinsel istismar içeren, çocukları tehlikeye atan, dolandırıcılığı teşvik eden ya da başkalarının haklarını ihlal eden içerik ve davranışlara izin verilmez. Uygulamanın güvenliğini bozacak, hizmeti aşırı yükleyecek veya yetkisiz erişim sağlamaya yönelik işlemler de yasaktır." to "Illegal, threatening, hateful or harassing content, sexual exploitation, content that endangers children, fraud promotion or violations of others' rights are not allowed. Actions that compromise app security, overload the service or attempt unauthorized access are also prohibited.",
    "WXTRA arayüzü, marka unsurları, uygulama tasarımı ve WXTRA tarafından oluşturulan içerikler ilgili fikri mülkiyet haklarıyla korunabilir. Üçüncü taraf görsellerin hakları ilgili sahiplerine aittir. Hak ihlali olduğunu düşündüğün bir içerik varsa kaldırma veya inceleme talebi için destek ekibine ulaşabilirsin." to "The WXTRA interface, branding, app design and content created by WXTRA may be protected by intellectual property rights. Rights to third-party images belong to their respective owners. If you believe content infringes rights, contact support to request removal or review.",
    "WXTRA'da gelecekte sunulabilecek otomatik veya yapay zekâ destekli özellikler yardımcı amaçlıdır. Bu özelliklerin ürettiği sonuçların her zaman hatasız, eksiksiz veya sana özel hukuki, finansal ya da profesyonel tavsiye niteliğinde olduğu garanti edilmez. Sonuçları kullanmadan önce uygunluğunu kontrol etmelisin." to "Automated or AI-assisted features that may be offered in the future are for assistance. Their results are not guaranteed to be error-free, complete or personalized legal, financial or professional advice. Check their suitability before relying on results.",
    "Hesabını korumak için cihazının ve Google hesabının güvenlik ayarlarını güncel tut. Şüpheli giriş veya hesap erişimi fark edersen mümkün olan en kısa sürede şifreni ve ilgili hesap güvenlik ayarlarını değiştir ve WXTRA desteğine başvur." to "Keep your device and Google account security settings up to date. If you notice suspicious sign-in or account access, change your password and relevant security settings as soon as possible and contact WXTRA support.",
    "WXTRA hizmeti geliştirilirken bazı özellikler değişebilir, geçici olarak kullanılamayabilir veya kaldırılabilir. Üçüncü taraf hizmetlerden kaynaklanan kesintiler de yaşanabilir. Hizmetin sürekliliği ve tüm içeriklerin her zaman erişilebilir olması garanti edilmez." to "Some features may change, become temporarily unavailable or be removed as WXTRA evolves. Third-party service interruptions may also occur. Continuous service and constant availability of all content are not guaranteed.",
    "WXTRA; yeni özellikler, güvenlik gereksinimleri veya yasal değişiklikler nedeniyle bu koşulları güncelleyebilir. Önemli değişiklikler olduğunda kullanıcıların uygun şekilde bilgilendirilmesi hedeflenir. Güncellenen koşulların yayınlanmasından sonra uygulamayı kullanmaya devam etmen, yürürlükteki koşulları kabul ettiğin anlamına gelebilir." to "WXTRA may update these terms because of new features, security requirements or legal changes. Users will be informed appropriately about important changes. Continuing to use the app after updated terms are published may mean you accept the current terms.",
    "Hesabını kapatmak veya silmek istediğinde uygulamadaki hesap yönetimi seçeneklerini kullanabilirsin. Kuralları ciddi biçimde ihlal eden hesaplarda, güvenliği korumak veya yasal yükümlülükleri yerine getirmek amacıyla erişim sınırlandırılabilir veya hesap kapatılabilir." to "Use the account-management options in the app to close or delete your account. Accounts that seriously violate the rules may be restricted or closed to protect security or meet legal obligations.",
    "Kullanım koşulları, içerik hakları veya hesabınla ilgili soruların için WXTRA destek ekibine ulaşabilirsin. İletişim: destek@wxtra.app. Bildiriminde mümkünse kullanıcı adını, uygulama sürümünü ve sorunun kısa açıklamasını belirt." to "For questions about these terms, content rights or your account, contact WXTRA support. Contact: destek@wxtra.app. If possible, include your username, app version and a short description of the issue.",
    "“Daha güzel bir deneyim, kurallara birlikte uymakla mümkün.”" to "A better experience is possible when we follow the rules together.",
    "Hemen Başla  →" to "Get Started  →",
    "WXTRA" to "WXTRA",
    "W" to "W",
    "Bildirimler" to "Notifications",
    "Ruh Hâli" to "Mood",
    "Günün Koleksiyonu" to "Today's Collection",
    "💎" to "💎",
    "Özel koleksiyonlar, 4K içerikler ve daha fazlası…" to "Exclusive collections, 4K content and more…",
    "›" to "›",
    "Keşfet" to "Explore",
    "Huzurun Adresi" to "Where Calm Lives",
    "Tümünü Gör  →" to "See All  →",
    "G" to "G",
    "Google ile devam et" to "Continue with Google",
    "Tamam" to "Done",
    "Kaydet" to "Save",
    "İptal" to "Cancel",
    "Bu sürümde yedek, uygulamanın özel depolama alanında tutulur. Gerçek bulut/Drive senkronizasyonu için ayrıca sunucu ve hesap yetkilendirmesi gerekir." to "In this version, backups are stored in the app's private storage. Real cloud/Drive synchronization requires a server and account authorization.",
    "Durum: Son yedek hazır ✓" to "Status: Latest backup ready ✓",
    "Durum: Henüz yedek oluşturulmadı" to "Status: No backup created yet",
    "Yedekleme ayarları" to "Backup settings",
    "Otomatik yedekleme" to "Automatic backup",
    "Otomatik yedekleme seçeneği sunucu senkronizasyonu etkin olduğunda kullanılabilir. Bu sürümde manuel yerel yedekleme güvenle çalışır." to "Automatic backup is available when server synchronization is enabled. Manual local backup works safely in this version.",
    "Yedeklenecekler: profil bilgileri, favoriler ve uygulama tercihleri." to "Backed up: profile information, favorites and app preferences.",
    "Güvenlik merkezi" to "Security center",
    "Profil ve uygulama tercihleri Android'in uygulamaya özel depolama alanında tutulur." to "Profile and app preferences are stored in Android's app-specific storage.",
    "WXTRA kişisel verileri satmayı veya iznin dışında reklam amacıyla paylaşmayı amaçlamaz. Hesap senkronizasyonu eklenirse yetkilendirme ve güvenlik kontrolleri ayrıca uygulanır." to "WXTRA does not intend to sell personal data or share it for advertising without permission. If account synchronization is added, authorization and security controls will also apply.",
    "Kapat" to "Close",
    "Depolama ve veriler" to "Storage and data",
    "Bu cihazdaki WXTRA verileri" to "WXTRA data on this device",
    "Duvar kâğıtlarını indirme alanı kullanılmaz; favoriler ve uygulama verileri yönetilir." to "No wallpaper download storage is used; favorites and app data are managed.",
    "WXTRA Pro" to "WXTRA Pro",
    "WXTRA Pro; daha fazla kişiselleştirme, premium içerikler ve gelişmiş özellikler için hazırlanan ayrı bir deneyimdir." to "WXTRA Pro is a separate experience designed for more personalization, premium content and advanced features.",
    "Hesabı sil" to "Delete account",
    "Bu işlem bu cihazdaki WXTRA profil bilgilerini, favorileri ve uygulama tercihlerini kaldırır. Devam etmek istiyor musun?" to "This will remove WXTRA profile information, favorites and app preferences from this device. Do you want to continue?",
    "Profil fotoğrafı" to "Profile photo",
    " ✓" to " ✓",
    "WXTRA Üyesi" to "WXTRA Member",
    "Favori" to "Favorite",
    "Koleksiyon" to "Collection",
    "Takipçi sistemi hesap altyapısıyla birlikte etkinleştirilecek." to "The follower system will be enabled with account infrastructure.",
    "Takip sistemi hesap altyapısıyla birlikte etkinleştirilecek." to "The following system will be enabled with account infrastructure.",
    "✦" to "✦",
    "Son Görüntülenenler" to "Recently Viewed",
    "Profili Düzenle" to "Edit Profile",
    "Cihaz ve Veri Yönetimi" to "Device & Data Management",
    "Depolama" to "Storage",
    "Hesap Yönetimi" to "Account Management",
    "Ayarlar" to "Settings",
    "Çıkış Yap" to "Sign Out",
    "Hesaptan çıkış yap" to "Sign out of your account",
    "WXTRA'ya hoş geldin!" to "Welcome to WXTRA!",
    "WXTRA'da veri ve gizlilik" to "Data and privacy at WXTRA",
    "Kurallarımız, daha güzel bir deneyim için" to "Our rules are here for a better experience",
    "— WXTRA" to "— WXTRA",
    "Sürüm Bilgisi" to "Version Info",
    "♥" to "♥",
    "© WXTRA" to "© WXTRA",
    "Tüm hakları saklıdır." to "All rights reserved.",
    "Yakında" to "Coming Soon",
    "Daha fazlası geliyor..." to "More is coming...",
    "“" to "“",
    "Kategoriler" to "Categories",
    "Doğanın Büyüsü" to "Magic of Nature",
    "duvar kâğıdı" to "wallpaper",
    "Favori Kategoriler" to "Favorite Categories",
    "Ayarlar varsayılana döndürüldü" to "Settings reset to default",
    "Dil Türkçe olarak ayarlandı" to "Language set to Turkish",
    "4'lü Dizilim" to "4 Columns",
    "3'lü Dizilim" to "3 Columns",
    "Popüler Şu An" to "Trending Now",
    "✨  Senin İçin Seçtiklerimiz" to "✨  Selected For You",
    "Senin İçin Seçtiklerimiz" to "Selected For You",
    "🏙️ Şehir" to "🏙️ City",
    "Görünüm Dizilimi" to "View Layout",
    "Öneriler" to "Recommendations",
    "Sürüm Numarası" to "Version Number",
    "Desteklenen Android Sürümleri" to "Supported Android Versions",
    "Android 8.0 ve üzeri" to "Android 8.0 and above",
    "Desteklenen MagicOS Sürümleri" to "Supported MagicOS Versions",
    "Android 8.0+ tabanlı MagicOS sürümleri" to "MagicOS versions based on Android 8.0+",
    "Geliştirici" to "Developer",
    "Kişiselleştirilmiş deneyim" to "Personalized experience",
    "Tümü" to "All",
    "▦  Tüm Kategoriler" to "▦  All Categories",
    "Sorun Bildir\n\nKarşılaştığın sorunu ve mümkünse ekran görüntüsünü WXTRA destek ekibine iletebilirsin.\n\ndestek@wxtra.app" to "Report a Problem\n\nYou can send the issue you encountered, and if possible a screenshot, to WXTRA support.\n\nsupport@wxtra.app",
    "Bize Ulaş\n\nE-posta: destek@wxtra.app\n\nMesajında cihaz modelini ve uygulama sürümünü belirtmen sorunu daha hızlı çözmemize yardımcı olur." to "Contact Us\n\nEmail: support@wxtra.app\n\nIncluding your device model and app version helps us solve the problem faster.",
    "WXTRA, tarzına uygun duvar kâğıtlarını keşfetmeni, favorilerini oluşturmanı ve kendi kişisel koleksiyonunu oluşturmanı sağlayan yeni nesil duvar kâğıdı deneyimidir. Güzelliği her yerde seninle buluşturur." to "WXTRA is a next-generation wallpaper experience that lets you discover wallpapers matching your style, create favorites and build personal collections. It brings beauty everywhere with you.",
    "Duvar kâğıdından fazlası. Telefonunun görünümünü kendi tarzına dönüştürmek; ilham veren, kaliteli ve özgün içerikleri tek bir yerde sunmak için geliştirildi." to "More than a wallpaper. It was created to transform your phone's look into your own style and bring inspiring, high-quality, original content together in one place.",
    "Daha Fazla Sen" to "More of You",
    "Profilini düzenle" to "Edit your profile",
    "Verilerim" to "My Data",
    "Motivasyon" to "Motivation",
    "Yeni" to "New",
    "Huzurun Adresi" to "A Place of Peace",
    "◐ Minimal" to "◐ Minimal",
    "🎮 Anime" to "🎮 Anime",
    "🪐 Uzay" to "🪐 Space",
    "🎨 Sanat" to "🎨 Art",
    "◑ Karanlık" to "◑ Dark",
    "Trend" to "Trending",
    "🔥 Trend" to "🔥 Trending",
    "✨ Minimal" to "✨ Minimal",
    "🌙 AMOLED" to "🌙 AMOLED",
    "🚗 Araba" to "🚗 Cars",
    "🌃 Gece" to "🌃 Night",
    "🏙️ Şehir" to "🏙️ City",
    "🤖 Anime" to "🤖 Anime",
    "✨ Yeni Gelenler" to "✨ New Arrivals",
    "👥 Topluluk Favorileri" to "👥 Community Favorites",
    "Mor" to "Purple",
    "Mavi" to "Blue",
    "Siyah" to "Black",
    "Beyaz" to "White",
    "Pzt · Minimal" to "Mon · Minimal",
    "Sal · AMOLED" to "Tue · AMOLED",
    "Per · Araba" to "Thu · Cars",
    "Cum · Uzay" to "Fri · Space",
    "Cmt · Anime" to "Sat · Anime",
).getOrDefault(text, text)
else mapOf(

    "WXTRA'ya Hoş Geldin" to "欢迎来到 WXTRA",
    "Dünyayı Renklendir, Senin Tarzınla" to "用你的风格点亮世界",
    "Binlerce eşsiz duvar kâğıdı ile her gün yeni bir ilham." to "数千张独特壁纸，每天带来新的灵感。",
    "Eşsiz Duvar Kâğıtları Dünyası" to "独特壁纸世界",
    "Her zevke uygun içerikler" to "适合各种喜好的内容",
    "Doğadan sanata, minimalden uzaya kadar yüksek kaliteli koleksiyonları keşfet." to "探索从自然、艺术、极简到太空的高品质合集。",
    "Kategorilerle Kolay Keşfet" to "按分类轻松探索",
    "İstediğin tarzı kolayca bul" to "轻松找到你喜欢的风格",
    "Doğa, şehir, uzay, anime, minimal ve daha fazlası tek yerde." to "自然、城市、太空、动漫、极简等内容一站式呈现。",
    "Kişiselleştir" to "个性化",
    "Kendi koleksiyonunu oluştur" to "创建你的合集",
    "Favorilerini kaydet, koleksiyonlarını oluştur ve deneyimini kendine göre şekillendir." to "保存收藏、创建合集，打造属于你的体验。",
    "Keşfet ve İlham Al" to "探索并获得灵感",
    "Dünyayı Renklendir" to "点亮世界",
    "Güzellik her yerde. Şimdi kendi tarzını WXTRA ile yansıt." to "美无处不在，用 WXTRA 展现你的风格。",
    "Sağa kaydırarak devam et" to "向右滑动继续",
    "Favorilerini Kaydet" to "保存收藏",
    "Koleksiyonlarını Oluştur" to "创建合集",
    "Kendine göre keşfet" to "按你的方式探索",
    "Duvar kâğıtlarını keşfet." to "探索壁纸。",
    "Senin İçin" to "为你推荐",
    "Popüler" to "热门",
    "Sınırların Ötesinde" to "超越界限",
    "Şimdi Keşfet" to "立即探索",
    "🌿 Doğa" to "🌿 自然",
    "🏙 Şehir" to "🏙 城市",
    "🚗 Araçlar" to "🚗 车辆",
    "◑ Karanlık" to "◑ 深色",
    "Araçlar" to "车辆",
    "📁  Kategorilerde Keşfet" to "📁  按分类探索",
    "Kategorilerde Keşfet" to "按分类探索",
    "Canlı Duvarlar" to "动态壁纸",
    "Çift Ekran" to "双屏",
    "🕘  En Yeni Duvar Kâğıtları" to "🕘  最新壁纸",
    "❤️  Ruh Hâline Göre" to "❤️  按心情",
    "Beğen" to "喜欢",
    "Görüntülenme" to "浏览",
    "Daha fazlası seni bekliyor..." to "更多内容等你发现...",
    "👑 Günün Seçimi" to "👑 今日精选",
    "Özel olarak seçildi" to "特别精选",
    "Doğanın en güzel tonları, şimdi ekranında." to "自然最美的色彩，现在就在你的屏幕上。",
    "Duvar Kâğıdını Aç" to "打开壁纸",
    "❤️ Senin İçin" to "❤️ 为你",
    "Beğenilerine göre" to "根据你的喜好",
    "En çok beğenilenler" to "最受喜爱",
    "📈 Yükselişte" to "📈 热门上升",
    "Son günlerde hızla popüler" to "近来快速走红",
    "👑 Haftanın Koleksiyonu" to "👑 本周合集",
    "Özel seçilmiş 24 duvar kâğıdı" to "24 张精选壁纸",
    "Koleksiyonu Keşfet" to "探索合集",
    "🎲 Rastgele Keşfet" to "🎲 随机探索",
    "Her açılışta yeni bir sürpriz" to "每次打开都有新惊喜",
    "Karıştır" to "随机播放",
    "En yeni içerikler" to "最新内容",
    "Kullanıcıların seçtikleri" to "用户精选",
    "Bir kategori seç" to "选择分类",
    "🎨 Renge Göre" to "🎨 按颜色",
    "Ruhuna uygun rengi seç" to "选择适合心情的颜色",
    "Kırmızı" to "红色",
    "Yeşil" to "绿色",
    "📱 Cihazına Özel" to "📱 适配设备",
    "Ekranına tam oturanlar" to "完美适配你的屏幕",
    "🗓️ Günlük Seri" to "🗓️ 每日系列",
    "Her gün yeni tema" to "每天新主题",
    "Çar · Doğa" to "周三 · 自然",
    "Paz · Özel" to "周日 · 精选",
    "👀 Son Görüntülediklerin" to "👀 最近浏览",
    "Kaldığın yerden devam et" to "继续上次浏览",
    "Sonsuz Keşif" to "无限探索",
    "Aşağı indikçe daha fazlası gelir." to "向下滚动会发现更多内容。",
    "Profilini görmek, favorilerini ve koleksiyonlarını kaydetmek için Google hesabınla devam et." to "使用 Google 账户继续，以查看资料并保存收藏和合集。",
    "Sadece bir dokunuş yeter • Profilin bu cihazda korunur" to "只需轻触一下 • 你的资料会保存在此设备",
    "Google hesabı" to "Google 账户",
    "Hesap bağlantısı" to "账户连接",
    "Profilini ve favorilerini bu cihazda yönetebilirsin. Google hesabı bağlantısı bu sürümde yerel profil oturumu olarak tutulur." to "你可以在此设备管理资料和收藏。本版本将 Google 账户连接作为本地资料会话保存。",
    "Verilerini güvenle yedekle" to "安全备份数据",
    "Cihazdaki alanı görüntüle" to "查看设备存储",
    "Profil ve uygulama verilerini yönet" to "管理资料和应用数据",
    "Yedekleme Ayarları" to "备份设置",
    "Otomatik yedekleme, sıklık ve geri yükleme seçenekleri" to "自动备份、频率和恢复选项",
    "Güvenlik Merkezi" to "安全中心",
    "Hesabını ve verilerini koru" to "保护账户和数据",
    "Şifre ve Giriş" to "密码与登录",
    "Hesap bağlantısını yönet" to "管理账户连接",
    "Gizlilik Ayarları" to "隐私设置",
    "Veri kullanımı ve gizlilik tercihleri" to "数据使用和隐私偏好",
    "Bildirim Ayarları" to "通知设置",
    "Hangi bildirimleri almak istediğini seç" to "选择要接收的通知",
    "İzinleri Yönet" to "管理权限",
    "Uygulama izinlerini kontrol et" to "管理应用权限",
    "Hesap Bilgileri" to "账户信息",
    "Ad, kullanıcı adı ve bağlantı" to "姓名、用户名和连接",
    "Hesap Silme" to "删除账户",
    "Tüm yerel profil verilerini sil" to "删除所有本地资料数据",
    "Yardım Merkezi" to "帮助中心",
    "Sık sorulan sorular" to "常见问题",
    "Bizimle İletişime Geç" to "联系我们",
    "Destek al, öneri gönder" to "获取支持或发送反馈",
    "Tema, dil ve genel ayarlar" to "主题、语言和常规设置",
    "Tüm yerel profil verileri silinir" to "所有本地资料数据将被删除",
    "Günlük yeni duvar kâğıdı" to "每日新壁纸",
    "Sorun Bildir" to "报告问题",
    "Bize yardımcı ol" to "帮助我们改进",
    "Bize Ulaş" to "联系我们",
    "E-posta: destek@wxtra.app" to "电子邮件：destek@wxtra.app",
    "Hesabını bağla ve favorilerini senkronize et." to "连接账户并同步收藏。",
    "E-posta hesabı" to "电子邮件账户",
    "Şifre" to "密码",
    "Giriş Yap" to "登录",
    "Kayıt Ol" to "注册",
    "Hesap İşlemleri" to "账户操作",
    "Google ile Giriş Yap" to "使用 Google 登录",
    "E-posta ile Giriş Yap / Kayıt Ol" to "使用电子邮件登录 / 注册",
    "Kendi hesabını oluştur" to "创建账户",
    "Hesabın bu cihazda aktif" to "你的账户已在此设备启用",
    "Hesap Bilgilerini Düzenle" to "编辑账户信息",
    "Adını ve kullanıcı adını değiştir" to "修改姓名和用户名",
    "Geri Yükle" to "恢复",
    "Diğer İşlemler" to "其他操作",
    "Hesap Bağlı" to "账户已连接",
    "Profil Düzenle" to "编辑资料",
    "Çince" to "中文",
    "Kullanıcı adı" to "用户名",
    "Beğeni" to "点赞",
    "Takipçi" to "粉丝",
    "Takip" to "关注",
    "Oluşturduklarım" to "我创建的",
    "Hesabımı Yedekle" to "备份我的数据",
    "Yedekten Geri Yükle" to "从备份恢复",
    "Profili Sıfırla" to "重置资料",
    "Geri Yüklendi ✓" to "已恢复 ✓",
    "Profil fotoğrafını seç" to "选择头像",
    "Vazgeç" to "取消",
    "Sürüm ve bilgiler" to "版本和信息",
    "Neler sunuyor?" to "提供什么？",
    "WXTRA nedir?" to "什么是 WXTRA？",
    "WXTRA'nın amacı" to "WXTRA 的宗旨",
    "Zengin duvar kâğıdı koleksiyonu" to "丰富的壁纸合集",
    "Binlerce özel içerik" to "数千项精选内容",
    "Her gün yeni içerik" to "每天新内容",
    "Kullanıcı profili" to "用户资料",
    "Sana özel deneyim" to "为你定制的体验",
    "Hesap senkronizasyonu" to "账户同步",
    "Verilerin her zaman seninle" to "数据始终伴随你",
    "Tarzını yansıt" to "展现你的风格",
    "Premium içerikler" to "高级内容",
    "Canlı duvar kâğıtları" to "动态壁纸",
    "Yapay zekâ ile öneriler" to "AI 推荐",
    "Topluluk ve paylaşım" to "社区与分享",
    "Çoklu cihaz senkronizasyonu" to "多设备同步",
    "Daha fazla kişiselleştirme seçeneği" to "更多个性化选项",
    "Güzel bir duvar kâğıdı sadece bir görüntü değil, her gün yeniden başlayan bir ilhamdır." to "美丽的壁纸不只是一张图片，更是每天重新开始的灵感。",
    "WXTRA tarafından sevgiyle geliştirildi." to "WXTRA 用心打造。",
    "Teşekkürler, sen bu yolculuğun bir parçasısın. 💜" to "谢谢你，你是这段旅程的一部分。💜",
    "Dünyayı Renklendir, Senin Tarzınla 💜" to "用你的风格点亮世界 💜",
    "Duvar Kâğıtları" to "壁纸",
    "Güzellik Her Yerde" to "美无处不在",
    "Sürüm 1.0.0" to "版本 1.0.0",
    "WXTRA seçkisi  •  Telefonuna uygun" to "WXTRA 精选 • 适合你的手机",
    "Duvar Kâğıdı Hazır ✓" to "壁纸已准备好 ✓",
    "Duvar Kâğıdı Yap" to "设置壁纸",
    "GÜNÜN ÖNERİSİ" to "今日推荐", "Daha Fazla Sen" to "更多的你", "WXTRA Üyesi" to "WXTRA 会员",
    "Profil Düzenle" to "编辑资料", "Son Görüntülenenler" to "最近浏览", "Geceye Farklı Bak" to "换一种方式看夜晚",
    "Her duvar, başka bir sen." to "每一张壁纸，都是不同的你。", "Keşfet" to "探索",
    "Keşfet  →" to "探索  →", "Duvar kâğıdı ara..." to "搜索壁纸...", "Duvar kağıdı ara…" to "搜索壁纸…",
    "WXTRA İLE" to "使用 WXTRA", "Daha Fazlasını Hisset" to "感受更多",
    "Senin tarzın. Senin duvarın. Senin hikayen." to "你的风格，你的壁纸，你的故事。",
    "Sıradan duvar kâğıtlarının ötesine geç." to "超越普通壁纸。", "YENİ UFUKLAR" to "新的视野",
    "Farklı Dünyaları Keşfet" to "探索不同世界", "Her ekran, yeni bir hikâye." to "每个屏幕，都是新的故事。",
    "Keşfetmeye Başla →" to "开始探索 →", "Bu Haftanın Özel Seçkisi" to "本周精选",
    "WXTRA ekibinin seçtiği favoriler." to "WXTRA 团队精选。", "Henüz favorin yok" to "还没有收藏",
    "Beğendiğin duvar kâğıtları burada görünecek." to "你喜欢的壁纸会显示在这里。", "Sizin için özel seçildi." to "为你特别精选。",
    "Özel seçki" to "精选", "Sonuç bulunamadı." to "未找到结果。", "WXTRA'ya hoş geldin!" to "欢迎来到 WXTRA！",
    "Yeni duvar kâğıtları ve koleksiyonlar burada görünecek." to "新的壁纸和合集会显示在这里。",
    "Daha fazla özellik, daha fazla özgürlük." to "更多功能，更多自由。", "Yakında  ›" to "即将推出  ›",
    "🔥  Popüler Şu An" to "🔥  当前热门", "🔥 Popüler Şu An" to "🔥 当前热门", "✨  Senin Ruh Hâlin" to "✨ 你的心情",
    "🎨  Senin İçin Seçtiklerimiz" to "🎨 为你精选", "📈 Yükselenler" to "📈 上升趋势", "🎨 Tarzına Göre" to "🎨 按风格",
    "👑 Haftanın Seçimleri" to "👑 本周精选", "👤 Senin İçin" to "👤 为你", "Tümünü Gör" to "查看全部",
    "Doğa" to "自然", "Anime" to "动漫", "Arabalar" to "汽车", "Uzay" to "太空", "Sakin" to "平静", "Enerjik" to "活力",
    "Melankolik" to "忧郁", "Odak" to "专注", "Mutlu" to "快乐", "Renkli Kuş" to "彩色鸟", "Kırmızı Dokunuş" to "红色触感",
    "Saklı Bahçe" to "隐藏花园", "Pembe Efsane" to "粉色传奇", "Gece Sürüşü" to "夜间驾驶", "Doğanın İçinde" to "置身自然",
    "Zarif Dokunuş" to "优雅触感", "Akış" to "流动", "Renkli Akşamlar" to "多彩夜晚", "Şehir" to "城市", "Gece" to "夜晚",
    "Minimal" to "极简", "Sanat" to "艺术", "Karanlık" to "深色", "Renkli" to "彩色", "Koleksiyonlarım" to "我的合集",
    "Karanlık Mod" to "深色模式", "Anime Dünyası" to "动漫世界", "WXTRA Hakkında" to "关于 WXTRA", "Profilim" to "我的资料",
    "Favorilerim" to "我的收藏", "Ayarlar" to "设置", "Bildirimler" to "通知", "Tema Arka Planı" to "主题背景",
    "Tema Yazı Rengi" to "主题文字颜色", "Tema Dizilimi" to "主题布局", "GÖRÜNÜM" to "外观", "BİLDİRİMLER" to "通知",
    "UYGULAMA" to "应用", "DESTEK" to "支持", "HAKKIMDA" to "关于", "Önbellek" to "缓存", "Temizle" to "清除",
    "Sıfırla" to "重置", "Sorun bildir" to "报告问题", "Bize ulaş" to "联系我们", "Gizlilik politikası" to "隐私政策",
    "Kullanım koşulları" to "使用条款", "Sürüm bilgisi" to "版本信息", "Dil" to "语言", "Türkçe" to "土耳其语",
    "İngilizce" to "英语", "Çince" to "中文", "Uygulama bildirimleri" to "应用通知", "Günlük öneri bildirimi" to "每日壁纸通知",
    "Kişiselleştirilmiş öneriler" to "个性化推荐", "Yeni duvar kâğıdı" to "新壁纸", "Bize yardımcı ol" to "帮助我们改进",
    "WXTRA destek" to "WXTRA 支持", "Profilini düzenle" to "编辑资料", "Kaydet" to "保存", "İptal" to "取消",
    "Profil fotoğrafını seç" to "选择头像", "Hesabına giriş yap" to "登录账户", "Hesap İşlemleri" to "账户",
    "Hesap Bağlı" to "账户已连接", "Hesabını bağla" to "连接账户", "Çıkış Yap" to "退出登录", "Hesaptan çıkış yap" to "退出账户",
    "Geri Yükle" to "恢复", "Geri Yüklendi ✓" to "已恢复 ✓", "Yedeklendi ✓" to "已备份 ✓", "Profili Sıfırla" to "重置资料",
    "Diğer İşlemler" to "其他", "Hızlı İşlemler" to "快捷操作", "Cihaz ve Veri Yönetimi" to "设备与数据管理",
    "Güvenlik ve Gizlilik" to "安全与隐私", "Bildirimler ve İzinler" to "通知与权限", "Hesap Yönetimi" to "账户管理",
    "Uygulama ve Destek" to "应用与支持", "WXTRA Hakkında" to "关于 WXTRA", "Kapat" to "关闭", "Tamam" to "确定",
    "Vazgeç" to "取消", "Arama" to "搜索", "Bugün" to "今天", "Günün Önerisi" to "今日推荐",
    "Her zevke, her ruh hâline uygun binlerce duvar kâğıdı seni bekliyor." to "数千张适合不同风格和心情的壁纸等你探索。",
    "Editörün Seçimi" to "编辑精选", "Doğanın Büyüsü" to "自然之美", "Nefes kesen manzaralarla kendini yeniden keşfet." to "在壮丽景色中重新发现自己。",
    "Tüm Kategoriler" to "全部分类", "Premium Kategoriler" to "高级分类", "Favori Kategoriler" to "收藏分类",
    "Özel ve eşsiz 4K+ koleksiyonlar." to "独特的 4K+ 精选合集。", "En çok sevilenleri keşfet." to "探索最受喜爱的内容。",
    "Güzellik Her Yerde" to "美，无处不在", "DUVAR KÂĞITLARI" to "壁纸", "Atla" to "跳过", "Hemen Başla  →" to "立即开始  →",
    "DAHA FAZLASINI KEŞFET" to "探索更多", "Ruh Hâli" to "心情", "Nasıl hissediyorsan\nona uygun dünyayı keşfet." to "探索与你心情相符的世界。",
    "Ruh Hâlini Seç  →" to "选择心情  →", "Günün Koleksiyonu" to "今日合集", "Özenle seçilmiş\nözel duvar kâğıtları." to "精心挑选的壁纸。",
    "Koleksiyona Git  →" to "前往合集  →", "Premium İçerikleri Keşfet" to "探索高级内容", "Özel koleksiyonlar, 4K içerikler ve daha fazlası…" to "精选合集、4K 内容及更多…",
    "Daha Fazla  →" to "查看更多  →", "En Yeni Duvar Kâğıtları" to "最新壁纸", "Ruh Hâline Göre" to "按心情",
    "Gizlilik Politikası" to "隐私政策", "Kullanım Koşulları" to "使用条款", "Sürüm Bilgisi" to "版本信息", "Koleksiyonlarım" to "我的合集",
    "Yedekleme" to "备份", "Verilerini güvenle yedekle" to "安全备份你的数据", "Depolama" to "存储", "Cihazdaki alanı görüntüle" to "查看设备存储空间",
    "Verilerim" to "我的数据", "Profil ve uygulama verilerini yönet" to "管理资料和应用数据", "Yedekleme Ayarları" to "备份设置",
    "Otomatik yedekleme, sıklık ve geri yükleme seçenekleri" to "自动备份、频率和恢复选项", "Güvenlik Merkezi" to "安全中心", "Hesabını ve verilerini koru" to "保护账户和数据",
    "Şifre ve Giriş" to "密码与登录", "Hesap bağlantısını yönet" to "管理账户连接", "Gizlilik Ayarları" to "隐私设置", "Veri kullanımı ve gizlilik tercihleri" to "数据使用和隐私偏好",
    "Bildirim Ayarları" to "通知设置", "Hangi bildirimleri almak istediğini seç" to "选择要接收的通知", "İzinleri Yönet" to "管理权限", "Uygulama izinlerini kontrol et" to "管理应用权限",
    "Hesap Bilgileri" to "账户信息", "Ad, kullanıcı adı ve bağlantı" to "姓名、用户名和连接", "Hesap Silme" to "删除账户", "Tüm yerel profil verilerini sil" to "删除所有本地资料数据",
    "Yardım Merkezi" to "帮助中心", "Sık sorulan sorular" to "常见问题", "Bizimle İletişime Geç" to "联系我们", "Destek al, öneri gönder" to "获取支持或发送反馈",
    "Tema, dil ve genel ayarlar" to "主题、语言和常规设置", "Çıkış Yap" to "退出登录", "Hesabı Sil" to "删除账户", "Tüm yerel profil verileri silinir" to "所有本地资料数据将被删除", "Hesaptan çıkış yap" to "退出账户",
    "Anasayfa" to "首页",
    "Kategori" to "分类",
    "Profil" to "个人资料",
    "Ara" to "搜索",
    "Sınırları Kaldır  →" to "解除限制  →",
    "Aşağıdaki başlıklara dokunarak ayrıntıları görebilirsin." to "点击下面的标题查看详情。",
    "VERİ GİZLİLİĞİ" to "数据隐私",
    "Son güncelleme: 8 Eylül 2026" to "最后更新：2026年9月8日",
    "KULLANIM KURALLARI" to "使用规则",
    "Aşağıdaki başlıklara dokunarak ayrıntıları açabilir ve WXTRA'yı kullanırken uyman gereken kuralları görebilirsin." to "点击下面的标题查看详情以及使用 WXTRA 时应遵守的规则。",
    "Kullanım Koşulları" to "使用条款",
    "Hesap ve kullanıcı sorumlulukları" to "账户与用户责任",
    "Duvar kâğıtlarının kullanımı" to "壁纸使用",
    "Yasaklanan içerikler ve davranışlar" to "禁止的内容与行为",
    "Telif hakları" to "版权",
    "Otomatik ve AI özelliklerinin kullanımı" to "自动化与 AI 功能",
    "Hesap güvenliği" to "账户安全",
    "İçerik ve hizmet sorumluluğu" to "内容与服务责任",
    "Koşulların değiştirilmesi" to "条款变更",
    "Hesabın kapatılması" to "账户关闭",
    "İletişim ve destek" to "联系与支持",
    "Hangi verileri topluyoruz?" to "我们收集哪些数据？",
    "Verilerimi neden kullanıyoruz?" to "为什么使用我的数据？",
    "Hesap ve profil bilgilerim" to "我的账户和资料信息",
    "Favoriler ve koleksiyonlar" to "收藏与合集",
    "Veriler nerede saklanıyor?" to "数据存储在哪里？",
    "Verilerimi kimler görebilir?" to "谁可以查看我的数据？",
    "Verilerimi nasıl silebilirim?" to "如何删除我的数据？",
    "Güvenlik" to "安全",
    "Gizlilik talepleri ve iletişim" to "隐私请求与联系",
    "Politika güncellemeleri" to "政策更新",
    "WXTRA'nın mevcut sürümünde uygulama tercihleri, favoriler, son görüntülenenler ve profil bilgileri gibi uygulamayı çalıştırmak için gerekli veriler cihazın özel depolama alanında tutulabilir. Google ile giriş kullanıldığında, giriş sağlayıcısından hesabın çalışması için gerekli temel profil bilgileri alınabilir. Gereksiz hassas kişisel veriler özellikle talep edilmedikçe toplanmaz." to "在当前版本的 WXTRA 中，应用偏好、收藏、最近浏览和资料信息等运行所需数据可能保存在设备的应用私有存储中。使用 Google 登录时，可能从身份提供方获取账户所需的基本资料信息。除非特别要求，否则不会收集不必要的敏感个人数据。",
    "Veriler; hesabını ve profilini yönetmek, favorilerini ve koleksiyonlarını korumak, uygulama ayarlarını hatırlamak, cihazlar arası senkronizasyonu desteklemek ve WXTRA deneyimini geliştirmek için kullanılabilir. Veriler yalnızca belirtilen amaçlar ve hizmetin çalışması için gerekli olduğu ölçüde işlenir." to "数据可用于管理账户和资料、保存收藏和合集、记住应用设置、支持设备间同步并改善 WXTRA 体验。数据仅在实现上述目的和服务运行所必需的范围内处理。",
    "Profilinde oluşturduğun ad, kullanıcı adı, profil fotoğrafı ve benzeri bilgiler kişiselleştirilmiş profil deneyimi için kullanılır. Profil bilgilerini uygulama içindeki Profilim bölümünden düzenleyebilirsin." to "你创建的姓名、用户名、头像等信息用于提供个性化资料体验，可在应用的个人资料页面编辑。",
    "Favorilediğin duvar kâğıtları, koleksiyonların ve bazı kullanım tercihlerin hesabın veya cihazındaki WXTRA verileriyle ilişkilendirilebilir. Böylece uygulamayı kullandığında tercihlerin korunabilir." to "你收藏的壁纸、合集和部分使用偏好可能与账户或设备中的 WXTRA 数据关联，以便保留你的偏好。",
    "Yerel profil ve uygulama tercihleri mevcut sürümde Android'in uygulamaya özel depolama alanında tutulur. Sunucu tabanlı hesap senkronizasyonu kullanılan bölümlerde veriler, hizmetin çalışması için gerekli güvenlik ve erişim kontrolleri uygulanarak işlenir." to "当前版本的本地资料和应用偏好保存在 Android 应用专属存储中。使用服务器账户同步的部分会在必要的安全和访问控制下处理数据。",
    "Kişisel verilerin satılmaz veya iznin dışında reklam amacıyla paylaşılmaz. Hizmetin çalışması için gerekli üçüncü taraf hizmet sağlayıcıları kullanıldığında yalnızca gerekli kapsamda veri işlenebilir. Yasal bir zorunluluk olmadıkça verilerin yetkisiz kişilerle paylaşılması amaçlanmaz." to "个人数据不会被出售，也不会未经许可用于广告分享。服务需要第三方提供商时，仅处理必要范围的数据。除法律要求外，不会向未经授权的人员分享数据。",
    "Profil ekranındaki hesap silme seçeneğini kullanarak cihazındaki WXTRA profil ve hesap verilerini kaldırmayı başlatabilirsin. Sunucularda tutulabilecek verilerin silinmesi için ayrıca destek ekibine talep iletilebilir. Yasal olarak saklanması gereken kayıtlar ilgili süre boyunca tutulabilir." to "你可以通过资料页面的删除账户选项开始删除设备上的 WXTRA 资料和账户数据。服务器上的数据可另行联系支持团队请求删除。法律要求保留的记录可能在规定期限内保留。",
    "WXTRA, kişisel verileri yetkisiz erişim, kayıp veya kötüye kullanıma karşı korumak için uygun teknik ve idari önlemler kullanmayı amaçlar. Bununla birlikte internet üzerinden yapılan hiçbir veri aktarımının mutlak olarak risksiz olduğu garanti edilemez." to "WXTRA 致力于采取适当的技术和管理措施保护个人数据，防止未经授权的访问、丢失或滥用。但无法保证互联网数据传输绝对没有风险。",
    "Verilerinle ilgili erişim, düzeltme, silme veya gizlilik soruların için WXTRA destek ekibine ulaşabilirsin. İletişim: destek@wxtra.app" to "如需访问、更正或删除数据，或有隐私问题，请联系 WXTRA 支持。联系方式：destek@wxtra.app",
    "Bu Gizlilik Politikası, uygulamanın özellikleri veya veri işleme yöntemleri değiştikçe güncellenebilir. Önemli değişikliklerde kullanıcıların bilgilendirilmesi hedeflenir." to "本隐私政策可能随应用功能或数据处理方式变化而更新。重大变更将尽量通知用户。",
    "WXTRA uygulamasını indirerek, kullanarak veya hesap oluşturarak bu kullanım koşullarını kabul etmiş olursun. Bu koşullar; uygulamadaki özelliklerin, içeriklerin ve hesap hizmetlerinin kullanımına ilişkin temel kuralları açıklar. Koşulları kabul etmiyorsan WXTRA'yı kullanmamalısın." to "下载、使用 WXTRA 或创建账户即表示你同意本使用条款。本条款说明应用功能、内容和账户服务的基本使用规则。如不同意，请勿使用 WXTRA。",
    "Hesap bilgilerinin doğru ve güncel olmasından sen sorumlusun. Hesabının güvenliğini korumalı, giriş bilgilerini başkalarıyla paylaşmamalısın. Hesabın üzerinden gerçekleştirilen işlemlerden, yetkisiz kullanım fark ettiğinde WXTRA'ya bildirimde bulunman beklenir." to "你负责确保账户信息准确且最新，应保护账户安全，不得分享登录信息。如发现未经授权的使用，应及时通知 WXTRA。",
    "WXTRA'daki duvar kâğıtları yalnızca uygulamanın sunduğu kullanım izinleri kapsamında kullanılmalıdır. Bir görseli ticari amaçla yeniden satmak, başka bir içerik olarak dağıtmak veya hak sahibinin izni olmadan sahiplenmek uygun değildir. İndirme ve cihazda duvar kâğıdı olarak kullanma hakkı, görselin lisansına göre değişebilir." to "WXTRA 中的壁纸只能在应用提供的许可范围内使用。未经权利人许可，不得商业转售、重新分发或声称拥有图片。下载和作为设备壁纸使用的权利取决于图片许可。",
    "Favoriler ve koleksiyonlar, içerikleri kişisel kullanımın için düzenlemene yardımcı olur. Bu özellikleri kötüye kullanmamalı, başkalarının hesabına veya verilerine erişmeye çalışmamalısın." to "收藏和合集用于整理个人使用的内容。不得滥用这些功能，也不得尝试访问他人的账户或数据。",
    "Yasa dışı, tehdit edici, nefret veya taciz içeren, cinsel istismar içeren, çocukları tehlikeye atan, dolandırıcılığı teşvik eden ya da başkalarının haklarını ihlal eden içerik ve davranışlara izin verilmez. Uygulamanın güvenliğini bozacak, hizmeti aşırı yükleyecek veya yetkisiz erişim sağlamaya yönelik işlemler de yasaktır." to "不允许非法、威胁、仇恨、骚扰、性剥削、危害儿童、鼓励欺诈或侵犯他人权利的内容和行为。破坏应用安全、过载服务或试图未经授权访问的行为同样禁止。",
    "WXTRA arayüzü, marka unsurları, uygulama tasarımı ve WXTRA tarafından oluşturulan içerikler ilgili fikri mülkiyet haklarıyla korunabilir. Üçüncü taraf görsellerin hakları ilgili sahiplerine aittir. Hak ihlali olduğunu düşündüğün bir içerik varsa kaldırma veya inceleme talebi için destek ekibine ulaşabilirsin." to "WXTRA 界面、品牌元素、应用设计及 WXTRA 创建的内容可能受知识产权保护。第三方图片的权利属于相应权利人。如认为内容侵权，可联系支持团队请求删除或审核。",
    "WXTRA'da gelecekte sunulabilecek otomatik veya yapay zekâ destekli özellikler yardımcı amaçlıdır. Bu özelliklerin ürettiği sonuçların her zaman hatasız, eksiksiz veya sana özel hukuki, finansal ya da profesyonel tavsiye niteliğinde olduğu garanti edilmez. Sonuçları kullanmadan önce uygunluğunu kontrol etmelisin." to "未来可能提供的自动化或 AI 功能仅用于辅助。不能保证其结果始终无误、完整或构成针对你的法律、财务或专业建议。使用结果前请自行确认适用性。",
    "Hesabını korumak için cihazının ve Google hesabının güvenlik ayarlarını güncel tut. Şüpheli giriş veya hesap erişimi fark edersen mümkün olan en kısa sürede şifreni ve ilgili hesap güvenlik ayarlarını değiştir ve WXTRA desteğine başvur." to "请保持设备和 Google 账户安全设置最新。如发现可疑登录或账户访问，请尽快修改密码及相关安全设置并联系 WXTRA 支持。",
    "WXTRA hizmeti geliştirilirken bazı özellikler değişebilir, geçici olarak kullanılamayabilir veya kaldırılabilir. Üçüncü taraf hizmetlerden kaynaklanan kesintiler de yaşanabilir. Hizmetin sürekliliği ve tüm içeriklerin her zaman erişilebilir olması garanti edilmez." to "随着 WXTRA 的发展，部分功能可能变化、暂时不可用或被移除。第三方服务也可能发生中断。无法保证服务持续运行或所有内容始终可用。",
    "WXTRA; yeni özellikler, güvenlik gereksinimleri veya yasal değişiklikler nedeniyle bu koşulları güncelleyebilir. Önemli değişiklikler olduğunda kullanıcıların uygun şekilde bilgilendirilmesi hedeflenir. Güncellenen koşulların yayınlanmasından sonra uygulamayı kullanmaya devam etmen, yürürlükteki koşulları kabul ettiğin anlamına gelebilir." to "WXTRA 可能因新功能、安全要求或法律变化更新本条款。重大变更将尽量通知用户。更新条款发布后继续使用应用可能表示你接受现行条款。",
    "Hesabını kapatmak veya silmek istediğinde uygulamadaki hesap yönetimi seçeneklerini kullanabilirsin. Kuralları ciddi biçimde ihlal eden hesaplarda, güvenliği korumak veya yasal yükümlülükleri yerine getirmek amacıyla erişim sınırlandırılabilir veya hesap kapatılabilir." to "如需关闭或删除账户，可使用应用中的账户管理选项。严重违反规则的账户可能为安全或法律义务而被限制或关闭。",
    "Kullanım koşulları, içerik hakları veya hesabınla ilgili soruların için WXTRA destek ekibine ulaşabilirsin. İletişim: destek@wxtra.app. Bildiriminde mümkünse kullanıcı adını, uygulama sürümünü ve sorunun kısa açıklamasını belirt." to "如对使用条款、内容权利或账户有疑问，请联系 WXTRA 支持。联系方式：destek@wxtra.app。请尽量提供用户名、应用版本和问题简述。",
    "“Daha güzel bir deneyim, kurallara birlikte uymakla mümkün.”" to "遵守规则，我们才能共同拥有更好的体验。",
    "Hemen Başla  →" to "立即开始  →",
    "WXTRA" to "WXTRA",
    "W" to "W",
    "Bildirimler" to "通知",
    "Ruh Hâli" to "心情",
    "Günün Koleksiyonu" to "今日合集",
    "💎" to "💎",
    "Özel koleksiyonlar, 4K içerikler ve daha fazlası…" to "精选合集、4K 内容及更多…",
    "›" to "›",
    "Keşfet" to "探索",
    "Huzurun Adresi" to "宁静之地",
    "Tümünü Gör  →" to "查看全部  →",
    "G" to "G",
    "Google ile devam et" to "使用 Google 继续",
    "Tamam" to "确定",
    "Kaydet" to "保存",
    "İptal" to "取消",
    "Bu sürümde yedek, uygulamanın özel depolama alanında tutulur. Gerçek bulut/Drive senkronizasyonu için ayrıca sunucu ve hesap yetkilendirmesi gerekir." to "本版本的备份保存在应用私有存储中。真正的云端/Drive 同步需要服务器和账户授权。",
    "Durum: Son yedek hazır ✓" to "状态：最新备份已准备 ✓",
    "Durum: Henüz yedek oluşturulmadı" to "状态：尚未创建备份",
    "Yedekleme ayarları" to "备份设置",
    "Otomatik yedekleme" to "自动备份",
    "Otomatik yedekleme seçeneği sunucu senkronizasyonu etkin olduğunda kullanılabilir. Bu sürümde manuel yerel yedekleme güvenle çalışır." to "启用服务器同步后可使用自动备份。本版本的手动本地备份可安全使用。",
    "Yedeklenecekler: profil bilgileri, favoriler ve uygulama tercihleri." to "备份内容：资料信息、收藏和应用偏好。",
    "Güvenlik merkezi" to "安全中心",
    "Profil ve uygulama tercihleri Android'in uygulamaya özel depolama alanında tutulur." to "资料和应用偏好保存在 Android 应用专属存储中。",
    "WXTRA kişisel verileri satmayı veya iznin dışında reklam amacıyla paylaşmayı amaçlamaz. Hesap senkronizasyonu eklenirse yetkilendirme ve güvenlik kontrolleri ayrıca uygulanır." to "WXTRA 不会出售个人数据，也不会未经许可用于广告分享。如加入账户同步，将实施额外的授权和安全控制。",
    "Kapat" to "关闭",
    "Depolama ve veriler" to "存储与数据",
    "Bu cihazdaki WXTRA verileri" to "此设备上的 WXTRA 数据",
    "Duvar kâğıtlarını indirme alanı kullanılmaz; favoriler ve uygulama verileri yönetilir." to "不使用壁纸下载存储空间；管理收藏和应用数据。",
    "WXTRA Pro" to "WXTRA Pro",
    "WXTRA Pro; daha fazla kişiselleştirme, premium içerikler ve gelişmiş özellikler için hazırlanan ayrı bir deneyimdir." to "WXTRA Pro 是为更多个性化、高级内容和增强功能打造的独立体验。",
    "Hesabı sil" to "删除账户",
    "Bu işlem bu cihazdaki WXTRA profil bilgilerini, favorileri ve uygulama tercihlerini kaldırır. Devam etmek istiyor musun?" to "此操作将删除此设备上的 WXTRA 资料、收藏和应用偏好。确定继续吗？",
    "Profil fotoğrafı" to "头像",
    " ✓" to " ✓",
    "WXTRA Üyesi" to "WXTRA 会员",
    "Favori" to "收藏",
    "Koleksiyon" to "合集",
    "Takipçi sistemi hesap altyapısıyla birlikte etkinleştirilecek." to "粉丝系统将在账户基础设施完成后启用。",
    "Takip sistemi hesap altyapısıyla birlikte etkinleştirilecek." to "关注系统将在账户基础设施完成后启用。",
    "✦" to "✦",
    "Son Görüntülenenler" to "最近浏览",
    "Profili Düzenle" to "编辑资料",
    "Cihaz ve Veri Yönetimi" to "设备与数据管理",
    "Depolama" to "存储",
    "Hesap Yönetimi" to "账户管理",
    "Ayarlar" to "设置",
    "Çıkış Yap" to "退出登录",
    "Hesaptan çıkış yap" to "退出账户",
    "WXTRA'ya hoş geldin!" to "欢迎来到 WXTRA！",
    "WXTRA'da veri ve gizlilik" to "WXTRA 的数据与隐私",
    "Kurallarımız, daha güzel bir deneyim için" to "我们的规则旨在带来更好的体验",
    "— WXTRA" to "— WXTRA",
    "Sürüm Bilgisi" to "版本信息",
    "♥" to "♥",
    "© WXTRA" to "© WXTRA",
    "Tüm hakları saklıdır." to "保留所有权利。",
    "Yakında" to "即将推出",
    "Daha fazlası geliyor..." to "更多内容即将到来...",
    "“" to "“",
    "Kategoriler" to "分类",
    "Doğanın Büyüsü" to "自然之美",
    "duvar kâğıdı" to "壁纸",
    "Favori Kategoriler" to "收藏分类",
    "Ayarlar varsayılana döndürüldü" to "设置已恢复默认",
    "Dil Türkçe olarak ayarlandı" to "语言已设置为土耳其语",
    "Sorun Bildir\n\nKarşılaştığın sorunu ve mümkünse ekran görüntüsünü WXTRA destek ekibine iletebilirsin.\n\ndestek@wxtra.app" to "报告问题\n\n你可以将遇到的问题以及可能的截图发送给 WXTRA 支持团队。\n\nsupport@wxtra.app",
    "Bize Ulaş\n\nE-posta: destek@wxtra.app\n\nMesajında cihaz modelini ve uygulama sürümünü belirtmen sorunu daha hızlı çözmemize yardımcı olur." to "联系我们\n\n电子邮件：support@wxtra.app\n\n提供设备型号和应用版本有助于更快解决问题。",
    "3'lü Dizilim" to "3 列布局",
    "4'lü Dizilim" to "4 列布局",
    "4K Ultra HD" to "4K 超高清",
    "Ad" to "姓名",
    "Ana ekran" to "主屏幕",
    "Ana ekran + Kilit ekranı" to "主屏幕 + 锁屏",
    "Android 8.0 ve üzeri" to "Android 8.0 及以上",
    "Android 8.0+ tabanlı MagicOS sürümleri" to "基于 Android 8.0+ 的 MagicOS 版本",
    "Ayarları varsayılana döndür" to "恢复默认设置",
    "Bildirim ve Uygulama Ayarları" to "通知与应用设置",
    "DISCOVER MORE" to "探索更多",
    "Desteklenen Android Sürümleri" to "支持的 Android 版本",
    "Desteklenen MagicOS Sürümleri" to "支持的 MagicOS 版本",
    "Duvar Kâğıdını Nereye Uygula?" to "将壁纸应用到哪里？",
    "Duvar kâğıdı ara…" to "搜索壁纸…",
    "Duvar kâğıdından fazlası. Telefonunun görünümünü kendi tarzına dönüştürmek; ilham veren, kaliteli ve özgün içerikleri tek bir yerde sunmak için geliştirildi." to "不只是壁纸。它旨在让你按照自己的风格打造手机外观，并在一个地方提供富有灵感、高质量且独特的内容。",
    "E-posta" to "电子邮件",
    "E-posta ile devam et" to "使用电子邮件继续",
    "Etkileyici Manzaralar" to "震撼风景",
    "G  Google ile devam et" to "G  使用 Google 继续",
    "Geliştirici" to "开发者",
    "Görünüm Dizilimi" to "布局方式",
    "Görünüm ve kişiselleştirme" to "外观与个性化",
    "Güzel duvar kâğıtları, daha güzel hikâyeler." to "精美壁纸，精彩故事。",
    "Her gün yeni bir hikâye. WXTRA, telefonunu kişiselleştirmek için seçilmiş duvar kâğıtlarını tek yerde sunar." to "每天一个新故事。WXTRA 将精选壁纸汇聚一处，帮助你个性化手机。",
    "Kilit ekranı" to "锁屏",
    "Kişiselleştirilmiş deneyim" to "个性化体验",
    "Kurallar" to "规则",
    "Mesajında cihaz modelini ve uygulama sürümünü belirtmen sorunu daha hızlı çözmemize yardımcı olur." to "提供设备型号和应用版本有助于我们更快解决问题。",
    "Notifications" to "通知",
    "Popüler Şu An" to "当前热门",
    "Profil bilgilerin, favorilerin ve uygulama tercihlerin için yerel yedek oluşturabilirsin." to "你可以为个人资料、收藏和应用偏好创建本地备份。",
    "Profili düzenle" to "编辑资料",
    "Retro" to "复古",
    "Saygı, Güven, Daha Güzel Bir Dünya" to "尊重、信任、更美好的世界",
    "Sağ..." to "向右…",
    "Senin Ruh Hâlin" to "你的心情",
    "Senin İçin Seçtiklerimiz" to "为你精选",
    "Soyut" to "抽象",
    "Sürüm 0.1.0" to "版本 0.1.0",
    "Sürüm Numarası" to "版本号",
    "Sıradan duvar kâğıtlarına veda." to "告别普通壁纸。",
    "Tümü" to "全部",
    "Veri ve Yedekleme" to "数据与备份",
    "Veri ve gizlilik" to "数据与隐私",
    "Verilerin senin kontrolünde" to "你的数据由你掌控",
    "WXTRA hakkında" to "关于 WXTRA",
    "WXTRA kullanımı hakkında" to "关于使用 WXTRA",
    "WXTRA, tarzına uygun duvar kâğıtlarını keşfetmeni, favorilerini oluşturmanı ve kendi kişisel koleksiyonunu oluşturmanı sağlayan yeni nesil duvar kâğıdı deneyimidir. Güzelliği her yerde seninle buluşturur." to "WXTRA 是新一代壁纸体验，让你发现适合自己风格的壁纸、创建收藏，并打造个人专属合集，让美好始终伴随你。",
    "Yardım ve Destek" to "帮助与支持",
    "Öneriler" to "推荐",
    "İki ekrana birden otomatik uygulanmayacak. Bir seçenek seç:" to "不会自动同时应用到两个屏幕。请选择一个选项：",
    "▦  Tüm Kategoriler" to "▦  所有分类",
    "✨  Senin İçin Seçtiklerimiz" to "✨  为你精选",
    "🏙️ Şehir" to "🏙️ 城市",
    "Motivasyon" to "动力",
    "Yeni" to "新内容",
    "Huzurun Adresi" to "宁静之所",
    "◐ Minimal" to "◐ 极简",
    "🎮 Anime" to "🎮 动漫",
    "🪐 Uzay" to "🪐 太空",
    "🎨 Sanat" to "🎨 艺术",
    "◑ Karanlık" to "◑ 深色",
    "Trend" to "热门",
    "🔥 Trend" to "🔥 热门",
    "✨ Minimal" to "✨ 极简",
    "🌙 AMOLED" to "🌙 AMOLED",
    "🚗 Araba" to "🚗 汽车",
    "🌃 Gece" to "🌃 夜晚",
    "🏙️ Şehir" to "🏙️ 城市",
    "🤖 Anime" to "🤖 动漫",
    "✨ Yeni Gelenler" to "✨ 最新内容",
    "👥 Topluluk Favorileri" to "👥 社区精选",
    "Mor" to "紫色",
    "Mavi" to "蓝色",
    "Siyah" to "黑色",
    "Beyaz" to "白色",
    "Pzt · Minimal" to "周一 · 极简",
    "Sal · AMOLED" to "周二 · AMOLED",
    "Per · Araba" to "周四 · 汽车",
    "Cum · Uzay" to "周五 · 太空",
    "Cmt · Anime" to "周六 · 动漫",
).getOrDefault(text, text)
}

private val backgroundPresets = listOf(
    // Koyu mor / siyah ağırlıklı, premium görünümlü gradyanlar
    listOf(Color(0xFF07050D), Color(0xFF241039), Color(0xFF090611)), // Obsidian Violet
    listOf(Color(0xFF09070F), Color(0xFF32145A), Color(0xFF0C0715)), // Midnight Violet
    listOf(Color(0xFF08050D), Color(0xFF3D1768), Color(0xFF100718)), // Dark Amethyst
    listOf(Color(0xFF05050A), Color(0xFF21102F), Color(0xFF08050C)), // Black Plum
    listOf(Color(0xFF09040F), Color(0xFF5A168A), Color(0xFF17052A)), // Neon Violet
    listOf(Color(0xFF07050C), Color(0xFF32104E), Color(0xFF110817)), // Deep Purple
    listOf(Color(0xFF0A0710), Color(0xFF4A245C), Color(0xFF130B19)), // Purple Smoke
    listOf(Color(0xFF04050A), Color(0xFF171126), Color(0xFF080610)), // Void
    listOf(Color(0xFF0B0B10), Color(0xFF292833), Color(0xFF12121A)), // Moon Pearl
    listOf(Color(0xFF0B0C11), Color(0xFF3A3A46), Color(0xFF171820)), // Silver Mist
    listOf(Color(0xFF101015), Color(0xFF4A4A56), Color(0xFFE8E7EC)), // Frosted Pearl
    listOf(Color(0xFF15151A), Color(0xFF6C6B75), Color(0xFFF4F3F6)), // Soft White
    listOf(Color(0xFF08060F), Color(0xFF24183D), Color(0xFF0D0917)), // Cosmic
    listOf(Color(0xFF10051B), Color(0xFF6A18A6), Color(0xFF160625)), // Ultraviolet
    listOf(Color(0xFF030407), Color(0xFF12141B), Color(0xFF05060A))  // Dark Pearl
)
private val backgroundNames = listOf(
    "Obsidian Violet", "Midnight Violet", "Dark Amethyst", "Black Plum", "Neon Violet",
    "Deep Purple", "Purple Smoke", "Void", "Moon Pearl", "Silver Mist",
    "Frosted Pearl", "Soft White", "Cosmic", "Ultraviolet", "Dark Pearl"
)
private val textPresets = listOf(
    Color(0xFFF5F3FF), Color(0xFFFFF4E8), Color(0xFFEFE4FF), Color(0xFFE5FFF4), Color(0xFFFFE8F0),
    Color(0xFFFFF2CC), Color(0xFFE4F1FF), Color(0xFFF0ECFF), Color(0xFFE8F0FF), Color(0xFFFFEAF3),
    Color(0xFFE9F0FF), Color(0xFFE7F8FF), Color(0xFFF7F3FF), Color(0xFFFFFFFF), Color(0xFFEAF1FF)
)
private val textNames = listOf(
    "Obsidian Ink", "Warm Graphite", "Lavender Ink", "Mint Ink", "Rose Ink",
    "Champagne Ink", "Sky Ink", "Crystal Ink", "Sapphire Ink", "Sakura Ink",
    "Mountain Ink", "Ocean Ink", "Pearl White", "Pure White", "Moon White"
)

private fun applyThemePreferences(context: Context) {
    val prefs = context.getSharedPreferences("wxtra_settings", Context.MODE_PRIVATE)
    appLanguage = prefs.getString("language", "tr") ?: "tr"
    Bg = defaultBg
    Card = defaultCard
    Card2 = defaultCard2
    Purple = defaultPurple
    Blue = defaultBlue
    TextMain = Color(0xFF171326)
    TextMuted = Color(0xFF706A82)
    Accent = Brush.horizontalGradient(listOf(Color(0xFFC6A7FF), Color(0xFF7B3FF2), Color(0xFFEAE2FF)))
    appBackgroundBrush = null
    layoutMode = prefs.getInt("layoutMode", 0).coerceIn(0, 3)
}

private fun layoutColumns(): Int = when (layoutMode) {
    0 -> 4
    1 -> 3
    2 -> 2
    else -> 1
}

private fun layoutAspectRatio(): Float = when (layoutMode) {
    0 -> 0.62f
    1 -> 0.57f
    2 -> 0.69f
    else -> 0.58f
}

private fun layoutOptionNames(): List<String> = when (appLanguage) {
    "en" -> listOf("4 Columns", "3 Columns", "2 Columns", "1 Column")
    "zh" -> listOf("4 列", "3 列", "2 列", "1 列")
    else -> listOf("4'lü Dizilim", "3'lü Dizilim", "2'li Dizilim", "1'li Dizilim")
}


private val names = listOf(
    "Renkli Kuş", "Kırmızı Dokunuş", "Saklı Bahçe", "Pembe Efsane",
    "Gece Sürüşü", "Doğanın İçinde", "Zarif Dokunuş", "Akış", "Renkli Akşamlar"
)

private const val WXTRA_PUBLIC_BASE = "http://46.20.15.241:8080"

// Profil fotoğrafı seçicisinde kullanılan yerel görseller.
// Duvar kâğıtları artık sunucudan geldiği için burada olmayan `wallpapers`
// listesini kullanmak yerine APK içindeki mevcut görseller kullanılır.
private val profileAvatars = listOf(
    R.drawable.wxtra_about_logo,
    R.drawable.wxtra_splash,
    R.drawable.wxtra_app_background,
    R.drawable.home_banner
)

private data class ServerWallpaper(
    val id: Long, val filename: String, val category: String,
    val width: Int, val height: Int, val title: String, val imageUrl: String
)
private data class ServerCategory(val id: Int, val name: String, val slug: String)
private var remoteWallpapers by mutableStateOf<List<ServerWallpaper>>(emptyList())
private var remoteCategories by mutableStateOf<List<ServerCategory>>(emptyList())

@Composable
private fun WallpaperVisual(index: Int, modifier: Modifier = Modifier, contentScale: ContentScale = ContentScale.Crop) {
    val remote = remoteWallpapers.getOrNull(index)
    if (remote != null) {
        AsyncImage(model = remote.imageUrl, contentDescription = remote.title, modifier = modifier, contentScale = contentScale)
    }
}
private fun wallpaperCount() = remoteWallpapers.size
private fun serverIndices() = (0 until wallpaperCount()).toList()

private sealed class Screen {
    data object Home : Screen()
    data object Explore : Screen()
    data object Favorites : Screen()
    data object Profile : Screen()
    data object Search : Screen()
    data object Notifications : Screen()
    data class Listing(val title: String, val indices: List<Int>) : Screen()
    data object Settings : Screen()
    data object About : Screen()
    data object Categories : Screen()
    data object Collections : Screen()
    data object Admin : Screen()
    data class Detail(val index: Int) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAApp() }
    }
}

@Composable
private fun WXTRAApp() {
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        applyThemePreferences(context)
        while (true) {
            runCatching {
                val result = withContext(Dispatchers.IO) { ServerCatalogApi.load() }
                remoteWallpapers = result.first
                remoteCategories = result.second
            }
            delay(5 * 60 * 1000L)
        }
    }
    val onboardingPrefs = remember { context.getSharedPreferences("wxtra_onboarding", Context.MODE_PRIVATE) }
    var onboardingDone by remember { mutableStateOf(onboardingPrefs.getBoolean("completed", false)) }
    if (!onboardingDone) {
        OnboardingScreen(onFinished = {
            onboardingPrefs.edit().putBoolean("completed", true).apply()
            onboardingDone = true
        })
        return
    }
    var backStack by remember { mutableStateOf(listOf<Screen>(Screen.Home)) }
    var search by remember { mutableStateOf("") }
    val profilePrefs = remember { context.getSharedPreferences("wxtra_profile", Context.MODE_PRIVATE) }
    var liked by remember {
        mutableStateOf(profilePrefs.getString("liked", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.filter { it in 0 until wallpaperCount() }.toSet())
    }
    var recentlyViewed by remember {
        mutableStateOf(profilePrefs.getString("recent", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.filter { it in 0 until wallpaperCount() }.toList())
    }
    fun toggleLikeGlobal(i: Int) {
        liked = if (i in liked) liked - i else liked + i
        profilePrefs.edit().putString("liked", liked.sorted().joinToString(",")).apply()
    }
    fun push(next: Screen) { backStack = backStack + next }
    fun openDetail(i: Int) {
        val next = listOf(i) + recentlyViewed.filter { it != i }
        recentlyViewed = next.take(12)
        profilePrefs.edit().putString("recent", recentlyViewed.joinToString(",")).apply()
        push(Screen.Detail(i))
    }

    val screen = backStack.last()
    fun pop() {
        if (backStack.size > 1) backStack = backStack.dropLast(1)
    }
    fun selectRoot(next: Screen) { backStack = listOf(next) }

    BackHandler(enabled = true) {
        when {
            backStack.size > 1 -> pop()
            screen != Screen.Home -> selectRoot(Screen.Home)
            else -> Unit
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(background = Bg, surface = Card, primary = Purple, onBackground = TextMain, onSurface = TextMain)) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            // App-wide photographic background. Content stays above it on every screen.
            Image(
                painter = painterResource(R.drawable.wxtra_app_background),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.42f))
                    )
                )
            )
            when (val s = screen) {
                Screen.Home -> MainScaffold(0, { selectRoot(it) }, screen) {
                    HomeScreen(
                        open = { openDetail(it) },
                        openSearch = { push(Screen.Search) },
                        openNotifications = { push(Screen.Notifications) },
                        openListing = { title, indices -> push(Screen.Listing(title, indices)) },
                        liked = liked,
                        toggleLike = { i -> toggleLikeGlobal(i) },
                    )
                }
                Screen.Categories -> MainScaffold(1, { selectRoot(it) }, screen) {
                    CategoriesScreen(back = { pop() }, openListing = { title, indices -> push(Screen.Listing(title, indices)) })
                }
                Screen.Explore -> MainScaffold(2, { selectRoot(it) }, screen) {
                    ExploreScreen(
                        open = { openDetail(it) },
                        openCategories = { push(Screen.Categories) },
                        openSearch = { push(Screen.Search) },
                        openNotifications = { push(Screen.Notifications) },
                        openListing = { title, indices -> push(Screen.Listing(title, indices)) },
                        liked = liked,
                        toggleLike = { i -> toggleLikeGlobal(i) },
                        recentlyViewed = recentlyViewed
                    )
                }
                Screen.Profile -> MainScaffold(3, { selectRoot(it) }, screen) {
                    ProfileScreen(
                        liked = liked,
                        setLiked = { liked = it; profilePrefs.edit().putString("liked", liked.sorted().joinToString(",")).apply() },
                        recentlyViewed = recentlyViewed,
                        openFavorites = { push(Screen.Favorites) },
                        openCollections = { push(Screen.Collections) },
                        openRecentlyViewed = {
                            if (recentlyViewed.isNotEmpty()) push(Screen.Listing("Son Görüntülenenler", recentlyViewed))
                        },
                        openAbout = { push(Screen.About) },
                        openSettings = { push(Screen.Settings) },
                        openAdmin = { push(Screen.Admin) }
                    )
                }
                Screen.Search -> SearchScreen(search, { search = it }, { openDetail(it) }, { pop() })
                Screen.Notifications -> NotificationsScreen { pop() }
                is Screen.Listing -> ListingScreen(s.title, s.indices, { openDetail(it) }, { pop() })
                Screen.Settings -> MainScaffold(4, { selectRoot(it) }, screen) {
                    SettingsScreen(back = { pop() }, openAdmin = { push(Screen.Admin) })
                }
                Screen.About -> AboutScreen { pop() }
                Screen.Collections -> CollectionsScreen({ pop() }, { openDetail(it) })
                Screen.Admin -> AdminPanelScreen(back = { pop() })
                Screen.Favorites -> FavoritesScreen(liked, { openDetail(it) }, toggleLike = { toggleLikeGlobal(it) }, back = { pop() })
                is Screen.Detail -> DetailScreen(
                    index = s.index,
                    liked = s.index in liked,
                    toggleLike = { toggleLikeGlobal(s.index) },
                    back = { pop() },
                )
            }
        }
    }
}

@Composable
private fun OnboardingScreen(onFinished: () -> Unit) {
    val pages = listOf(
        OnboardingPage(
            title = "WXTRA'ya Hoş Geldin",
            text = "Dünyayı Renklendir, Senin Tarzınla",
            detail = "Binlerce eşsiz duvar kâğıdı ile her gün yeni bir ilham.",
            kind = 0
        ),
        OnboardingPage(
            title = "Eşsiz Duvar Kâğıtları Dünyası",
            text = "Her zevke uygun içerikler",
            detail = "Doğadan sanata, minimalden uzaya kadar yüksek kaliteli koleksiyonları keşfet.",
            kind = 1
        ),
        OnboardingPage(
            title = "Kategorilerle Kolay Keşfet",
            text = "İstediğin tarzı kolayca bul",
            detail = "Doğa, şehir, uzay, anime, minimal ve daha fazlası tek yerde.",
            kind = 2
        ),
        OnboardingPage(
            title = "Kişiselleştir",
            text = "Kendi koleksiyonunu oluştur",
            detail = "Favorilerini kaydet, koleksiyonlarını oluştur ve deneyimini kendine göre şekillendir.",
            kind = 3
        ),
        OnboardingPage(
            title = "Keşfet ve İlham Al",
            text = "Dünyayı Renklendir",
            detail = "Güzellik her yerde. Şimdi kendi tarzını WXTRA ile yansıt.",
            kind = 4
        )
    )
    val listState = rememberLazyListState()
    val density = LocalDensity.current
    val pageWidthPx = with(density) { 360.dp.roundToPx() }
    val currentPage by remember {
        derivedStateOf {
            val first = listState.firstVisibleItemIndex
            val offset = listState.firstVisibleItemScrollOffset
            if (offset > pageWidthPx / 2) (first + 1).coerceAtMost(pages.lastIndex) else first.coerceIn(0, pages.lastIndex)
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFFF8F7FF))) {
        Image(
            painter = painterResource(R.drawable.wxtra_app_background),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.60f)))

        LazyRow(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(0.dp),
            horizontalArrangement = Arrangement.spacedBy(0.dp),
            userScrollEnabled = true
        ) {
            items(pages.size) { index ->
                OnboardingPageView(
                    page = pages[index],
                    modifier = Modifier.fillParentMaxWidth()
                )
            }
        }

        TextButton(
            onClick = onFinished,
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 28.dp, end = 18.dp)
        ) {
            Text(T("Atla"), color = Color(0xFF6D35D8), fontWeight = FontWeight.SemiBold)
        }

        Row(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 32.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            pages.indices.forEach { i ->
                Box(
                    Modifier
                        .padding(horizontal = 4.dp)
                        .size(if (i == currentPage) 22.dp else 8.dp, 8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (i == currentPage) Color(0xFF7B3FF2) else Color(0xFFBDB4D9))
                )
            }
        }

        if (currentPage == pages.lastIndex) {
            Button(
                onClick = onFinished,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 70.dp)
                    .fillMaxWidth(0.78f)
                    .height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7B3FF2))
            ) {
                Text(T("Hemen Başla  →"), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            Text(
                T("Sağa kaydırarak devam et"),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 70.dp),
                color = Color(0xFF777084),
                fontSize = 13.sp
            )
        }
    }
}

private data class OnboardingPage(
    val title: String,
    val text: String,
    val detail: String,
    val kind: Int
)

@Composable
private fun OnboardingPageView(page: OnboardingPage, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .padding(horizontal = 28.dp, vertical = 70.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(26.dp))
        when (page.kind) {
            0 -> {
                Image(
                    painter = painterResource(R.mipmap.ic_launcher),
                    contentDescription = "WXTRA",
                    modifier = Modifier.size(150.dp).clip(RoundedCornerShape(36.dp))
                )
                Spacer(Modifier.height(24.dp))
                Text(T("WXTRA"), fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF23104D), letterSpacing = 5.sp)
                Text(T("DUVAR KÂĞITLARI"), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF7B3FF2), letterSpacing = 2.sp)
            }
            else -> OnboardingIllustration(page.kind)
        }
        Spacer(Modifier.height(34.dp))
        Text(T(page.title), fontSize = 27.sp, lineHeight = 33.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF171326), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(T(page.text), fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF6D35D8), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(T(page.detail), fontSize = 15.sp, lineHeight = 22.sp, color = Color(0xFF706A82), textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth(0.88f))
        Spacer(Modifier.weight(1f))
        Text(T("Güzellik Her Yerde"), fontSize = 24.sp, fontWeight = FontWeight.Medium, color = Color(0xFF6D35D8))
        Spacer(Modifier.height(35.dp))
    }
}

@Composable
private fun OnboardingIllustration(kind: Int) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(290.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(Color.White.copy(alpha = 0.52f))
            .border(1.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(32.dp)),
        contentAlignment = Alignment.Center
    ) {
        when (kind) {
            1 -> Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(3) {
                    Box(
                        Modifier.size(92.dp, 190.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(Card)
                    )
                }
            }
            2 -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                listOf("Doğa", "Şehir", "Uzay", "Anime").chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                        row.forEach { label ->
                            Box(Modifier.size(130.dp, 76.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFFE8DEFF)), contentAlignment = Alignment.Center) {
                                Text(T(label), color = Color(0xFF4E288D), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            3 -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Favorite, null, tint = Color(0xFF7B3FF2), modifier = Modifier.size(72.dp))
                Spacer(Modifier.height(18.dp))
                listOf("Favorilerini Kaydet", "Koleksiyonlarını Oluştur", "Kendine göre keşfet").forEach {
                    Row(Modifier.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF8C58E8), modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(T(it), color = Color(0xFF2A2040), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            else -> {
                Box(
                    Modifier.size(170.dp, 235.dp)
                        .clip(RoundedCornerShape(26.dp))
                        .background(Card),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Wallpaper, null, tint = Purple, modifier = Modifier.size(48.dp))
                }
                Box(Modifier.offset(x = 70.dp, y = (-75).dp).size(58.dp).clip(CircleShape).background(Color(0xFF8B52F4)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Explore, null, tint = Color.White, modifier = Modifier.size(32.dp))
                }
            }
        }
    }
}

@Composable
private fun MainScaffold(
    selected: Int,
    onScreen: (Screen) -> Unit,
    screen: Screen,
    content: @Composable () -> Unit
) {
    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = { BottomNav(selected) { idx ->
            onScreen(when (idx) {
                0 -> Screen.Home
                1 -> Screen.Categories
                2 -> Screen.Explore
                3 -> Screen.Profile
                else -> Screen.Settings
            })
        } }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) { content() }
    }
}

@Composable
private fun TopHeader(onSearch: () -> Unit, onProfile: () -> Unit, onNotifications: () -> Unit = {}, title: String = "WXTRA", subtitle: String = "Duvar kâğıtlarını keşfet.") {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(T(title), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = TextMain, letterSpacing = 2.sp)
            Text(T(subtitle), color = TextMuted, fontSize = 13.sp)
        }
        IconButton(onClick = onSearch) { Icon(Icons.Default.Search, null, tint = TextMain) }
        IconButton(onClick = onNotifications) { Icon(Icons.Default.Notifications, null, tint = TextMain) }
        Box(Modifier.size(40.dp).clip(CircleShape).background(Accent).clickable { onProfile() }, contentAlignment = Alignment.Center) {
            Text(T("W"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun HomeScreen(
    open: (Int) -> Unit,
    openSearch: () -> Unit,
    openNotifications: () -> Unit,
    openListing: (String, List<Int>) -> Unit,
    liked: Set<Int>,
    toggleLike: (Int) -> Unit
) {
    val dynamicIndices = serverIndices()
    val popular = dynamicIndices.take(6)
    val latest = dynamicIndices.takeLast(6).asReversed().ifEmpty { dynamicIndices.take(6) }
    val forYou = dynamicIndices.sortedBy { (it * 37) % 101 }.take(6)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        // Üst başlık + arama
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "WXTRA",
                        fontSize = 29.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 4.sp,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            brush = Brush.linearGradient(listOf(Color(0xFF23163D), Color(0xFF7B3FF2), Color(0xFFB18AFF)))
                        )
                    )
                    Text(T("DAHA FAZLASINI KEŞFET"), color = TextMuted, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                IconButton(onClick = openSearch) {
                    Icon(Icons.Default.Search, contentDescription = T("Arama"), tint = TextMain, modifier = Modifier.size(25.dp))
                }
                Box {
                    IconButton(onClick = openNotifications) {
                        Icon(Icons.Default.Notifications, contentDescription = T("Bildirimler"), tint = TextMain, modifier = Modifier.size(25.dp))
                    }
                    Box(
                        Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFF4D78))
                            .align(Alignment.TopEnd).offset(x = (-5).dp, y = 5.dp)
                    )
                }
            }
        }

        // Hızlı sekmeler
        item {
            LazyRow(
                Modifier.padding(horizontal = 18.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(listOf("Senin İçin", "Popüler", "Yeni", "Ruh Hâli", "Keşfet")) { tab ->
                    Box(
                        Modifier.clip(RoundedCornerShape(50.dp))
                            .background(if (tab == "Senin İçin") Purple else Color(0xFFE9E0FF).copy(alpha = 0.96f))
                            .border(1.dp, if (tab == "Senin İçin") Purple.copy(.45f) else Purple.copy(.16f), RoundedCornerShape(50.dp))
                            .clickable {
                                when (tab) {
                                    "Popüler" -> openListing("Popüler", popular)
                                    "Yeni" -> openListing("Yeni", latest)
                                    "Ruh Hâli" -> openListing("Ruh Hâli", dynamicIndices.take(5))
                                    "Keşfet" -> openListing("Keşfet", dynamicIndices)
                                    else -> openListing("Senin İçin", forYou)
                                }
                            }
                            .padding(horizontal = 17.dp, vertical = 10.dp)
                    ) {
                        Text(T(tab), color = if (tab == "Senin İçin") Color.White else TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // Büyük Günün Önerisi
        item {
            val heroIndex = dynamicIndices[Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % dynamicIndices.size.coerceAtLeast(1)]
            Box(
                Modifier.fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 14.dp)
                    .height(318.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .clickable { open(heroIndex) }
            ) {
                WallpaperVisual(heroIndex, Modifier.fillMaxSize(), ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.88f)))
                ))
                Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                    Text("✦  ${T("Günün Önerisi")}", color = Color(0xFFD6A8FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(T("Sınırların Ötesinde"), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 31.sp)
                    Text(T("Her duvar, başka bir sen."), color = Color.White.copy(.82f), fontSize = 13.sp,
                        modifier = Modifier.padding(top = 4.dp))
                    Row(Modifier.fillMaxWidth().padding(top = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Engagement(index = heroIndex, liked = heroIndex in liked, onLike = { toggleLike(heroIndex) })
                        Spacer(Modifier.weight(1f))
                        Box(
                            Modifier.clip(RoundedCornerShape(50.dp)).background(Purple.copy(.95f))
                                .padding(horizontal = 18.dp, vertical = 10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(T("Şimdi Keşfet"), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(7.dp))
                                Icon(Icons.Default.ArrowForward, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        // Kategori kısayolları
        item {
            LazyRow(
                Modifier.padding(horizontal = 18.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(if (remoteCategories.isNotEmpty()) remoteCategories.map { it.name } else listOf("Doğa", "Şehir", "Minimal", "Anime", "Araçlar", "Uzay", "Sanat", "Karanlık")) { cat ->
                    val category = remoteCategories.firstOrNull { it.name == cat }
                    val cleanCat = cat.removePrefix("🌿 ").removePrefix("🏙 ").removePrefix("◐ ").removePrefix("🎮 ").removePrefix("🚗 ").removePrefix("🪐 ").removePrefix("🎨 ").removePrefix("◑ ")
                    val catIndices = if (category != null) remoteWallpapers.mapIndexedNotNull { idx, image -> if (image.category.equals(category.slug, true) || image.category.equals(category.name, true)) idx else null } else dynamicIndices.take(3)
                    Box(
                        Modifier.clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.82f))
                            .border(1.dp, Purple.copy(.14f), RoundedCornerShape(16.dp))
                            .clickable { openListing(cleanCat, catIndices) }
                            .padding(horizontal = 14.dp, vertical = 11.dp)
                    ) {
                        Text(T(cleanCat), color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        item {
            SectionTitle("🔥  Popüler Şu An", "Tümünü Gör") {
                openListing("Popüler Şu An", popular)
            }
        }
        item { WallpaperRow(popular, open, liked, toggleLike) }

        // İki keşif kartı
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    Modifier.weight(1f).height(132.dp).clip(RoundedCornerShape(22.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF102F2A), Color(0xFF251344))))
                        .padding(15.dp)
                ) {
                    Column {
                        Text(T("Ruh Hâli"), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(T("Nasıl hissediyorsan\nona uygun dünyayı keşfet."), color = TextMuted, fontSize = 10.sp,
                            modifier = Modifier.padding(top = 6.dp))
                        Text(T("Ruh Hâlini Seç  →"), color = Color(0xFFD6A8FF), fontSize = 10.sp,
                            fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                    }
                }
                Box(
                    Modifier.weight(1f).height(132.dp).clip(RoundedCornerShape(22.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF29104C), Color(0xFF161A38))))
                        .padding(15.dp)
                ) {
                    Column {
                        Text(T("Günün Koleksiyonu"), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(T("Özenle seçilmiş\nözel duvar kâğıtları."), color = TextMuted, fontSize = 10.sp,
                            modifier = Modifier.padding(top = 6.dp))
                        Text(T("Koleksiyona Git  →"), color = Color(0xFFD6A8FF), fontSize = 10.sp,
                            fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                    }
                }
            }
        }

        item {
            SectionTitle("✨  Senin İçin Seçtiklerimiz", "Tümünü Gör") {
                openListing("Senin İçin Seçtiklerimiz", forYou)
            }
        }
        item { WallpaperRow(forYou, open, liked, toggleLike) }

        item {
            SectionTitle("📁  Kategorilerde Keşfet", "Tümünü Gör") {
                openListing("Kategorilerde Keşfet", dynamicIndices)
            }
        }
        item {
            LazyRow(
                Modifier.padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(dynamicIndices.take(5)) { i ->
                    Box(
                        Modifier.width(150.dp).height(92.dp).clip(RoundedCornerShape(17.dp))
                    ) {
                        WallpaperVisual(i, Modifier.fillMaxSize(), ContentScale.Crop)
                        Box(Modifier.fillMaxSize().background(Color.Black.copy(.34f)))
                        Text(
                            T(remoteWallpapers.getOrNull(i)?.title?.ifBlank { remoteWallpapers.getOrNull(i)?.category ?: "WXTRA" } ?: "WXTRA"),
                            color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.BottomStart).padding(10.dp)
                        )
                    }
                }
            }
        }

        item {
            Box(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp)
                    .height(78.dp).clip(RoundedCornerShape(20.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF26104D), Color(0xFF4C1680))))
                    .padding(horizontal = 18.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(T("💎"), fontSize = 25.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(T("Premium İçerikleri Keşfet"), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(T("Özel koleksiyonlar, 4K içerikler ve daha fazlası…"), color = TextMuted, fontSize = 9.sp)
                    }
                    Text(T("Daha Fazla  →"), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            SectionTitle("🕘  En Yeni Duvar Kâğıtları", "Tümünü Gör") {
                openListing("En Yeni Duvar Kâğıtları", latest)
            }
        }
        item { WallpaperRow(latest, open, liked, toggleLike) }

        item {
            SectionTitle("❤️  Ruh Hâline Göre", "Tümünü Gör") {
                openListing("Ruh Hâline Göre", dynamicIndices.take(5))
            }
        }
        item {
            LazyRow(
                Modifier.padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(dynamicIndices.take(5)) { i ->
                    Box(Modifier.width(126.dp).height(100.dp).clip(RoundedCornerShape(18.dp))) {
                        WallpaperVisual(i, Modifier.fillMaxSize(), ContentScale.Crop)
                        Box(Modifier.fillMaxSize().background(Color.Black.copy(.28f)))
                        Text(
                            T(remoteWallpapers.getOrNull(i)?.title?.ifBlank { remoteWallpapers.getOrNull(i)?.category ?: "WXTRA" } ?: "WXTRA"),
                            color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.BottomStart).padding(9.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeTwoColumnRow(
    indices: List<Int>,
    open: (Int) -> Unit,
    liked: Set<Int>,
    toggleLike: (Int) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        indices.take(2).forEach { i ->
            ImageCard(
                index = i,
                open = open,
                liked = i in liked,
                onLike = { toggleLike(i) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun Engagement(index: Int, liked: Boolean, onLike: () -> Unit) {
    val baseLikes = 180 + (index * 73) % 820
    val views = 1200 + (index * 947) % 9800
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Row(
            Modifier
                .clip(RoundedCornerShape(50.dp))
                .background(Color.Black.copy(.48f))
                .clickable { onLike() }
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                T("Beğen"),
                tint = if (liked) Color(0xFFFF4D72) else Color.White,
                modifier = Modifier.size(15.dp)
            )
            Spacer(Modifier.width(4.dp))
            Text(
                compactNumber(baseLikes + if (liked) 1 else 0),
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
        Row(
            Modifier
                .clip(RoundedCornerShape(50.dp))
                .background(Color.Black.copy(.48f))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Visibility,
                T("Görüntülenme"),
                tint = Color.White,
                modifier = Modifier.size(15.dp)
            )
            Spacer(Modifier.width(4.dp))
            Text(
                compactNumber(views),
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun WallpaperRow(indices: List<Int>, open: (Int) -> Unit, liked: Set<Int>, toggleLike: (Int) -> Unit) {
    ResponsiveWallpaperGrid(indices, open, liked, toggleLike, desiredColumns = 4)
}

@Composable
private fun ResponsiveWallpaperGrid(
    indices: List<Int>,
    open: (Int) -> Unit,
    liked: Set<Int> = emptySet(),
    toggleLike: (Int) -> Unit = {},
    desiredColumns: Int = 4
) {
    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 18.dp)) {
        val columns = when {
            maxWidth < 300.dp -> 1
            else -> minOf(layoutColumns(), desiredColumns.coerceIn(1, 4))
        }
        val gap = 10.dp
        Column(verticalArrangement = Arrangement.spacedBy(gap)) {
            indices.chunked(columns).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    row.forEach { i ->
                        ImageCard(
                            index = i,
                            open = open,
                            liked = i in liked,
                            onLike = { toggleLike(i) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(T(title), color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        action?.let { Text(T(it), color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onAction?.invoke() }) }
    }
}

@Composable
private fun SearchBar(value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier, readOnly: Boolean = false) {
    OutlinedTextField(value = value, onValueChange = onValue, readOnly = readOnly, modifier = modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text(T("Duvar kağıdı ara…")) }, colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Card, focusedContainerColor = Card2, unfocusedBorderColor = Color.Transparent, focusedBorderColor = Purple))
}

@Composable
private fun Pill(text: String, selected: Boolean = false) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(if (selected) Purple else Card2).padding(horizontal = 16.dp, vertical = 10.dp)) { Text(T(text), color = Color.White, fontSize = 12.sp) }
}

@Composable
private fun ChipRow(
    chips: List<String>,
    onSelect: (String) -> Unit,
    selected: String = chips.firstOrNull().orEmpty()
) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        chips.forEach { chip ->
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (chip == selected) Purple else Color(0xFFE9E0FF).copy(alpha = 0.96f))
                    .border(1.dp, if (chip == selected) Purple.copy(.5f) else Purple.copy(.14f), RoundedCornerShape(50))
                    .clickable { onSelect(chip) }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(T(chip), color = if (chip == selected) Color.White else TextMain, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun CategoryTile(index: Int, title: String, modifier: Modifier, open: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(18.dp)).clickable { open() }) {
        WallpaperVisual(index, Modifier.fillMaxSize(), ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.7f)))))
        Text(T(title), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomStart).padding(12.dp))
    }
}

@Composable
private fun ProfileAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp).clip(RoundedCornerShape(16.dp)).background(Card).clickable { onClick() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = TextMain)
        Text(T(title), color = TextMain, modifier = Modifier.weight(1f).padding(start = 14.dp))
        Icon(Icons.Default.ArrowForward, null, tint = TextMuted)
    }
}

@Composable
private fun SettingsSection(title: String, items: List<String>) {
    Text(T(title), color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp))
    if (items.isNotEmpty()) SettingsRow(items[0])
    if (items.size > 1) SettingsRow(items[1])
    if (items.size > 2) SettingsRow(items[2])
    if (items.size > 3) SettingsRow(items[3])
} 

@Composable
private fun SettingsRow(item: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(Card).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(T(item), color = TextMain, modifier = Modifier.weight(1f)); Text(T("›"), color = TextMuted)
    }
}

@Composable
private fun CollectionCard(title: String, index: Int, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp).clip(RoundedCornerShape(18.dp)).background(Card).clickable { onClick() }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        WallpaperVisual(index, Modifier.size(74.dp).clip(RoundedCornerShape(14.dp)), ContentScale.Crop)
        Column(Modifier.padding(start = 12.dp)) { Text(T(title), color = TextMain, fontWeight = FontWeight.Bold); Text(T("Sizin için özel seçildi."), color = TextMuted, fontSize = 12.sp) }
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(T(value), color = TextMain, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(T(label), color = TextMuted, fontSize = 11.sp) }
}

@Composable
private fun TopBar(title: String, back: () -> Unit) {
    // Navigation is handled by Android/system back; no visual back arrow is shown.
    Row(
        Modifier.fillMaxWidth()
            .padding(horizontal = 18.dp)
            .padding(top = 28.dp)
            .padding(bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            T(title),
            color = TextMain,
            fontSize = 27.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.weight(1f)
        )
        Image(
            painter = painterResource(com.wextra.app.R.mipmap.ic_launcher),
            contentDescription = null,
            modifier = Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)),
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xF7FFFFFF), tonalElevation = 3.dp) {
        NavigationBarItem(
            selected = selected == 0,
            onClick = { onSelect(0) },
            icon = { Icon(Icons.Default.Home, null) },
            label = { Text(L("Anasayfa", "Home")) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 1,
            onClick = { onSelect(1) },
            icon = { Icon(Icons.Default.Wallpaper, null) },
            label = { Text(L("Kategori", "Categories")) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 2,
            onClick = { onSelect(2) },
            icon = { Icon(Icons.Default.Explore, null) },
            label = { Text(L("Keşfet", "Explore")) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 3,
            onClick = { onSelect(3) },
            icon = { Icon(Icons.Default.Person, null) },
            label = { Text(L("Profil", "Profile")) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 4,
            onClick = { onSelect(4) },
            icon = { Icon(Icons.Default.Settings, null) },
            label = { Text(L("Ayarlar", "Settings")) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
    }
}

@Composable
private fun ImageCard(
    index: Int,
    open: (Int) -> Unit,
    liked: Boolean,
    onLike: () -> Unit,
    modifier: Modifier = Modifier
) {
    val baseLikes = 180 + (index * 73) % 820
    val views = 1200 + (index * 947) % 9800

    BoxWithConstraints(
        modifier
            .aspectRatio(layoutAspectRatio())
            .clip(RoundedCornerShape(16.dp))
            .clickable { open(index) }
    ) {
        val compact = maxWidth < 112.dp
        val iconSize = if (compact) 12.dp else 15.dp
        val textSize = if (compact) 8.sp else 10.sp
        val statHorizontal = if (compact) 5.dp else 8.dp
        val statVertical = if (compact) 4.dp else 6.dp
        val statGap = if (compact) 4.dp else 8.dp

        WallpaperVisual(index, Modifier.fillMaxSize(), ContentScale.Crop)
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.66f)))
            )
        )

        IconButton(
            onClick = onLike,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(all = if (compact) 1.dp else 3.dp)
                .size(if (compact) 28.dp else 36.dp)
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(Color.Black.copy(.34f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = T("Beğen"),
                    tint = if (liked) Color(0xFFFF4D72) else Color.White,
                    modifier = Modifier.size(if (compact) 14.dp else 18.dp)
                )
            }
        }

        Row(
            Modifier
                .align(Alignment.BottomStart)
                .padding(all = if (compact) 6.dp else 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(statGap)
        ) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(50.dp))
                    .background(Color.Black.copy(.52f))
                    .padding(horizontal = statHorizontal, vertical = statVertical),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Favorite,
                    null,
                    tint = Color.White,
                    modifier = Modifier.size(iconSize)
                )
                Spacer(Modifier.width(if (compact) 2.dp else 4.dp))
                Text(
                    compactNumber(baseLikes + if (liked) 1 else 0),
                    color = Color.White,
                    fontSize = textSize,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
            }
            Row(
                Modifier
                    .clip(RoundedCornerShape(50.dp))
                    .background(Color.Black.copy(.52f))
                    .padding(horizontal = statHorizontal, vertical = statVertical),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Visibility,
                    null,
                    tint = Color.White,
                    modifier = Modifier.size(iconSize)
                )
                Spacer(Modifier.width(if (compact) 2.dp else 4.dp))
                Text(
                    compactNumber(views),
                    color = Color.White,
                    fontSize = textSize,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
            }
        }
    }
}

private fun compactNumber(value: Int): String = when {
    value >= 1000000 -> String.format(java.util.Locale.US, "%.1fM", value / 1000000f)
    value >= 1000 -> String.format(java.util.Locale.US, "%.1fK", value / 1000f)
    else -> value.toString()
}

@Composable
private fun CollectionHomeCard(index: Int, title: String, open: (Int) -> Unit) {
    Box(Modifier.width(210.dp).height(120.dp).clip(RoundedCornerShape(18.dp)).clickable { open(index) }) {
        WallpaperVisual(index, Modifier.fillMaxSize(), ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.8f)))))
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            Text(T(title), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(T("Özel seçki"), color = Color.White.copy(.75f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun ExploreImageRow(indices: List<Int>, open: (Int) -> Unit, columns: Int, liked: Set<Int> = emptySet(), toggleLike: (Int) -> Unit = {}) {
    // Bölüm kartları uygulamadaki ortak Görünüm Dizilimi ayarını takip eder.
    ResponsiveWallpaperGrid(indices, open, liked, toggleLike, desiredColumns = 4)
}

@Composable
private fun ExploreScreen(
    open: (Int) -> Unit,
    openCategories: () -> Unit,
    openSearch: () -> Unit,
    openNotifications: () -> Unit,
    openListing: (String, List<Int>) -> Unit,
    liked: Set<Int>,
    toggleLike: (Int) -> Unit,
    recentlyViewed: List<Int>
) {
    val exploreLiked = liked
    var activeFilter by remember { mutableStateOf("Trend") }
    val filters = listOf(
        "🔥 Trend", "✨ Minimal", "🌙 AMOLED", "🌿 Doğa", "🚗 Araba",
        "🪐 Uzay", "🎨 Sanat", "🌃 Gece", "🏙️ Şehir", "🤖 Anime"
    )
    val filterKeys = filters.map { it.substringAfter(" ") }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(166.dp)
                    .clip(RoundedCornerShape(bottomStart = 30.dp, bottomEnd = 30.dp))
            ) {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Purple.copy(.82f), Bg.copy(.98f)))))
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(T("Keşfet"), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text(T("Sıradan duvar kâğıtlarının ötesine geç."), color = Color.White.copy(.78f), fontSize = 13.sp)
                    }
                    IconButton(onClick = openNotifications) {
                        Icon(Icons.Default.Notifications, null, tint = Color.White)
                    }
                }
                Text(
                    T("Daha fazlası seni bekliyor..."),
                    color = Color.White.copy(.82f),
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp)
                )
            }
        }
        item {
            LazyRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                items(filters) { filter ->
                    val key = filter.substringAfter(" ")
                    FilterChip(
                        selected = activeFilter == key,
                        onClick = { activeFilter = key },
                        label = { Text(T(filter), maxLines = 1) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Purple,
                            selectedLabelColor = Color.White,
                            containerColor = Card,
                            labelColor = TextMain
                        )
                    )
                }
            }
        }
        item {
            ExploreSectionHeader("👑 Günün Seçimi", "Özel olarak seçildi") { openListing("👑 Günün Seçimi", serverIndices()) }
            Box(
                Modifier.padding(horizontal = 18.dp).fillMaxWidth().height(210.dp)
                    .clip(RoundedCornerShape(24.dp)).clickable { open(2) }
            ) {
                WallpaperVisual(2, Modifier.fillMaxSize(), ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(.82f), Color.Transparent))))
                Column(Modifier.align(Alignment.CenterStart).padding(18.dp).widthIn(max = 245.dp)) {
                    Text(T("GÜNÜN ÖNERİSİ"), color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(T("Huzurun Adresi"), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 4.dp))
                    Text(T("Doğanın en güzel tonları, şimdi ekranında."), color = Color.White.copy(.82f), fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                    Button(onClick = { open(2) }, modifier = Modifier.padding(top = 12.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                        Text(T("Duvar Kâğıdını Aç"), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            ExploreSectionHeader("❤️ Senin İçin", "Beğenilerine göre") { openListing("❤️ Senin İçin", serverIndices()) }
            ExploreImageRow(listOf(4, 3, 0, 5, 7, 8), open, 5, exploreLiked, toggleLike)
        }
        item {
            ExploreSectionHeader("🔥 Popüler Şu An", "En çok beğenilenler") { openListing("🔥 Popüler Şu An", serverIndices()) }
            ExploreImageRow(listOf(4, 3, 5), open, 3, exploreLiked, toggleLike)
        }
        item {
            ExploreSectionHeader("📈 Yükselişte", "Son günlerde hızla popüler") { openListing("📈 Yükselişte", serverIndices()) }
            ExploreImageRow(listOf(7, 3, 5, 2), open, 4, exploreLiked, toggleLike)
        }
        item {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ExploreFeatureCard(
                    title = "👑 Haftanın Koleksiyonu",
                    subtitle = "Özel seçilmiş 24 duvar kâğıdı",
                    button = "Koleksiyonu Keşfet",
                    index = 3,
                    modifier = Modifier.weight(1f),
                    open = open
                )
                ExploreFeatureCard(
                    title = "🎲 Rastgele Keşfet",
                    subtitle = "Her açılışta yeni bir sürpriz",
                    button = "Karıştır",
                    index = 7,
                    modifier = Modifier.weight(1f),
                    open = open
                )
            }
        }
        item {
            ExploreSectionHeader("✨ Yeni Gelenler", "En yeni içerikler") { openListing("✨ Yeni Gelenler", serverIndices()) }
            ExploreImageRow(listOf(0, 6, 7, 8, 1), open, 5, exploreLiked, toggleLike)
        }
        item {
            ExploreSectionHeader("👥 Topluluk Favorileri", "Kullanıcıların seçtikleri") { openListing("👥 Topluluk Favorileri", serverIndices()) }
            ExploreImageRow(serverIndices().take(5), open, 5, exploreLiked, toggleLike)
        }
        item {
            ExploreSectionHeader("🎨 Tarzına Göre", "Bir kategori seç") { openListing("🎨 Tarzına Göre", serverIndices()) }
            LazyRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(serverIndices().take(7).mapIndexed { idx, i -> i to remoteWallpapers.getOrNull(i)?.category ?: "WXTRA" }) { item ->
                    CategoryTile(item.first, item.second, Modifier.size(width = 118.dp, height = 96.dp)) { open(item.first) }
                }
            }
        }
        item {
            ExploreSectionHeader("🎨 Renge Göre", "Ruhuna uygun rengi seç") { openListing("🎨 Renge Göre", serverIndices()) }
            LazyRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(listOf(
                    "Mor" to Purple, "Mavi" to Blue, "Kırmızı" to Color(0xFFE84A5F),
                    "Yeşil" to Color(0xFF4CAF7A), "Siyah" to Color(0xFF111111), "Beyaz" to Color(0xFFF2F2F2)
                )) { item ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(68.dp)) {
                        Box(Modifier.size(48.dp).clip(CircleShape).background(item.second).clickable {
                            val idx = when (item.first) { "Mor" -> 7; "Mavi" -> 0; "Kırmızı" -> 1; "Yeşil" -> 2; "Siyah" -> 4; else -> 3 }
                            if (idx in serverIndices()) open(idx)
                        })
                        Text(T(item.first), color = TextMain, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }
        }
        item {
            ExploreSectionHeader("📱 Cihazına Özel", "Ekranına tam oturanlar") { openListing("📱 Cihazına Özel", serverIndices()) }
            ExploreImageRow(serverIndices().take(4), open, 4, exploreLiked, toggleLike)
        }
        item {
            ExploreSectionHeader("🗓️ Günlük Seri", "Her gün yeni tema") { openListing("🗓️ Günlük Seri", serverIndices()) }
            LazyRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(listOf("Pzt · Minimal", "Sal · AMOLED", "Çar · Doğa", "Per · Araba", "Cum · Uzay", "Cmt · Anime", "Paz · Özel")) { day ->
                    Surface(shape = RoundedCornerShape(16.dp), color = Card2, modifier = Modifier.clickable {
                            val idx = when { day.contains("Minimal") -> 7; day.contains("AMOLED") -> 4; day.contains("Doğa") -> 2; day.contains("Araba") -> 3; day.contains("Uzay") -> 0; day.contains("Anime") -> 8; else -> 6 }
                            if (idx in serverIndices()) open(idx)
                        }) {
                        Text(T(day), color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 13.dp))
                    }
                }
            }
        }
        item {
            ExploreSectionHeader("👀 Son Görüntülediklerin", "Kaldığın yerden devam et") { openListing("👀 Son Görüntülediklerin", if (recentlyViewed.isEmpty()) serverIndices() else recentlyViewed.filter { it in serverIndices() }) }
            ExploreImageRow(if (recentlyViewed.isEmpty()) serverIndices().takeLast(4) else recentlyViewed.filter { it in serverIndices() }, open, 4, exploreLiked, toggleLike)
        }
        item {
            Box(Modifier.padding(horizontal = 18.dp, vertical = 12.dp).fillMaxWidth().height(86.dp).clip(RoundedCornerShape(20.dp)).background(Accent).clickable(enabled = wallpaperCount() > 0) { open((System.currentTimeMillis() % wallpaperCount().coerceAtLeast(1)).toInt()) }) {
                Row(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(T("Sonsuz Keşif"), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text(T("Aşağı indikçe daha fazlası gelir."), color = Color.White.copy(.8f), fontSize = 11.sp)
                    }
                    Icon(Icons.Default.ArrowForward, null, tint = Color.White)
                }
            }
        }
    }
}

@Composable
private fun ExploreSectionHeader(title: String, subtitle: String, onClick: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp).then(if (onClick != null) Modifier.clickable { onClick() } else Modifier), verticalAlignment = Alignment.Bottom) {
        Column(Modifier.weight(1f)) {
            Text(T(title), color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
            Text(T(subtitle), color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
        }
        Text(T("Tümünü Gör  →"), color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ExploreFeatureCard(
    title: String,
    subtitle: String,
    button: String,
    index: Int,
    modifier: Modifier,
    open: (Int) -> Unit
) {
    Box(modifier.height(190.dp).clip(RoundedCornerShape(20.dp)).clickable { open(index) }) {
        WallpaperVisual(index, Modifier.fillMaxSize(), ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(.15f), Color.Black.copy(.86f)))))
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.Bottom) {
            Text(T(title), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            Text(T(subtitle), color = Color.White.copy(.72f), fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
            Surface(color = Purple, shape = RoundedCornerShape(12.dp), modifier = Modifier.padding(top = 10.dp)) {
                Text(T(button), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp))
            }
        }
    }
}

@Composable
private fun FavoritesScreen(liked: Set<Int>, open: (Int) -> Unit, toggleLike: (Int) -> Unit, back: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar(L("Favoriler","Favorites"), back) }
        if (liked.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(50.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FavoriteBorder, null, tint = Purple, modifier = Modifier.size(54.dp))
                    Text(T("Henüz favorin yok"), color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp))
                    Text(T("Beğendiğin duvar kâğıtları burada görünecek."), color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        } else {
            item {
                LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 108.dp), modifier = Modifier.height(560.dp), contentPadding = PaddingValues(18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    gridItems(liked.toList()) { i -> ImageCard(i, open, true, { toggleLike(i) }, Modifier.fillMaxWidth()) }
                }
            }
        }
    }
}


private const val WXTRA_GOOGLE_WEB_CLIENT_ID = "YOUR_WEB_CLIENT_ID.apps.googleusercontent.com"

private fun generateGoogleNonce(): String {
    val bytes = ByteArray(32)
    SecureRandom().nextBytes(bytes)
    return Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
}

private suspend fun signInWithGoogle(context: Context): Result<JSONObject> {
    try {
        if (WXTRA_GOOGLE_WEB_CLIENT_ID.startsWith("YOUR_")) {
            return Result.failure(IllegalStateException("Google Client ID henüz ayarlanmadı"))
        }
        val manager = CredentialManager.create(context)
        val option = GetSignInWithGoogleOption.Builder(WXTRA_GOOGLE_WEB_CLIENT_ID)
            .setNonce(generateGoogleNonce())
            .build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(option)
            .build()
        val response = manager.getCredential(context, request)
        val credential = response.credential
        if (credential !is CustomCredential || credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            return Result.failure(IllegalStateException("Google kimlik bilgisi alınamadı"))
        }
        val googleCredential = try {
            GoogleIdTokenCredential.createFrom(credential.data)
        } catch (e: GoogleIdTokenParsingException) {
            return Result.failure(IllegalStateException("Google kimlik bilgisi okunamadı", e))
        }

        return withContext(Dispatchers.IO) {
            val connection = (URL("$WXTRA_API_BASE/auth/google").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 20000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
            }
            val body = JSONObject()
                .put("idToken", googleCredential.idToken)
                .put("termsAccepted", true)
                .put("termsVersion", "1.0")
                .toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                Result.failure(IllegalStateException("Sunucu Google girişini reddetti ($code)"))
            } else {
                Result.success(JSONObject(text))
            }
        }
    } catch (e: Exception) {
        return Result.failure(e)
    }
}

@Composable
private fun ProfileAuthScreen(
    onGoogle: suspend () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("wxtra_profile", Context.MODE_PRIVATE) }
    var googleBusy by remember { mutableStateOf(false) }
    var googleError by remember { mutableStateOf("") }
    var termsAccepted by remember { mutableStateOf(prefs.getBoolean("terms_accepted_v1", false)) }
    var showTerms by remember { mutableStateOf(false) }

    // Google ile devam etmeden önce kullanıcı koşullarının açıkça kabul edilmesi gerekir.
    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.wxtra_app_background),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.52f)))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 22.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.mipmap.ic_launcher),
                contentDescription = "WXTRA",
                modifier = Modifier.size(104.dp).clip(RoundedCornerShape(30.dp)),
                contentScale = ContentScale.Crop
            )
            Text(
                T("WXTRA'ya Hoş Geldin"),
                color = TextMain,
                fontSize = 27.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 18.dp)
            )
            Text(
                T("Profilini görmek, favorilerini ve koleksiyonlarını kaydetmek için Google hesabınla devam et."),
                color = TextMuted,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)
            )
            Spacer(Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth().clickable {
                    termsAccepted = !termsAccepted
                    prefs.edit().putBoolean("terms_accepted_v1", termsAccepted).apply()
                },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = termsAccepted,
                    onCheckedChange = {
                        termsAccepted = it
                        prefs.edit().putBoolean("terms_accepted_v1", it).apply()
                    },
                    colors = CheckboxDefaults.colors(checkedColor = Purple)
                )
                Text(
                    T("Kullanım Koşulları'nı kabul ediyorum"),
                    color = TextMain,
                    fontSize = 13.sp,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { showTerms = true }) {
                    Text(T("Oku"), color = Purple, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    if (!termsAccepted || googleBusy) return@Button
                    googleBusy = true
                    googleError = ""
                    scope.launch {
                        try { onGoogle() } catch (e: Exception) { googleError = e.message ?: T("Google ile giriş başarısız") } finally { googleBusy = false }
                    }
                },
                enabled = termsAccepted && !googleBusy,
                modifier = Modifier.fillMaxWidth().height(58.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Purple,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(18.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
            ) {
                Text(T("G"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(12.dp))
                Text(T("Google ile devam et"), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            if (googleError.isNotBlank()) {
                Text(googleError, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
            }
            Text(
                T(if (termsAccepted) "Sadece bir dokunuş yeter • Profilin bu cihazda korunur" else "Devam etmek için kullanım koşullarını kabul et"),
                color = TextMuted,
                fontSize = 11.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(top = 14.dp)
            )
        }
    }

    if (showTerms) {
        AlertDialog(
            onDismissRequest = { showTerms = false },
            title = { Text(T("Kullanım Koşulları"), color = TextMain, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(T("Hesabını güvenli kullanmalı ve giriş bilgilerini paylaşmamalısın."), color = TextMuted)
                    Text(T("Uygulamadaki içerikleri yalnızca yasal ve kişisel kullanım amaçlarıyla kullanmalısın."), color = TextMuted)
                    Text(T("Gizlilik ve veri kullanımı hakkında ayrıntılar için Gizlilik Politikası bölümünü inceleyebilirsin."), color = TextMuted)
                    Text(T("Kabul ederek bu koşulları okuduğunu ve kabul ettiğini onaylarsın."), color = TextMain, fontWeight = FontWeight.Medium)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    termsAccepted = true
                    prefs.edit().putBoolean("terms_accepted_v1", true).apply()
                    showTerms = false
                }) { Text(T("Kabul Et"), color = Purple) }
            },
            dismissButton = {
                TextButton(onClick = { showTerms = false }) { Text(T("Kapat"), color = TextMuted) }
            },
            containerColor = Card2
        )
    }
}

@Composable
private fun ProfileScreen(
    liked: Set<Int>,
    setLiked: (Set<Int>) -> Unit,
    recentlyViewed: List<Int>,
    openFavorites: () -> Unit,
    openCollections: () -> Unit,
    openRecentlyViewed: () -> Unit,
    openAbout: () -> Unit,
    openSettings: () -> Unit,
    openAdmin: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("wxtra_profile", Context.MODE_PRIVATE) }

    var signedIn by remember { mutableStateOf(prefs.getBoolean("signedIn_v2", false)) }
    var accountEmail by remember { mutableStateOf(prefs.getString("email", "") ?: "") }
    var displayName by remember { mutableStateOf(prefs.getString("name", "wextra") ?: "wextra") }
    var username by remember { mutableStateOf(prefs.getString("username", "wextra") ?: "wextra") }
    var avatarIndex by remember { mutableStateOf(prefs.getInt("avatar", 0).coerceIn(0, profileAvatars.lastIndex)) }

    var showLogin by remember { mutableStateOf(false) }
    var showEditProfile by remember { mutableStateOf(false) }
    var showAvatarPicker by remember { mutableStateOf(false) }
    var showBackupInfo by remember { mutableStateOf(false) }
    var showSecurityInfo by remember { mutableStateOf(false) }
    var showStorageInfo by remember { mutableStateOf(false) }
    var showBackupSettings by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showProInfo by remember { mutableStateOf(false) }
    var backupDone by remember { mutableStateOf(prefs.getBoolean("backup_done", false)) }
    var adminUnlocked by remember { mutableStateOf(prefs.getBoolean("admin_unlocked", false)) }

    fun saveProfile() {
        prefs.edit()
            .putBoolean("signedIn_v2", signedIn)
            .putBoolean("signedIn", signedIn)
            .putString("email", accountEmail)
            .putString("name", displayName)
            .putString("username", username)
            .putInt("avatar", avatarIndex)
            .apply()
    }


    if (!signedIn) {
        ProfileAuthScreen(
            onGoogle = {
                val result = signInWithGoogle(context)
                result.getOrElse { throw it }.let { payload ->
                    signedIn = true
                    accountEmail = payload.optString("email", "Google hesabı")
                    displayName = payload.optString("name", displayName)
                    username = payload.optString("username", username)
                    saveProfile()
                }
            }
        )
        return
    }

    if (showLogin) {
        AlertDialog(
            onDismissRequest = { showLogin = false },
            title = { Text(T("Hesap bağlantısı"), color = TextMain) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(T("Profilini ve favorilerini bu cihazda yönetebilirsin. Google hesabı bağlantısı bu sürümde yerel profil oturumu olarak tutulur."), color = TextMuted)
                    Text(T("Bağlı hesap: $accountEmail"), color = TextMain, fontWeight = FontWeight.Medium)
                }
            },
            confirmButton = { TextButton(onClick = { showLogin = false }) { Text(T("Tamam"), color = Purple) } },
            containerColor = Card2
        )
    }

    if (showEditProfile) {
        AlertDialog(
            onDismissRequest = { showEditProfile = false },
            title = { Text(T("Profili düzenle"), color = TextMain) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = displayName, onValueChange = { displayName = it }, label = { Text(T("Ad")) }, singleLine = true)
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it.filter { c -> c.isLetterOrDigit() || c == '_' } },
                        label = { Text(T("Kullanıcı adı")) },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { saveProfile(); showEditProfile = false }) { Text(T("Kaydet"), color = Purple) }
            },
            dismissButton = { TextButton(onClick = { showEditProfile = false }) { Text(T("İptal"), color = TextMuted) } },
            containerColor = Card2
        )
    }

    if (showAvatarPicker) {
        AlertDialog(
            onDismissRequest = { showAvatarPicker = false },
            title = { Text(T("Profil fotoğrafını seç"), color = TextMain) },
            text = {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.height(260.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    gridItems(profileAvatars.indices.toList()) { i ->
                        Image(
                            painterResource(profileAvatars[i]),
                            null,
                            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)).clickable {
                                avatarIndex = i
                                saveProfile()
                                showAvatarPicker = false
                            },
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            },
            confirmButton = {},
            containerColor = Card2
        )
    }

    if (showBackupInfo) {
        AlertDialog(
            onDismissRequest = { showBackupInfo = false },
            title = { Text(T("Yedekleme"), color = TextMain) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(T("Profil bilgilerin, favorilerin ve uygulama tercihlerin için yerel yedek oluşturabilirsin."), color = TextMuted)
                    Text(T("Bu sürümde yedek, uygulamanın özel depolama alanında tutulur. Gerçek bulut/Drive senkronizasyonu için ayrıca sunucu ve hesap yetkilendirmesi gerekir."), color = TextMuted, fontSize = 12.sp)
                    Text(if (backupDone) T("Durum: Son yedek hazır ✓") else T("Durum: Henüz yedek oluşturulmadı"), color = if (backupDone) Purple else TextMain, fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = { TextButton(onClick = { showBackupInfo = false }) { Text(T("Tamam"), color = Purple) } },
            containerColor = Card2
        )
    }

    if (showBackupSettings) {
        AlertDialog(
            onDismissRequest = { showBackupSettings = false },
            title = { Text(T("Yedekleme ayarları"), color = TextMain) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(T("Otomatik yedekleme"), color = TextMain, fontWeight = FontWeight.Bold)
                    Text(T("Otomatik yedekleme seçeneği sunucu senkronizasyonu etkin olduğunda kullanılabilir. Bu sürümde manuel yerel yedekleme güvenle çalışır."), color = TextMuted)
                    Text(T("Yedeklenecekler: profil bilgileri, favoriler ve uygulama tercihleri."), color = TextMuted, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showBackupSettings = false }) { Text(T("Tamam"), color = Purple) } },
            containerColor = Card2
        )
    }

    if (showSecurityInfo) {
        AlertDialog(
            onDismissRequest = { showSecurityInfo = false },
            title = { Text(T("Güvenlik merkezi"), color = TextMain) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(T("Profil ve uygulama tercihleri Android'in uygulamaya özel depolama alanında tutulur."), color = TextMuted)
                    Text(T("WXTRA kişisel verileri satmayı veya iznin dışında reklam amacıyla paylaşmayı amaçlamaz. Hesap senkronizasyonu eklenirse yetkilendirme ve güvenlik kontrolleri ayrıca uygulanır."), color = TextMuted, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showSecurityInfo = false }) { Text(T("Kapat"), color = Purple) } },
            containerColor = Card2
        )
    }

    if (showStorageInfo) {
        AlertDialog(
            onDismissRequest = { showStorageInfo = false },
            title = { Text(T("Depolama ve veriler"), color = TextMain) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(T("Bu cihazdaki WXTRA verileri"), color = TextMain, fontWeight = FontWeight.Bold)
                    Text(T("${liked.size} favori • Profil ayarları • ${recentlyViewed.size} son görüntülenen"), color = TextMuted)
                    Text(T("Duvar kâğıtlarını indirme alanı kullanılmaz; favoriler ve uygulama verileri yönetilir."), color = TextMuted, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showStorageInfo = false }) { Text(T("Kapat"), color = Purple) } },
            containerColor = Card2
        )
    }

    if (showProInfo) {
        AlertDialog(
            onDismissRequest = { showProInfo = false },
            title = { Text(T("WXTRA Pro"), color = TextMain, fontWeight = FontWeight.Bold) },
            text = { Text(T("WXTRA Pro; daha fazla kişiselleştirme, premium içerikler ve gelişmiş özellikler için hazırlanan ayrı bir deneyimdir."), color = TextMuted, lineHeight = 20.sp) },
            confirmButton = { TextButton(onClick = { showProInfo = false }) { Text(T("Tamam"), color = Purple) } },
            containerColor = Card2
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(T("Hesabı sil"), color = Color(0xFFFF4D5F)) },
            text = { Text(T("Bu işlem bu cihazdaki WXTRA profil bilgilerini, favorileri ve uygulama tercihlerini kaldırır. Devam etmek istiyor musun?"), color = TextMuted) },
            confirmButton = {
                TextButton(onClick = {
                    prefs.edit().clear().apply()
                    setLiked(emptySet())
                    signedIn = false
                    accountEmail = ""
                    displayName = "wextra"
                    username = "wextra"
                    showDeleteConfirm = false
                }) { Text(T("Hesabı Sil"), color = Color(0xFFFF4D5F), fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text(T("Vazgeç"), color = TextMuted) } },
            containerColor = Card2
        )
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
                    .clip(RoundedCornerShape(22.dp)).background(Card).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                    Box(
                        Modifier.size(88.dp).clip(CircleShape).background(Purple.copy(.25f)).padding(3.dp).clip(CircleShape).clickable {
                            showAvatarPicker = true
                        }
                    ) {
                        Image(painterResource(profileAvatars[avatarIndex]), T("Profil fotoğrafı"), Modifier.fillMaxSize().clip(CircleShape), contentScale = ContentScale.Crop)
                    }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(displayName, color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text(T(" ✓"), color = Purple, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(T("@$username"), color = TextMuted, fontSize = 12.sp)
                        Text(T("WXTRA Üyesi"), color = TextMuted, fontSize = 11.sp)
                    }
                    OutlinedButton(onClick = { showEditProfile = true }) {
                        Icon(Icons.Default.Edit, null, tint = Purple, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(T("Profil Düzenle"), color = Purple, fontSize = 11.sp)
                    }
                }
        }

        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                ProfileStatCard(liked.size.toString(), T("Favori"), Icons.Default.Favorite, openFavorites, Modifier.weight(1f))
                ProfileStatCard("8", T("Koleksiyon"), Icons.Default.Wallpaper, openCollections, Modifier.weight(1f))
                ProfileStatCard("0", T("Takipçi"), Icons.Default.Person, { Toast.makeText(context, T("Takipçi sistemi hesap altyapısıyla birlikte etkinleştirilecek."), Toast.LENGTH_SHORT).show() }, Modifier.weight(1f))
                ProfileStatCard("0", T("Takip"), Icons.Default.Person, { Toast.makeText(context, T("Takip sistemi hesap altyapısıyla birlikte etkinleştirilecek."), Toast.LENGTH_SHORT).show() }, Modifier.weight(1f))
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp).clip(RoundedCornerShape(20.dp)).background(Accent).clickable { showProInfo = true }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(T("✦"), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(T("WXTRA Pro"), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(T("Daha fazla özellik, daha fazla özgürlük."), color = Color.White.copy(.84f), fontSize = 11.sp)
                }
                Text(T("Sınırları Kaldır  →"), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        item { ProfileSectionTitle(T("Hızlı İşlemler"), Icons.Default.Explore) }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProfileMini("♡", T("Favorilerim")) { openFavorites() }
                ProfileMini("▣", T("Koleksiyonlarım")) { openCollections() }
                ProfileMini("◷", T("Son Görüntülenenler")) { if (recentlyViewed.isNotEmpty()) openRecentlyViewed() else showStorageInfo = true }
                ProfileMini("✎", T("Profili Düzenle")) { showEditProfile = true }
            }
        }

        item { ProfileSectionTitle(T("Cihaz ve Veri Yönetimi"), Icons.Default.CloudUpload) }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProfileDashboardCard(Icons.Default.CloudUpload, T("Yedekleme"), T("Verilerini güvenle yedekle"), Modifier.weight(1f)) { showBackupInfo = true }
                ProfileDashboardCard(Icons.Default.CloudDownload, T("Depolama"), T("Cihazdaki alanı görüntüle"), Modifier.weight(1f)) { showStorageInfo = true }
                ProfileDashboardCard(Icons.Default.Info, T("Verilerim"), T("Profil ve uygulama verilerini yönet"), Modifier.weight(1f)) { showStorageInfo = true }
            }
        }
        item {
            ProfileDashboardWide(Icons.Default.Settings, T("Yedekleme Ayarları"), T("Otomatik yedekleme, sıklık ve geri yükleme seçenekleri")) { showBackupSettings = true }
        }

        item { ProfileSectionTitle(T("Güvenlik ve Gizlilik"), Icons.Default.Lock) }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProfileDashboardCard(Icons.Default.Lock, T("Güvenlik Merkezi"), T("Hesabını ve verilerini koru"), Modifier.weight(1f)) { showSecurityInfo = true }
                ProfileDashboardCard(Icons.Default.Lock, T("Şifre ve Giriş"), T("Hesap bağlantısını yönet"), Modifier.weight(1f)) { showLogin = true }
                ProfileDashboardCard(Icons.Default.Visibility, T("Gizlilik Ayarları"), T("Veri kullanımı ve gizlilik tercihleri"), Modifier.weight(1f)) { openSettings() }
            }
        }

        item { ProfileSectionTitle(T("Bildirimler ve İzinler"), Icons.Default.Notifications) }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProfileDashboardCard(Icons.Default.Notifications, T("Bildirim Ayarları"), T("Hangi bildirimleri almak istediğini seç"), Modifier.weight(1f)) { openSettings() }
                ProfileDashboardCard(Icons.Default.Settings, T("İzinleri Yönet"), T("Uygulama izinlerini kontrol et"), Modifier.weight(1f)) { openSettings() }
            }
        }

        item { ProfileSectionTitle(T("Hesap Yönetimi"), Icons.Default.Person) }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProfileDashboardCard(Icons.Default.Person, T("Hesap Bilgileri"), T("Ad, kullanıcı adı ve bağlantı"), Modifier.weight(1f)) { showEditProfile = true }
                ProfileDashboardCard(Icons.Default.Close, T("Hesap Silme"), T("Tüm yerel profil verilerini sil"), Modifier.weight(1f)) { showDeleteConfirm = true }
            }
        }

        if (adminUnlocked) {
            item { ProfileSectionTitle(T("Yönetim"), Icons.Default.Settings) }
            item {
                ProfileDashboardWide(
                    Icons.Default.Settings,
                    T("Admin Paneli"),
                    T("Duvar kâğıtlarını, kategorileri ve sunucu içeriklerini yönet")
                ) { openAdmin() }
            }
        }

        item { ProfileSectionTitle(T("Uygulama ve Destek"), Icons.Default.Settings) }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProfileDashboardCard(Icons.Default.Settings, T("Ayarlar"), T("Tema, dil ve genel ayarlar"), Modifier.weight(1f)) { openSettings() }
                ProfileDashboardCard(Icons.Default.Help, T("Yardım Merkezi"), T("Sık sorulan sorular"), Modifier.weight(1f)) { openSettings() }
                ProfileDashboardCard(Icons.Default.Email, T("Bizimle İletişime Geç"), T("Destek al, öneri gönder"), Modifier.weight(1f)) { openSettings() }
            }
        }
        item {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                ProfileLargeAction(T("Çıkış Yap"), T("Hesaptan çıkış yap"), "↪", { signedIn = false; accountEmail = ""; saveProfile() }, false)
                ProfileLargeAction(T("Hesabı Sil"), T("Tüm yerel profil verileri silinir"), "×", { showDeleteConfirm = true }, true)
            }
        }
        item { ProfileAction(T("WXTRA Hakkında"), Icons.Default.Info, openAbout) }
    }
}

@Composable
private fun ProfileDashboardCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier.height(112.dp).clip(RoundedCornerShape(18.dp)).background(Card).clickable { onClick() }.padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(Purple.copy(.12f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(21.dp))
        }
        Text(T(title), color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(T(subtitle), color = TextMuted, fontSize = 10.sp, lineHeight = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ProfileDashboardWide(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp).clip(RoundedCornerShape(18.dp)).background(Card).clickable { onClick() }.padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(Purple.copy(.12f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Purple)
        }
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(T(title), color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(T(subtitle), color = TextMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.ArrowForward, null, tint = TextMuted, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun ProfileStatCard(
    value: String,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .height(92.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Card)
            .clickable { onClick() }
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = Purple, modifier = Modifier.size(20.dp))
        Text(T(value), color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 3.dp))
        Text(T(label), color = TextMuted, fontSize = 10.sp)
    }
}

@Composable
private fun ProfileSectionTitle(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        Modifier.padding(horizontal = 22.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Purple, modifier = Modifier.size(25.dp))
        Text(
            T(title),
            color = TextMain,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 10.dp)
        )
    }
}

@Composable
private fun RowScope.ProfileMini(label: String, title: String, onClick: () -> Unit = {}) {
    Column(
        Modifier
            .weight(1f)
            .height(102.dp)
            .clip(RoundedCornerShape(17.dp))
            .background(Card)
            .clickable { onClick() }
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(T(label), color = Purple, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(
            T(title),
            color = TextMain,
            fontSize = 10.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 7.dp)
        )
    }
}

@Composable
private fun ProfileWideAction(label: String, title: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .height(82.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(Card2)
            .clickable { onClick() }
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(T(label), color = Purple, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text(
            T(title),
            color = TextMain,
            fontSize = 10.sp,
            maxLines = 2,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 5.dp)
        )
    }
}

@Composable
private fun ProfileLargeAction(
    title: String,
    subtitle: String,
    mark: String,
    onClick: () -> Unit,
    destructive: Boolean = false
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(Card)
            .clickable { onClick() }
            .padding(horizontal = 15.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(36.dp), contentAlignment = Alignment.Center) {
            Text(
                mark,
                color = if (destructive) Color(0xFFFF4D5F) else TextMain,
                fontSize = 21.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(
                T(title),
                color = if (destructive) Color(0xFFFF5C70) else TextMain,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                T(subtitle),
                color = TextMuted,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Icon(
            Icons.Default.ArrowForward,
            null,
            tint = if (destructive) Color(0xFFFF4D5F) else TextMuted,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun SearchScreen(value: String, onValue: (String) -> Unit, open: (Int) -> Unit, back: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp)) {
        item { TopBar(L("Ara","Search"), back) }
        item { SearchBar(value, onValue, Modifier.padding(bottom = 18.dp)) }
        val availableIndices = serverIndices()
        val results = if (value.isBlank()) availableIndices else availableIndices.filter { idx -> remoteWallpapers.getOrNull(idx)?.let { wp -> wp.title.contains(value, true) || wp.category.contains(value, true) || wp.filename.contains(value, true) } == true }
        item {
            if (results.isEmpty()) Text(T("Sonuç bulunamadı."), color = TextMuted, modifier = Modifier.padding(20.dp))
            else LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 108.dp), modifier = Modifier.height(600.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                gridItems(results) { i -> ImageCard(i, open, false, {}, Modifier.fillMaxWidth()) }
            }
        }
    }
}

@Composable
private fun NotificationsScreen(back: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar(L("Bildirimler","Notifications"), back) }
        item {
            Column(Modifier.padding(18.dp).clip(RoundedCornerShape(18.dp)).background(Card).padding(18.dp)) {
                Icon(Icons.Default.Notifications, null, tint = Purple, modifier = Modifier.size(30.dp))
                Text(T("WXTRA'ya hoş geldin!"), color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                Text(T("Yeni duvar kâğıtları ve koleksiyonlar burada görünecek."), color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
            }
        }
    }
}

@Composable
private fun ListingScreen(title: String, indices: List<Int>, open: (Int) -> Unit, back: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar(title, back) }
        item {
            LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 108.dp), modifier = Modifier.height(720.dp), contentPadding = PaddingValues(18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                gridItems(indices) { i -> ImageCard(i, open, false, {}, Modifier.fillMaxWidth()) }
            }
        }
    }
}

private fun cacheSizeBytes(file: java.io.File): Long {
    if (!file.exists()) return 0L
    return if (file.isFile) file.length() else file.listFiles()?.sumOf { cacheSizeBytes(it) } ?: 0L
}

@Composable
private fun SettingsScreen(back: () -> Unit, openAdmin: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("wxtra_settings", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var notifications by remember { mutableStateOf(prefs.getBoolean("notifications", true)) }
    var dailyWallpaper by remember { mutableStateOf(prefs.getBoolean("dailyWallpaper", true)) }
    var recommendations by remember { mutableStateOf(prefs.getBoolean("recommendations", true)) }
    var language by remember { mutableStateOf(prefs.getString("language", "tr") ?: "tr") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var infoDialog by remember { mutableStateOf<String?>(null) }
    var layoutDialog by remember { mutableStateOf(false) }
    var showPrivacyPolicy by remember { mutableStateOf(false) }
    var showTermsOfUse by remember { mutableStateOf(false) }
    var showVersionInfo by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }

    if (showPrivacyPolicy) {
        PrivacyPolicyScreen { showPrivacyPolicy = false }
        return
    }
    if (showTermsOfUse) {
        TermsOfUseScreen { showTermsOfUse = false }
        return
    }
    if (showVersionInfo) {
        VersionInfoScreen { showVersionInfo = false }
        return
    }
    if (showAbout) {
        AboutScreen { showAbout = false }
        return
    }

    fun refresh() {
        applyThemePreferences(context)
    }
    fun save(key: String, value: Any) {
        prefs.edit().apply {
            when (value) {
                is Boolean -> putBoolean(key, value)
                is Int -> putInt(key, value)
                is String -> putString(key, value)
            }
        }.apply()
        refresh()
    }

    if (layoutDialog) {
        ChoiceDialog(
            L("Görünüm Dizilimi", "View Layout"),
            layoutOptionNames(),
            layoutMode,
            { selected ->
                layoutMode = selected.coerceIn(0, 3)
                prefs.edit().putInt("layoutMode", layoutMode).apply()
                layoutDialog = false
            }
        ) { layoutDialog = false }
    }

    when (dialog) {
        "language" -> ChoiceDialog(
            L("Dil", "Language"),
            listOf("Türkçe", "English", "中文"),
            when (language) { "tr" -> 0; "en" -> 1; else -> 2 },
            {
                language = when (it) { 0 -> "tr"; 1 -> "en"; else -> "zh" }
                appLanguage = language
                save("language", language)
                dialog = null
                Toast.makeText(context, when (language) { "tr" -> "Dil Türkçe olarak ayarlandı"; "en" -> "Language set to English"; else -> "语言已设置为中文" }, Toast.LENGTH_SHORT).show()
            }
        ) { dialog = null }
        null -> Unit
    }

    infoDialog?.let { message ->
        AlertDialog(
            onDismissRequest = { infoDialog = null },
            title = { Text(T(message.substringBefore("\n\n")), color = TextMain, fontWeight = FontWeight.Bold) },
            text = { Text(T(message.substringAfter("\n\n", "")), color = TextMuted, lineHeight = 20.sp) },
            confirmButton = { TextButton(onClick = { infoDialog = null }) { Text(L("Tamam","Done"), color = Purple) } },
            containerColor = Card2
        )
    }


    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { TopBar(L("Ayarlar","Settings"), back) }

        item { Text(L("BİLDİRİMLER","NOTIFICATIONS"), color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) }
        item { SettingsSwitchRow(L("Bildirimler","Notifications"), L("Uygulama bildirimleri","App notifications"), notifications) { notifications = it; save("notifications", it) } }
        item { SettingsSwitchRow(L("Günlük yeni duvar kâğıdı","Daily new wallpaper"), L("Günlük öneri bildirimi","Daily wallpaper notification"), dailyWallpaper) { dailyWallpaper = it; save("dailyWallpaper", it) } }
        item { SettingsSwitchRow(L("Öneriler","Recommendations"), L("Kişiselleştirilmiş öneriler","Personalized recommendations"), recommendations) { recommendations = it; save("recommendations", it) } }

        item { Text(L("UYGULAMA","APP"), color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) }
        item {
            SettingsActionRow(
                L("Görünüm Dizilimi", "View Layout"),
                layoutOptionNames()[layoutMode.coerceIn(0, 3)]
            ) { layoutDialog = true }
        }
        item { SettingsActionRow(L("Dil","Language"), when (language) { "tr" -> "Türkçe"; "en" -> "English"; else -> "中文" }) { dialog = "language" } }
        item { SettingsActionRow(L("Önbellek","Cache"), L("Temizle","Clear")) {
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    val cache = context.cacheDir
                    val before = cacheSizeBytes(cache)
                    cache.listFiles()?.forEach { it.deleteRecursively() }
                    val after = cacheSizeBytes(cache)
                    before to after
                }
                val (before, after) = result
                Toast.makeText(
                    context,
                    T("Önbellek temizlendi • ${(before / 1024 / 1024)} MB → ${(after / 1024 / 1024)} MB"),
                    Toast.LENGTH_LONG
                ).show()
            }
        } }
        item { SettingsActionRow(L("Ayarları varsayılana döndür","Reset settings to default"), "Sıfırla") {
            prefs.edit().clear().apply(); notifications = true; dailyWallpaper = true; recommendations = true; language = "tr"; refresh()
            Toast.makeText(context, T("Ayarlar varsayılana döndürüldü"), Toast.LENGTH_SHORT).show()
        } }

        item { Text(L("DESTEK","SUPPORT"), color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) }
        item { SettingsActionRow(L("Sorun bildir","Report a problem"), "Bize yardımcı ol") { infoDialog = "Sorun Bildir\n\nKarşılaştığın sorunu ve mümkünse ekran görüntüsünü WXTRA destek ekibine iletebilirsin.\n\ndestek@wxtra.app" } }
        item { SettingsActionRow(L("Bize ulaş","Contact us"), "WXTRA destek") { infoDialog = "Bize Ulaş\n\nE-posta: destek@wxtra.app\n\nMesajında cihaz modelini ve uygulama sürümünü belirtmen sorunu daha hızlı çözmemize yardımcı olur." } }

        item { Text(L("HAKKIMDA","ABOUT"), color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) }
        item {
            SettingsActionRow(T("Yönetici Paneli"), T("Yönetici girişi")) { openAdmin() }
        }
        item { SettingsActionRow(L("WXTRA hakkında","About WXTRA"), "WXTRA 1.0.0") { showAbout = true } }
        item { SettingsActionRow(L("Gizlilik politikası","Privacy Policy"), "Veri ve gizlilik") { showPrivacyPolicy = true } }
        item { SettingsActionRow(L("Kullanım koşulları","Terms of Use"), "Kurallar") { showTermsOfUse = true } }
        item { SettingsActionRow(L("Sürüm bilgisi","Version info"), "1.0.0") { showVersionInfo = true } }
    }
}


@Composable
private fun PrivacyPolicyScreen(back: () -> Unit) {
    val expanded = remember { mutableStateOf(setOf<Int>()) }

    val sections = listOf(
        "Hangi verileri topluyoruz?" to "WXTRA'nın mevcut sürümünde uygulama tercihleri, favoriler, son görüntülenenler ve profil bilgileri gibi uygulamayı çalıştırmak için gerekli veriler cihazın özel depolama alanında tutulabilir. Google ile giriş kullanıldığında, giriş sağlayıcısından hesabın çalışması için gerekli temel profil bilgileri alınabilir. Gereksiz hassas kişisel veriler özellikle talep edilmedikçe toplanmaz.",
        "Verilerimi neden kullanıyoruz?" to "Veriler; hesabını ve profilini yönetmek, favorilerini ve koleksiyonlarını korumak, uygulama ayarlarını hatırlamak, cihazlar arası senkronizasyonu desteklemek ve WXTRA deneyimini geliştirmek için kullanılabilir. Veriler yalnızca belirtilen amaçlar ve hizmetin çalışması için gerekli olduğu ölçüde işlenir.",
        "Hesap ve profil bilgilerim" to "Profilinde oluşturduğun ad, kullanıcı adı, profil fotoğrafı ve benzeri bilgiler kişiselleştirilmiş profil deneyimi için kullanılır. Profil bilgilerini uygulama içindeki Profilim bölümünden düzenleyebilirsin.",
        "Favoriler ve koleksiyonlar" to "Favorilediğin duvar kâğıtları, koleksiyonların ve bazı kullanım tercihlerin hesabın veya cihazındaki WXTRA verileriyle ilişkilendirilebilir. Böylece uygulamayı kullandığında tercihlerin korunabilir.",
        "Veriler nerede saklanıyor?" to "Yerel profil ve uygulama tercihleri mevcut sürümde Android'in uygulamaya özel depolama alanında tutulur. Sunucu tabanlı hesap senkronizasyonu kullanılan bölümlerde veriler, hizmetin çalışması için gerekli güvenlik ve erişim kontrolleri uygulanarak işlenir.",
        "Verilerimi kimler görebilir?" to "Kişisel verilerin satılmaz veya iznin dışında reklam amacıyla paylaşılmaz. Hizmetin çalışması için gerekli üçüncü taraf hizmet sağlayıcıları kullanıldığında yalnızca gerekli kapsamda veri işlenebilir. Yasal bir zorunluluk olmadıkça verilerin yetkisiz kişilerle paylaşılması amaçlanmaz.",
        "Verilerimi nasıl silebilirim?" to "Profil ekranındaki hesap silme seçeneğini kullanarak cihazındaki WXTRA profil ve hesap verilerini kaldırmayı başlatabilirsin. Sunucularda tutulabilecek verilerin silinmesi için ayrıca destek ekibine talep iletilebilir. Yasal olarak saklanması gereken kayıtlar ilgili süre boyunca tutulabilir.",
        "Güvenlik" to "WXTRA, kişisel verileri yetkisiz erişim, kayıp veya kötüye kullanıma karşı korumak için uygun teknik ve idari önlemler kullanmayı amaçlar. Bununla birlikte internet üzerinden yapılan hiçbir veri aktarımının mutlak olarak risksiz olduğu garanti edilemez.",
        "Gizlilik talepleri ve iletişim" to "Verilerinle ilgili erişim, düzeltme, silme veya gizlilik soruların için WXTRA destek ekibine ulaşabilirsin. İletişim: destek@wxtra.app",
        "Politika güncellemeleri" to "Bu Gizlilik Politikası, uygulamanın özellikleri veya veri işleme yöntemleri değiştikçe güncellenebilir. Önemli değişikliklerde kullanıcıların bilgilendirilmesi hedeflenir."
    )

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item { TopBar(T("Gizlilik Politikası"), back) }
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFFEDE7FF),
                                Color(0xFFF8F5FF),
                                Color(0xFFE9DEFF)
                            )
                        )
                    )
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(48.dp).clip(CircleShape).background(Purple),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Lock, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(T("Verilerin senin kontrolünde"), color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(T("WXTRA'da veri ve gizlilik"), color = TextMuted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    T("Aşağıdaki başlıklara dokunarak ayrıntıları görebilirsin."),
                    color = TextMuted, fontSize = 13.sp, lineHeight = 19.sp
                )
            }
        }
        item {
            Text(
                T("VERİ GİZLİLİĞİ"),
                color = Purple, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 18.dp)
            )
        }
        items(sections.size) { index ->
            val (title, description) = sections[index]
            val isExpanded = expanded.value.contains(index)
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Card)
                    .clickable {
                        expanded.value = if (isExpanded) expanded.value - index else expanded.value + index
                    }
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        T(title), color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Text(if (isExpanded) "⌃" else "⌄", color = Purple, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                }
                if (isExpanded) {
                    Spacer(Modifier.height(10.dp))
                    Text(T(description), color = TextMuted, fontSize = 12.sp, lineHeight = 19.sp)
                }
            }
        }
        item {
            Text(
                T("Son güncelleme: 8 Eylül 2026"),
                color = TextMuted, fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp)
            )
        }
    }
}

@Composable
private fun TermsOfUseScreen(back: () -> Unit) {
    val expanded = remember { mutableStateOf(setOf<Int>()) }

    val sections = listOf(
        "Kullanım Koşulları" to "WXTRA uygulamasını indirerek, kullanarak veya hesap oluşturarak bu kullanım koşullarını kabul etmiş olursun. Bu koşullar; uygulamadaki özelliklerin, içeriklerin ve hesap hizmetlerinin kullanımına ilişkin temel kuralları açıklar. Koşulları kabul etmiyorsan WXTRA'yı kullanmamalısın.",
        "Hesap ve kullanıcı sorumlulukları" to "Hesap bilgilerinin doğru ve güncel olmasından sen sorumlusun. Hesabının güvenliğini korumalı, giriş bilgilerini başkalarıyla paylaşmamalısın. Hesabın üzerinden gerçekleştirilen işlemlerden, yetkisiz kullanım fark ettiğinde WXTRA'ya bildirimde bulunman beklenir.",
        "Duvar kâğıtlarının kullanımı" to "WXTRA'daki duvar kâğıtları yalnızca uygulamanın sunduğu kullanım izinleri kapsamında kullanılmalıdır. Bir görseli ticari amaçla yeniden satmak, başka bir içerik olarak dağıtmak veya hak sahibinin izni olmadan sahiplenmek uygun değildir. İndirme ve cihazda duvar kâğıdı olarak kullanma hakkı, görselin lisansına göre değişebilir.",
        "Favoriler ve koleksiyonlar" to "Favoriler ve koleksiyonlar, içerikleri kişisel kullanımın için düzenlemene yardımcı olur. Bu özellikleri kötüye kullanmamalı, başkalarının hesabına veya verilerine erişmeye çalışmamalısın.",
        "Yasaklanan içerikler ve davranışlar" to "Yasa dışı, tehdit edici, nefret veya taciz içeren, cinsel istismar içeren, çocukları tehlikeye atan, dolandırıcılığı teşvik eden ya da başkalarının haklarını ihlal eden içerik ve davranışlara izin verilmez. Uygulamanın güvenliğini bozacak, hizmeti aşırı yükleyecek veya yetkisiz erişim sağlamaya yönelik işlemler de yasaktır.",
        "Telif hakları" to "WXTRA arayüzü, marka unsurları, uygulama tasarımı ve WXTRA tarafından oluşturulan içerikler ilgili fikri mülkiyet haklarıyla korunabilir. Üçüncü taraf görsellerin hakları ilgili sahiplerine aittir. Hak ihlali olduğunu düşündüğün bir içerik varsa kaldırma veya inceleme talebi için destek ekibine ulaşabilirsin.",
        "Otomatik ve AI özelliklerinin kullanımı" to "WXTRA'da gelecekte sunulabilecek otomatik veya yapay zekâ destekli özellikler yardımcı amaçlıdır. Bu özelliklerin ürettiği sonuçların her zaman hatasız, eksiksiz veya sana özel hukuki, finansal ya da profesyonel tavsiye niteliğinde olduğu garanti edilmez. Sonuçları kullanmadan önce uygunluğunu kontrol etmelisin.",
        "Hesap güvenliği" to "Hesabını korumak için cihazının ve Google hesabının güvenlik ayarlarını güncel tut. Şüpheli giriş veya hesap erişimi fark edersen mümkün olan en kısa sürede şifreni ve ilgili hesap güvenlik ayarlarını değiştir ve WXTRA desteğine başvur.",
        "İçerik ve hizmet sorumluluğu" to "WXTRA hizmeti geliştirilirken bazı özellikler değişebilir, geçici olarak kullanılamayabilir veya kaldırılabilir. Üçüncü taraf hizmetlerden kaynaklanan kesintiler de yaşanabilir. Hizmetin sürekliliği ve tüm içeriklerin her zaman erişilebilir olması garanti edilmez.",
        "Koşulların değiştirilmesi" to "WXTRA; yeni özellikler, güvenlik gereksinimleri veya yasal değişiklikler nedeniyle bu koşulları güncelleyebilir. Önemli değişiklikler olduğunda kullanıcıların uygun şekilde bilgilendirilmesi hedeflenir. Güncellenen koşulların yayınlanmasından sonra uygulamayı kullanmaya devam etmen, yürürlükteki koşulları kabul ettiğin anlamına gelebilir.",
        "Hesabın kapatılması" to "Hesabını kapatmak veya silmek istediğinde uygulamadaki hesap yönetimi seçeneklerini kullanabilirsin. Kuralları ciddi biçimde ihlal eden hesaplarda, güvenliği korumak veya yasal yükümlülükleri yerine getirmek amacıyla erişim sınırlandırılabilir veya hesap kapatılabilir.",
        "İletişim ve destek" to "Kullanım koşulları, içerik hakları veya hesabınla ilgili soruların için WXTRA destek ekibine ulaşabilirsin. İletişim: destek@wxtra.app. Bildiriminde mümkünse kullanıcı adını, uygulama sürümünü ve sorunun kısa açıklamasını belirt."
    )

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item { TopBar(T("Kullanım Koşulları"), back) }
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFFEDE7FF),
                                Color(0xFFF9F6FF),
                                Color(0xFFE7D8FF)
                            )
                        )
                    )
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(58.dp).clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = 0.88f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.wxtra_about_logo),
                            contentDescription = "WXTRA",
                            modifier = Modifier.fillMaxSize().padding(5.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(T("Saygı, Güven, Daha Güzel Bir Dünya"), color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(3.dp))
                        Text(T("Kurallarımız, daha güzel bir deneyim için"), color = TextMuted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    T("Aşağıdaki başlıklara dokunarak ayrıntıları açabilir ve WXTRA'yı kullanırken uyman gereken kuralları görebilirsin."),
                    color = TextMuted, fontSize = 13.sp, lineHeight = 19.sp
                )
            }
        }
        item {
            Text(
                T("KULLANIM KURALLARI"),
                color = Purple, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 18.dp)
            )
        }
        items(sections.size) { index ->
            val (title, description) = sections[index]
            val isExpanded = expanded.value.contains(index)
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Card)
                    .clickable {
                        expanded.value = if (isExpanded) expanded.value - index else expanded.value + index
                    }
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(Purple.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            when (index) {
                                0 -> "§"; 1 -> "●"; 2 -> "▣"; 3 -> "♥"; 4 -> "⊘"; 5 -> "©"
                                6 -> "✦"; 7 -> "✓"; 8 -> "!"; 9 -> "↻"; 10 -> "⌫"; else -> "✉"
                            },
                            color = Purple, fontSize = 16.sp, fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(
                        T(title), color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Text(if (isExpanded) "⌃" else "⌄", color = Purple, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                }
                if (isExpanded) {
                    Spacer(Modifier.height(10.dp))
                    Text(T(description), color = TextMuted, fontSize = 12.sp, lineHeight = 19.sp)
                }
            }
        }
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 18.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFFE5D5FF), Color(0xFFF8F3FF), Color(0xFFDCC7FF))
                        )
                    )
                    .padding(20.dp)
            ) {
                Text(T("“Daha güzel bir deneyim, kurallara birlikte uymakla mümkün.”"), color = TextMain, fontSize = 14.sp, lineHeight = 21.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(8.dp))
                Text(T("— WXTRA"), color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                T("Son güncelleme: 8 Eylül 2026"),
                color = TextMuted, fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
private fun SettingsActionRow(title: String, value: String, enabled: Boolean = true, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(Card).clickable(enabled = enabled) { onClick() }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(T(title), color = if (enabled) TextMain else TextMuted, modifier = Modifier.weight(1f))
        Text(T(value), color = TextMuted, fontSize = 12.sp)
        Spacer(Modifier.width(7.dp)); Text(T("›"), color = TextMuted)
    }
}

@Composable
private fun SettingsSwitchRow(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(Card).padding(horizontal = 15.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(T(title), color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(T(subtitle), color = TextMuted, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked, colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Purple))
    }
}

@Composable
private fun ChoiceDialog(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(T(title), color = TextMain, fontWeight = FontWeight.Bold) },
        text = { LazyColumn(
            modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(options.size) { index ->
                val option = options[index]
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (selected == index) Purple.copy(.18f) else Card).clickable { onSelect(index) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = selected == index, onClick = { onSelect(index) }, colors = RadioButtonDefaults.colors(selectedColor = Purple))
                    if (options === backgroundNames) {
                        Box(
                            Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(backgroundPresets[index]))
                        )
                    }
                    Text(T(option), color = TextMain, modifier = Modifier.padding(start = 10.dp))
                }
            }
        } },
        confirmButton = {},
        containerColor = Card2
    )
}

@Composable
private fun VersionInfoScreen(back: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar(T("Sürüm Bilgisi"), back) }
        item {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.95f), Color(0xFFF0E8FF).copy(alpha = 0.95f), Color(0xFFE7D9FF).copy(alpha = 0.92f))))
                    .border(1.dp, Color.White.copy(alpha = 0.95f), RoundedCornerShape(30.dp))
                    .padding(vertical = 24.dp, horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(painterResource(R.drawable.wxtra_about_logo), "WXTRA", Modifier.size(132.dp).clip(RoundedCornerShape(28.dp)), contentScale = ContentScale.Crop)
                Text(T("WXTRA"), color = TextMain, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 10.dp))
                Text(T("Duvar Kâğıtları"), color = Purple, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(T("Güzellik Her Yerde"), color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
        item { VersionInfoCard(Icons.Default.Info, "Sürüm Numarası", "1.0.0") }
        item { VersionInfoCard(Icons.Default.Info, "Desteklenen Android Sürümleri", "Android 8.0 ve üzeri") }
        item { VersionInfoCard(Icons.Default.Settings, "Desteklenen MagicOS Sürümleri", "Android 8.0+ tabanlı MagicOS sürümleri") }
        item { VersionInfoCard(Icons.Default.Person, "Geliştirici", "WXTRA") }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.width(58.dp).height(1.dp).background(Purple.copy(alpha = 0.35f)))
                    Text(T("♥"), color = Purple, fontSize = 25.sp, modifier = Modifier.padding(horizontal = 16.dp))
                    Box(Modifier.width(58.dp).height(1.dp).background(Purple.copy(alpha = 0.35f)))
                }
                Text(T("Güzellik Her Yerde"), color = TextMuted, fontSize = 14.sp, letterSpacing = 3.sp, modifier = Modifier.padding(top = 10.dp))
                Text(T("© WXTRA"), color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
                Text(T("Tüm hakları saklıdır."), color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
private fun VersionInfoCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(22.dp)).background(Card)
            .border(1.dp, Color.White.copy(alpha = 0.9f), RoundedCornerShape(22.dp))
            .padding(horizontal = 14.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(58.dp).clip(RoundedCornerShape(18.dp)).background(Purple.copy(alpha = 0.10f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(30.dp))
        }
        Column(Modifier.padding(start = 15.dp)) {
            Text(T(title), color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(T(value), color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun AboutScreen(back: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            TopBar(L("WXTRA Hakkında", "About WXTRA"), back)
        }
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color.White.copy(alpha = 0.94f),
                                Color(0xFFF0E8FF).copy(alpha = 0.94f),
                                Color(0xFFE7D9FF).copy(alpha = 0.92f)
                            )
                        )
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.95f), RoundedCornerShape(30.dp))
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(R.drawable.wxtra_about_logo),
                    contentDescription = "WXTRA",
                    modifier = Modifier.size(145.dp).clip(RoundedCornerShape(30.dp)),
                    contentScale = ContentScale.Crop
                )
                Text(T("WXTRA"), color = TextMain, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 10.dp))
                Text(T("Güzellik Her Yerde"), color = Purple, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(T("Dünyayı Renklendir, Senin Tarzınla 💜"), color = TextMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 7.dp))
                Box(
                    Modifier
                        .padding(top = 14.dp)
                        .clip(RoundedCornerShape(50.dp))
                        .background(Purple.copy(alpha = 0.12f))
                        .padding(horizontal = 18.dp, vertical = 8.dp)
                ) { Text(T("Sürüm 1.0.0"), color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            }
        }
        item {
            AboutInfoCard(
                title = "WXTRA nedir?",
                icon = Icons.Default.Info,
                text = "WXTRA, tarzına uygun duvar kâğıtlarını keşfetmeni, favorilerini oluşturmanı ve kendi kişisel koleksiyonunu oluşturmanı sağlayan yeni nesil duvar kâğıdı deneyimidir. Güzelliği her yerde seninle buluşturur."
            )
        }
        item {
            AboutInfoCard(
                title = "WXTRA'nın amacı",
                icon = Icons.Default.Explore,
                text = "Duvar kâğıdından fazlası. Telefonunun görünümünü kendi tarzına dönüştürmek; ilham veren, kaliteli ve özgün içerikleri tek bir yerde sunmak için geliştirildi."
            )
        }
        item {
            Text(
                T("Neler sunuyor?"),
                color = TextMain,
                fontSize = 21.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(start = 22.dp, top = 20.dp, bottom = 10.dp)
            )
            Column(Modifier.padding(horizontal = 18.dp)) {
                AboutFeatureRow(Icons.Default.Wallpaper, "Zengin duvar kâğıdı koleksiyonu", "Binlerce özel içerik")
                AboutFeatureRow(Icons.Default.Explore, "Keşfet", "Her gün yeni içerik")
                AboutFeatureRow(Icons.Default.Favorite, "Favoriler", "Sevdiklerini kaydet")
                AboutFeatureRow(Icons.Default.Person, "Kullanıcı profili", "Sana özel deneyim")
                AboutFeatureRow(Icons.Default.CloudDownload, "Hesap senkronizasyonu", "Verilerin her zaman seninle")
                AboutFeatureRow(Icons.Default.Palette, "Kişiselleştirilmiş deneyim", "Tarzını yansıt")
            }
        }
        item {
            Column(
                Modifier
                    .padding(18.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFFE8D7FF), Color(0xFFF7EEFF))))
                    .border(1.dp, Purple.copy(alpha = 0.14f), RoundedCornerShape(24.dp))
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, null, tint = Purple, modifier = Modifier.size(28.dp))
                    Text(T("Yakında"), color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 12.dp))
                }
                Text(T("Daha fazlası geliyor..."), color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                listOf(
                    "Premium içerikler",
                    "Canlı duvar kâğıtları",
                    "Yapay zekâ ile öneriler",
                    "Topluluk ve paylaşım",
                    "Çoklu cihaz senkronizasyonu",
                    "Daha fazla kişiselleştirme seçeneği"
                ).forEach { feature ->
                    Row(Modifier.padding(top = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FavoriteBorder, null, tint = Purple, modifier = Modifier.size(18.dp))
                        Text(T(feature), color = TextMain, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
                    }
                }
            }
        }
        item {
            Column(
                Modifier
                    .padding(horizontal = 18.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.White.copy(alpha = 0.78f))
                    .border(1.dp, Color.White.copy(alpha = 0.9f), RoundedCornerShape(24.dp))
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(T("“"), color = Purple, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text(
                    T("Güzel bir duvar kâğıdı sadece bir görüntü değil, her gün yeniden başlayan bir ilhamdır."),
                    color = TextMain,
                    fontSize = 15.sp,
                    lineHeight = 23.sp
                )
                Text(T("— WXTRA"), color = Purple, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            }
        }
        item {
            Box(
                Modifier
                    .padding(18.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.horizontalGradient(listOf(Purple, Color(0xFFB45CFF))))
                    .padding(vertical = 22.dp, horizontal = 18.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(T("♥"), color = Color.White, fontSize = 27.sp)
                    Text(T("WXTRA tarafından sevgiyle geliştirildi."), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(T("Teşekkürler, sen bu yolculuğun bir parçasısın. 💜"), color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

@Composable
private fun AboutInfoCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Column(
        Modifier
            .padding(horizontal = 18.dp)
            .padding(top = 18.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = 0.82f))
            .border(1.dp, Color.White.copy(alpha = 0.9f), RoundedCornerShape(24.dp))
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(28.dp))
            Text(T(title), color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 12.dp))
        }
        Text(T(text), color = TextMain.copy(alpha = 0.86f), fontSize = 13.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
private fun AboutFeatureRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.82f))
            .border(1.dp, Color.White.copy(alpha = 0.9f), RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Purple.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.padding(start = 12.dp)) {
            Text(T(title), color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(T(subtitle), color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
private fun CategoriesScreen(back: () -> Unit, openListing: (String, List<Int>) -> Unit) {
    LaunchedEffect(Unit) {
        runCatching {
            val result = withContext(Dispatchers.IO) { ServerCatalogApi.load() }
            remoteWallpapers = result.first
            remoteCategories = result.second
        }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
                Text(T("Kategoriler"), color = TextMain, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold)
                Text(T("Sunucudaki güncel kategoriler"), color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
        if (remoteCategories.isEmpty()) {
            item { CircularProgressIndicator(Modifier.padding(28.dp), color = Purple) }
        } else {
            items(remoteCategories, key = { it.id }) { cat ->
                val indices = remoteWallpapers.mapIndexedNotNull { index, image -> if (image.category.equals(cat.slug, true) || image.category.equals(cat.name, true)) index else null }
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp).clip(RoundedCornerShape(20.dp)).background(Card).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(58.dp).clip(RoundedCornerShape(16.dp)).background(Purple.copy(.10f)), contentAlignment = Alignment.Center) {
                        val preview = indices.firstOrNull()
                        if (preview != null) WallpaperVisual(preview, Modifier.fillMaxSize(), ContentScale.Crop) else Icon(Icons.Default.Explore, null, tint = Purple)
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 13.dp)) {
                        Text(T(cat.name), color = TextMain, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("${indices.size} ${T("görsel")}", color = TextMuted, fontSize = 11.sp)
                    }
                    IconButton(onClick = { openListing(cat.name, indices) }) { Icon(Icons.Default.ArrowForward, null, tint = Purple) }
                }
            }
        }
    }
}

@Composable
private fun CollectionsScreen(back: () -> Unit, open: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar("Koleksiyonlarım", back) }
        item { CollectionCard("4K Ultra HD", 0) { open(0) } }
        item { CollectionCard("Etkileyici Manzaralar", 2) { open(2) } }
        item { CollectionCard("Karanlık Mod", 7) { open(7) } }
        item { CollectionCard("Anime Dünyası", 8) { open(8) } }
    }
}

private fun downloadBitmap(url: String): android.graphics.Bitmap? {
    val connection = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 15_000; readTimeout = 30_000
        requestMethod = "GET"
    }
    return try {
        connection.inputStream.use { BitmapFactory.decodeStream(BufferedInputStream(it)) }
    } finally { connection.disconnect() }
}

@Composable
private fun DetailScreen(index: Int, liked: Boolean, toggleLike: () -> Unit, back: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var applied by remember { mutableStateOf(false) }
    var applying by remember { mutableStateOf(false) }
    var showWallpaperChoice by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val remote = remoteWallpapers.getOrNull(index)
    val displayTitle = remote?.title?.ifBlank { remote.filename } ?: names.getOrElse(index) { "WXTRA" }

    if (remote == null) {
        Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(T("Duvar kâğıdı bulunamadı"), color = TextMain, fontWeight = FontWeight.Bold)
                TextButton(onClick = back) { Text(T("Geri"), color = Purple) }
            }
        }
        return
    }

    if (showWallpaperChoice) {
        AlertDialog(
            onDismissRequest = { if (!applying) showWallpaperChoice = false },
            title = { Text(T("Duvar Kâğıdını Nereye Uygula?"), color = TextMain, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(T("İki ekrana birden otomatik uygulanmayacak. Bir seçenek seç:"), color = TextMuted, fontSize = 12.sp)
                    listOf("Ana ekran" to WallpaperManager.FLAG_SYSTEM, "Kilit ekranı" to WallpaperManager.FLAG_LOCK, "Ana ekran + Kilit ekranı" to (WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)).forEach { (label, flag) ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Card).clickable(enabled = !applying) {
                            applying = true
                            scope.launch {
                                val success = withContext(Dispatchers.IO) {
                                    try {
                                        val wm = WallpaperManager.getInstance(context)
                                        val bitmap = remote?.let { downloadBitmap(it.imageUrl) }
                                        if (bitmap != null) { wm.setBitmap(bitmap, null, true, flag); true } else false
                                    } catch (_: Exception) { false }
                                }
                                applied = success
                                applying = false
                                showWallpaperChoice = false
                            }
                        }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Wallpaper, null, tint = Purple)
                            Text(T(label), color = TextMain, modifier = Modifier.padding(start = 12.dp))
                        }
                    }
                }
            },
            confirmButton = {},
            containerColor = Card2
        )
    }
    if (showInfo) {
        AlertDialog(
            onDismissRequest = { showInfo = false },
            title = { Text(T(displayTitle), color = TextMain, fontWeight = FontWeight.Bold) },
            text = { Text(T("WXTRA seçkisi • Duvar kâğıdı ${index + 1}. Bu görseli favorilerine ekleyebilir veya ana/kilit ekranına uygulayabilirsin."), color = TextMuted) },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text(L("Kapat", "Close"), color = Purple) } },
            containerColor = Card2
        )
    }
    Box(Modifier.fillMaxSize().background(Bg)) {
        WallpaperVisual(index, Modifier.fillMaxSize(), ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(.10f), Color.Transparent, Color.Black.copy(.58f)))))

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp)) {
            Text(T(displayTitle), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp))
            Text(T("WXTRA seçkisi  •  Telefonuna uygun"), color = Color.White.copy(.82f), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
            Row(
                Modifier.padding(top = 10.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color.Black.copy(.46f)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(Modifier.size(50.dp).clip(CircleShape).background(Color.White.copy(.12f)).clickable { showInfo = true }) {
                    Icon(Icons.Default.Info, null, tint = Color.White, modifier = Modifier.align(Alignment.Center))
                }
                Box(Modifier.weight(1f).height(50.dp).clip(RoundedCornerShape(20.dp)).background(Accent).clickable(enabled = !applying) { showWallpaperChoice = true }) {
                    Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.Wallpaper, null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text(T(if (applied) "Duvar Kâğıdı Hazır ✓" else "Duvar Kâğıdı Yap"), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                Box(Modifier.size(50.dp).clip(CircleShape).background(Color.White.copy(.12f)).clickable { toggleLike() }) {
                    Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (liked) Color(0xFFFF4D72) else Color.White, modifier = Modifier.align(Alignment.Center))
                }
            }
        }
    }
}


private const val WXTRA_API_BASE = "http://46.20.15.241:8080/api"
private const val WXTRA_ADMIN_TOKEN = "WXTRA_ADMIN_2026_583921"

private data class AdminCategory(val id: Int, val name: String, val slug: String)

private data class AdminImage(
    val id: Long,
    val filename: String,
    val category: String,
    val width: Int,
    val height: Int,
    val title: String
)

private fun adminTranslate(text: String): String = when (appLanguage) {
    "en" -> mapOf(
        "Admin Paneli" to "Admin Panel",
        "Yönetim" to "Management",
        "Duvar kâğıtlarını, kategorileri ve sunucu içeriklerini yönet" to "Manage wallpapers, categories and server content",
        "Yönetici Girişi" to "Administrator Login", "Kullanıcı adı" to "Username", "Şifre" to "Password", "Yönetici Paneli" to "Admin Panel", "Yönetici girişi" to "Admin login", "Kullanıcı adı veya şifre hatalı" to "Invalid username or password",
        "Admin panelini açmak için yönetici PIN kodunu gir." to "Enter the administrator PIN to open the admin panel.",
        "PIN" to "PIN", "Giriş" to "Enter", "PIN hatalı" to "Incorrect PIN",
        "İptal" to "Cancel", "Duvar Kâğıdı Yükle" to "Upload Wallpaper",
        "Sunucuyu Yenile" to "Refresh Server", "Kategori" to "Category",
        "Başlık" to "Title", "Açıklama" to "Description", "Etiketler" to "Tags",
        "Dosya seç" to "Choose files", "Seçilen dosya sayısı" to "Selected files", "Yükle" to "Upload", "Sil" to "Delete",
        "Henüz görsel yok" to "No wallpapers yet", "Sunucu" to "Server",
        "Görsel başarıyla yüklendi" to "Wallpaper uploaded successfully",
        "Görsel silindi" to "Wallpaper deleted", "Yükleme başarısız" to "Upload failed",
        "Silme başarısız" to "Delete failed", "Kategori yüklenemedi" to "Categories could not be loaded",
        "Görseller yüklenemedi" to "Wallpapers could not be loaded", "Admin Panelinden Çık" to "Leave Admin Panel",
        "Yüklenecek görseli seç" to "Choose a wallpaper to upload", "Seçili dosya" to "Selected file"
    )[text] ?: text
    "zh" -> mapOf(
        "Admin Paneli" to "管理面板", "Yönetim" to "管理",
        "Duvar kâğıtlarını, kategorileri ve sunucu içeriklerini yönet" to "管理壁纸、分类和服务器内容",
        "Yönetici Girişi" to "管理员登录", "Kullanıcı adı" to "用户名", "Şifre" to "密码", "Yönetici Paneli" to "管理面板", "Yönetici girişi" to "管理员登录", "Kullanıcı adı veya şifre hatalı" to "用户名或密码错误", "Admin panelini açmak için yönetici PIN kodunu gir." to "输入管理员 PIN 以打开管理面板",
        "PIN" to "PIN", "Giriş" to "进入", "PIN hatalı" to "PIN 错误", "İptal" to "取消",
        "Duvar Kâğıdı Yükle" to "上传壁纸", "Sunucuyu Yenile" to "刷新服务器", "Kategori" to "分类",
        "Başlık" to "标题", "Açıklama" to "描述", "Etiketler" to "标签", "Dosya seç" to "选择文件", "Seçilen dosya sayısı" to "已选文件",
        "Yükle" to "上传", "Sil" to "删除", "Henüz görsel yok" to "暂无壁纸", "Sunucu" to "服务器",
        "Görsel başarıyla yüklendi" to "壁纸上传成功", "Görsel silindi" to "壁纸已删除",
        "Yükleme başarısız" to "上传失败", "Silme başarısız" to "删除失败", "Kategori yüklenemedi" to "无法加载分类",
        "Görseller yüklenemedi" to "无法加载壁纸", "Admin Panelinden Çık" to "退出管理面板",
        "Yüklenecek görseli seç" to "选择要上传的壁纸", "Seçili dosya" to "已选文件"
    )[text] ?: text
    else -> text
}

private fun AT(text: String): String = adminTranslate(text)

@Composable
private fun AdminPanelScreen(back: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var categories by remember { mutableStateOf<List<AdminCategory>>(emptyList()) }
    var images by remember { mutableStateOf<List<AdminImage>>(emptyList()) }
    var categoryId by remember { mutableStateOf(1) }
    var categorySlug by remember { mutableStateOf("nature") }
    var description by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var showCategoryMenu by remember { mutableStateOf(false) }
    var newCategoryName by remember { mutableStateOf("") }
    var newCategorySlug by remember { mutableStateOf("") }
    var editingCategory by remember { mutableStateOf<AdminCategory?>(null) }
    var editCategoryName by remember { mutableStateOf("") }
    var editCategorySlug by remember { mutableStateOf("") }
    val adminPrefs = remember { context.getSharedPreferences("wxtra_admin", Context.MODE_PRIVATE) }
    var authenticated by remember { mutableStateOf(adminPrefs.getBoolean("authenticated", false)) }
    var loginUser by remember { mutableStateOf("") }
    var loginPass by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf("") }
    var selectedUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var uploadProgress by remember { mutableStateOf(0) }

    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> selectedUris = uris }

    if (!authenticated) {
        Box(Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Card),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        Modifier.size(56.dp).clip(CircleShape).background(Accent),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Lock, null, tint = Color.White) }
                    Text(AT("Yönetici Girişi"), color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    Text(AT("Sunucudaki WXTRA yönetim alanına güvenli giriş"), color = TextMuted, fontSize = 12.sp)
                    OutlinedTextField(loginUser, { loginUser = it }, label = { Text(AT("Kullanıcı adı")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(loginPass, { loginPass = it }, label = { Text(AT("Şifre")) }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                    if (loginError.isNotBlank()) Text(loginError, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    Button(
                        onClick = {
                            if (loginUser.isBlank() || loginPass.isBlank()) { loginError = AT("Kullanıcı adı ve şifre gerekli"); return@Button }
                            scope.launch {
                                busy = true
                                try {
                                    AdminApi.login(loginUser.trim(), loginPass)
                                    adminPrefs.edit().putBoolean("authenticated", true).apply()
                                    authenticated = true
                                    loginError = ""
                                } catch (e: Exception) { loginError = e.message ?: AT("Kullanıcı adı veya şifre hatalı") }
                                finally { busy = false }
                            }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) AT("Kontrol ediliyor…") else T("Giriş")) }
                    Text(T("İlk kurulum hesabı: admin / WXTRA@2026"), color = TextMuted, fontSize = 10.sp)
                }
            }
        }
        return
    }

    fun refresh() {
        scope.launch {
            busy = true
            try {
                categories = withContext(Dispatchers.IO) { AdminApi.loadCategories() }
                images = withContext(Dispatchers.IO) { AdminApi.loadImages() }
                if (categories.none { it.id == categoryId } && categories.isNotEmpty()) {
                    categoryId = categories.first().id
                    categorySlug = categories.first().slug
                }
            } catch (e: Exception) { message = e.message ?: AT("Sunucuya bağlanılamadı") }
            finally { busy = false }
        }
    }
    LaunchedEffect(Unit) { refresh() }

    if (editingCategory != null) {
        AlertDialog(
            onDismissRequest = { editingCategory = null },
            title = { Text(AT("Kategoriyi düzenle")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(editCategoryName, { editCategoryName = it }, label = { Text(AT("Kategori adı")) }, singleLine = true)
                    OutlinedTextField(editCategorySlug, { editCategorySlug = it.lowercase().replace("[^a-z0-9-]".toRegex(), "-") }, label = { Text("Slug") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val c = editingCategory ?: return@TextButton
                    if (editCategoryName.isBlank() || editCategorySlug.isBlank()) { message = AT("Kategori adı ve slug gerekli"); return@TextButton }
                    scope.launch {
                        busy = true
                        try {
                            withContext(Dispatchers.IO) { AdminApi.editCategory(c.id, editCategoryName.trim(), editCategorySlug.trim()) }
                            categories = withContext(Dispatchers.IO) { AdminApi.loadCategories() }
                            if (categoryId == c.id) categorySlug = editCategorySlug.trim()
                            message = AT("Kategori güncellendi")
                            editingCategory = null
                        } catch (e: Exception) { message = e.message ?: AT("Kategori güncellenemedi") }
                        finally { busy = false }
                    }
                }) { Text(T("Kaydet")) }
            },
            dismissButton = { TextButton(onClick = { editingCategory = null }) { Text(T("İptal")) } }
        )
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp)) {
        TopBar(AT("Admin Paneli"), back)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(22.dp)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(AT("WXTRA Yönetim"), color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                            Text("${images.size} ${T("görsel")} • ${categories.size} ${T("kategori")}", color = TextMuted, fontSize = 12.sp)
                        }
                        AssistChip(onClick = { refresh() }, label = { Text(AT("Yenile")) }, leadingIcon = { Icon(Icons.Default.Refresh, null) })
                        Spacer(Modifier.width(6.dp))
                        IconButton(onClick = { adminPrefs.edit().putBoolean("authenticated", false).apply(); authenticated = false }) { Icon(Icons.Default.Logout, T("Çıkış"), tint = TextMuted) }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(AT("Toplu görsel yükleme"), color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(AT("Birden fazla görsel seç; başlık dosya adından otomatik alınır."), color = TextMuted, fontSize = 12.sp)
                        OutlinedButton(onClick = { picker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.CloudUpload, null, tint = Purple)
                            Spacer(Modifier.width(8.dp))
                            Text(if (selectedUris.isEmpty()) AT("Görselleri seç") else "${AT("Seçilen")}: ${selectedUris.size}", color = Purple)
                        }
                        Box {
                            OutlinedButton(onClick = { showCategoryMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("${AT("Kategori")}: ${categories.firstOrNull { it.id == categoryId }?.name ?: categorySlug}", color = TextMain)
                            }
                            DropdownMenu(expanded = showCategoryMenu, onDismissRequest = { showCategoryMenu = false }) {
                                categories.forEach { cat ->
                                    DropdownMenuItem(text = { Text(cat.name) }, onClick = { categoryId = cat.id; categorySlug = cat.slug; showCategoryMenu = false })
                                }
                            }
                        }
                        OutlinedTextField(description, { description = it }, label = { Text(AT("Açıklama")) }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        OutlinedTextField(tags, { tags = it }, label = { Text(AT("Etiketler")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        if (busy && selectedUris.isNotEmpty()) LinearProgressIndicator(progress = { uploadProgress.toFloat() / selectedUris.size.coerceAtLeast(1) }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (selectedUris.isEmpty()) { message = AT("Önce görsel seç"); return@Button }
                            scope.launch {
                                busy = true; uploadProgress = 0; message = ""
                                try {
                                    selectedUris.forEachIndexed { index, uri ->
                                        val autoTitle = (getDisplayName(context.contentResolver, uri) ?: "wallpaper")
                                            .substringBeforeLast('.').replace('_', ' ').replace('-', ' ').trim()
                                        withContext(Dispatchers.IO) { AdminApi.upload(context.contentResolver, uri, categorySlug, autoTitle, description, tags) }
                                        uploadProgress = index + 1
                                    }
                                    selectedUris = emptyList(); description = ""; tags = ""
                                    val result = withContext(Dispatchers.IO) { ServerCatalogApi.load() }
                                    remoteWallpapers = result.first; remoteCategories = result.second
                                    images = withContext(Dispatchers.IO) { AdminApi.loadImages() }
                                    message = AT("Görseller başarıyla yüklendi")
                                } catch (e: Exception) { message = e.message ?: AT("Yükleme başarısız") }
                                finally { busy = false }
                            }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(AT("Sunucuya yükle")) }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text(AT("Kategori yönetimi"), color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(newCategoryName, { newCategoryName = it }, label = { Text(AT("Yeni kategori adı")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(newCategorySlug, { newCategorySlug = it.lowercase().replace("[^a-z0-9-]".toRegex(), "-") }, label = { Text("Slug") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Button(onClick = {
                            if (newCategoryName.isBlank() || newCategorySlug.isBlank()) { message = AT("Kategori adı ve slug gerekli"); return@Button }
                            scope.launch {
                                busy = true
                                try {
                                    withContext(Dispatchers.IO) { AdminApi.addCategory(newCategoryName.trim(), newCategorySlug.trim()) }
                                    newCategoryName = ""; newCategorySlug = ""; categories = withContext(Dispatchers.IO) { AdminApi.loadCategories() }
                                    message = AT("Kategori eklendi")
                                } catch (e: Exception) { message = e.message ?: AT("Kategori eklenemedi") }
                                finally { busy = false }
                            }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(AT("Kategori Ekle")) }
                        categories.forEach { cat ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(cat.name, color = TextMain, fontWeight = FontWeight.Medium); Text(cat.slug, color = TextMuted, fontSize = 11.sp) }
                                IconButton(onClick = { editingCategory = cat; editCategoryName = cat.name; editCategorySlug = cat.slug }) { Icon(Icons.Default.Edit, AT("Düzenle"), tint = Purple) }
                                IconButton(onClick = {
                                    scope.launch {
                                        busy = true
                                        try { withContext(Dispatchers.IO) { AdminApi.deleteCategory(cat.id) }; categories = categories.filterNot { it.id == cat.id }; if (categoryId == cat.id && categories.isNotEmpty()) { categoryId = categories.first().id; categorySlug = categories.first().slug }; message = AT("Kategori silindi") }
                                        catch (e: Exception) { message = e.message ?: AT("Kategori silinemedi") }
                                        finally { busy = false }
                                    }
                                }, enabled = !busy) { Icon(Icons.Default.Close, AT("Sil"), tint = MaterialTheme.colorScheme.error) }
                            }
                        }
                    }
                }
            }
            item { Text("${AT("Sunucudaki görseller")} (${images.size})", color = TextMain, fontWeight = FontWeight.Bold) }
            if (images.isEmpty()) item { Text(AT("Henüz görsel yok"), color = TextMuted, modifier = Modifier.padding(12.dp)) }
            else items(images, key = { it.id }) { image ->
                Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(
                            model = "$WXTRA_PUBLIC_BASE/api/images/file/${Uri.encode(image.filename)}",
                            contentDescription = image.title,
                            modifier = Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            Text(image.title.ifBlank { image.filename }, color = TextMain, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${image.category} • ${image.width}×${image.height}", color = TextMuted, fontSize = 11.sp)
                        }
                        IconButton(onClick = {
                            scope.launch {
                                busy = true
                                try { withContext(Dispatchers.IO) { AdminApi.delete(image.id) }; images = images.filterNot { it.id == image.id }; message = AT("Görsel silindi") }
                                catch (e: Exception) { message = e.message ?: AT("Silme başarısız") }
                                finally { busy = false }
                            }
                        }, enabled = !busy) { Icon(Icons.Default.Close, AT("Sil"), tint = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            if (message.isNotBlank()) item { Text(message, color = Purple, fontWeight = FontWeight.Medium, fontSize = 12.sp) }
        }
    }
}

private fun getDisplayName(resolver: ContentResolver, uri: Uri): String? {
    resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) return c.getString(0)
    }
    return null
}

private object ServerCatalogApi {
    private fun get(path: String): String {
        val c = URL("$WXTRA_API_BASE$path").openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.connectTimeout = 12_000; c.readTimeout = 20_000
        c.setRequestProperty("Accept", "application/json")
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IOException("$code: ${body.take(300)}")
            body
        } finally { c.disconnect() }
    }
    fun load(): Pair<List<ServerWallpaper>, List<ServerCategory>> {
        val ia = JSONObject(get("/images")).optJSONArray("images") ?: JSONArray()
        val ca = JSONArray(get("/categories"))
        val images = buildList {
            for (i in 0 until ia.length()) {
                val o = ia.getJSONObject(i); val f = o.optString("filename")
                if (f.isBlank()) continue
                add(ServerWallpaper(o.optLong("id"), f, o.optString("category", "other"), o.optInt("width"), o.optInt("height"), o.optString("title").ifBlank { f.substringBeforeLast('.') }, "$WXTRA_PUBLIC_BASE/api/images/file/${Uri.encode(f)}"))
            }
        }
        val categories = buildList {
            for (i in 0 until ca.length()) { val o=ca.getJSONObject(i); add(ServerCategory(o.getInt("id"),o.getString("name"),o.optString("slug","other"))) }
        }
        return images to categories
    }
}

private object AdminApi {
    private fun connection(path: String, method: String): HttpURLConnection {
        val c = (URL("$WXTRA_API_BASE$path").openConnection() as HttpURLConnection)
        c.requestMethod = method
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        c.setRequestProperty("X-WXTRA-ADMIN", WXTRA_ADMIN_TOKEN)
        c.setRequestProperty("Accept", "application/json")
        c.doInput = true
        return c
    }

    fun login(username: String, password: String) {
        val c = connection("/admin/login", "POST")
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        c.outputStream.use { it.write(JSONObject().put("username", username).put("password", password).toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (code !in 200..299) throw IOException(AT("Kullanıcı adı veya şifre hatalı"))
        if (!JSONObject(body).optBoolean("ok", false)) throw IOException(AT("Kullanıcı adı veya şifre hatalı"))
    }

    fun loadCategories(): List<AdminCategory> {
        val c = connection("/categories", "GET")
        return try {
            val text = c.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(text)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(AdminCategory(o.getInt("id"), o.getString("name"), o.optString("slug", "other")))
                }
            }
        } finally { c.disconnect() }
    }

    fun addCategory(name: String, slug: String) {
        val c = connection("/categories", "POST")
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        c.outputStream.use { it.write(JSONObject().put("name", name).put("slug", slug).toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        stream?.bufferedReader()?.use { it.readText() }
        c.disconnect()
        if (code !in 200..299) throw IOException("$code")
    }

    fun editCategory(id: Int, name: String, slug: String) {
        val c = connection("/categories/$id", "PUT")
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        c.outputStream.use { it.write(JSONObject().put("name", name).put("slug", slug).toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (code !in 200..299) throw IOException("$code: ${body.take(300)}")
    }

    fun deleteCategory(id: Int) {
        val c = connection("/categories/$id", "DELETE")
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IOException("$code: ${body.take(300)}")
        } finally { c.disconnect() }
    }

    fun loadImages(): List<AdminImage> {
        val c = connection("/images", "GET")
        return try {
            val text = c.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(text)
            val arr = root.optJSONArray("images") ?: JSONArray()
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(AdminImage(
                        id = o.optLong("id"),
                        filename = o.optString("filename"),
                        category = o.optString("category", "other"),
                        width = o.optInt("width"),
                        height = o.optInt("height"),
                        title = o.optString("title")
                    ))
                }
            }
        } finally { c.disconnect() }
    }

    fun upload(resolver: ContentResolver, uri: Uri, category: String, title: String, description: String, tags: String) {
        val boundary = "----WXTRA${System.currentTimeMillis()}"
        val c = connection("/images/upload", "POST")
        c.doOutput = true
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        val out = DataOutputStream(c.outputStream)
        fun field(name: String, value: String) {
            out.writeBytes("--$boundary\r\n")
            out.writeBytes("Content-Disposition: form-data; name=\"$name\"\r\n\r\n")
            out.write(value.toByteArray(Charsets.UTF_8))
            out.writeBytes("\r\n")
        }
        field("category", category)
        field("title", title)
        field("description", description)
        field("tags", tags)
        val filename = getDisplayName(resolver, uri) ?: "wallpaper.jpg"
        out.writeBytes("--$boundary\r\n")
        out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"$filename\"\r\n")
        out.writeBytes("Content-Type: image/*\r\n\r\n")
        resolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(8192)
            var n: Int
            while (input.read(buffer).also { n = it } != -1) out.write(buffer, 0, n)
        } ?: throw IOException("Dosya açılamadı")
        out.writeBytes("\r\n--$boundary--\r\n")
        out.flush(); out.close()
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (code !in 200..299) throw IOException("$code: ${body.take(300)}")
    }

    fun delete(id: Long) {
        val c = connection("/images/$id", "DELETE")
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            stream?.bufferedReader()?.use { it.readText() }
            if (code !in 200..299) throw IOException("$code")
        } finally { c.disconnect() }
    }
}
