# REST API sözleşmesi

Base URL: `API_BASE_URL`

## Kimlik doğrulama

`Authorization: Bearer <JWT>`

### `POST /api/auth/google`

```json
{"id_token":"<Google ID token>"}
```

Dönen:

```json
{"access_token":"<JWT>","token_type":"bearer"}
```

## İçerik

- `GET /api/wallpapers?page=1&page_size=20`
- `GET /api/wallpapers/{id}`
- `GET /api/wallpapers/trending`
- `GET /api/wallpapers/latest`
- `GET /api/wallpapers/recommended`
- `GET /api/categories`
- `GET /api/categories/{id}/wallpapers`
- `GET /api/search?q=mor&sort=trend&page=1&page_size=20`

`sort`: `new | popular | trend | favorite | editor`

## Favoriler

- `GET /api/favorites`
- `POST /api/favorites/{wallpaperId}`
- `DELETE /api/favorites/{wallpaperId}`

## Kullanıcı

- `GET /api/user`
- `PUT /api/user`
- `DELETE /api/user`

## Bildirim

- `GET /api/notifications`
- `PUT /api/notifications/settings`

Production API; repository/service katmanı, PostgreSQL transaction'ları, Redis cache, JWT doğrulaması, rate limit, audit log ve object storage/CDN ile tamamlanmalıdır.
