# WXTRA

WXTRA, telefon için modern bir duvar kâğıdı keşif uygulamasıdır.

## Yeniden kurulum planı

Bu sürüm temiz bir başlangıçtır. Uygulama önce **server olmadan** ayağa kaldırılır; server bağlantısı en son aşamada eklenecektir.

### Şu anki temel
- Jetpack Compose + Material 3
- Açılış ekranı / WXTRA splash
- Ana Sayfa
- Keşfet
- Wallpaper Swipe
- Profil
- Yerel örnek duvar kâğıtları
- Favori durumu
- Duvar kâğıdı detay ekranı
- Telefon ekranına uygun portrait tasarım

### Daha sonra
- Gerçek wallpaper katalog API'si
- Kullanıcı giriş/kayıt
- Google hesabı
- Favori/collection senkronizasyonu
- Admin paneli ve görsel yükleme
- Server taraflı kategori ve içerik yönetimi

> Server entegrasyonu özellikle bu aşamada uygulama koduna bağlı değildir.

## GitHub APK

`.github/workflows/apk.yml` dosyası GitHub Actions üzerinden debug APK üretir.
