WXTRA – tema, dil ve ana sayfa güncellemesi

Bu sürümde:
- 15 premium gradient arka plan teması eklendi.
- Tema seçenekleri kaydırılabilir hale getirildi.
- 14 dizilim korunarak kart genişlikleri ekran kenarlarına göre hesaplandı; yatay listelerde taşma/yarım kart problemi düzeltildi.
- English seçimi uygulama genelindeki ana UI metinlerine uygulanıyor.
- Ana sayfaya WXTRA başlığı, bildirim butonu ve arama alanı eklendi.
- Minimum Android sürümü: 8.0 (API 26).


WXTRA v31: profile-wide English translations, premium background gradients, symmetric home mood rows, 4-card rising row, improved home header/search.


WXTRA v32: mood row now uses the same symmetric, horizontally scrollable card layout as Trending.
