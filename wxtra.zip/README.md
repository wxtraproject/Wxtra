WXTRA

Launcher icon updated with the user-provided WXTRA logo (31588.png).
