# Wxtra Wallpaper

Minimal Flutter wallpaper app with:
- Wxtra logo-based visual identity
- Home page without categories
- "Günün Duvar Kağıtları" with 5 swipeable cards
- Tap-to-preview screen
- Download action placeholder
- GitHub Actions APK build
- Flutter analyze + test before APK build

## Build
flutter pub get
flutter analyze
flutter test
flutter build apk --release
