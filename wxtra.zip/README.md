# Premium Duvar Kağıdı

Türkçe, premium duvar kağıdı keşif uygulaması. Mobil istemci + REST API + PostgreSQL + Redis + Nginx mimarisi.

## Mimari

```text
Flutter Mobile
     │ HTTPS / JSON
     ▼
FastAPI REST API
     ├── PostgreSQL
     ├── Redis
     └── CDN / Image Storage
             ▲
             │
        Admin Panel (gelecekte)
```

## Proje yapısı

```text
mobile/     Flutter uygulaması
backend/    FastAPI API
docs/       API sözleşmesi ve mimari notları
docker/     Production yardımcı dosyaları
```

## İlk çalıştırma

### Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

API: `http://localhost:8000`
Dokümantasyon: `http://localhost:8000/docs`

### Docker

```bash
cp .env.example .env
docker compose up --build
```

### Mobil

Flutter SDK kurulu olmalıdır.

```bash
cd mobile
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8000/api
```

Android gerçek cihazda `10.0.2.2` yerine geliştirme makinesinin LAN IP'sini kullanın.

## Production

1. PostgreSQL'i kalıcı diskle çalıştırın.
2. Redis'i özel ağda tutun.
3. API'yi yalnızca Nginx üzerinden HTTPS ile yayınlayın.
4. Google OAuth redirect URI'larını production domain ile eşleyin.
5. `JWT_SECRET`, DB parolası ve OAuth secret'larını `.env` dışında source control'e koymayın.
6. Görselleri uygulama paketine gömmek yerine object storage + CDN üzerinden servis edin.
7. Migration sistemi olarak Alembic eklenip deployment pipeline'ında çalıştırılmalıdır.

## Ürün kuralları

- Uygulamada indirme / dışa aktarma / galeriye kaydetme özelliği yoktur.
- Uygulama içinde ekran görüntüsü üretme özelliği yoktur.
- Kullanıcı yalnızca uygulama içi görüntüleme ve favorileme yapabilir.
- Kullanıcı tarafından değiştirilebilen görsel ayar yalnızca kart dizilimidir.
- UI Türkçedir.

## Lisans

Proje başlangıç iskeleti MIT lisansı ile hazırlanmıştır.
