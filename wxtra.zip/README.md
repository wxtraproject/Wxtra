# WXTRA V24

Ana sayfadaki üst görsel artık sabit `home_hero` görseli değildir. Uygulamanın kendi mevcut duvar kâğıtları arasından günün görseli otomatik seçilir ve günlük olarak değişir.
