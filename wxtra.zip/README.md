# WXTRA

WXTRA Android wallpaper app (Jetpack Compose).

## Build

```bash
./gradlew :app:assembleDebug
```

## Latest fix

- Fixed the Kotlin compile error caused by calling the local `push()` function before its declaration in `MainActivity.kt`.
- Kept the app-wide 9:16 photographic background resource and existing UI/functionality intact.
- Performed structural source checks after the fix: balanced Kotlin delimiters and no `push()` calls occur before its declaration.

The environment used for this package did not contain a Gradle installation, so a full local APK compilation could not be executed here. The project is configured for Android Gradle Plugin 8.7.3 / Kotlin 2.0.21 / Java 17 as defined in the Gradle files.
