# WXTRA – Profil ekranı V26

Profil ekranı yeni tasarıma göre düzenlendi: profil başlığı, istatistikler, WXTRA Pro alanı, favoriler/koleksiyonlar/oluşturduklarım/geçmiş, Google/e-posta giriş seçenekleri, veri-yedekleme alanı ve hesap işlemleri.

Not: Google/Firebase kimlik doğrulamasının gerçek sunucu bağlantısı için Firebase proje yapılandırması (`google-services.json`) ve OAuth yapılandırması ayrıca eklenmelidir. Bu sürümde profil ekranı ve akışları hazırdır.
