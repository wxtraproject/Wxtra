# WXTRA

WXTRA'nın temiz başlangıç sürümü.

## Mevcut kapsam
- Jetpack Compose + Material 3
- WXTRA splash / başlangıç ekranı
- **Sadece Ayarlar ekranı**
- Yerel, server'sız çalışma
- Portrait telefon arayüzü

## Bu aşamada yok
- Ana Sayfa
- Kategoriler
- Keşfet
- Wallpaper Swipe
- Profil
- Admin paneli
- Login / kayıt
- Server / API bağlantısı

Server bağlantısı uygulama tamamen hazırlandıktan sonra, son aşamada eklenecektir.

## APK
GitHub Actions workflow'u debug APK üretmek için kullanılabilir.
