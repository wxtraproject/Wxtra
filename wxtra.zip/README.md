# WXTRA

WXTRA Android wallpaper app (Jetpack Compose).

## Final review in this package

- User Profile area kept as the main personalized account hub: avatar, name/username, Google account state, favorites, collections, recent views, backup/restore, security, storage, settings, logout and account deletion.
- Profile unauthenticated state uses the Google-only entry flow; e-mail sign-in/registration UI is not used.
- Settings -> WXTRA Hakkında opens the full in-app About screen.
- Privacy Policy and Terms of Use remain in-app with expandable sections and explanatory text.
- Version screen shows app version plus Android and MagicOS support wording.
- Android compatibility is configured with minSdk 26 (Android 8.0+), compileSdk/targetSdk 35.
- MagicOS wording intentionally refers to Android 8.0+ based MagicOS builds rather than claiming an arbitrary MagicOS version range.
- Static source checks performed: balanced Kotlin delimiters, no empty `onClick` blocks, no empty `clickable` blocks, and `push()` is declared before use.
- Launcher and splash assets are preserved.

A full APK build could not be run in this environment because Gradle/Android SDK are not installed here. GitHub Actions is configured to build with Gradle 8.9 and JDK 17.
