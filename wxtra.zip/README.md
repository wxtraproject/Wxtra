WXTRA - Sıfırdan görsel temel

Tüm eski sayfa tasarımları kaldırıldı. Wallpaper görselleri korunarak sade bir temel bırakıldı.
Bu sürüm sonraki tasarım çalışmalarının başlangıç noktasıdır.
