# WXTRA v36

## Bu sürümde
- Profil ekranındaki gereksiz **Hesap İşlemleri** bölümü kaldırıldı.
- Profildeki Türkçe sabit metinlerin İngilizce karşılıkları tamamlandı.
- Profil istatistikleri ve işlem başlıkları dil seçimine uyumlu hale getirildi.
- Ayarlar sıfırlama bildirimi İngilizce seçiliyken İngilizce gösterilir.
- v35'teki premium koyu mor / siyah / beyazımsı tema seçenekleri korunmuştur.

## Not
APK oluşturma işlemi GitHub Actions üzerinden yapılabilir.
