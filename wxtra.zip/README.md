# WXTRA

Fresh Android wallpaper-app starter.

## Build fix
Java and Kotlin are explicitly aligned to **JVM 17**, and the included GitHub Actions workflow uses JDK 17. This fixes the error:

`Inconsistent JVM-target compatibility detected ... JavaWithJava (1.8) and compileDebugKotlin (17)`

## Current UI
Home, Explore, Wallpaper Detail, AI Studio placeholder, Favorites and Profile.

Firebase, Google Sign-In and cloud/backend services are intentionally not included yet.
