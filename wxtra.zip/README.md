# Wxtra — Premium Duvar Kağıdı

GitHub Actions ile Android APK/AAB derlemeye hazır Flutter + FastAPI başlangıç projesi.

## GitHub'da önemli

Bu repository'deki `.github/workflows/android.yml` **eski `settings.gradle bul` scriptini kullanmaz**. Android klasörü yoksa GitHub runner üzerinde `flutter create --platforms=android` ile oluşturur ve sonra build eder.

Repository'ye ZIP'in içindeki **`premium_wallpaper_github` klasörünün içeriğini** yükleyin; GitHub'da `.github/workflows/android.yml` doğrudan repository kökünde görünmelidir.

Beklenen kök:

```text
.github/workflows/android.yml
mobile/pubspec.yaml
mobile/lib/main.dart
backend/app/main.py
README.md
```

Push sonrası Actions → **Wxtra Android Build** çalışır. Başarılı iş sonunda `wxtra-release-apk` ve `wxtra-release-aab` artifact'leri oluşur.

## API

Mobil API adresi kod içine gömülmez. GitHub Repository → Settings → Secrets and variables → Actions → New repository secret bölümünde `API_BASE_URL` oluşturun.

Örnek:

```text
https://api.senin-domainin.com/api
```

Secret tanımlı değilse workflow yalnızca build testi için Android emülatör varsayılanını kullanır.

## Ürün kuralları

- İndirme / Download özelliği yoktur.
- Galeriye kaydetme veya dosya dışa aktarma yoktur.
- Uygulama içi ekran görüntüsü alma özelliği yoktur.
- Kullanıcıya açık görsel kişiselleştirme yalnızca kart dizilimidir.
- Arayüz Türkçedir.

## Son kontrol

- Ana ekran WXTRA beyaz/mor/lila görsel diliyle yeniden düzenlendi.
- Ana ekrandaki keşif, kategori, favori, detay, paylaşım ve duvar kağıdı akışları korunup tıklanabilir bırakıldı.
- Ayarlar ekranındaki dil seçimi, alt sayfayı yanlışlıkla kapatan Navigator bağlamı hatası giderildi.
- Android geri tuşunda uygulama içi sekmelerden Ana Sayfa'ya güvenli dönüş eklendi.
- Tema davranışı sabit açık WXTRA temasında; Tema ayarı yalnızca kart dizilimini değiştirir.
- Önbellek temizliği Flutter görsel önbelleğine ek olarak WXTRA tarafından oluşturulan geçici PNG'leri de temizler.


## Son sürümde
- Admin paneli yalnızca APK içinde gizli erişimle bulunur.
- Ayarlar başlığına 10 kez dokunma ile admin giriş ekranı açılır.
- Wallpaper/kategori CRUD, yayın durumu, içerik seçimi, planlama, duyuru, sistem ve istatistik ekranları yerel olarak çalışır.
- Kullanıcı kişisel verileri admin panelinde gösterilmez.
- Gerçek üretim senkronizasyonu için `API_BASE_URL` üzerinden REST API bağlanır.
