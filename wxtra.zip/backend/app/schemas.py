from pydantic import BaseModel, Field
from typing import Optional, List

class UserOut(BaseModel):
    id: str
    username: str
    email: str
    avatar_url: Optional[str] = None
    favorite_count: int = 0
    view_count: int = 0

class WallpaperOut(BaseModel):
    id: str
    title: str
    image_url: str
    category: str
    tags: List[str] = []
    is_favorite: bool = False

class PaginatedWallpapers(BaseModel):
    items: List[WallpaperOut]
    page: int
    page_size: int
    has_next: bool

class CategoryOut(BaseModel):
    id: str
    name: str
    cover_url: str
    wallpaper_count: int = 0

class NotificationSettings(BaseModel):
    new_wallpapers: bool = True
    favorite_categories: bool = True
    recommendations: bool = True
    editor_picks: bool = True

class GoogleAuthRequest(BaseModel):
    id_token: str = Field(min_length=10)

class UserUpdate(BaseModel):
    username: Optional[str] = Field(default=None, min_length=2, max_length=40)
    avatar_url: Optional[str] = None
