from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = "sqlite:///./wallpaper.db"
    redis_url: str = "redis://localhost:6379/0"
    jwt_secret: str = "change-me"
    google_client_id: str = ""
    google_client_secret: str = ""
    cors_origins: str = "http://localhost:3000"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
