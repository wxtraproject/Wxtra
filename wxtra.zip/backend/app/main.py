from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .schemas import (
    UserOut, WallpaperOut, PaginatedWallpapers, CategoryOut,
    NotificationSettings, GoogleAuthRequest, UserUpdate
)
from typing import Optional

app = FastAPI(
    title="Premium Duvar Kağıdı API",
    version="1.0.0",
    description="Türkçe premium duvar kağıdı keşif uygulaması REST API'si."
)

origins = [x.strip() for x in settings.cors_origins.split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Development seed. Production'da PostgreSQL repository katmanına taşınır.
WALLPAPERS = [
    {
        "id": "wp-001", "title": "Mor Işık", "image_url": "",
        "category": "Soyut", "tags": ["mor", "premium", "minimal"], "is_favorite": False
    },
    {
        "id": "wp-002", "title": "Gece Ufku", "image_url": "",
        "category": "Uzay", "tags": ["uzay", "karanlık", "yıldız"], "is_favorite": False
    },
    {
        "id": "wp-003", "title": "Sessiz Dağlar", "image_url": "",
        "category": "Doğa", "tags": ["dağ", "doğa", "manzara"], "is_favorite": False
    },
]

CATEGORIES = [
    {"id": "amoled", "name": "AMOLED", "cover_url": "", "wallpaper_count": 0},
    {"id": "minimal", "name": "Minimal", "cover_url": "", "wallpaper_count": 0},
    {"id": "nature", "name": "Doğa", "cover_url": "", "wallpaper_count": 0},
    {"id": "space", "name": "Uzay", "cover_url": "", "wallpaper_count": 0},
    {"id": "cars", "name": "Arabalar", "cover_url": "", "wallpaper_count": 0},
    {"id": "anime", "name": "Anime", "cover_url": "", "wallpaper_count": 0},
    {"id": "abstract", "name": "Soyut", "cover_url": "", "wallpaper_count": 0},
    {"id": "city", "name": "Şehir", "cover_url": "", "wallpaper_count": 0},
]

@app.get("/health")
def health():
    return {"status": "ok", "service": "wallpaper-api"}

@app.post("/api/auth/google")
def google_login(payload: GoogleAuthRequest):
    # Production: Google token signature/audience doğrulaması + kullanıcı upsert.
    return {"access_token": "development-token", "token_type": "bearer"}

@app.get("/api/user", response_model=UserOut)
def get_user():
    return UserOut(
        id="demo-user", username="Wxtra", email="kullanici@example.com",
        favorite_count=12, view_count=48
    )

@app.put("/api/user", response_model=UserOut)
def update_user(payload: UserUpdate):
    return UserOut(
        id="demo-user",
        username=payload.username or "Wxtra",
        email="kullanici@example.com",
        avatar_url=payload.avatar_url,
        favorite_count=12,
        view_count=48,
    )

@app.delete("/api/user")
def delete_user():
    return {"message": "Hesap silme isteği alındı."}

def paginate(items, page: int, page_size: int):
    start = (page - 1) * page_size
    chunk = items[start:start + page_size]
    return PaginatedWallpapers(
        items=chunk, page=page, page_size=page_size,
        has_next=start + page_size < len(items)
    )

@app.get("/api/wallpapers", response_model=PaginatedWallpapers)
def list_wallpapers(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    return paginate(WALLPAPERS, page, page_size)

@app.get("/api/wallpapers/trending", response_model=PaginatedWallpapers)
def trending(page: int = 1, page_size: int = 20):
    return paginate(list(reversed(WALLPAPERS)), page, page_size)

@app.get("/api/wallpapers/latest", response_model=PaginatedWallpapers)
def latest(page: int = 1, page_size: int = 20):
    return paginate(WALLPAPERS, page, page_size)

@app.get("/api/wallpapers/recommended", response_model=PaginatedWallpapers)
def recommended(page: int = 1, page_size: int = 20):
    return paginate(WALLPAPERS, page, page_size)

@app.get("/api/wallpapers/{wallpaper_id}", response_model=WallpaperOut)
def wallpaper_detail(wallpaper_id: str):
    item = next((x for x in WALLPAPERS if x["id"] == wallpaper_id), None)
    if not item:
        raise HTTPException(404, "Duvar kağıdı bulunamadı.")
    return item

@app.get("/api/categories", response_model=list[CategoryOut])
def categories():
    return CATEGORIES

@app.get("/api/categories/{category_id}/wallpapers", response_model=PaginatedWallpapers)
def category_wallpapers(category_id: str, page: int = 1, page_size: int = 20):
    category = next((c for c in CATEGORIES if c["id"] == category_id), None)
    if not category:
        raise HTTPException(404, "Kategori bulunamadı.")
    items = [x for x in WALLPAPERS if x["category"].lower() == category["name"].lower()]
    return paginate(items, page, page_size)

@app.get("/api/search", response_model=PaginatedWallpapers)
def search(
    q: str = Query("", max_length=100),
    sort: str = Query("new"),
    page: int = 1,
    page_size: int = 20,
):
    term = q.strip().lower()
    if not term:
        items = WALLPAPERS
    else:
        items = [
            x for x in WALLPAPERS
            if term in x["title"].lower()
            or term in x["category"].lower()
            or any(term in tag.lower() for tag in x["tags"])
        ]
    if sort in {"popular", "trend", "favorite"}:
        items = list(reversed(items))
    return paginate(items, page, page_size)

@app.post("/api/favorites/{wallpaper_id}")
def add_favorite(wallpaper_id: str):
    if not any(x["id"] == wallpaper_id for x in WALLPAPERS):
        raise HTTPException(404, "Duvar kağıdı bulunamadı.")
    return {"wallpaper_id": wallpaper_id, "favorite": True}

@app.delete("/api/favorites/{wallpaper_id}")
def remove_favorite(wallpaper_id: str):
    return {"wallpaper_id": wallpaper_id, "favorite": False}

@app.get("/api/favorites", response_model=PaginatedWallpapers)
def favorites(page: int = 1, page_size: int = 20):
    return paginate(WALLPAPERS[:1], page, page_size)

@app.get("/api/notifications")
def notifications():
    return []

@app.put("/api/notifications/settings", response_model=NotificationSettings)
def notification_settings(payload: NotificationSettings):
    return payload
