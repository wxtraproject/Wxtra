# WXTRA — Server Later

Bu klasör bilerek boş tutulur.

WXTRA'nın ilk sürümünde uygulama yerel/mock içerikle çalışır. API, kullanıcı senkronizasyonu, admin yükleme ve uzak katalog bağlantısı **en son aşamada** eklenecektir.

Server entegrasyonu yapılırken:
- API adresi BuildConfig üzerinden verilecek.
- HTTP yerine HTTPS kullanılacak.
- Kullanıcı kimlik doğrulaması sunucu tarafında doğrulanacak.
- Admin yetkileri istemciye gömülmeyecek.
