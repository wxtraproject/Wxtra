# WXTRA

WXTRA, statik ve canlı duvar kağıtlarını tek bir premium deneyimde birleştiren Android uygulama projesidir.

## Bu sürüm
Bu sürüm özellikle telefon üzerinden GitHub ile geliştirilmeye uygun olacak şekilde hazırlanmıştır. Ana ekran, keşfet, detay, canlı önizleme, AI Studio, düzenleyici, dinamik wallpaper, koleksiyonlar, favoriler, profil, premium ve yan menü akışları aynı projededir.

### Ana özellik akışı
1. Açılış
2. Ana Sayfa
3. Keşfet
4. Wallpaper Detay
5. Canlı Önizleme
6. AI Studio
7. Wallpaper Düzenleyici
8. Dinamik Wallpaper
9. Koleksiyonlar
10. Favoriler
11. Profil / Creator
12. Premium

Statik wallpaper Android WallpaperManager ile uygulanabilir; canlı wallpaper Android WallpaperService üzerinden açılır. Örnek görseller `app/src/main/res/drawable` altında bulunur.

## GitHub'dan APK
`.github/workflows/build.yml` dosyası GitHub Actions üzerinden debug APK üretir. GitHub'da **Actions → Build WXTRA APK → Run workflow** ile manuel olarak da çalıştırılabilir.

## Sonraki aşama
Firebase, Google giriş, gerçek creator yükleme, Firestore/Storage katalogu, AI servisi ve Google Play Billing bağlantıları eklenecektir.
