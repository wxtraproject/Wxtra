# WXTRA

WXTRA wallpaper app — white, premium, image-first experience.

## Current UI
- Ana Sayfa: Senin için, WXTRA PRO, Popüler, Trendler, Yeni Eklenenler, Editörün Seçimi
- Keşfet: arama, filtre çipleri ve iki sütunlu keşif görünümü
- AI Stüdyo: prompt + stil seçenekleri + premium CTA
- Favoriler: iki sütunlu kayıtlı duvar kâğıdı görünümü
- Profil: istatistikler, koleksiyonlar, ayarlar ve PRO alanı
- WXTRA PRO: premium tanıtım ekranı
- Duvar kâğıdı detay: önizleme ve doğrudan duvar kâğıdı yap

İndirme özelliği intentionally yoktur.
