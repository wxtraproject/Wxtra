# WXTRA

WXTRA is a fresh Android wallpaper-app starter built from scratch.

## Current phase
- Jetpack Compose UI
- Home
- Explore
- Wallpaper detail
- AI Studio placeholder
- Favorites
- Profile
- Bundled demo wallpapers
- No Firebase / Google Sign-In / backend yet

## Open
Open the project folder in Android Studio and run it on an Android device/emulator.

The next phase is visual refinement: WXTRA branding, exact spacing, cards, animations, categories, editor, collections, dynamic wallpapers and polished empty/loading states. Backend is intentionally postponed.
