package com.wextra.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF6D35F5)
private val Purple2 = Color(0xFFB08BFF)
private val Ink = Color(0xFFF7F5FF)
private val Muted = Color(0xFFB7B3C8)
private val Soft = Color(0x16FFFFFF)
private val Line = Color(0x24FFFFFF)
private val AppGradient = Brush.linearGradient(
    colors = listOf(
        Color(0xFF0B0F1A),
        Color(0xFF151A32),
        Color(0xFF2B1554),
        Color(0xFF120E29),
        Color(0xFF0B0F1A)
    )
)

data class Wallpaper(val title: String, val subtitle: String, val image: Int)

private val wallpapers = listOf(
    Wallpaper("Renkli Kuş", "Doğanın renkleri", R.drawable.wallpaper_0),
    Wallpaper("Kırmızı Dokunuş", "Çiçeklerin hikâyesi", R.drawable.wallpaper_1),
    Wallpaper("Saklı Bahçe", "Renklerin içinde", R.drawable.wallpaper_2),
    Wallpaper("Pembe Efsane", "Otomobil tutkusu", R.drawable.wallpaper_3),
    Wallpaper("Gece Sürüşü", "Şehir ışıkları", R.drawable.wallpaper_4),
    Wallpaper("Doğanın İçinde", "Canlı yaşam", R.drawable.wallpaper_5),
    Wallpaper("Zarif Dokunuş", "Minimal çiçekler", R.drawable.wallpaper_6),
    Wallpaper("Akış", "Soyut evren", R.drawable.wallpaper_7),
    Wallpaper("Renkli Akşamlar", "Yollar seni bekliyor", R.drawable.wallpaper_8)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAApp() }
    }
}

@Composable
fun WXTRAApp() {
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Wallpaper?>(null) }
    var showPro by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Color(0xFF0B0F1A), surface = Color(0xFF11162A), onBackground = Ink, onSurface = Ink)) {
        when {
            selected != null -> DetailScreen(selected!!, { selected = null })
            showPro -> ProScreen { showPro = false }
            else -> Scaffold(
                containerColor = Color(0xCC0B0F1A),
                bottomBar = { WXTRANav(tab) { tab = it } }
            ) { padding ->
                when (tab) {
                    0 -> HomeScreen(padding, { selected = it }, { showPro = true })
                    1 -> ExploreScreen(padding, { selected = it })
                    2 -> AIStudioScreen(padding, { showPro = true })
                    3 -> FavoritesScreen(padding, { selected = it })
                    else -> ProfileScreen(padding, { showPro = true })
                }
            }
        }
    }
}

@Composable
fun WXTRANav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xCC0B0F1A), modifier = Modifier.height(82.dp)) {
        val labels = listOf("Ana Sayfa", "Keşfet", "AI", "Favoriler", "Profil")
        val icons = listOf(Icons.Default.Home, Icons.Default.Explore, Icons.Default.AutoAwesome, Icons.Default.FavoriteBorder, Icons.Default.Person)
        labels.forEachIndexed { index, label ->
            NavigationBarItem(
                selected = selected == index,
                onClick = { onSelect(index) },
                icon = {
                    if (index == 2) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Purple2))), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AutoAwesome, null, tint = Color.White)
                        }
                    } else Icon(icons[index], null)
                },
                label = { Text(label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, indicatorColor = Color(0xFFEDE6FF))
            )
        }
    }
}

@Composable
fun HomeScreen(padding: PaddingValues, open: (Wallpaper) -> Unit, pro: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).background(AppGradient)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("WXTRA", fontSize = 31.sp, fontWeight = FontWeight.Black, color = Ink, letterSpacing = 1.sp)
                Text("DUVARIN. SENİN TARZIN.", fontSize = 9.sp, color = Muted, letterSpacing = 1.7.sp)
            }
            IconButton(onClick = {}) { Icon(Icons.Default.Search, null, tint = Ink) }
            IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, null, tint = Ink) }
            Box(Modifier.size(38.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Purple2))), contentAlignment = Alignment.Center) {
                Text("W", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        HeroCard(wallpapers[2], open)
        SectionTitle("Senin için", "Tarzına uygun seçkiler")
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(wallpapers.take(5)) { ImageCard(it, 178.dp, 238.dp, open) }
        }
        ProBanner(pro)
        SectionTitle("Popüler", "Şu an en çok beğenilenler")
        SmallRow(wallpapers.reversed().take(6), open)
        SectionTitle("Trendler", "WXTRA'da yükselenler")
        SmallRow(wallpapers.drop(2).take(6), open)
        SectionTitle("Yeni Eklenenler", "İlk sen keşfet")
        SmallRow(wallpapers.takeLast(6), open)
        SectionTitle("Editörün Seçimi", "WXTRA ekibinden özel seçim")
        SmallRow(wallpapers.take(6).reversed(), open)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 11.dp), verticalAlignment = Alignment.Bottom) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(subtitle, fontSize = 12.sp, color = Muted)
        }
        Text("Tümü  ›", color = Purple, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
    }
}

@Composable
fun HeroCard(wallpaper: Wallpaper, open: (Wallpaper) -> Unit) {
    Box(Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(290.dp).clip(RoundedCornerShape(28.dp)).clickable { open(wallpaper) }) {
        Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .86f)))))
        Row(Modifier.align(Alignment.TopStart).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(12.dp), color = Color.White.copy(alpha = .9f)) {
                Text("✦  BUGÜNÜN SEÇKİSİ", modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp), color = Ink, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
        Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
            Text(wallpaper.title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Her ekranda yeni bir hikâye.", color = Color.White.copy(alpha = .82f), fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Button(onClick = { open(wallpaper) }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC0B0F1A), contentColor = Ink)) { Text("Görüntüle  →") }
        }
    }
}

@Composable
fun ImageCard(wallpaper: Wallpaper, width: Dp, height: Dp, open: (Wallpaper) -> Unit) {
    Column(Modifier.width(width).clickable { open(wallpaper) }) {
        Box(Modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(22.dp))) {
            Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .28f)))))
            Icon(Icons.Default.FavoriteBorder, null, tint = Color.White, modifier = Modifier.align(Alignment.TopEnd).padding(11.dp))
        }
        Text(wallpaper.title, modifier = Modifier.padding(top = 8.dp, start = 2.dp), color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
        Text(wallpaper.subtitle, modifier = Modifier.padding(start = 2.dp), color = Muted, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
fun SmallRow(list: List<Wallpaper>, open: (Wallpaper) -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(list) { ImageCard(it, 128.dp, 158.dp, open) }
    }
}

@Composable
fun ProBanner(onClick: () -> Unit) {
    Row(Modifier.padding(20.dp).fillMaxWidth().height(132.dp).clip(RoundedCornerShape(25.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF171225), Purple, Color(0xFFBC96FF)))).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Text("♛", color = Color(0xFFFFD66E), fontSize = 27.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("WXTRA PRO", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Özel seçkiler ve premium deneyim.", color = Color.White.copy(alpha = .84f), fontSize = 11.sp)
            Spacer(Modifier.height(5.dp))
            Text("Sana özel dünyayı aç.", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Button(onClick = onClick, shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC0B0F1A), contentColor = Purple)) { Text("Keşfet") }
    }
}

@Composable
fun ExploreScreen(padding: PaddingValues, open: (Wallpaper) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).background(AppGradient)) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Keşfet", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink); Text("Yeni favorini bul.", color = Muted, fontSize = 12.sp) }
            IconButton(onClick = {}) { Icon(Icons.Default.Tune, null) }
        }
        OutlinedTextField(value = "", onValueChange = {}, placeholder = { Text("Duvar kâğıdı ara...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(17.dp), singleLine = true)
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf("Tümü", "Popüler", "Trendler", "Yeni")) { chip -> AssistChip(onClick = {}, label = { Text(chip) }) }
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(wallpapers.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    row.forEach { ImageCard(it, 0.dp, 215.dp, open, Modifier.weight(1f)) }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ImageCard(wallpaper: Wallpaper, width: Dp, height: Dp, open: (Wallpaper) -> Unit, modifier: Modifier) {
    Column(modifier.clickable { open(wallpaper) }) {
        Box(Modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(20.dp))) {
            Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Surface(Modifier.align(Alignment.TopEnd).padding(9.dp), shape = CircleShape, color = Color.Black.copy(alpha = .25f)) { Icon(Icons.Default.FavoriteBorder, null, tint = Color.White, modifier = Modifier.padding(7.dp).size(18.dp)) }
        }
        Text(wallpaper.title, modifier = Modifier.padding(top = 7.dp, start = 2.dp), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Text(wallpaper.subtitle, modifier = Modifier.padding(start = 2.dp), fontSize = 11.sp, color = Muted)
    }
}

@Composable
fun FavoritesScreen(padding: PaddingValues, open: (Wallpaper) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).background(AppGradient)) {
        Text("Favoriler", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.padding(horizontal = 20.dp, vertical = 20.dp))
        Text("Kaydettiğin ilhamlar burada.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp))
        LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(wallpapers.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    row.forEach { ImageCard(it, 0.dp, 220.dp, open, Modifier.weight(1f)) }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun AIStudioScreen(padding: PaddingValues, pro: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).background(AppGradient)) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("AI Stüdyo", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink); Text("Hayal et. WXTRA oluştursun.", color = Muted, fontSize = 12.sp) }
            Surface(shape = RoundedCornerShape(10.dp), color = Color(0x22A78BFA)) { Text("PRO", color = Color(0xFFC4B5FD), fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)) }
        }
        Card(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color(0x18FFFFFF))) {
            Column(Modifier.padding(18.dp)) {
                Text("Duvarını tarif et", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Stil, ışık ve atmosferi sen seç.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
                Spacer(Modifier.height(13.dp))
                OutlinedTextField(value = "", onValueChange = {}, placeholder = { Text("Örn. neon şehir, yağmurlu gece...") }, minLines = 5, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(17.dp))
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    listOf("Sinematik", "Minimal", "Neon", "Doğa").forEach { AssistChip(onClick = {}, label = { Text(it) }) }
                }
                Spacer(Modifier.height(13.dp))
                Button(onClick = pro, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("AI ile oluştur") }
            }
        }
        SectionTitle("İlham al", "AI ile oluşturabileceğin stiller")
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(wallpapers.take(5)) { ImageCard(it, 145.dp, 185.dp, {}) } }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun ProfileScreen(padding: PaddingValues, pro: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).background(AppGradient)) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) { Text("Profil", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f)); IconButton(onClick = {}) { Icon(Icons.Default.Settings, null) } }
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(96.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Purple2))), contentAlignment = Alignment.Center) { Text("W", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Black) }
            Text("WXTRA Kullanıcısı", fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
            Text("Kendi duvarını, kendi tarzını oluştur.", color = Muted, fontSize = 12.sp)
            Row(Modifier.padding(vertical = 22.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("12", "Favori"); Stat("04", "Koleksiyon"); Stat("PRO", "Durum")
            }
        }
        ProBanner(pro)
        ProfileRow(Icons.Default.FavoriteBorder, "Favorilerim", "Kaydettiğin duvar kâğıtları")
        ProfileRow(Icons.Default.CollectionsBookmark, "Koleksiyonlar", "Kendi seçkilerini oluştur")
        ProfileRow(Icons.Default.AutoAwesome, "AI Stüdyo", "Yeni fikirler üret")
        ProfileRow(Icons.Default.Settings, "Ayarlar", "Uygulama tercihleri")
        Spacer(Modifier.height(20.dp))
    }
}

@Composable fun Stat(value: String, label: String) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(value, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 11.sp) } }

@Composable
fun ProfileRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(Modifier.padding(horizontal = 20.dp, vertical = 5.dp).fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Soft).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Purple, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 11.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
fun ProScreen(back: () -> Unit) {
    Column(Modifier.fillMaxSize().background(AppGradient).verticalScroll(rememberScrollState())) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null) }; Text("WXTRA PRO", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        Box(Modifier.padding(20.dp).fillMaxWidth().height(250.dp).clip(RoundedCornerShape(30.dp)).background(Brush.linearGradient(listOf(Color(0xFF151126), Purple, Color(0xFFBD9CFF))))) {
            Column(Modifier.align(Alignment.BottomStart).padding(22.dp)) {
                Text("WXTRA PRO", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("Duvar kâğıdının premium hali.", color = Color.White.copy(alpha = .85f))
                Spacer(Modifier.height(12.dp)); Text("✦ Özel seçkiler", color = Color.White); Text("✦ Premium AI deneyimi", color = Color.White); Text("✦ Reklamsız deneyim", color = Color.White)
            }
        }
        Text("Daha fazlasını hisset.", fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
        Text("WXTRA'nın özel dünyasını keşfet.", color = Muted, modifier = Modifier.padding(horizontal = 20.dp, vertical = 5.dp))
        Button(onClick = {}, modifier = Modifier.padding(20.dp).fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp)) { Text("WXTRA PRO'ya geç  ✦") }
    }
}

@Composable
fun DetailScreen(wallpaper: Wallpaper, back: () -> Unit) {
    Box(Modifier.fillMaxSize().background(AppGradient)) {
        Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .1f), Color.Transparent, Color.Black.copy(alpha = .72f)))))
        Row(Modifier.fillMaxWidth().padding(top = 34.dp, start = 12.dp, end = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            FilledIconButton(onClick = back, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White.copy(alpha = .9f))) { Icon(Icons.Default.ArrowBack, null) }
            FilledIconButton(onClick = {}, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White.copy(alpha = .9f))) { Icon(Icons.Default.FavoriteBorder, null) }
        }
        Card(Modifier.align(Alignment.BottomCenter).fillMaxWidth(), shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp), colors = CardDefaults.cardColors(containerColor = Color(0xE60F1324))) {
            Column(Modifier.padding(20.dp)) {
                Text(wallpaper.title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(wallpaper.subtitle, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(15.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) { Tag("9:16"); Tag("Ultra HD"); Tag("WXTRA") }
                Spacer(Modifier.height(16.dp))
                Button(onClick = {}, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp)) { Icon(Icons.Default.Wallpaper, null); Spacer(Modifier.width(8.dp)); Text("Duvar kâğıdı yap") }
                Text("İndirme özelliği bulunmaz • doğrudan duvar kâğıdı olarak uygula.", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 9.dp))
            }
        }
    }
}

@Composable fun Tag(text: String) { Surface(shape = RoundedCornerShape(10.dp), color = Soft) { Text(text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), fontSize = 10.sp, color = Muted, fontWeight = FontWeight.SemiBold) } }
