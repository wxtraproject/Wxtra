package com.wextra.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF6D35F5)
private val Purple2 = Color(0xFFAA7BFF)
private val Ink = Color(0xFF121218)
private val Muted = Color(0xFF777783)
private val Soft = Color(0xFFF7F5FC)

data class Wallpaper(val title:String,val subtitle:String,val image:Int)
private val wallpapers=listOf(
 Wallpaper("Renkli Kuş","Doğanın renkleri",R.drawable.wallpaper_0),
 Wallpaper("Kırmızı Dokunuş","Çiçeklerin hikâyesi",R.drawable.wallpaper_1),
 Wallpaper("Saklı Bahçe","Sınırların ötesinde",R.drawable.wallpaper_2),
 Wallpaper("Pembe Efsane","Otomobil tutkusu",R.drawable.wallpaper_3),
 Wallpaper("Gece Sürüşü","Şehir ışıkları",R.drawable.wallpaper_4),
 Wallpaper("Doğanın İçinde","Canlı yaşam",R.drawable.wallpaper_5),
 Wallpaper("Zarif Dokunuş","Minimal çiçekler",R.drawable.wallpaper_6),
 Wallpaper("Akış","Soyut evren",R.drawable.wallpaper_7),
 Wallpaper("Renkli Akşamlar","Yollar seni bekliyor",R.drawable.wallpaper_8)
)

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{WXTRAApp()}}}

@Composable fun WXTRAApp(){var tab by remember{mutableIntStateOf(0)};var selected by remember{mutableStateOf<Wallpaper?>(null)};MaterialTheme(colorScheme=lightColorScheme(primary=Purple,background=Color.White)){if(selected!=null)Detail(selected!!){selected=null}else Scaffold(containerColor=Color.White,bottomBar={Nav(tab){tab=it}}){p->when(tab){0->Home(p){selected=it};1->Explore(p){selected=it};2->AI(p);3->Favorites(p){selected=it};else->Profile(p)}}}}}

@Composable fun Nav(selected:Int,on:(Int)->Unit){NavigationBar(containerColor=Color.White,modifier=Modifier.height(78.dp)){val labs=listOf("Ana Sayfa","Keşfet","AI","Favoriler","Profil");val icons=listOf(Icons.Default.Home,Icons.Default.Explore,Icons.Default.AutoAwesome,Icons.Default.FavoriteBorder,Icons.Default.Person);labs.forEachIndexed{i,l->NavigationBarItem(selected=selected==i,onClick={on(i)},icon={if(i==2)Box(Modifier.size(48.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple,Purple2))),contentAlignment=Alignment.Center){Icon(Icons.Default.AutoAwesome,null,tint=Color.White)}else Icon(icons[i],null)},label={Text(l,fontSize=10.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Purple,selectedTextColor=Purple,indicatorColor=Color(0xFFECE5FF)))}}}

@Composable fun Home(p:PaddingValues,open:(Wallpaper)->Unit){Column(Modifier.fillMaxSize().padding(p).verticalScroll(rememberScrollState()).background(Color.White)){Row(Modifier.fillMaxWidth().padding(20.dp,16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("WXTRA",fontSize=32.sp,fontWeight=FontWeight.Black,color=Ink);Text("DAHA FAZLASI, DAHA SEN.",fontSize=10.sp,letterSpacing=2.sp,color=Muted)}IconButton(onClick={}){Icon(Icons.Default.Search,null)}IconButton(onClick={}){Icon(Icons.Default.NotificationsNone,null)}Box(Modifier.size(38.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple,Purple2))),contentAlignment=Alignment.Center){Text("W",color=Color.White,fontWeight=FontWeight.Bold)}}Hero(wallpapers[2],open);Section("Senin için","Tarzına uygun, özel seçkiler."){LazyRow(contentPadding=PaddingValues(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)){items(wallpapers.take(5)){ImageCard(it,190.dp,250.dp,open)}}};Pro();Section("Popüler","En çok beğenilen duvar kâğıtları."){Small(wallpapers.reversed().take(6),open)};Section("Trendler","Şu anda yükselen duvar kâğıtları."){Small(wallpapers.drop(2).take(6),open)};Section("Yeni Eklenenler","En yeni duvar kâğıtlarını keşfet."){Small(wallpapers.takeLast(6),open)};Section("Editörün Seçimi","WXTRA ekibinin senin için seçtikleri."){Small(wallpapers.shuffled().take(6),open)};Spacer(Modifier.height(20.dp))}}

@Composable fun Section(t:String,s:String,content:@Composable()->Unit){Row(Modifier.fillMaxWidth().padding(20.dp,18.dp,20.dp,10.dp),verticalAlignment=Alignment.Bottom){Column(Modifier.weight(1f)){Text(t,fontSize=23.sp,fontWeight=FontWeight.Bold,color=Ink);Text(s,fontSize=12.sp,color=Muted)}Text("Tümünü gör  →",color=Purple,fontWeight=FontWeight.SemiBold,fontSize=12.sp)}content()}

@Composable fun Hero(w:Wallpaper,open:(Wallpaper)->Unit){Box(Modifier.padding(horizontal=20.dp).fillMaxWidth().height(285.dp).clip(RoundedCornerShape(28.dp)).clickable{open(w)}){Image(painterResource(w.image),null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop);Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,Color.Black.copy(.82f)))));Column(Modifier.align(Alignment.BottomStart).padding(22.dp)){Text("GÜNÜN SEÇKİSİ",color=Color.White.copy(.75f),fontSize=11.sp,letterSpacing=2.sp);Text(w.title,color=Color.White,fontSize=28.sp,fontWeight=FontWeight.Bold);Text("Her ekranda yeni bir hikâye.",color=Color.White.copy(.9f));Spacer(Modifier.height(10.dp));Button(onClick={open(w)},shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Color.White,contentColor=Ink)){Text("Keşfet  →")}}}}

@Composable fun ImageCard(w:Wallpaper,width:androidx.compose.ui.unit.Dp,height:androidx.compose.ui.unit.Dp,open:(Wallpaper)->Unit){Box(Modifier.width(width).height(height).clip(RoundedCornerShape(22.dp)).clickable{open(w)}){Image(painterResource(w.image),null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop);Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,Color.Black.copy(.72f)))));Icon(Icons.Default.FavoriteBorder,null,tint=Color.White,modifier=Modifier.align(Alignment.TopEnd).padding(12.dp));Column(Modifier.align(Alignment.BottomStart).padding(14.dp)){Text(w.title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=17.sp);Text(w.subtitle,color=Color.White.copy(.8f),fontSize=11.sp)}}}
@Composable fun Small(list:List<Wallpaper>,open:(Wallpaper)->Unit){LazyRow(contentPadding=PaddingValues(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){items(list){ImageCard(it,125.dp,155.dp,open)}}}

@Composable fun Pro(){Row(Modifier.padding(20.dp).fillMaxWidth().height(128.dp).clip(RoundedCornerShape(24.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF15102B),Purple,Color(0xFFC49DFF)))).padding(18.dp),verticalAlignment=Alignment.CenterVertically){Text("♛",color=Color(0xFFFFD76A),fontSize=34.sp);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("WXTRA PRO",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Bold);Text("Sıradışı duvar kâğıtları, sadece sana özel.",color=Color.White.copy(.82f),fontSize=11.sp);Text("Sınırsız koleksiyonlara eriş.",color=Color.White,fontSize=12.sp)}Button(onClick={},shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Color.White,contentColor=Purple)){Text("PRO'yu keşfet")}}}

@Composable fun Explore(p:PaddingValues,open:(Wallpaper)->Unit){Column(Modifier.fillMaxSize().padding(p).background(Color.White)){Text("Keşfet",fontSize=28.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp));OutlinedTextField(value="",onValueChange={},placeholder={Text("Duvar kâğıdı ara...")},leadingIcon={Icon(Icons.Default.Search,null)},modifier=Modifier.fillMaxWidth().padding(horizontal=20.dp),shape=RoundedCornerShape(18.dp));LazyRow(contentPadding=PaddingValues(20.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){items(listOf("Tümü","Yeni","Popüler","Trendler")){AssistChip(onClick={},label={Text(it)})}};Row(Modifier.padding(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)){wallpapers.take(2).forEach{ImageCard(it,170.dp,230.dp,open)}}}}
@Composable fun Favorites(p:PaddingValues,open:(Wallpaper)->Unit){Column(Modifier.fillMaxSize().padding(p).background(Color.White)){Text("Favorilerim",fontSize=28.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp));LazyRow(contentPadding=PaddingValues(20.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)){items(wallpapers.take(6)){ImageCard(it,170.dp,230.dp,open)}}}}
@Composable fun AI(p:PaddingValues){Column(Modifier.fillMaxSize().padding(p).background(Color.White)){Text("AI Stüdyo",fontSize=28.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp));Card(Modifier.padding(20.dp).fillMaxWidth(),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=Soft)){Column(Modifier.padding(18.dp)){Text("Hayal et, duvar kâğıdına dönüştür.",fontSize=18.sp,fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(12.dp));OutlinedTextField(value="",onValueChange={},placeholder={Text("Ne hayal ediyorsun?")},minLines=4,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(12.dp));Button(onClick={},Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.AutoAwesome,null);Spacer(Modifier.width(8.dp));Text("Şimdi oluştur")}}}}}
@Composable fun Profile(p:PaddingValues){Column(Modifier.fillMaxSize().padding(p).background(Color.White)){Text("Profil",fontSize=28.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp));Column(Modifier.fillMaxWidth(),horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.size(90.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple,Purple2))),contentAlignment=Alignment.Center){Text("W",color=Color.White,fontSize=34.sp,fontWeight=FontWeight.Bold)};Text("WXTRA Kullanıcısı",fontSize=21.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp));Text("Duvar kâğıtlarınla daha fazlası.",color=Muted);Spacer(Modifier.height(18.dp));Pro()}}}
@Composable fun Detail(w:Wallpaper,back:()->Unit){Box(Modifier.fillMaxSize()){Image(painterResource(w.image),null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop);Row(Modifier.fillMaxWidth().padding(top=36.dp,start=12.dp,end=12.dp),horizontalArrangement=Arrangement.SpaceBetween){FilledIconButton(onClick=back){Icon(Icons.Default.ArrowBack,null)};FilledIconButton(onClick={}){Icon(Icons.Default.FavoriteBorder,null)}};Card(Modifier.align(Alignment.BottomCenter).fillMaxWidth(),shape=RoundedCornerShape(topStart=28.dp,topEnd=28.dp)){Column(Modifier.padding(20.dp)){Text(w.title,fontSize=25.sp,fontWeight=FontWeight.Bold);Text(w.subtitle,color=Muted);Spacer(Modifier.height(16.dp));Row(horizontalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.fillMaxWidth()){OutlinedButton(onClick={},Modifier.weight(1f)){Icon(Icons.Default.PhoneAndroid,null);Spacer(Modifier.width(5.dp));Text("Ana ekran")};Button(onClick={},Modifier.weight(1f)){Icon(Icons.Default.Lock,null);Spacer(Modifier.width(5.dp));Text("Kilit ekranı")}}}}}}
