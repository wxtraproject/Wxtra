package com.wextra.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF6D35F5)
private val Purple2 = Color(0xFFAA7BFF)
private val Ink = Color(0xFF121218)
private val Muted = Color(0xFF777783)
private val Soft = Color(0xFFF7F5FC)

data class Wallpaper(val title: String, val subtitle: String, val image: Int)

private val wallpapers = listOf(
    Wallpaper("Renkli Kuş", "Doğanın renkleri", R.drawable.wallpaper_0),
    Wallpaper("Kırmızı Dokunuş", "Çiçeklerin hikâyesi", R.drawable.wallpaper_1),
    Wallpaper("Saklı Bahçe", "Sınırların ötesinde", R.drawable.wallpaper_2),
    Wallpaper("Pembe Efsane", "Otomobil tutkusu", R.drawable.wallpaper_3),
    Wallpaper("Gece Sürüşü", "Şehir ışıkları", R.drawable.wallpaper_4),
    Wallpaper("Doğanın İçinde", "Canlı yaşam", R.drawable.wallpaper_5),
    Wallpaper("Zarif Dokunuş", "Minimal çiçekler", R.drawable.wallpaper_6),
    Wallpaper("Akış", "Soyut evren", R.drawable.wallpaper_7),
    Wallpaper("Renkli Akşamlar", "Yollar seni bekliyor", R.drawable.wallpaper_8)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAApp() }
    }
}

@Composable
fun WXTRAApp() {
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Wallpaper?>(null) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = Color.White)) {
        if (selected != null) {
            DetailScreen(selected!!) { selected = null }
        } else {
            Scaffold(
                containerColor = Color.White,
                bottomBar = { WXTRANav(tab) { tab = it } }
            ) { padding ->
                when (tab) {
                    0 -> HomeScreen(padding) { selected = it }
                    1 -> ExploreScreen(padding) { selected = it }
                    2 -> AIStudioScreen(padding)
                    3 -> FavoritesScreen(padding) { selected = it }
                    else -> ProfileScreen(padding)
                }
            }
        }
    }
}

@Composable
fun WXTRANav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color.White, modifier = Modifier.height(78.dp)) {
        val labels = listOf("Ana Sayfa", "Keşfet", "AI", "Favoriler", "Profil")
        val icons = listOf(Icons.Default.Home, Icons.Default.Explore, Icons.Default.AutoAwesome, Icons.Default.FavoriteBorder, Icons.Default.Person)
        labels.forEachIndexed { index, label ->
            NavigationBarItem(
                selected = selected == index,
                onClick = { onSelect(index) },
                icon = {
                    if (index == 2) {
                        Box(
                            Modifier.size(48.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Purple2))),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.AutoAwesome, null, tint = Color.White) }
                    } else {
                        Icon(icons[index], null)
                    }
                },
                label = { Text(label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Purple,
                    selectedTextColor = Purple,
                    indicatorColor = Color(0xFFECE5FF)
                )
            )
        }
    }
}

@Composable
fun HomeScreen(padding: PaddingValues, open: (Wallpaper) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).background(Color.White)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("WXTRA", fontSize = 32.sp, fontWeight = FontWeight.Black, color = Ink)
                Text("DAHA FAZLASI, DAHA SEN.", fontSize = 10.sp, letterSpacing = 2.sp, color = Muted)
            }
            IconButton(onClick = {}) { Icon(Icons.Default.Search, null) }
            IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, null) }
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Purple2))),
                contentAlignment = Alignment.Center
            ) { Text("W", color = Color.White, fontWeight = FontWeight.Bold) }
        }

        HeroCard(wallpapers[2], open)
        SectionTitle("Senin için", "Tarzına uygun, özel seçkiler.")
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(wallpapers.take(5)) { wallpaper -> ImageCard(wallpaper, 190.dp, 250.dp, open) }
        }
        ProBanner()
        SectionTitle("Popüler", "En çok beğenilen duvar kâğıtları.")
        SmallRow(wallpapers.reversed().take(6), open)
        SectionTitle("Trendler", "Şu anda yükselen duvar kâğıtları.")
        SmallRow(wallpapers.drop(2).take(6), open)
        SectionTitle("Yeni Eklenenler", "En yeni duvar kâğıtlarını keşfet.")
        SmallRow(wallpapers.takeLast(6), open)
        SectionTitle("Editörün Seçimi", "WXTRA ekibinin senin için seçtikleri.")
        SmallRow(wallpapers.take(6).reversed(), open)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 10.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(subtitle, fontSize = 12.sp, color = Muted)
        }
        Text("Tümünü gör  →", color = Purple, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
    }
}

@Composable
fun HeroCard(wallpaper: Wallpaper, open: (Wallpaper) -> Unit) {
    Box(
        Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(285.dp)
            .clip(RoundedCornerShape(28.dp)).clickable { open(wallpaper) }
    ) {
        Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .82f)))))
        Column(Modifier.align(Alignment.BottomStart).padding(22.dp)) {
            Text("GÜNÜN SEÇKİSİ", color = Color.White.copy(alpha = .75f), fontSize = 11.sp, letterSpacing = 2.sp)
            Text(wallpaper.title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Her ekranda yeni bir hikâye.", color = Color.White.copy(alpha = .9f))
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { open(wallpaper) },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Ink)
            ) { Text("Keşfet  →") }
        }
    }
}

@Composable
fun ImageCard(wallpaper: Wallpaper, width: Dp, height: Dp, open: (Wallpaper) -> Unit) {
    Box(
        Modifier.width(width).height(height).clip(RoundedCornerShape(22.dp)).clickable { open(wallpaper) }
    ) {
        Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .72f)))))
        Icon(Icons.Default.FavoriteBorder, null, tint = Color.White, modifier = Modifier.align(Alignment.TopEnd).padding(12.dp))
        Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
            Text(wallpaper.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(wallpaper.subtitle, color = Color.White.copy(alpha = .8f), fontSize = 11.sp)
        }
    }
}

@Composable
fun SmallRow(list: List<Wallpaper>, open: (Wallpaper) -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(list) { wallpaper -> ImageCard(wallpaper, 125.dp, 155.dp, open) }
    }
}

@Composable
fun ProBanner() {
    Row(
        Modifier.padding(20.dp).fillMaxWidth().height(128.dp).clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF15102B), Purple, Color(0xFFC49DFF))))
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("♛", color = Color(0xFFFFD76A), fontSize = 34.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("WXTRA PRO", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("Sıradışı duvar kâğıtları, sadece sana özel.", color = Color.White.copy(alpha = .82f), fontSize = 11.sp)
            Text("Sınırsız koleksiyonlara eriş.", color = Color.White, fontSize = 12.sp)
        }
        Button(
            onClick = {},
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Purple)
        ) { Text("PRO'yu keşfet") }
    }
}

@Composable
fun ExploreScreen(padding: PaddingValues, open: (Wallpaper) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).background(Color.White)) {
        Text("Keşfet", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp))
        OutlinedTextField(
            value = "", onValueChange = {}, placeholder = { Text("Duvar kâğıdı ara...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(18.dp)
        )
        LazyRow(contentPadding = PaddingValues(20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf("Tümü", "Yeni", "Popüler", "Trendler")) { chip -> AssistChip(onClick = {}, label = { Text(chip) }) }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(wallpapers) { wallpaper -> ImageCard(wallpaper, 170.dp, 230.dp, open) }
        }
    }
}

@Composable
fun FavoritesScreen(padding: PaddingValues, open: (Wallpaper) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).background(Color.White)) {
        Text("Favorilerim", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp))
        LazyRow(contentPadding = PaddingValues(20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(wallpapers.take(6)) { wallpaper -> ImageCard(wallpaper, 170.dp, 230.dp, open) }
        }
    }
}

@Composable
fun AIStudioScreen(padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).background(Color.White)) {
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("AI Stüdyo", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Hayal et, duvar kâğıdına dönüştür.", color = Muted, fontSize = 13.sp)
            }
            Text("PRO", color = Purple, fontWeight = FontWeight.Bold)
        }
        Card(Modifier.padding(20.dp).fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Soft)) {
            Column(Modifier.padding(18.dp)) {
                Text("Ne hayal ediyorsun?", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = "", onValueChange = {}, placeholder = { Text("Örn. neon bir şehir, yağmurlu gece...") }, minLines = 4, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Button(onClick = {}, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Şimdi oluştur")
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).background(Color.White)) {
        Text("Profil", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(90.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Purple2))), contentAlignment = Alignment.Center) {
                Text("W", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }
            Text("WXTRA Kullanıcısı", fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
            Text("Duvar kâğıtlarınla daha fazlası.", color = Muted)
            Spacer(Modifier.height(18.dp))
            ProBanner()
        }
    }
}

@Composable
fun DetailScreen(wallpaper: Wallpaper, back: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Row(Modifier.fillMaxWidth().padding(top = 36.dp, start = 12.dp, end = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            FilledIconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null) }
            FilledIconButton(onClick = {}) { Icon(Icons.Default.FavoriteBorder, null) }
        }
        Card(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text(wallpaper.title, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text(wallpaper.subtitle, color = Muted)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = {}, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.PhoneAndroid, null); Spacer(Modifier.width(5.dp)); Text("Ana ekran")
                    }
                    Button(onClick = {}, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Lock, null); Spacer(Modifier.width(5.dp)); Text("Kilit ekranı")
                    }
                }
            }
        }
    }
}
