# Wxtra — Premium Duvar Kağıdı Keşif Uygulaması

Gönderilen Wxtra logosu merkeze alınarak hazırlanmış Türkçe premium mobil arayüz ve REST API başlangıç projesidir.

## GitHub'dan APK / AAB

Repo, Android platform dosyalarını sabit bir Gradle şablonuyla saklamak yerine GitHub Actions içinde kullanılan Flutter stable sürümüyle üretir. Böylece eski veya eksik `settings.gradle` kaynaklı derleme hatalarından kaçınılır.

### Kurulum

1. ZIP'i açın ve içindeki `premium_wallpaper_github` klasörünün içeriğini GitHub reposuna gönderin.
2. `main` veya `master` branch'ine push edin.
3. GitHub > **Actions** > **Wxtra Android Build** işini açın.
4. İş tamamlanınca **Artifacts** altında `wxtra-release-apk` ve `wxtra-release-aab` oluşur.

### API URL

Repo > Settings > Secrets and variables > Actions bölümüne:

`API_BASE_URL=https://alan-adiniz.example/api`

secret'ını ekleyin.

Secret verilmezse geliştirme için Android emülatörü adresi `http://10.0.2.2:8000/api` kullanılır.

## Tasarım

Bu sürüm gönderdiğin logoyu görsel kimlik olarak kullanır ve mockup'taki ince premium dokuyu temel alır:

- Kırık beyaz / çok açık lavanta yüzeyler
- Sabit mor vurgu
- İnce cam hissi ve düşük kontrastlı kartlar
- Yuvarlatılmış premium kartlar
- Akıcı alt navigasyon
- Ana Sayfa, Kategoriler, Keşfet, Favoriler, Ayarlar
- Profil ve tam ekran detay
- Keşfet aramasında debounce
- Favorilerde 2 / 3 sütun kart dizilimi

Tema rengi veya kullanıcı accent rengi seçimi yoktur.

## Ürün kısıtları

Uygulamada indirme, dosya dışa aktarma, galeriye kaydetme ve uygulama içinde ekran görüntüsü oluşturma özelliği bulunmaz. Görsel detayında yalnızca görüntüleme, favorileme ve paylaşım aksiyonu bulunur.

## REST API

Backend başlangıç sözleşmesi:

- `POST /api/auth/google`
- `GET /api/user`
- `GET /api/wallpapers`
- `GET /api/wallpapers/{id}`
- `GET /api/wallpapers/trending`
- `GET /api/wallpapers/latest`
- `GET /api/wallpapers/recommended`
- `GET /api/categories`
- `GET /api/categories/{id}/wallpapers`
- `GET /api/search`
- `GET /api/favorites`
- `POST /api/favorites/{id}`
- `DELETE /api/favorites/{id}`
- `GET /api/notifications`
- `PUT /api/notifications/settings`

`backend/app/main.py` geliştirme veri kaynağıyla ayağa kalkar. Production katmanında PostgreSQL repository, JWT, gerçek Google ID token doğrulaması, Redis cache, CDN/object storage, rate limit ve yönetim yetkilendirmesi eklenmelidir.

## VDS

```bash
cp .env.example .env
docker compose up --build -d
```

API sağlık kontrolü:

```text
GET /health
```

Production'da Nginx + HTTPS kullanın; PostgreSQL/Redis'i internete açık bırakmayın.

## Yerel Flutter

Flutter SDK kurulu bir ortamda:

```bash
cd mobile
flutter create --platforms=android --org com.wxtra --project-name wxtra_wallpaper --no-pub .
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8000/api
```

## Önemli

Bu çalışma ortamında Flutter SDK yüklü olmadığı için burada gerçek `flutter build apk` çalıştırılarak binary üretimi doğrulanamadı. Bunun yerine CI workflow'u Android platformunu her çalıştırmada Flutter stable ile yeniden oluşturacak şekilde tasarlandı ve ZIP içeriği yapısal olarak kontrol edildi.
