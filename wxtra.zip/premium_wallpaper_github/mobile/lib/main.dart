import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

const _purple = Color(0xFF5F2FE8);
const _ink = Color(0xFF171526);
const _surface = Color(0xFFF8F7FC);
const _muted = Color(0xFF777487);
const _apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://10.0.2.2:8000/api',
);

void main() {
  runApp(const WxtraApp());
}

class AppSettings {
  final ThemeMode themeMode;
  final int accentColor;
  final String? backgroundImagePath;
  final String cardLayout;
  final bool newWallpapers;
  final bool favoriteCategories;
  final bool recommendations;
  final bool editorPicks;
  final bool launchEnabled;
  final bool launchNewWallpapers;
  final bool launchFavoriteCategory;
  final bool launchRecommendations;
  final bool launchEditorPicks;
  final String launchFrequency;
  final bool googleConnected;

  const AppSettings({
    this.themeMode = ThemeMode.system,
    this.accentColor = 0xFF5F2FE8,
    this.backgroundImagePath,
    this.cardLayout = 'grid2',
    this.newWallpapers = true,
    this.favoriteCategories = true,
    this.recommendations = true,
    this.editorPicks = true,
    this.launchEnabled = true,
    this.launchNewWallpapers = true,
    this.launchFavoriteCategory = true,
    this.launchRecommendations = true,
    this.launchEditorPicks = true,
    this.launchFrequency = 'Her açılışta',
    this.googleConnected = false,
  });

  Color get accent => Color(accentColor);

  AppSettings copyWith({
    ThemeMode? themeMode,
    int? accentColor,
    String? backgroundImagePath,
    bool clearBackground = false,
    String? cardLayout,
    bool? newWallpapers,
    bool? favoriteCategories,
    bool? recommendations,
    bool? editorPicks,
    bool? launchEnabled,
    bool? launchNewWallpapers,
    bool? launchFavoriteCategory,
    bool? launchRecommendations,
    bool? launchEditorPicks,
    String? launchFrequency,
    bool? googleConnected,
  }) => AppSettings(
    themeMode: themeMode ?? this.themeMode,
    accentColor: accentColor ?? this.accentColor,
    backgroundImagePath: clearBackground ? null : (backgroundImagePath ?? this.backgroundImagePath),
    cardLayout: cardLayout ?? this.cardLayout,
    newWallpapers: newWallpapers ?? this.newWallpapers,
    favoriteCategories: favoriteCategories ?? this.favoriteCategories,
    recommendations: recommendations ?? this.recommendations,
    editorPicks: editorPicks ?? this.editorPicks,
    launchEnabled: launchEnabled ?? this.launchEnabled,
    launchNewWallpapers: launchNewWallpapers ?? this.launchNewWallpapers,
    launchFavoriteCategory: launchFavoriteCategory ?? this.launchFavoriteCategory,
    launchRecommendations: launchRecommendations ?? this.launchRecommendations,
    launchEditorPicks: launchEditorPicks ?? this.launchEditorPicks,
    launchFrequency: launchFrequency ?? this.launchFrequency,
    googleConnected: googleConnected ?? this.googleConnected,
  );

  static Future<AppSettings> load() async {
    final p = await SharedPreferences.getInstance();
    return AppSettings(
      themeMode: ThemeMode.values.firstWhere((m) => m.name == (p.getString('themeMode') ?? 'system'), orElse: () => ThemeMode.system),
      accentColor: p.getInt('accentColor') ?? 0xFF5F2FE8,
      backgroundImagePath: p.getString('backgroundImagePath'),
      cardLayout: p.getString('cardLayout') ?? 'grid2',
      newWallpapers: p.getBool('newWallpapers') ?? true,
      favoriteCategories: p.getBool('favoriteCategories') ?? true,
      recommendations: p.getBool('recommendations') ?? true,
      editorPicks: p.getBool('editorPicks') ?? true,
      launchEnabled: p.getBool('launchEnabled') ?? true,
      launchNewWallpapers: p.getBool('launchNewWallpapers') ?? true,
      launchFavoriteCategory: p.getBool('launchFavoriteCategory') ?? true,
      launchRecommendations: p.getBool('launchRecommendations') ?? true,
      launchEditorPicks: p.getBool('launchEditorPicks') ?? true,
      launchFrequency: p.getString('launchFrequency') ?? 'Her açılışta',
      googleConnected: p.getBool('googleConnected') ?? false,
    );
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('themeMode', themeMode.name);
    await p.setInt('accentColor', accentColor);
    if (backgroundImagePath == null) {
      await p.remove('backgroundImagePath');
    } else {
      await p.setString('backgroundImagePath', backgroundImagePath!);
    }
    await p.setString('cardLayout', cardLayout);
    await p.setBool('newWallpapers', newWallpapers);
    await p.setBool('favoriteCategories', favoriteCategories);
    await p.setBool('recommendations', recommendations);
    await p.setBool('editorPicks', editorPicks);
    await p.setBool('launchEnabled', launchEnabled);
    await p.setBool('launchNewWallpapers', launchNewWallpapers);
    await p.setBool('launchFavoriteCategory', launchFavoriteCategory);
    await p.setBool('launchRecommendations', launchRecommendations);
    await p.setBool('launchEditorPicks', launchEditorPicks);
    await p.setString('launchFrequency', launchFrequency);
    await p.setBool('googleConnected', googleConnected);
  }
}

class WxtraApp extends StatefulWidget {
  const WxtraApp({super.key});
  @override State<WxtraApp> createState() => _WxtraAppState();
}

class _WxtraAppState extends State<WxtraApp> {
  AppSettings _settings = const AppSettings();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final loaded = await AppSettings.load();
    if (!mounted) return;
    setState(() { _settings = loaded; _loaded = true; });
  }

  Future<void> _updateSettings(AppSettings next) async {
    setState(() => _settings = next);
    await next.save();
  }

  ThemeData _theme(Brightness brightness) {
    final seed = _settings.accent;
    final scheme = ColorScheme.fromSeed(seedColor: seed, brightness: brightness);
    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      scaffoldBackgroundColor: brightness == Brightness.dark ? const Color(0xFF101019) : _surface,
      colorScheme: scheme,
      fontFamily: 'Roboto',
      appBarTheme: AppBarTheme(
        backgroundColor: brightness == Brightness.dark ? const Color(0xFF101019) : _surface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        foregroundColor: brightness == Brightness.dark ? Colors.white : _ink,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return MaterialApp(debugShowCheckedModeBanner: false, theme: _theme(Brightness.light), home: const Scaffold(body: Center(child: CircularProgressIndicator())));
    }
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Wxtra',
      theme: _theme(Brightness.light),
      darkTheme: _theme(Brightness.dark),
      themeMode: _settings.themeMode,
      home: AppShell(settings: _settings, onSettingsChanged: _updateSettings),
    );
  }
}

class AppShell extends StatefulWidget {
  final AppSettings settings;
  final ValueChanged<AppSettings> onSettingsChanged;
  const AppShell({super.key, required this.settings, required this.onSettingsChanged});
  @override State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  bool _launchShown = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_launchShown && widget.settings.launchEnabled) {
      _launchShown = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _showLaunchSheet();
      });
    }
  }

  Future<void> _showLaunchSheet() async {
    final s = widget.settings;
    final items = <String>[
      if (s.launchNewWallpapers) 'Yeni duvar kağıtları',
      if (s.launchFavoriteCategory) 'Favori kategori',
      if (s.launchRecommendations) 'Öneriler',
      if (s.launchEditorPicks) 'Editör seçimleri',
    ];
    if (items.isEmpty) return;
    if (s.launchFrequency == 'Sadece günde bir kez') {
      final p = await SharedPreferences.getInstance();
      final today = DateTime.now().toIso8601String().substring(0, 10);
      if (p.getString('launchLastShown') == today) return;
      await p.setString('launchLastShown', today);
    }
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 22),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Senin için hazır', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            const Text('Açılış ekranında göstermek istediğin içerikler:', style: TextStyle(color: _muted)),
            const SizedBox(height: 14),
            ...items.map((item) => ListTile(leading: Icon(_launchIcon(item), color: widget.settings.accent), title: Text(item, style: const TextStyle(fontWeight: FontWeight.w700)), contentPadding: EdgeInsets.zero)),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity, child: FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Keşfetmeye başla'))),
          ]),
        ),
      ),
    );
  }

  IconData _launchIcon(String item) {
    if (item == 'Yeni duvar kağıtları') return Icons.wallpaper_rounded;
    if (item == 'Favori kategori') return Icons.favorite_rounded;
    if (item == 'Öneriler') return Icons.lightbulb_rounded;
    return Icons.star_rounded;
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.settings;
    final pages = [
      HomePage(onNavigate: (i) => setState(() => _index = i)),
      const CategoriesPage(),
      const DiscoverPage(),
      FavoritesPage(layout: s.cardLayout),
      SettingsPage(settings: s, onChanged: widget.onSettingsChanged),
    ];
    final bg = s.backgroundImagePath;
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          image: bg != null ? DecorationImage(image: FileImage(File(bg)), fit: BoxFit.cover, opacity: .18) : null,
        ),
        child: SafeArea(child: IndexedStack(index: _index, children: pages)),
      ),
      bottomNavigationBar: NavigationBar(
        height: 73,
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        backgroundColor: Theme.of(context).colorScheme.surface,
        indicatorColor: s.accent.withValues(alpha: .11),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Ana Sayfa'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'Kategoriler'),
          NavigationDestination(icon: Icon(Icons.search_rounded), selectedIcon: Icon(Icons.search_rounded), label: 'Keşfet'),
          NavigationDestination(icon: Icon(Icons.favorite_border_rounded), selectedIcon: Icon(Icons.favorite_rounded), label: 'Favoriler'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'Ayarlar'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final ValueChanged<int> onNavigate;
  const HomePage({super.key, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      color: _purple,
      backgroundColor: Colors.white,
      onRefresh: () async {},
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
        children: [
          _HomeHeader(onSearch: () => onNavigate(2)),
          const SizedBox(height: 18),
          const _HeroBrandCard(),
          const SizedBox(height: 24),
          Row(
            children: [
              const Expanded(
                child: _SectionHeader(title: 'Günün Duvar Kağıtları'),
              ),
              _TinyPill(label: '5 yeni'),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 286,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: 5,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (context, index) {
                final item = _demoWallpapers[index];
                return GestureDetector(
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => DetailPage(item: item)),
                  ),
                  child: WallpaperCard(item: item, width: 172),
                );
              },
            ),
          ),
          const SizedBox(height: 10),
          const Center(child: _CarouselDots()),
          const SizedBox(height: 24),
          const _GlassFeatureCard(),
          const SizedBox(height: 24),
          Row(
            children: [
              const Expanded(child: _SectionHeader(title: 'Senin İçin Seçtik')), 
              TextButton(
                onPressed: () => onNavigate(2),
                child: const Text('Keşfet'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 174,
            child: Row(
              children: _demoWallpapers.skip(2).take(3).map((item) {
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => DetailPage(item: item)),
                      ),
                      child: WallpaperCard(item: item),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class _HomeHeader extends StatelessWidget {
  final VoidCallback onSearch;
  const _HomeHeader({required this.onSearch});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 48,
          height: 48,
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: .86),
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: _purple.withValues(alpha: .10)),
            boxShadow: [
              BoxShadow(
                color: _purple.withValues(alpha: .10),
                blurRadius: 22,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Image.asset('assets/logo.png'),
        ),
        const SizedBox(width: 11),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'WXTRA',
                style: TextStyle(
                  color: _ink,
                  fontSize: 19,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 4.2,
                ),
              ),
              SizedBox(height: 2),
              Text(
                'Her ekran yeni bir hikâye',
                style: TextStyle(color: _muted, fontSize: 11, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        _CircleButton(icon: Icons.search_rounded, onTap: onSearch),
        const SizedBox(width: 7),
        _CircleButton(icon: Icons.tune_rounded, onTap: () {}),
      ],
    );
  }
}

class _HeroBrandCard extends StatelessWidget {
  const _HeroBrandCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 188,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFFFFFF), Color(0xFFF1EDFF), Color(0xFFE2D7FF)],
        ),
        border: Border.all(color: Colors.white.withValues(alpha: .88)),
        boxShadow: [
          BoxShadow(
            color: _purple.withValues(alpha: .13),
            blurRadius: 28,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned.fill(child: _FineWaveTexture()),
          Positioned(
            right: -26,
            top: -26,
            child: Container(
              width: 142,
              height: 142,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _purple.withValues(alpha: .10),
              ),
            ),
          ),
          Positioned(
            right: 16,
            top: 20,
            child: Image.asset('assets/logo.png', width: 112, height: 112),
          ),
          const Positioned(
            left: 20,
            top: 22,
            child: Text(
              'Daha Fazlası.',
              style: TextStyle(
                fontSize: 27,
                height: 1.05,
                fontWeight: FontWeight.w900,
                color: _ink,
              ),
            ),
          ),
          const Positioned(
            left: 20,
            top: 82,
            child: SizedBox(
              width: 190,
              child: Text(
                'Sadece bir duvar kâğıdı değil, ekranına ilham.',
                style: TextStyle(color: _muted, fontSize: 12.5, height: 1.35, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          Positioned(
            left: 20,
            bottom: 18,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: _purple.withValues(alpha: .09),
                borderRadius: BorderRadius.circular(99),
                border: Border.all(color: _purple.withValues(alpha: .13)),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.auto_awesome_rounded, size: 14, color: _purple),
                  SizedBox(width: 6),
                  Text('Bugünün seçkisi', style: TextStyle(color: _purple, fontSize: 11, fontWeight: FontWeight.w900)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _GlassFeatureCard extends StatelessWidget {
  const _GlassFeatureCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _purple.withValues(alpha: .96),
            const Color(0xFF8A63F5).withValues(alpha: .88),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: _purple.withValues(alpha: .18),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: .16),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.white.withValues(alpha: .22)),
            ),
            child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 26),
          ),
          const SizedBox(width: 13),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Ekranını değiştir', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
                SizedBox(height: 3),
                Text('Mor ışıltılı seçkiler her gün yenilenir.', style: TextStyle(color: Colors.white70, fontSize: 11.5, height: 1.3)),
              ],
            ),
          ),
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: .90), shape: BoxShape.circle),
            child: const Icon(Icons.arrow_forward_rounded, color: _purple, size: 19),
          ),
        ],
      ),
    );
  }
}

class _TinyPill extends StatelessWidget {
  final String label;
  const _TinyPill({required this.label});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: _purple.withValues(alpha: .08),
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: _purple.withValues(alpha: .10)),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        child: Text(label, style: const TextStyle(color: _purple, fontSize: 10, fontWeight: FontWeight.w900)),
      ),
    );
  }
}

class _CarouselDots extends StatelessWidget {
  const _CarouselDots();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (int i = 0; i < 5; i++)
          Container(
            width: i == 0 ? 20 : 6,
            height: 6,
            margin: const EdgeInsets.symmetric(horizontal: 3),
            decoration: BoxDecoration(
              color: i == 0 ? _purple : _purple.withValues(alpha: .18),
              borderRadius: BorderRadius.circular(99),
            ),
          ),
      ],
    );
  }
}

class _FineWaveTexture extends StatelessWidget {
  const _FineWaveTexture();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _WavePainter());
  }
}

class _WavePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..color = _purple.withValues(alpha: .09);

    for (double y = -40; y < size.height + 80; y += 44) {
      final path = Path()..moveTo(-20, y);
      path.cubicTo(size.width * .20, y - 34, size.width * .52, y + 36, size.width + 20, y - 20);
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class CategoriesPage extends StatelessWidget {
  const CategoriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
      children: [
        Row(
          children: [
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Kategoriler', style: _PageTitleStyle()),
                  SizedBox(height: 6),
                  Text('Tarzına uygun dünyayı keşfet.', style: TextStyle(color: _muted)),
                ],
              ),
            ),
            _CircleButton(icon: Icons.search_rounded, onTap: () {}),
          ],
        ),
        const SizedBox(height: 18),
        const _CategoryChips(),
        const SizedBox(height: 18),
        _CategoryFeatureCard(
          name: 'Doğa',
          subtitle: 'Huzurun renkleri',
          gradient: [Color(0xFFB7C9FF), Color(0xFF4D3A9C)],
          seed: 1,
          height: 205,
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _CategoryTallCard(name: 'Şehir', subtitle: 'Modern yaşam', seed: 4),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                children: [
                  _CategoryWideCard(name: 'Minimal', subtitle: 'Sade güzellik', seed: 7),
                  const SizedBox(height: 12),
                  _CategoryWideCard(name: 'Hayvanlar', subtitle: 'Sadık dostlar', seed: 9),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Row(
          children: _categories.skip(4).take(4).map((name) {
            final i = _categories.indexOf(name);
            return Expanded(
              child: Padding(
                padding: EdgeInsets.only(right: name == _categories.skip(4).take(4).last ? 0 : 8),
                child: _CategoryCircle(name: name, seed: i + 20),
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 16),
        _TrendBanner(onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const CategoryDetailPage(category: 'Trend')),
        )),
      ],
    );
  }
}

class _CategoryChips extends StatelessWidget {
  const _CategoryChips();
  @override
  Widget build(BuildContext context) {
    const labels = ['Tümü', 'Doğa', 'Şehir', 'Minimal', 'Uzay'];
    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: labels.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: i == 0 ? _purple : Colors.white,
            borderRadius: BorderRadius.circular(99),
            border: Border.all(color: i == 0 ? _purple : _purple.withValues(alpha: .12)),
            boxShadow: i == 0 ? [BoxShadow(color: _purple.withValues(alpha: .18), blurRadius: 14, offset: const Offset(0, 6))] : null,
          ),
          child: Text(labels[i], style: TextStyle(color: i == 0 ? Colors.white : _muted, fontWeight: FontWeight.w800, fontSize: 12)),
        ),
      ),
    );
  }
}

class _CategoryFeatureCard extends StatelessWidget {
  final String name, subtitle;
  final List<Color> gradient;
  final int seed;
  final double height;
  const _CategoryFeatureCard({required this.name, required this.subtitle, required this.gradient, required this.seed, required this.height});
  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(26),
    child: SizedBox(
      height: height,
      child: Stack(fit: StackFit.expand, children: [
        DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: gradient)), child: _SoftShape(seed: seed)),
        Positioned(left: 16, bottom: 16, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          Text(subtitle, style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w700)),
        ])),
        Positioned(right: 14, top: 14, child: _GlassArrow(onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CategoryDetailPage(category: name))))),
      ]),
    ),
  );
}

class _CategoryTallCard extends StatelessWidget {
  final String name, subtitle; final int seed;
  const _CategoryTallCard({required this.name, required this.subtitle, required this.seed});
  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(25),
    child: SizedBox(height: 250, child: Stack(fit: StackFit.expand, children: [
      DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: [_demoGradients[seed % _demoGradients.length].$1, _demoGradients[seed % _demoGradients.length].$2])), child: _SoftShape(seed: seed)),
      Positioned(left: 15, right: 12, bottom: 14, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)), Text(subtitle, style: const TextStyle(color: Colors.white70, fontSize: 11))])),
      Positioned(right: 11, top: 11, child: _GlassArrow(onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CategoryDetailPage(category: name))))),
    ])),
  );
}

class _CategoryWideCard extends StatelessWidget {
  final String name, subtitle; final int seed;
  const _CategoryWideCard({required this.name, required this.subtitle, required this.seed});
  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(22),
    child: SizedBox(height: 119, child: Stack(fit: StackFit.expand, children: [
      DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [_demoGradients[seed % _demoGradients.length].$1, _demoGradients[seed % _demoGradients.length].$2])), child: _SoftShape(seed: seed)),
      Positioned(left: 14, bottom: 13, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)), Text(subtitle, style: const TextStyle(color: Colors.white70, fontSize: 10))])),
      Positioned(right: 9, top: 9, child: _GlassArrow(onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CategoryDetailPage(category: name))))),
    ])),
  );
}

class _CategoryCircle extends StatelessWidget {
  final String name; final int seed;
  const _CategoryCircle({required this.name, required this.seed});
  @override
  Widget build(BuildContext context) => Column(children: [
    ClipOval(child: SizedBox(width: 66, height: 66, child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: [_demoGradients[seed % _demoGradients.length].$1, _demoGradients[seed % _demoGradients.length].$2])), child: _SoftShape(seed: seed)))),
    const SizedBox(height: 6),
    Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _ink, fontSize: 10, fontWeight: FontWeight.w800)),
  ]);
}

class _GlassArrow extends StatelessWidget {
  final VoidCallback onTap;
  const _GlassArrow({required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(99), child: Container(width: 38, height: 38, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .22), shape: BoxShape.circle, border: Border.all(color: Colors.white.withValues(alpha: .28))), child: const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 18)));
}

class _TrendBanner extends StatelessWidget {
  final VoidCallback onTap;
  const _TrendBanner({required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(23), child: Container(
    height: 82,
    padding: const EdgeInsets.symmetric(horizontal: 17),
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(23), gradient: const LinearGradient(colors: [Color(0xFFE9DEFF), Color(0xFFD2C0FF)])),
    child: Row(children: [
      const Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Trend Koleksiyon', style: TextStyle(color: _ink, fontSize: 16, fontWeight: FontWeight.w900)), SizedBox(height: 3), Text('Şimdi keşfet', style: TextStyle(color: _muted, fontSize: 11, fontWeight: FontWeight.w700))])),
      Container(width: 40, height: 40, decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle), child: const Icon(Icons.arrow_forward_rounded, color: _purple)),
    ]),
  ));
}

class CategoryDetailPage extends StatelessWidget {
  final String category;
  const CategoryDetailPage({super.key, required this.category});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text(category, style: const TextStyle(fontWeight: FontWeight.w900))), body: GridView.builder(
      padding: const EdgeInsets.all(18), itemCount: _demoWallpapers.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .68),
      itemBuilder: (_, index) => WallpaperCard(item: _demoWallpapers[index], variant: index % 3),
    ));
  }
}

class DiscoverPage extends StatefulWidget {
  const DiscoverPage({super.key});
  @override State<DiscoverPage> createState() => _DiscoverPageState();
}
class _DiscoverPageState extends State<DiscoverPage> {
  final _controller = TextEditingController(); Timer? _debounce; String _query = ''; String _filter = 'Yeni';
  @override void dispose() { _debounce?.cancel(); _controller.dispose(); super.dispose(); }
  void _search(String value) { _debounce?.cancel(); _debounce = Timer(const Duration(milliseconds: 300), () { if (mounted) setState(() => _query = value.trim().toLowerCase()); }); }
  @override
  Widget build(BuildContext context) {
    final results = _demoWallpapers.where((item) => _query.isEmpty || item.title.toLowerCase().contains(_query) || item.category.toLowerCase().contains(_query) || item.tags.any((tag) => tag.toLowerCase().contains(_query))).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(18, 18, 18, 12), child: Container(height: 56, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: _purple.withValues(alpha: .06), blurRadius: 18, offset: const Offset(0, 7))]), child: TextField(controller: _controller, onChanged: _search, decoration: InputDecoration(hintText: 'Duvar kağıdı ara...', prefixIcon: const Icon(Icons.search_rounded), suffixIcon: IconButton(onPressed: () {}, icon: const Icon(Icons.tune_rounded)), border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(vertical: 17))))),
      SizedBox(height: 42, child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 18), scrollDirection: Axis.horizontal, itemCount: 5, separatorBuilder: (_, __) => const SizedBox(width: 8), itemBuilder: (_, i) { final label = ['Yeni','Popüler','Trend','En çok favorilenen','Editör seçimi'][i]; final selected = _filter == label; return ChoiceChip(label: Text(label), selected: selected, onSelected: (_) => setState(() => _filter = label), selectedColor: _purple, backgroundColor: Colors.white, labelStyle: TextStyle(color: selected ? Colors.white : _muted, fontWeight: FontWeight.w800), side: BorderSide(color: selected ? _purple : _purple.withValues(alpha: .12))); })),
      const SizedBox(height: 8),
      Expanded(child: results.isEmpty ? const Center(child: Text('Sonuç bulunamadı.')) : GridView.builder(padding: const EdgeInsets.fromLTRB(18, 6, 18, 24), itemCount: results.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .68), itemBuilder: (_, index) => WallpaperCard(item: results[index], variant: index % 4))),
    ]);
  }
}

class FavoritesPage extends StatelessWidget {
  final String layout;
  const FavoritesPage({super.key, required this.layout});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
      children: [
        Row(
          children: [
            const Expanded(
              child: Text('Favoriler', style: _PageTitleStyle()),
            ),
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: _purple.withValues(alpha: .10),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.grid_view_rounded, color: _purple, size: 20),
            ),
            const SizedBox(width: 6),
            const Icon(Icons.view_list_rounded, color: _muted),
          ],
        ),
        const SizedBox(height: 6),
        const Text(
          'En çok sevdiklerin burada.',
          style: TextStyle(color: _muted),
        ),
        const SizedBox(height: 16),
        if (_demoWallpapers.isNotEmpty)
          Container(
            height: 112,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25),
              gradient: const LinearGradient(
                colors: [Color(0xFFE9DEFF), Color(0xFFF7F3FF)],
              ),
            ),
            child: Row(
              children: [
                const Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(left: 18),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Koleksiyonun',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: _ink,
                          ),
                        ),
                        SizedBox(height: 3),
                        Text(
                          'Sevdiklerin tek yerde.',
                          style: TextStyle(color: _muted, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                ),
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topRight: Radius.circular(25),
                    bottomRight: Radius.circular(25),
                  ),
                  child: SizedBox(
                    width: 120,
                    height: 112,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: _demoWallpapers.first.gradient,
                        ),
                      ),
                      child: const _SoftShape(seed: 55),
                    ),
                  ),
                ),
              ],
            ),
          ),
        const SizedBox(height: 18),
        if (layout == 'list')
          ..._demoWallpapers.map((item) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _FavoriteListTile(item: item),
          ))
        else if (layout == 'large')
          ..._demoWallpapers.map((item) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: SizedBox(height: 250, child: WallpaperCard(item: item)),
          ))
        else
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _demoWallpapers.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: layout == 'grid3' ? 3 : 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: layout == 'grid3' ? .62 : .68,
            ),
            itemBuilder: (_, index) => WallpaperCard(item: _demoWallpapers[index], variant: (index + 1) % 4),
          ),
      ],
    );
  }
}

class SettingsPage extends StatelessWidget {
  final AppSettings settings;
  final ValueChanged<AppSettings> onChanged;
  const SettingsPage({super.key, required this.settings, required this.onChanged});

  void _set(BuildContext context, AppSettings next) {
    onChanged(next);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ayar kaydedildi'), duration: Duration(milliseconds: 900)));
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
      children: [
        const Text('Ayarlar', style: _PageTitleStyle()),
        const SizedBox(height: 6),
        const Text('Uygulama deneyimini kişiselleştir.', style: TextStyle(color: _muted)),
        const SizedBox(height: 18),
        _SettingsGroup(title: 'Profil', children: [
          _SettingsTile(icon: Icons.person_outline_rounded, title: 'Profil', subtitle: settings.googleConnected ? 'Google hesabı bağlı' : 'Hesabını yönet', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(settings: settings, onChanged: onChanged)))),
          _SettingsTile(icon: Icons.login_rounded, title: settings.googleConnected ? 'Google hesabı bağlı' : 'Google ile kayıt', subtitle: settings.googleConnected ? 'Senkronizasyon açık' : 'Favorilerini cihazlar arasında eşitle', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(settings: settings, onChanged: onChanged)))),
        ]),
        _SettingsGroup(title: 'Görünüm', children: [
          _SettingsTile(icon: Icons.palette_outlined, title: 'Tema ve renk', subtitle: _themeLabel(settings.themeMode), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AppearancePage(settings: settings, onChanged: onChanged)))),
          _SettingsTile(icon: Icons.image_outlined, title: 'Arka plan', subtitle: settings.backgroundImagePath == null ? 'Varsayılan' : 'Özel resim seçildi', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AppearancePage(settings: settings, onChanged: onChanged)))),
          _SettingsTile(icon: Icons.dashboard_customize_outlined, title: 'Kart dizilimi', subtitle: _layoutLabel(settings.cardLayout), onTap: () async {
            final value = await showModalBottomSheet<String>(context: context, showDragHandle: true, builder: (_) => _LayoutPicker(current: settings.cardLayout));
            if (value != null) _set(context, settings.copyWith(cardLayout: value));
          }),
        ]),
        _SettingsGroup(title: 'Bildirimler', children: [
          _SwitchTile(title: 'Yeni duvar kağıtları', value: settings.newWallpapers, onChanged: (v) => _set(context, settings.copyWith(newWallpapers: v))),
          _SwitchTile(title: 'Favori kategori', value: settings.favoriteCategories, onChanged: (v) => _set(context, settings.copyWith(favoriteCategories: v))),
          _SwitchTile(title: 'Öneriler', value: settings.recommendations, onChanged: (v) => _set(context, settings.copyWith(recommendations: v))),
          _SwitchTile(title: 'Editör seçimleri', value: settings.editorPicks, onChanged: (v) => _set(context, settings.copyWith(editorPicks: v))),
        ]),
        _SettingsGroup(title: 'Açılır ekran', children: [
          _SettingsTile(icon: Icons.open_in_new_rounded, title: 'Açılır ekran ayarları', subtitle: settings.launchEnabled ? settings.launchFrequency : 'Kapalı', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LaunchSettingsPage(settings: settings, onChanged: onChanged)))),
        ]),
        _SettingsGroup(title: 'Gizlilik', children: [
          _SettingsTile(icon: Icons.privacy_tip_outlined, title: 'Gizlilik politikası', onTap: () => _showPolicy(context, 'Gizlilik Politikası', 'Wxtra; hesap, favoriler, ayarlar ve uygulama kullanımına ilişkin verileri yalnızca uygulama deneyimini sağlamak için işler. İzinler ve üçüncü taraf servisler kullanıldığında ayrıca bilgilendirme yapılır.')),
          _SettingsTile(icon: Icons.description_outlined, title: 'Kullanım şartları', onTap: () => _showPolicy(context, 'Kullanım Şartları', 'Wxtra içerikleri kişisel kullanım içindir. Uygulamayı kullanırken yürürlükteki mevzuata ve içerik lisanslarına uymanız gerekir.')),
          _SettingsTile(icon: Icons.delete_outline_rounded, title: 'Hesabı sil', onTap: () => _confirmAccountDelete(context)),
        ]),
        _SettingsGroup(title: 'Uygulama', children: [
          const _SettingsTile(icon: Icons.info_outline_rounded, title: 'Uygulama sürümü', subtitle: '1.0.0'),
          _SettingsTile(icon: Icons.cloud_outlined, title: 'API durumu', subtitle: 'Kontrol etmek için dokun', onTap: () => _checkApi(context)),
          _SettingsTile(icon: Icons.cleaning_services_outlined, title: 'Önbelleği temizle', subtitle: 'Geçici verileri temizle', onTap: () => _clearCache(context)),
          _SettingsTile(icon: Icons.support_agent_outlined, title: 'Destek', subtitle: 'Sorun bildir veya yardım al', onTap: () => _support(context)),
        ]),
        _SettingsGroup(title: 'Admin uygulama paneli', children: [
          _SettingsTile(icon: Icons.admin_panel_settings_outlined, title: 'Admin paneli', subtitle: 'İçerik ve sistem yönetimi', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPage()))),
        ]),
      ],
    );
  }

  String _themeLabel(ThemeMode mode) => mode == ThemeMode.dark ? 'Koyu' : mode == ThemeMode.light ? 'Açık' : 'Sistem';
  String _layoutLabel(String v) => {'grid2': 'Izgara · 2 sütun', 'grid3': 'Izgara · 3 sütun', 'list': 'Liste', 'large': 'Büyük kart' }[v] ?? 'Izgara';

  void _showPolicy(BuildContext context, String title, String body) => showDialog<void>(context: context, builder: (_) => AlertDialog(title: Text(title), content: SingleChildScrollView(child: Text(body)), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Kapat'))]));

  Future<void> _confirmAccountDelete(BuildContext context) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('Hesap silinsin mi?'), content: const Text('Yerel hesap bağlantısı ve kaydedilmiş ayarlar temizlenecek.'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sil'))]));
    if (ok == true) {
      final p = await SharedPreferences.getInstance();
      await p.clear();
      onChanged(const AppSettings());
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Yerel hesap verileri temizlendi.')));
    }
  }

  Future<void> _clearCache(BuildContext context) async {
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Önbellek temizlendi.')));
  }

  Future<void> _support(BuildContext context) async {
    final uri = Uri(scheme: 'mailto', path: 'destek@wxtra.app', queryParameters: {'subject': 'Wxtra destek'});
    final launched = await launchUrl(uri);
    if (!launched && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('E-posta uygulaması bulunamadı. destek@wxtra.app adresine yazabilirsin.')));
    }
  }

  Future<void> _checkApi(BuildContext context) async {
    showDialog<void>(context: context, barrierDismissible: false, builder: (_) => const AlertDialog(content: Row(children: [SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)), SizedBox(width: 16), Text('API kontrol ediliyor...')]))) ;
    final ok = await ApiService().checkHealth();
    if (context.mounted) Navigator.pop(context);
    if (!context.mounted) return;
    showDialog<void>(context: context, builder: (_) => AlertDialog(title: Text(ok ? 'API çevrimiçi' : 'API bağlantısı yok'), content: Text(ok ? 'Sunucu yanıt verdi.' : 'Sunucuya ulaşılamadı. İnternet bağlantını ve API adresini kontrol et.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tamam'))]));
  }
}

class AppearancePage extends StatefulWidget {
  final AppSettings settings;
  final ValueChanged<AppSettings> onChanged;
  const AppearancePage({super.key, required this.settings, required this.onChanged});
  @override State<AppearancePage> createState() => _AppearancePageState();
}
class _AppearancePageState extends State<AppearancePage> {
  final _picker = ImagePicker();
  late AppSettings s;
  @override void initState() { super.initState(); s = widget.settings; }
  Future<void> _save(AppSettings next) async { setState(() => s = next); widget.onChanged(next); }
  Future<void> _pickImage() async {
    final file = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (file == null) return;
    await _save(s.copyWith(backgroundImagePath: file.path));
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Görünüm', style: TextStyle(fontWeight: FontWeight.w900))),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Tema', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      const SizedBox(height: 10),
      SegmentedButton<ThemeMode>(segments: const [ButtonSegment(value: ThemeMode.system, label: Text('Sistem'), icon: Icon(Icons.phone_android)), ButtonSegment(value: ThemeMode.light, label: Text('Açık'), icon: Icon(Icons.light_mode)), ButtonSegment(value: ThemeMode.dark, label: Text('Koyu'), icon: Icon(Icons.dark_mode))], selected: {s.themeMode}, onSelectionChanged: (v) => _save(s.copyWith(themeMode: v.first))),
      const SizedBox(height: 24),
      const Text('Vurgu rengi', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      const SizedBox(height: 12),
      Wrap(
        spacing: 12,
        runSpacing: 12,
        children: [
          0xFF5F2FE8, 0xFF246BFD, 0xFFE83E8C, 0xFFFF9D22, 0xFF23A66F, 0xFF00A7B5,
        ].map<Widget>((c) {
          final selected = s.accentColor == c;
          return InkWell(
            onTap: () => _save(s.copyWith(accentColor: c)),
            borderRadius: BorderRadius.circular(99),
            child: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: Color(c),
                shape: BoxShape.circle,
                border: Border.all(color: selected ? Colors.white : Colors.transparent, width: 3),
                boxShadow: selected ? [BoxShadow(color: Color(c).withValues(alpha: .35), blurRadius: 10)] : null,
              ),
              child: selected ? const Icon(Icons.check, color: Colors.white) : null,
            ),
          );
        }).toList(),
      ),
      const SizedBox(height: 24),
      Row(children: [const Expanded(child: Text('Arka plan', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900))), if (s.backgroundImagePath != null) TextButton(onPressed: () => _save(s.copyWith(clearBackground: true)), child: const Text('Kaldır'))]),
      const SizedBox(height: 10),
      Container(height: 180, decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xFFE9DEFF), Color(0xFFB8C8FF)]), image: s.backgroundImagePath != null ? DecorationImage(image: FileImage(File(s.backgroundImagePath!)), fit: BoxFit.cover) : null), child: s.backgroundImagePath == null ? Center(child: FilledButton.icon(onPressed: _pickImage, icon: const Icon(Icons.add_photo_alternate_outlined), label: const Text('Resim ekle'))) : null),
      const SizedBox(height: 24),
      const Text('Kart dizilimi', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      const SizedBox(height: 10),
      _LayoutPicker(current: s.cardLayout, onSelected: (v) => _save(s.copyWith(cardLayout: v))),
    ]),
  );
}

class LaunchSettingsPage extends StatefulWidget {
  final AppSettings settings; final ValueChanged<AppSettings> onChanged;
  const LaunchSettingsPage({super.key, required this.settings, required this.onChanged});
  @override State<LaunchSettingsPage> createState() => _LaunchSettingsPageState();
}
class _LaunchSettingsPageState extends State<LaunchSettingsPage> {
  late AppSettings s;
  @override void initState() { super.initState(); s = widget.settings; }
  void set(AppSettings next) { setState(() => s = next); widget.onChanged(next); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Açılır ekran', style: TextStyle(fontWeight: FontWeight.w900))), body: ListView(padding: const EdgeInsets.all(18), children: [
    SwitchListTile.adaptive(value: s.launchEnabled, onChanged: (v) => set(s.copyWith(launchEnabled: v)), title: const Text('Açılır ekranı etkinleştir', style: TextStyle(fontWeight: FontWeight.w800)), subtitle: const Text('Uygulama açıldığında seçtiğin içerikleri göster'), contentPadding: EdgeInsets.zero),
    const SizedBox(height: 12),
    const Text('Gösterilecek içerikler', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
    _SwitchTile(title: 'Yeni duvar kağıtları', value: s.launchNewWallpapers, onChanged: (v) => set(s.copyWith(launchNewWallpapers: v))),
    _SwitchTile(title: 'Favori kategori', value: s.launchFavoriteCategory, onChanged: (v) => set(s.copyWith(launchFavoriteCategory: v))),
    _SwitchTile(title: 'Öneriler', value: s.launchRecommendations, onChanged: (v) => set(s.copyWith(launchRecommendations: v))),
    _SwitchTile(title: 'Editör seçimleri', value: s.launchEditorPicks, onChanged: (v) => set(s.copyWith(launchEditorPicks: v))),
    const SizedBox(height: 16),
    DropdownButtonFormField<String>(initialValue: s.launchFrequency, decoration: const InputDecoration(labelText: 'Gösterim sıklığı', border: OutlineInputBorder()), items: const ['Her açılışta', 'Sadece günde bir kez'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) { if (v != null) set(s.copyWith(launchFrequency: v)); }),
  ]));
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Admin Paneli', style: TextStyle(fontWeight: FontWeight.w900))), body: ListView(padding: const EdgeInsets.all(18), children: [
    _AdminAction(icon: Icons.wallpaper_rounded, title: 'İçerik yönetimi', subtitle: 'Duvar kağıtlarını yönet', onTap: () => _info(context, 'İçerik yönetimi', 'API bağlantısı hazır olduğunda yeni içerik ekleme ve düzenleme burada yapılacak.')),
    _AdminAction(icon: Icons.category_rounded, title: 'Kategoriler', subtitle: 'Kategorileri düzenle', onTap: () => _info(context, 'Kategoriler', 'Kategori yönetimi için API uç noktası kullanılacak.')),
    _AdminAction(icon: Icons.people_alt_rounded, title: 'Kullanıcılar', subtitle: 'Kullanıcı istatistikleri', onTap: () => _info(context, 'Kullanıcılar', 'Kullanıcı yönetimi sunucu tarafında güvenli yetkilendirme ile çalışmalıdır.')),
    _AdminAction(icon: Icons.campaign_rounded, title: 'Bildirim gönder', subtitle: 'Kullanıcılara duyuru yap', onTap: () => _info(context, 'Bildirim gönder', 'Push bildirim servisi bağlandığında aktif olacaktır.')),
    _AdminAction(icon: Icons.key_rounded, title: 'API ayarları', subtitle: 'Uç nokta ve anahtarlar', onTap: () => _info(context, 'API ayarları', 'API adresi build-time API_BASE_URL değişkeninden alınır.')),
    _AdminAction(icon: Icons.monitor_heart_outlined, title: 'Sistem durumu', subtitle: 'Sunucu ve servis bilgileri', onTap: () => _check(context)),
  ]));
  static void _info(BuildContext c, String t, String b) => showDialog<void>(context: c, builder: (_) => AlertDialog(title: Text(t), content: Text(b), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Tamam'))]));
  static Future<void> _check(BuildContext c) async { final ok = await ApiService().checkHealth(); if (!c.mounted) return; _info(c, 'Sistem durumu', ok ? 'API çevrimiçi.' : 'API çevrimdışı.'); }
}
class _AdminAction extends StatelessWidget { final IconData icon; final String title, subtitle; final VoidCallback onTap; const _AdminAction({required this.icon, required this.title, required this.subtitle, required this.onTap}); @override Widget build(BuildContext context) => Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(onTap: onTap, leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: Icon(icon, color: Theme.of(context).colorScheme.primary)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right_rounded))); }

class _LayoutPicker extends StatelessWidget {
  final String current; final ValueChanged<String>? onSelected;
  const _LayoutPicker({required this.current, this.onSelected});
  @override Widget build(BuildContext context) => Column(mainAxisSize: MainAxisSize.min, children: [
    for (final item in const [('grid2','Izgara · 2 sütun',Icons.grid_view_rounded),('grid3','Izgara · 3 sütun',Icons.apps_rounded),('list','Liste',Icons.view_list_rounded),('large','Büyük kart',Icons.crop_portrait_rounded)])
      ListTile(leading: Icon(item.$3), title: Text(item.$2), trailing: current == item.$1 ? const Icon(Icons.check_rounded, color: _purple) : null, onTap: () { if (onSelected != null) onSelected!(item.$1); else Navigator.pop(context, item.$1); }),
  ]);
}

class _FavoriteListTile extends StatelessWidget {
  final Wallpaper item; const _FavoriteListTile({required this.item});
  @override Widget build(BuildContext context) => InkWell(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: item))), borderRadius: BorderRadius.circular(22), child: Container(height: 100, decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(22)), child: Row(children: [ClipRRect(borderRadius: const BorderRadius.horizontal(left: Radius.circular(22)), child: SizedBox(width: 100, height: 100, child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: item.gradient)), child: const _SoftShape(seed: 42)))), const SizedBox(width: 14), Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [Text(item.title, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(item.category, style: const TextStyle(color: _muted)),])), const Icon(Icons.favorite_rounded, color: _purple), const SizedBox(width: 16)])));
}

class ProfilePage extends StatefulWidget {
  final AppSettings settings; final ValueChanged<AppSettings> onChanged;
  const ProfilePage({super.key, required this.settings, required this.onChanged});
  @override State<ProfilePage> createState() => _ProfilePageState();
}
class _ProfilePageState extends State<ProfilePage> {
  late AppSettings s;
  @override void initState() { super.initState(); s = widget.settings; }
  Future<void> _google() async {
    final next = s.copyWith(googleConnected: !s.googleConnected);
    setState(() => s = next); widget.onChanged(next);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(next.googleConnected ? 'Google hesabı bağlandı.' : 'Google hesabı bağlantısı kaldırıldı.')));
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Profil', style: TextStyle(fontWeight: FontWeight.w900))), body: ListView(padding: const EdgeInsets.all(20), children: [
    CircleAvatar(radius: 48, backgroundColor: widget.settings.accent.withValues(alpha: .14), child: Icon(Icons.person, size: 42, color: widget.settings.accent)),
    const SizedBox(height: 14),
    Center(child: Text(s.googleConnected ? 'Google hesabı' : 'Hesabını bağla', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
    const SizedBox(height: 4),
    Center(child: Text(s.googleConnected ? 'Google ile senkronize' : 'Henüz hesap bağlanmadı', style: const TextStyle(color: _muted))),
    const SizedBox(height: 22),
    SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: _google, icon: const Text('G', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), label: Text(s.googleConnected ? 'Google bağlantısını kaldır' : 'Google ile kayıt'))),
    const SizedBox(height: 18),
    _ProfileFeature(icon: Icons.favorite_rounded, title: 'Favorilerini sakla', subtitle: 'Cihazlar arasında senkronize et'),
    _ProfileFeature(icon: Icons.sync_rounded, title: 'Cihazlar arası senkronizasyon', subtitle: s.googleConnected ? 'Senkronizasyon açık' : 'Google hesabını bağlayınca açılır'),
    _ProfileFeature(icon: Icons.auto_awesome_rounded, title: 'Sana özel öneriler', subtitle: 'Beğenilerine göre içerik'),
  ]));
}
class _ProfileFeature extends StatelessWidget { final IconData icon; final String title, subtitle; const _ProfileFeature({required this.icon, required this.title, required this.subtitle}); @override Widget build(BuildContext context) => ListTile(contentPadding: const EdgeInsets.symmetric(vertical: 5), leading: CircleAvatar(backgroundColor: _purple.withValues(alpha: .10), child: Icon(icon, color: _purple)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(subtitle)); }

class DetailPage extends StatelessWidget {
  final Wallpaper item;
  const DetailPage({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: item.gradient,
              ),
            ),
            child: _SoftShape(seed: item.id.hashCode),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _OverlayButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
                  Row(
                    children: [
                      _OverlayButton(icon: Icons.favorite_border_rounded, onTap: () {}),
                      const SizedBox(width: 6),
                      _OverlayButton(icon: Icons.share_outlined, onTap: () {}),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 18,
            child: SafeArea(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(25),
                child: Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: .92),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: _ink)),
                      const SizedBox(height: 4),
                      Text(item.category, style: const TextStyle(color: _muted, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 9),
                      Text(item.tags.map((e) => '#$e').join('  '), style: const TextStyle(color: _muted)),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          const Expanded(child: Text('Benzer duvar kağıtları', style: TextStyle(fontWeight: FontWeight.w900))),
                          TextButton(onPressed: () {}, child: const Text('Tümünü gör')),
                        ],
                      ),
                      SizedBox(
                        height: 66,
                        child: Row(
                          children: _demoWallpapers.take(4).map((w) => Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(right: 7),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(13),
                                child: DecoratedBox(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(colors: w.gradient),
                                  ),
                                ),
                              ),
                            ),
                          )).toList(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class WallpaperCard extends StatelessWidget {
  final Wallpaper item;
  final double? width;
  final int variant;

  const WallpaperCard({
    super.key,
    required this.item,
    this.width,
    this.variant = 0,
  });

  @override
  Widget build(BuildContext context) {
    final radius = switch (variant) {
      3 => 34.0,
      2 => 18.0,
      _ => 25.0,
    };

    return SizedBox(
      width: width,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: Stack(
          fit: StackFit.expand,
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: item.gradient,
                ),
              ),
              child: _SoftShape(seed: item.id.hashCode + variant * 11),
            ),
            if (variant == 1)
              Positioned(
                right: -25,
                top: 18,
                child: Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withValues(alpha: .16),
                  ),
                ),
              ),
            if (variant == 2)
              Positioned(
                left: -30,
                bottom: 18,
                child: Container(
                  width: 125,
                  height: 125,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withValues(alpha: .13),
                  ),
                ),
              ),
            if (variant == 3)
              Positioned.fill(
                child: CustomPaint(painter: _CardGlowPainter()),
              ),
            Positioned(
              top: 10,
              right: 10,
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: .20),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white.withValues(alpha: .35),
                  ),
                ),
                child: const Icon(
                  Icons.favorite_border_rounded,
                  size: 18,
                  color: Colors.white,
                ),
              ),
            ),
            Positioned(
              left: 10,
              right: 10,
              bottom: 10,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(17),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 11,
                    vertical: 9,
                  ),
                  color: Colors.black.withValues(alpha: .25),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        item.category,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CardGlowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.2..color = Colors.white.withValues(alpha: .18);
    for (double x = -size.height; x < size.width + size.height; x += 42) {
      final path = Path()..moveTo(x, size.height)..quadraticBezierTo(x + 28, size.height * .55, x + 70, 0);
      canvas.drawPath(path, paint);
    }
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _SoftShape extends StatelessWidget {
  final int seed;
  const _SoftShape({required this.seed});

  @override
  Widget build(BuildContext context) {
    final offset = (seed % 60).toDouble();
    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned(
          top: -30 + offset / 4,
          left: -30 + offset / 5,
          child: Container(
            width: 160,
            height: 160,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withValues(alpha: .22),
            ),
          ),
        ),
        Positioned(
          right: -35,
          bottom: -22,
          child: Container(
            width: 155,
            height: 155,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withValues(alpha: .12),
            ),
          ),
        ),
        Center(
          child: Transform.rotate(
            angle: -.18,
            child: Container(
              width: 86,
              height: 210,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(55),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.white.withValues(alpha: .50),
                    Colors.white.withValues(alpha: .05),
                  ],
                ),
                border: Border.all(color: Colors.white.withValues(alpha: .30)),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _CircleButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _CircleButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: SizedBox(width: 42, height: 42, child: Icon(icon, size: 20)),
      ),
    );
  }
}

class _OverlayButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _OverlayButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: .28),
        shape: BoxShape.circle,
      ),
      child: IconButton(
        onPressed: onTap,
        icon: Icon(icon, color: Colors.white),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String? action;
  const _SectionHeader({required this.title, this.action});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: _ink))),
        if (action != null) Text(action!, style: const TextStyle(color: _purple, fontWeight: FontWeight.w800, fontSize: 12)),
      ],
    );
  }
}

class _PageTitleStyle extends TextStyle {
  const _PageTitleStyle()
      : super(fontSize: 28, fontWeight: FontWeight.w900, color: _ink);
}

class _SettingsGroup extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const _SettingsGroup({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 17),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 3, bottom: 9),
            child: Text(title, style: const TextStyle(color: _muted, fontWeight: FontWeight.w900)),
          ),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(children: children),
          ),
        ],
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback? onTap;
  const _SettingsTile({required this.icon, required this.title, this.subtitle, this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: CircleAvatar(
        radius: 20,
        backgroundColor: _purple.withValues(alpha: .10),
        child: Icon(icon, color: _purple, size: 20),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: subtitle == null ? null : Text(subtitle!, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: const Icon(Icons.chevron_right_rounded, color: _muted),
    );
  }
}

class _SwitchTile extends StatelessWidget {
  final String title; final bool value; final ValueChanged<bool> onChanged;
  const _SwitchTile({required this.title, required this.value, required this.onChanged});
  @override Widget build(BuildContext context) => SwitchListTile.adaptive(value: value, onChanged: onChanged, title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)));
}

class Wallpaper {
  final String id;
  final String title;
  final String category;
  final List<String> tags;
  final List<Color> gradient;

  const Wallpaper({
    required this.id,
    required this.title,
    required this.category,
    required this.tags,
    required this.gradient,
  });
}

class ApiService {
  ApiService({this.baseUrl = _apiBaseUrl});

  final String baseUrl;

  Future<bool> checkHealth() async {
    final client = HttpClient();
    try {
      final healthUrl = baseUrl.endsWith('/api') ? baseUrl.substring(0, baseUrl.length - 4) + '/health' : '$baseUrl/health';
      final request = await client.getUrl(Uri.parse(healthUrl));
      final response = await request.close().timeout(const Duration(seconds: 5));
      return response.statusCode == 200;
    } catch (_) {
      return false;
    } finally {
      client.close(force: true);
    }
  }

  Future<List<Wallpaper>> fetchWallpapers() async {
    final client = HttpClient();
    try {
      final request = await client.getUrl(Uri.parse('$baseUrl/wallpapers'));
      final response = await request.close().timeout(const Duration(seconds: 5));
      if (response.statusCode != 200) throw HttpException('API hatası');
      final body = await response.transform(utf8.decoder).join();
      final json = jsonDecode(body) as Map<String, dynamic>;
      final items = (json['items'] as List<dynamic>? ?? <dynamic>[]);
      return items.map((raw) {
        final map = raw as Map<String, dynamic>;
        return Wallpaper(
          id: map['id']?.toString() ?? 'api',
          title: map['title']?.toString() ?? 'Duvar Kağıdı',
          category: map['category']?.toString() ?? 'Soyut',
          tags: List<String>.from(map['tags'] ?? const []),
          gradient: const [_purple, Color(0xFFD6C7FF)],
        );
      }).toList();
    } finally {
      client.close(force: true);
    }
  }
}

const _categories = [
  'AMOLED', 'Minimal', 'Doğa', 'Uzay', 'Arabalar', 'Anime',
  'Soyut', 'Şehir', 'Karanlık', 'Teknoloji', 'Manzara', 'Hayvanlar',
];

const _demoGradients = <(Color, Color)>[
  (Color(0xFF7D42F5), Color(0xFFD7B5FF)),
  (Color(0xFF111426), Color(0xFF5265B6)),
  (Color(0xFF415E7D), Color(0xFFB8D2E6)),
  (Color(0xFF171022), Color(0xFF6D4EAF)),
  (Color(0xFF7E2A2A), Color(0xFFE5A06A)),
  (Color(0xFF3F245E), Color(0xFFE3B6FF)),
];

const _demoWallpapers = [
  Wallpaper(id: '1', title: 'Mor Işık', category: 'Soyut', tags: ['mor', 'minimal'], gradient: [Color(0xFF5D22D4), Color(0xFFE3BFFF)]),
  Wallpaper(id: '2', title: 'Gece Ufku', category: 'Uzay', tags: ['uzay', 'karanlık'], gradient: [Color(0xFF131733), Color(0xFF6A5AAE)]),
  Wallpaper(id: '3', title: 'Mor Zirve', category: 'Doğa', tags: ['dağ', 'manzara'], gradient: [Color(0xFF6C4EB0), Color(0xFFEEB2D9)]),
  Wallpaper(id: '4', title: 'Sessiz Yol', category: 'Minimal', tags: ['sade', 'minimal'], gradient: [Color(0xFF1E2539), Color(0xFF8E9CBC)]),
  Wallpaper(id: '5', title: 'Neon Şehir', category: 'Şehir', tags: ['neon', 'şehir'], gradient: [Color(0xFF24165F), Color(0xFFE138BB)]),
  Wallpaper(id: '6', title: 'Ay Çiçeği', category: 'Doğa', tags: ['çiçek', 'mor'], gradient: [Color(0xFF2D1A4B), Color(0xFFAC82DC)]),
];
