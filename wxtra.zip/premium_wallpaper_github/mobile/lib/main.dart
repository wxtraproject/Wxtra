import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wallpaper_manager_flutter/wallpaper_manager_flutter.dart';

const _purple = Color(0xFF5F2FE8);
const _purple2 = Color(0xFF8A63F5);
const _ink = Color(0xFF171526);
const _surface = Color(0xFFF8F7FC);
const _muted = Color(0xFF777487);
const _dark = Color(0xFF11111A);
const _apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://10.0.2.2:8000/api',
);

void main() => runApp(const WxtraApp());

class AppSettings {
  final ThemeMode themeMode;
  final int accentColor;
  final String? backgroundImagePath;
  final String cardLayout;
  final bool notificationsEnabled;
  final bool newWallpapers;
  final bool favoriteCategories;
  final bool recommendations;
  final bool editorPicks;
  final bool launchEnabled;
  final bool launchNewWallpapers;
  final bool launchFavoriteCategory;
  final bool launchRecommendations;
  final bool launchEditorPicks;
  final String launchFrequency;
  final bool googleConnected;

  const AppSettings({
    this.themeMode = ThemeMode.system,
    this.accentColor = 0xFF5F2FE8,
    this.backgroundImagePath,
    this.cardLayout = 'grid2',
    this.notificationsEnabled = true,
    this.newWallpapers = true,
    this.favoriteCategories = true,
    this.recommendations = true,
    this.editorPicks = true,
    this.launchEnabled = false,
    this.launchNewWallpapers = true,
    this.launchFavoriteCategory = true,
    this.launchRecommendations = true,
    this.launchEditorPicks = true,
    this.launchFrequency = 'Her açılışta',
    this.googleConnected = false,
  });

  Color get accent => Color(accentColor);

  AppSettings copyWith({
    ThemeMode? themeMode,
    int? accentColor,
    String? backgroundImagePath,
    bool clearBackground = false,
    String? cardLayout,
    bool? notificationsEnabled,
    bool? newWallpapers,
    bool? favoriteCategories,
    bool? recommendations,
    bool? editorPicks,
    bool? launchEnabled,
    bool? launchNewWallpapers,
    bool? launchFavoriteCategory,
    bool? launchRecommendations,
    bool? launchEditorPicks,
    String? launchFrequency,
    bool? googleConnected,
  }) {
    return AppSettings(
      themeMode: themeMode ?? this.themeMode,
      accentColor: accentColor ?? this.accentColor,
      backgroundImagePath: clearBackground ? null : (backgroundImagePath ?? this.backgroundImagePath),
      cardLayout: cardLayout ?? this.cardLayout,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      newWallpapers: newWallpapers ?? this.newWallpapers,
      favoriteCategories: favoriteCategories ?? this.favoriteCategories,
      recommendations: recommendations ?? this.recommendations,
      editorPicks: editorPicks ?? this.editorPicks,
      launchEnabled: launchEnabled ?? this.launchEnabled,
      launchNewWallpapers: launchNewWallpapers ?? this.launchNewWallpapers,
      launchFavoriteCategory: launchFavoriteCategory ?? this.launchFavoriteCategory,
      launchRecommendations: launchRecommendations ?? this.launchRecommendations,
      launchEditorPicks: launchEditorPicks ?? this.launchEditorPicks,
      launchFrequency: launchFrequency ?? this.launchFrequency,
      googleConnected: googleConnected ?? this.googleConnected,
    );
  }

  static Future<AppSettings> load() async {
    final p = await SharedPreferences.getInstance();
    return AppSettings(
      themeMode: ThemeMode.values.firstWhere(
        (m) => m.name == (p.getString('themeMode') ?? 'system'),
        orElse: () => ThemeMode.system,
      ),
      accentColor: p.getInt('accentColor') ?? 0xFF5F2FE8,
      backgroundImagePath: p.getString('backgroundImagePath'),
      cardLayout: p.getString('cardLayout') ?? 'grid2',
      notificationsEnabled: p.getBool('notificationsEnabled') ?? true,
      newWallpapers: p.getBool('newWallpapers') ?? true,
      favoriteCategories: p.getBool('favoriteCategories') ?? true,
      recommendations: p.getBool('recommendations') ?? true,
      editorPicks: p.getBool('editorPicks') ?? true,
      launchEnabled: p.getBool('launchEnabled') ?? false,
      launchNewWallpapers: p.getBool('launchNewWallpapers') ?? true,
      launchFavoriteCategory: p.getBool('launchFavoriteCategory') ?? true,
      launchRecommendations: p.getBool('launchRecommendations') ?? true,
      launchEditorPicks: p.getBool('launchEditorPicks') ?? true,
      launchFrequency: p.getString('launchFrequency') ?? 'Her açılışta',
      googleConnected: p.getBool('googleConnected') ?? false,
    );
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('themeMode', themeMode.name);
    await p.setInt('accentColor', accentColor);
    if (backgroundImagePath == null) {
      await p.remove('backgroundImagePath');
    } else {
      await p.setString('backgroundImagePath', backgroundImagePath!);
    }
    await p.setString('cardLayout', cardLayout);
    await p.setBool('notificationsEnabled', notificationsEnabled);
    await p.setBool('newWallpapers', newWallpapers);
    await p.setBool('favoriteCategories', favoriteCategories);
    await p.setBool('recommendations', recommendations);
    await p.setBool('editorPicks', editorPicks);
    await p.setBool('launchEnabled', launchEnabled);
    await p.setBool('launchNewWallpapers', launchNewWallpapers);
    await p.setBool('launchFavoriteCategory', launchFavoriteCategory);
    await p.setBool('launchRecommendations', launchRecommendations);
    await p.setBool('launchEditorPicks', launchEditorPicks);
    await p.setString('launchFrequency', launchFrequency);
    await p.setBool('googleConnected', googleConnected);
  }
}

class FavoritesStore extends ChangeNotifier {
  static const _key = 'favorite_ids';
  final Set<String> _ids = <String>{};

  bool contains(String id) => _ids.contains(id);
  Set<String> get ids => Set.unmodifiable(_ids);

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    _ids
      ..clear()
      ..addAll(p.getStringList(_key) ?? const <String>[]);
    notifyListeners();
  }

  Future<void> clear() async {
    _ids.clear();
    final p = await SharedPreferences.getInstance();
    await p.remove(_key);
    notifyListeners();
  }

  Future<void> toggle(String id) async {
    if (_ids.contains(id)) {
      _ids.remove(id);
    } else {
      _ids.add(id);
    }
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_key, _ids.toList());
    notifyListeners();
  }
}

class WxtraApp extends StatefulWidget {
  const WxtraApp({super.key});
  @override
  State<WxtraApp> createState() => _WxtraAppState();
}

class _WxtraAppState extends State<WxtraApp> {
  AppSettings _settings = const AppSettings();
  final FavoritesStore _favorites = FavoritesStore();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final values = await Future.wait([
      AppSettings.load(),
      _favorites.load(),
    ]);
    if (!mounted) return;
    setState(() {
      _settings = values.first as AppSettings;
      _loaded = true;
    });
  }

  Future<void> _updateSettings(AppSettings next) async {
    setState(() => _settings = next);
    await next.save();
  }

  ThemeData _theme(Brightness brightness) {
    final scheme = ColorScheme.fromSeed(seedColor: _settings.accent, brightness: brightness);
    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: brightness == Brightness.dark ? _dark : _surface,
      appBarTheme: AppBarTheme(
        backgroundColor: brightness == Brightness.dark ? _dark : _surface,
        foregroundColor: brightness == Brightness.dark ? Colors.white : _ink,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: brightness == Brightness.dark ? const Color(0xFF2B2935) : _ink,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: _theme(Brightness.light),
        home: const Scaffold(body: Center(child: CircularProgressIndicator())),
      );
    }
    return AnimatedBuilder(
      animation: _favorites,
      builder: (_, __) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Wxtra',
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        themeMode: _settings.themeMode,
        home: AppShell(
          settings: _settings,
          favorites: _favorites,
          onSettingsChanged: _updateSettings,
        ),
      ),
    );
  }
}

class AppShell extends StatefulWidget {
  final AppSettings settings;
  final FavoritesStore favorites;
  final ValueChanged<AppSettings> onSettingsChanged;
  const AppShell({super.key, required this.settings, required this.favorites, required this.onSettingsChanged});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  bool _launchShown = false;
  static const _launchLastShownKey = 'launchLastShownAt';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_launchShown || !widget.settings.launchEnabled) return;
    _launchShown = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _maybeShowLaunchSheet();
    });
  }

  Future<void> _maybeShowLaunchSheet() async {
    if (!widget.settings.launchEnabled) return;
    if (widget.settings.launchFrequency == 'Günde bir kez') {
      final prefs = await SharedPreferences.getInstance();
      final last = prefs.getInt(_launchLastShownKey);
      final now = DateTime.now();
      if (last != null) {
        final previous = DateTime.fromMillisecondsSinceEpoch(last);
        if (previous.year == now.year && previous.month == now.month && previous.day == now.day) return;
      }
    }
    await _showLaunchSheet();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_launchLastShownKey, DateTime.now().millisecondsSinceEpoch);
  }

  Future<void> _showLaunchSheet() async {
    final candidates = <Wallpaper>[];
    if (widget.settings.launchNewWallpapers) candidates.add(_demoWallpapers[0]);
    if (widget.settings.launchFavoriteCategory) {
      candidates.add(_demoWallpapers.firstWhere((w) => w.category == 'Doğa', orElse: () => _demoWallpapers[2]));
    }
    if (widget.settings.launchRecommendations) candidates.add(_demoWallpapers[1]);
    if (widget.settings.launchEditorPicks) candidates.add(_demoWallpapers[4]);
    if (candidates.isEmpty) return;
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: false,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Bugünün seçkisi', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              SizedBox(
                height: 135,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: candidates.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (_, i) => SizedBox(
                    width: 104,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.of(sheetContext).pop();
                        if (!mounted) return;
                        Navigator.of(context).push(MaterialPageRoute(builder: (_) => DetailPage(item: candidates[i], favorites: widget.favorites)));
                      },
                      child: WallpaperCard(item: candidates[i], favorites: widget.favorites, variant: i % 4),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onNavigate: (i) => setState(() => _index = i), favorites: widget.favorites),
      CategoriesPage(favorites: widget.favorites, layout: widget.settings.cardLayout),
      DiscoverPage(favorites: widget.favorites, layout: widget.settings.cardLayout),
      FavoritesPage(layout: widget.settings.cardLayout, favorites: widget.favorites),
      SettingsPage(settings: widget.settings, favorites: widget.favorites, onChanged: widget.onSettingsChanged),
    ];
    final backgroundPath = widget.settings.backgroundImagePath;
    final backgroundOverlay = Theme.of(context).brightness == Brightness.dark ? const Color(0xB011111A) : const Color(0xDDF8F7FC);
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (backgroundPath != null)
            Image.file(
              File(backgroundPath),
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox.expand(),
            ),
          if (backgroundPath != null)
            ColoredBox(color: backgroundOverlay),
          SafeArea(child: IndexedStack(index: _index, children: pages)),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (v) => setState(() => _index = v),
        height: 74,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Ana Sayfa'),
          NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view_rounded), label: 'Kategoriler'),
          NavigationDestination(icon: Icon(Icons.search_outlined), selectedIcon: Icon(Icons.search_rounded), label: 'Keşfet'),
          NavigationDestination(icon: Icon(Icons.favorite_border_rounded), selectedIcon: Icon(Icons.favorite_rounded), label: 'Favoriler'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'Ayarlar'),
        ],
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final ValueChanged<int> onNavigate;
  final FavoritesStore favorites;
  const HomePage({super.key, required this.onNavigate, required this.favorites});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final PageController _pageController = PageController(viewportFraction: .84);
  int _page = 0;

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
      children: [
        _HomeHeader(
          onSearch: () => widget.onNavigate(2),
          onMenu: () => _showHomeMenu(context),
        ),
        const SizedBox(height: 18),
        GestureDetector(
          onTap: () => _openDetail(_demoWallpapers.first),
          child: const _HeroBrandCard(),
        ),
        const SizedBox(height: 24),
        Row(children: [const Expanded(child: _SectionHeader(title: 'Günün Duvar Kağıtları')), _TinyPill(label: '${_demoWallpapers.length} seçki')]),
        const SizedBox(height: 12),
        SizedBox(
          height: 300,
          child: PageView.builder(
            controller: _pageController,
            itemCount: 5,
            onPageChanged: (v) => setState(() => _page = v),
            itemBuilder: (_, index) {
              final item = _demoWallpapers[index];
              return Padding(
                padding: const EdgeInsets.only(right: 12),
                child: GestureDetector(
                  onTap: () => _openDetail(item),
                  child: WallpaperCard(item: item, variant: index % 4, favorites: widget.favorites),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 10),
        _ActiveDots(count: 5, current: _page),
        const SizedBox(height: 24),
        InkWell(
          onTap: () => _openDetail(_demoWallpapers[_page]),
          borderRadius: BorderRadius.circular(25),
          child: const _GlassFeatureCard(),
        ),
        const SizedBox(height: 24),
        const _SectionHeader(title: 'Senin İçin Seçtik'),
        const SizedBox(height: 10),
        Row(
          children: _demoWallpapers.skip(2).take(3).map((item) => Expanded(
            child: Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(onTap: () => _openDetail(item), child: WallpaperCard(item: item, variant: 1, favorites: widget.favorites)),
            ),
          )).toList(),
        ),
      ],
    );
  }

  Future<void> _showHomeMenu(BuildContext context) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.auto_awesome_rounded), title: const Text('Günün seçkisi'), onTap: () { Navigator.of(sheetContext).pop(); _openDetail(_demoWallpapers.first); }),
          ListTile(leading: const Icon(Icons.search_rounded), title: const Text('Keşfet'), onTap: () { Navigator.of(sheetContext).pop(); widget.onNavigate(2); }),
          ListTile(leading: const Icon(Icons.favorite_rounded), title: const Text('Favoriler'), onTap: () { Navigator.of(sheetContext).pop(); widget.onNavigate(3); }),
          ListTile(leading: const Icon(Icons.settings_rounded), title: const Text('Ayarlar'), onTap: () { Navigator.of(sheetContext).pop(); widget.onNavigate(4); }),
          const SizedBox(height: 10),
        ]),
      ),
    );
  }

  void _openDetail(Wallpaper item) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => DetailPage(item: item, favorites: widget.favorites)));
  }
}

class _HomeHeader extends StatelessWidget {
  final VoidCallback onSearch;
  final VoidCallback onMenu;
  const _HomeHeader({required this.onSearch, required this.onMenu});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(
        width: 48, height: 48, padding: const EdgeInsets.all(5),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17), boxShadow: [BoxShadow(color: _purple.withValues(alpha: .11), blurRadius: 18, offset: const Offset(0, 7))]),
        child: ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.asset('assets/logo.png', fit: BoxFit.cover)),
      ),
      const SizedBox(width: 11),
      Expanded(
        child: ShaderMask(
          shaderCallback: (r) => LinearGradient(
            colors: [Theme.of(context).colorScheme.primary, Theme.of(context).colorScheme.secondary],
          ).createShader(r),
          child: const Text('WXTRA', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 3.6)),
        ),
      ),
      _CircleButton(icon: Icons.search_rounded, onTap: onSearch),
      const SizedBox(width: 7),
      _CircleButton(icon: Icons.menu_rounded, onTap: onMenu),
    ]);
  }
}

class _HeroBrandCard extends StatelessWidget {
  const _HeroBrandCard();
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 188,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white, Color(0xFFF1EDFF), Color(0xFFE2D7FF)]),
        border: Border.all(color: Colors.white.withValues(alpha: .88)),
        boxShadow: [BoxShadow(color: _purple.withValues(alpha: .13), blurRadius: 28, offset: const Offset(0, 14))],
      ),
      child: Stack(children: [
        const Positioned.fill(child: _FineWaveTexture()),
        Positioned(right: 10, top: 10, child: Image.asset('assets/logo.png', width: 126, height: 126)),
        const Positioned(left: 20, top: 22, child: Text('Daha Fazlası.', style: TextStyle(fontSize: 27, height: 1.05, fontWeight: FontWeight.w900, color: _ink))),
        const Positioned(left: 20, top: 82, child: SizedBox(width: 205, child: Text('Sadece bir duvar kâğıdı değil, ekranına ilham.', style: TextStyle(color: _muted, fontSize: 12.5, height: 1.35, fontWeight: FontWeight.w600)))),
        Positioned(left: 20, bottom: 18, child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: _purple.withValues(alpha: .09), borderRadius: BorderRadius.circular(99)), child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.auto_awesome_rounded, size: 14, color: _purple), SizedBox(width: 6), Text('Günün seçkisi', style: TextStyle(color: _purple, fontSize: 11, fontWeight: FontWeight.w900))]))),
      ]),
    );
  }
}

class _GlassFeatureCard extends StatelessWidget {
  const _GlassFeatureCard();
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(25), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [_purple, _purple2]), boxShadow: [BoxShadow(color: _purple.withValues(alpha: .18), blurRadius: 24, offset: const Offset(0, 12))]),
      child: const Row(children: [
        _FeatureIcon(icon: Icons.auto_awesome_rounded),
        SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Ekranını değiştir', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)), SizedBox(height: 3), Text('Seçtiğin duvar kâğıdını telefonunda uygula.', style: TextStyle(color: Colors.white70, fontSize: 11.5, height: 1.3))])),
        Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 24),
      ]),
    );
  }
}

class _FeatureIcon extends StatelessWidget {
  final IconData icon;
  const _FeatureIcon({required this.icon});
  @override
  Widget build(BuildContext context) => Container(width: 54, height: 54, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .16), borderRadius: BorderRadius.circular(18)), child: Icon(icon, color: Colors.white, size: 26));
}

class _TinyPill extends StatelessWidget {
  final String label;
  const _TinyPill({required this.label});
  @override
  Widget build(BuildContext context) => DecoratedBox(decoration: BoxDecoration(color: _purple.withValues(alpha: .08), borderRadius: BorderRadius.circular(99)), child: Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), child: Text(label, style: const TextStyle(color: _purple, fontSize: 10, fontWeight: FontWeight.w900))));
}

class _ActiveDots extends StatelessWidget {
  final int count;
  final int current;
  const _ActiveDots({required this.count, required this.current});
  @override
  Widget build(BuildContext context) => Row(mainAxisAlignment: MainAxisAlignment.center, children: [for (int i = 0; i < count; i++) AnimatedContainer(duration: const Duration(milliseconds: 220), width: i == current ? 20 : 6, height: 6, margin: const EdgeInsets.symmetric(horizontal: 3), decoration: BoxDecoration(color: i == current ? _purple : _purple.withValues(alpha: .18), borderRadius: BorderRadius.circular(99)))]);
}

class _FineWaveTexture extends StatelessWidget {
  const _FineWaveTexture();
  @override
  Widget build(BuildContext context) => CustomPaint(painter: _WavePainter());
}
class _WavePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.stroke..strokeWidth = 1..color = _purple.withValues(alpha: .08);
    for (double y = -40; y < size.height + 80; y += 44) {
      final path = Path()..moveTo(-20, y);
      path.cubicTo(size.width * .20, y - 34, size.width * .52, y + 36, size.width + 20, y - 20);
      canvas.drawPath(path, paint);
    }
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class CategoriesPage extends StatelessWidget {
  final FavoritesStore favorites;
  final String layout;
  const CategoriesPage({super.key, required this.favorites, required this.layout});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 30), children: [
      const Text('Kategoriler', style: _PageTitleStyle()),
      const SizedBox(height: 6),
      const Text('Tarzına uygun koleksiyonu keşfet.', style: TextStyle(color: _muted)),
      const SizedBox(height: 18),
      GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _categories.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.05),
        itemBuilder: (_, index) {
          final name = _categories[index];
          return _CategorySquareCard(name: name, seed: index + 10, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryDetailPage(category: name, favorites: favorites, layout: layout))));
        },
      ),
    ]);
  }
}

class _CategorySquareCard extends StatelessWidget {
  final String name;
  final int seed;
  final VoidCallback onTap;
  const _CategorySquareCard({required this.name, required this.seed, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(24), child: ClipRRect(borderRadius: BorderRadius.circular(24), child: Stack(fit: StackFit.expand, children: [DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: _gradientFor(seed))), child: _SoftShape(seed: seed)), Positioned(left: 14, bottom: 14, child: Text(name, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900))), Positioned(right: 10, top: 10, child: Container(width: 36, height: 36, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .20), shape: BoxShape.circle), child: const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 18)))])));
}

class CategoryDetailPage extends StatelessWidget {
  final String category;
  final FavoritesStore favorites;
  final String layout;
  const CategoryDetailPage({super.key, required this.category, required this.favorites, this.layout = 'grid2'});
  @override
  Widget build(BuildContext context) {
    final items = _demoWallpapers.where((w) => w.category == category).toList();
    final shown = items.isEmpty ? _demoWallpapers : items;
    return Scaffold(
      appBar: AppBar(title: Text(category, style: const TextStyle(fontWeight: FontWeight.w900))),
      body: layout == 'list'
          ? ListView.builder(
              padding: const EdgeInsets.all(18),
              itemCount: shown.length,
              itemBuilder: (_, i) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: SizedBox(
                  height: 180,
                  child: GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: shown[i], favorites: favorites))),
                    child: WallpaperCard(item: shown[i], variant: 2, favorites: favorites),
                  ),
                ),
              ),
            )
          : GridView.builder(
              padding: const EdgeInsets.all(18),
              itemCount: shown.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: layout == 'grid3' ? 3 : 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: layout == 'large' ? .72 : .68,
              ),
              itemBuilder: (_, i) => GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: shown[i], favorites: favorites))),
                child: WallpaperCard(item: shown[i], variant: layout == 'large' ? 3 : i % 4, favorites: favorites),
              ),
            ),
    );
  }
}

class DiscoverPage extends StatefulWidget {
  final FavoritesStore favorites;
  final String layout;
  const DiscoverPage({super.key, required this.favorites, required this.layout});
  @override State<DiscoverPage> createState() => _DiscoverPageState();
}
class _DiscoverPageState extends State<DiscoverPage> {
  final _controller = TextEditingController();
  Timer? _debounce;
  String _query = '';
  String _filter = 'Yeni';
  @override void dispose() { _debounce?.cancel(); _controller.dispose(); super.dispose(); }
  void _search(String value) { _debounce?.cancel(); _debounce = Timer(const Duration(milliseconds: 300), () { if (mounted) setState(() => _query = value.trim().toLowerCase()); }); }
  @override
  Widget build(BuildContext context) {
    List<Wallpaper> results = _demoWallpapers.where((item) => _query.isEmpty || item.title.toLowerCase().contains(_query) || item.category.toLowerCase().contains(_query) || item.tags.any((tag) => tag.toLowerCase().contains(_query))).toList();
    if (_filter == 'Trend' || _filter == 'Popüler' || _filter == 'En çok favorilenen') results = List.of(results.reversed);
    if (_filter == 'Editör seçimi') results = results.take(4).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(18, 18, 18, 10), child: Container(height: 56, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: _purple.withValues(alpha: .06), blurRadius: 18, offset: const Offset(0, 7))]), child: TextField(controller: _controller, onChanged: _search, decoration: InputDecoration(hintText: 'Duvar kağıdı ara...', prefixIcon: const Icon(Icons.search_rounded), suffixIcon: IconButton(onPressed: () => _controller.clear(), icon: const Icon(Icons.close_rounded)), border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(vertical: 17))))),
      SizedBox(height: 46, child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 18), scrollDirection: Axis.horizontal, itemCount: 5, separatorBuilder: (_, __) => const SizedBox(width: 8), itemBuilder: (_, i) { final label = ['Yeni', 'Popüler', 'Trend', 'En çok favorilenen', 'Editör seçimi'][i]; final selected = _filter == label; return ChoiceChip(label: Text(label), selected: selected, onSelected: (_) => setState(() => _filter = label), selectedColor: _purple, backgroundColor: Colors.white, labelStyle: TextStyle(color: selected ? Colors.white : _muted, fontWeight: FontWeight.w800), side: BorderSide(color: selected ? _purple : _purple.withValues(alpha: .12))); })),
      const SizedBox(height: 6),
      Expanded(
        child: results.isEmpty
            ? const Center(child: Text('Sonuç bulunamadı.'))
            : widget.layout == 'list'
                ? ListView.builder(
                    padding: const EdgeInsets.fromLTRB(18, 6, 18, 24),
                    itemCount: results.length,
                    itemBuilder: (_, index) {
                      final item = results[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: SizedBox(
                          height: 170,
                          child: GestureDetector(
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: item, favorites: widget.favorites))),
                            child: WallpaperCard(item: item, variant: 2, favorites: widget.favorites),
                          ),
                        ),
                      );
                    },
                  )
                : GridView.builder(
                    padding: const EdgeInsets.fromLTRB(18, 6, 18, 24),
                    itemCount: results.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: widget.layout == 'grid3' ? 3 : 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: widget.layout == 'large' ? .72 : .68,
                    ),
                    itemBuilder: (_, index) {
                      final item = results[index];
                      return GestureDetector(
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: item, favorites: widget.favorites))),
                        child: WallpaperCard(item: item, variant: widget.layout == 'large' ? 3 : index % 4, favorites: widget.favorites),
                      );
                    },
                  ),
      ),
    ]);
  }
}

class FavoritesPage extends StatelessWidget {
  final String layout;
  final FavoritesStore favorites;
  const FavoritesPage({super.key, required this.layout, required this.favorites});
  @override
  Widget build(BuildContext context) {
    final items = _demoWallpapers.where((w) => favorites.contains(w.id)).toList();
    final count = layout == 'grid3' ? 3 : 2;
    return ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 30), children: [
      const Text('Favoriler', style: _PageTitleStyle()),
      const SizedBox(height: 6),
      const Text('Sevdiklerin burada.', style: TextStyle(color: _muted)),
      const SizedBox(height: 16),
      if (items.isEmpty)
        const _EmptyFavorites()
      else if (layout == 'list')
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          itemBuilder: (_, index) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: SizedBox(
              height: 180,
              child: GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: items[index], favorites: favorites))),
                child: WallpaperCard(item: items[index], variant: 2, favorites: favorites),
              ),
            ),
          ),
        )
      else
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: count,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: layout == 'large' ? .72 : (count == 3 ? .62 : .68),
          ),
          itemBuilder: (_, index) => GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: items[index], favorites: favorites))),
            child: WallpaperCard(item: items[index], variant: layout == 'large' ? 3 : index % 4, favorites: favorites),
          ),
        ),
    ]);
  }
}
class _EmptyFavorites extends StatelessWidget { const _EmptyFavorites(); @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(28), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)), child: const Column(children: [Icon(Icons.favorite_border_rounded, size: 44, color: _purple), SizedBox(height: 10), Text('Henüz favorin yok', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), SizedBox(height: 4), Text('Beğendiğin duvar kağıtlarının kalp simgesine dokun.', textAlign: TextAlign.center, style: TextStyle(color: _muted))])); }

class SettingsPage extends StatelessWidget {
  final AppSettings settings;
  final FavoritesStore favorites;
  final ValueChanged<AppSettings> onChanged;
  const SettingsPage({super.key, required this.settings, required this.favorites, required this.onChanged});

  void _set(BuildContext context, AppSettings next) {
    onChanged(next);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Ayar kaydedildi'), duration: Duration(milliseconds: 700)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
      children: [
        const Text('Ayarlar', style: _PageTitleStyle()),
        const SizedBox(height: 6),
        const Text('Uygulama deneyimini yönet.', style: TextStyle(color: _muted)),
        const SizedBox(height: 18),
        _SettingsGroup(
          title: 'Profil',
          children: [
            _SettingsTile(
              icon: Icons.person_outline_rounded,
              title: 'Profil',
              subtitle: settings.googleConnected ? 'Google hesabı bağlı' : 'Google ile kayıt',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ProfilePage(settings: settings, onChanged: onChanged),
                ),
              ),
            ),
          ],
        ),
        _SettingsGroup(
          title: 'Görünüm',
          children: [
            _SettingsTile(
              icon: Icons.palette_outlined,
              title: 'Görünüm',
              subtitle: _themeLabel(settings.themeMode),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AppearancePage(settings: settings, onChanged: onChanged),
                ),
              ),
            ),
            _SettingsTile(
              icon: Icons.image_outlined,
              title: 'Arka plan',
              subtitle: settings.backgroundImagePath == null ? 'Varsayılan' : 'Özel resim',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AppearancePage(settings: settings, onChanged: onChanged),
                ),
              ),
            ),
            _SettingsTile(
              icon: Icons.dashboard_customize_outlined,
              title: 'Kart dizilimi',
              subtitle: _layoutLabel(settings.cardLayout),
              onTap: () async {
                final value = await showModalBottomSheet<String>(
                  context: context,
                  showDragHandle: true,
                  builder: (_) => _LayoutPicker(current: settings.cardLayout),
                );
                if (value != null) _set(context, settings.copyWith(cardLayout: value));
              },
            ),
          ],
        ),
        _SettingsGroup(
          title: 'Bildirimler',
          children: [
            _SwitchTile(title: 'Bildirimler', value: settings.notificationsEnabled, onChanged: (v) => _set(context, settings.copyWith(notificationsEnabled: v))),
            IgnorePointer(
              ignoring: !settings.notificationsEnabled,
              child: Opacity(
                opacity: settings.notificationsEnabled ? 1 : .45,
                child: Column(
                  children: [
                    _SwitchTile(title: 'Yeni duvar kağıtları', value: settings.newWallpapers, onChanged: (v) => _set(context, settings.copyWith(newWallpapers: v))),
                    _SwitchTile(title: 'Favori kategori', value: settings.favoriteCategories, onChanged: (v) => _set(context, settings.copyWith(favoriteCategories: v))),
                    _SwitchTile(title: 'Öneriler', value: settings.recommendations, onChanged: (v) => _set(context, settings.copyWith(recommendations: v))),
                    _SwitchTile(title: 'Editör seçimleri', value: settings.editorPicks, onChanged: (v) => _set(context, settings.copyWith(editorPicks: v))),
                  ],
                ),
              ),
            ),
          ],
        ),
        _SettingsGroup(
          title: 'Açılır ekran',
          children: [
            _SettingsTile(
              icon: Icons.open_in_new_rounded,
              title: 'Açılır ekran',
              subtitle: settings.launchEnabled ? settings.launchFrequency : 'Kapalı',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => LaunchSettingsPage(settings: settings, onChanged: onChanged),
                ),
              ),
            ),
          ],
        ),
        _SettingsGroup(
          title: 'Gizlilik',
          children: [
            _SettingsTile(icon: Icons.privacy_tip_outlined, title: 'Gizlilik politikası', onTap: () => _dialog(context, 'Gizlilik Politikası', 'Wxtra hesap, favori ve ayar verilerini uygulama deneyimini sağlamak için işler.')),
            _SettingsTile(icon: Icons.description_outlined, title: 'Kullanım şartları', onTap: () => _dialog(context, 'Kullanım Şartları', 'Uygulamayı kullanırken içerik ve telif kurallarına uyman gerekir.')),
            _SettingsTile(icon: Icons.delete_outline_rounded, title: 'Hesabı temizle', onTap: () => _clearAccount(context)),
          ],
        ),
        _SettingsGroup(
          title: 'Uygulama',
          children: [
            const _SettingsTile(icon: Icons.info_outline_rounded, title: 'Uygulama sürümü', subtitle: '1.0.0'),
            _SettingsTile(icon: Icons.cloud_outlined, title: 'API durumu', subtitle: 'Sunucuyu kontrol et', onTap: () => _checkApi(context)),
            _SettingsTile(icon: Icons.cleaning_services_outlined, title: 'Önbelleği temizle', onTap: () => _clearCache(context)),
            _SettingsTile(icon: Icons.support_agent_outlined, title: 'Destek', subtitle: 'Yardım ve geri bildirim', onTap: () => _support(context)),
          ],
        ),
        _SettingsGroup(
          title: 'Admin uygulama paneli',
          children: [
            _SettingsTile(icon: Icons.admin_panel_settings_outlined, title: 'Admin paneli', subtitle: 'İçerik ve sistem yönetimi', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPage()))),
          ],
        ),
      ],
    );
  }

  String _themeLabel(ThemeMode m) => m == ThemeMode.dark ? 'Koyu' : m == ThemeMode.light ? 'Açık' : 'Sistem';
  String _layoutLabel(String v) => {'grid2': '2 sütun', 'grid3': '3 sütun', 'list': 'Liste', 'large': 'Büyük kart'}[v] ?? '2 sütun';

  void _dialog(BuildContext c, String title, String body) {
    showDialog<void>(
      context: c,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Kapat'))],
      ),
    );
  }

  Future<void> _clearAccount(BuildContext c) async {
    final ok = await showDialog<bool>(
      context: c,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Yerel veriler temizlensin mi?'),
        content: const Text('Ayarlar ve yerel oturum bağlantısı temizlenecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.of(dialogContext).pop(true), child: const Text('Temizle')),
        ],
      ),
    );
    if (ok != true) return;
    final p = await SharedPreferences.getInstance();
    await p.clear();
    await favorites.clear();
    onChanged(const AppSettings());
    if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('Yerel veriler temizlendi.')));
  }

  Future<void> _clearCache(BuildContext c) async {
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
    if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('Önbellek temizlendi.')));
  }

  Future<void> _support(BuildContext c) async {
    try {
      final ok = await launchUrl(Uri(scheme: 'mailto', path: 'destek@wxtra.app', queryParameters: {'subject': 'Wxtra destek'}));
      if (!ok && c.mounted) ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('E-posta uygulaması açılamadı.')));
    } catch (_) {
      if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('E-posta uygulaması açılamadı.')));
    }
  }

  Future<void> _checkApi(BuildContext c) async {
    showDialog<void>(context: c, barrierDismissible: false, builder: (_) => const AlertDialog(content: Row(children: [SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)), SizedBox(width: 14), Text('API kontrol ediliyor...')])));
    final ok = await ApiService().checkHealth();
    if (c.mounted) Navigator.of(c, rootNavigator: true).pop();
    if (c.mounted) _dialog(c, ok ? 'API çevrimiçi' : 'API bağlantısı yok', ok ? 'Sunucu yanıt verdi.' : 'Sunucuya ulaşılamadı.');
  }
}

class AppearancePage extends StatefulWidget {
  final AppSettings settings; final ValueChanged<AppSettings> onChanged;
  const AppearancePage({super.key, required this.settings, required this.onChanged});
  @override State<AppearancePage> createState()=>_AppearancePageState();
}
class _AppearancePageState extends State<AppearancePage>{
  late AppSettings s; final ImagePicker _picker=ImagePicker();
  @override void initState(){super.initState();s=widget.settings;}
  void _save(AppSettings next) {
    setState(() => s = next);
    widget.onChanged(next);
  }
  Future<void> _pick() async {
    try {
      final picked = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
      if (picked == null) return;
      final directory = await getApplicationDocumentsDirectory();
      final target = File('${directory.path}/wxtra_background.jpg');
      await File(picked.path).copy(target.path);
      _save(s.copyWith(backgroundImagePath: target.path));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Arka plan resmi seçilemedi.')));
      }
    }
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Görünüm',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Tema',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:10),
    Row(children:ThemeMode.values.map((m){final active=s.themeMode==m;final label=m==ThemeMode.system?'Sistem':m==ThemeMode.light?'Açık':'Koyu';return Expanded(child:Padding(padding:const EdgeInsets.only(right:8),child:ChoiceChip(label:Text(label),selected:active,onSelected:(_)=>_save(s.copyWith(themeMode:m)),labelStyle:TextStyle(color:active?Colors.white:_muted,fontWeight:FontWeight.w800),selectedColor:_purple)));}).toList()),
    const SizedBox(height:22),
    const Text('Vurgu rengi',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
    const SizedBox(height:10),
    Wrap(
      spacing:12,
      runSpacing:10,
      children:[
        for(final color in const [0xFF5F2FE8,0xFF2563EB,0xFFE83E8C,0xFFFF9F1C,0xFF16A34A,0xFF06B6D4])
          GestureDetector(
            onTap:()=>_save(s.copyWith(accentColor:color)),
            child:Container(
              width:42,height:42,
              decoration:BoxDecoration(
                color:Color(color),shape:BoxShape.circle,
                border:Border.all(color:s.accentColor==color?Colors.white:_surface,width:3),
                boxShadow:[if(s.accentColor==color) BoxShadow(color:Color(color).withValues(alpha:.30),blurRadius:10)],
              ),
              child:s.accentColor==color?const Icon(Icons.check_rounded,color:Colors.white,size:20):null,
            ),
          ),
      ],
    ),
    const SizedBox(height:22),const Text('Arka plan',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:10),
    Container(height:130,decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xFFF2EDFF),Color(0xFFE2D7FF)])),child:s.backgroundImagePath==null?const Center(child:Text('Varsayılan arka plan',style:TextStyle(color:_muted,fontWeight:FontWeight.w800))):ClipRRect(borderRadius:BorderRadius.circular(24),child:Image.file(File(s.backgroundImagePath!),fit:BoxFit.cover,errorBuilder:(_, __, ___)=>const Center(child:Text('Resim bulunamadı',style:TextStyle(color:_muted,fontWeight:FontWeight.w800)))))),
    const SizedBox(height:10),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:_pick,icon:const Icon(Icons.image_rounded),label:const Text('Resim seç'))),const SizedBox(width:10),OutlinedButton(onPressed:s.backgroundImagePath==null?null:()=>_save(s.copyWith(clearBackground:true)),child:const Text('Kaldır'))]),
    const SizedBox(height:22),const Text('Kart dizilimi',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:10),_LayoutPicker(current:s.cardLayout,onChanged:(v)=>_save(s.copyWith(cardLayout:v)),embedded:true),
  ]));
}

class LaunchSettingsPage extends StatefulWidget {
  final AppSettings settings;
  final ValueChanged<AppSettings> onChanged;
  const LaunchSettingsPage({super.key, required this.settings, required this.onChanged});

  @override
  State<LaunchSettingsPage> createState() => _LaunchSettingsPageState();
}

class _LaunchSettingsPageState extends State<LaunchSettingsPage> {
  late AppSettings s;

  @override
  void initState() {
    super.initState();
    s = widget.settings;
  }

  void _save(AppSettings next) {
    setState(() => s = next);
    widget.onChanged(next);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Açılır ekran', style: TextStyle(fontWeight: FontWeight.w900))),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            SwitchListTile.adaptive(
              value: s.launchEnabled,
              onChanged: (v) => _save(s.copyWith(launchEnabled: v)),
              title: const Text('Açılır ekranı etkinleştir'),
            ),
            const SizedBox(height: 8),
            const Text('Gösterilecek içerikler', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            _SwitchTile(title: 'Yeni duvar kağıtları', value: s.launchNewWallpapers, onChanged: (v) => _save(s.copyWith(launchNewWallpapers: v))),
            _SwitchTile(title: 'Favori kategori', value: s.launchFavoriteCategory, onChanged: (v) => _save(s.copyWith(launchFavoriteCategory: v))),
            _SwitchTile(title: 'Öneriler', value: s.launchRecommendations, onChanged: (v) => _save(s.copyWith(launchRecommendations: v))),
            _SwitchTile(title: 'Editör seçimleri', value: s.launchEditorPicks, onChanged: (v) => _save(s.copyWith(launchEditorPicks: v))),
            const SizedBox(height: 12),
            ListTile(
              title: const Text('Gösterim sıklığı'),
              trailing: DropdownButton<String>(
                value: s.launchFrequency,
                items: const [
                  DropdownMenuItem(value: 'Her açılışta', child: Text('Her açılışta')),
                  DropdownMenuItem(value: 'Günde bir kez', child: Text('Günde bir kez')),
                ],
                onChanged: (v) {
                  if (v != null) _save(s.copyWith(launchFrequency: v));
                },
              ),
            ),
          ],
        ),
      );
}

class ProfilePage extends StatefulWidget {
  final AppSettings settings;
  final ValueChanged<AppSettings> onChanged;
  const ProfilePage({super.key, required this.settings, required this.onChanged});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late AppSettings s;

  @override
  void initState() {
    super.initState();
    s = widget.settings;
  }

  void _toggleGoogle() {
    final next = s.copyWith(googleConnected: !s.googleConnected);
    setState(() => s = next);
    widget.onChanged(next);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Profil', style: TextStyle(fontWeight: FontWeight.w900))),
        body: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              const CircleAvatar(
                radius: 48,
                backgroundColor: Color(0xFFE8E0FF),
                child: Icon(Icons.person_rounded, size: 52, color: _purple),
              ),
              const SizedBox(height: 14),
              Text(
                s.googleConnected ? 'Google hesabı bağlı' : 'Hesabını bağla',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 4),
              const Text('Favorilerini ve tercihlerini senkronize et', style: TextStyle(color: _muted)),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _toggleGoogle,
                  icon: const Text('G', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
                  label: Text(s.googleConnected ? 'Google bağlantısını kaldır' : 'Google ile kayıt'),
                ),
              ),
              const SizedBox(height: 18),
              const _ProfileFeature(icon: Icons.favorite_rounded, title: 'Favorilerini sakla', subtitle: 'Cihazlar arasında eşitle'),
              const _ProfileFeature(icon: Icons.sync_rounded, title: 'Senkronizasyon', subtitle: 'Hesabınla devam eder'),
              const _ProfileFeature(icon: Icons.auto_awesome_rounded, title: 'Sana özel öneriler', subtitle: 'Beğenilerine göre içerik'),
            ],
          ),
        ),
      );
}

class _ProfileFeature extends StatelessWidget{final IconData icon;final String title,subtitle;const _ProfileFeature({required this.icon,required this.title,required this.subtitle});@override Widget build(BuildContext context)=>ListTile(leading:CircleAvatar(backgroundColor:_purple.withValues(alpha:.1),child:Icon(icon,color:_purple)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text(subtitle));}

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  int _announcementCount = 0;

  void _openAdminAction(String title, String description, {bool announcement = false}) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Text(description),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Kapat')),
          if (announcement)
            FilledButton(
              onPressed: () {
                setState(() => _announcementCount++);
                Navigator.of(dialogContext).pop();
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Duyuru taslağı oluşturuldu.')));
              },
              child: const Text('Taslak oluştur'),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Admin Paneli', style: TextStyle(fontWeight: FontWeight.w900))),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_purple, _purple2]),
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Yönetim merkezi', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                  SizedBox(height: 5),
                  Text('İçerik, kategori ve sistem araçlarına buradan eriş.', style: TextStyle(color: Colors.white70)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _AdminTile(icon: Icons.photo_library_rounded, title: 'İçerik yönetimi', subtitle: 'Duvar kağıtlarını yönet', onTap: () => _openAdminAction('İçerik yönetimi', 'Duvar kağıdı ekleme, düzenleme ve kaldırma için yönetim ekranı hazır. API bağlantısı geldiğinde işlemler sunucuya kaydedilecek.')),
            _AdminTile(icon: Icons.category_rounded, title: 'Kategoriler', subtitle: 'Kategori oluştur ve düzenle', onTap: () => _openAdminAction('Kategoriler', 'Kategori yapısı uygulamadaki aktif koleksiyonlardan besleniyor.')),
            _AdminTile(icon: Icons.people_rounded, title: 'Kullanıcılar', subtitle: 'Kullanıcı istatistikleri', onTap: () => _openAdminAction('Kullanıcılar', 'Demo kullanıcı istatistikleri: 1 kullanıcı, 128 favori, 2.400 görüntüleme.')),
            _AdminTile(icon: Icons.notifications_rounded, title: 'Bildirim gönder', subtitle: _announcementCount == 0 ? 'Kullanıcılara duyuru yap' : '$_announcementCount taslak', onTap: () => _openAdminAction('Bildirim gönder', 'Duyuru başlığı ve mesajı için taslak oluşturabilirsin.', announcement: true)),
            _AdminTile(icon: Icons.api_rounded, title: 'API ayarları', subtitle: 'Uç nokta ve bağlantı bilgileri', onTap: () => _openAdminAction('API ayarları', 'API adresi çalışma zamanında API_BASE_URL ile belirlenir. Mevcut adres: $_apiBaseUrl')),
            _AdminTile(icon: Icons.monitor_heart_rounded, title: 'Sistem durumu', subtitle: 'Sunucu ve servis bilgileri', onTap: () => _openAdminAction('Sistem durumu', 'API durumunu Ayarlar > Uygulama > API durumu üzerinden anlık kontrol edebilirsin.')),
          ],
        ),
      );
}

class _AdminTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _AdminTile({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: ListTile(
          onTap: onTap,
          leading: CircleAvatar(backgroundColor: _purple.withValues(alpha: .1), child: Icon(icon, color: _purple)),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right_rounded),
        ),
      );
}

class DetailPage extends StatefulWidget {
  final Wallpaper item;
  final FavoritesStore favorites;
  const DetailPage({super.key, required this.item, required this.favorites});
  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  bool get isFavorite => widget.favorites.contains(widget.item.id);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: widget.item.gradient,
              ),
            ),
            child: _SoftShape(seed: widget.item.id.hashCode),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _OverlayButton(
                    icon: Icons.arrow_back_rounded,
                    onTap: () => Navigator.pop(context),
                  ),
                  Row(
                    children: [
                      _OverlayButton(
                        icon: isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                        onTap: () async {
                          await widget.favorites.toggle(widget.item.id);
                          setState(() {});
                        },
                      ),
                      const SizedBox(width: 7),
                      _OverlayButton(icon: Icons.share_outlined, onTap: _share),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 18,
            child: SafeArea(
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: .92),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.item.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: _ink)),
                    const SizedBox(height: 4),
                    Text(widget.item.category, style: const TextStyle(color: _muted, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: _applyWallpaper,
                            icon: const Icon(Icons.wallpaper_rounded),
                            label: const Text('Duvar kağıdı yap'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        IconButton(
                          onPressed: _share,
                          icon: const Icon(Icons.share_rounded, color: _purple),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<Uint8List> _renderWallpaper() async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder, const Rect.fromLTWH(0, 0, 1080, 1920));
    final paint = Paint()
      ..shader = ui.Gradient.linear(
        const Offset(0, 0),
        const Offset(1080, 1920),
        widget.item.gradient,
      );
    canvas.drawRect(const Rect.fromLTWH(0, 0, 1080, 1920), paint);
    final picture = recorder.endRecording();
    final image = await picture.toImage(1080, 1920);
    final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    return bytes!.buffer.asUint8List();
  }

  Future<String> _makeTempFile() async {
    final bytes = await _renderWallpaper();
    final file = File('${Directory.systemTemp.path}/wxtra_${widget.item.id}.png');
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }

  Future<void> _share() async {
    try {
      final path = await _makeTempFile();
      await Share.shareXFiles(
        [XFile(path, mimeType: 'image/png')],
        text: '${widget.item.title} · ${widget.item.category}',
        subject: widget.item.title,
        fileNameOverrides: ['${widget.item.title}.png'],
      );
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Paylaşım başlatılamadı.')),
        );
      }
    }
  }

  Future<void> _applyWallpaper() async {
    try {
      final choice = await showModalBottomSheet<int>(
        context: context,
        showDragHandle: true,
        builder: (sheetContext) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(title: const Text('Ana ekran'), onTap: () => Navigator.of(sheetContext).pop(WallpaperManagerFlutter.homeScreen)),
              ListTile(title: const Text('Kilit ekranı'), onTap: () => Navigator.of(sheetContext).pop(WallpaperManagerFlutter.lockScreen)),
              ListTile(title: const Text('İkisi birden'), onTap: () => Navigator.of(sheetContext).pop(WallpaperManagerFlutter.bothScreens)),
              const SizedBox(height: 10),
            ],
          ),
        ),
      );
      if (choice == null) return;
      final path = await _makeTempFile();
      final ok = await WallpaperManagerFlutter().setWallpaper(File(path), choice);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(ok ? 'Duvar kağıdı uygulandı.' : 'Duvar kağıdı uygulanamadı.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Duvar kağıdı uygulanamadı.')),
        );
      }
    }
  }
}

class WallpaperCard extends StatelessWidget {
  final Wallpaper item;
  final double? width;
  final int variant;
  final FavoritesStore? favorites;

  const WallpaperCard({
    super.key,
    required this.item,
    this.width,
    this.variant = 0,
    this.favorites,
  });

  @override
  Widget build(BuildContext context) {
    final active = favorites?.contains(item.id) ?? false;
    final radius = switch (variant) {
      3 => 32.0,
      2 => 18.0,
      _ => 25.0,
    };

    return SizedBox(
      width: width,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: Stack(
          fit: StackFit.expand,
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: item.gradient,
                ),
              ),
              child: _SoftShape(seed: item.id.hashCode + variant * 7),
            ),
            Positioned(
              top: 10,
              right: 10,
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: favorites == null ? null : () => favorites!.toggle(item.id),
                  customBorder: const CircleBorder(),
                  child: Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: .20),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white.withValues(alpha: .35)),
                    ),
                    child: Icon(
                      active ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                      size: 18,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 10,
              right: 10,
              bottom: 10,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(17),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
                  color: Colors.black.withValues(alpha: .25),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        item.category,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SoftShape extends StatelessWidget{
  final int seed; const _SoftShape({required this.seed});
  @override Widget build(BuildContext context){final o=(seed.abs()%60).toDouble();return Stack(fit:StackFit.expand,children:[Positioned(top:-30+o/4,left:-30+o/5,child:Container(width:160,height:160,decoration:BoxDecoration(shape:BoxShape.circle,color:Colors.white.withValues(alpha:.22)))),Positioned(right:-35,bottom:-22,child:Container(width:155,height:155,decoration:BoxDecoration(shape:BoxShape.circle,color:Colors.black.withValues(alpha:.12)))),Center(child:Transform.rotate(angle:-.18,child:Container(width:86,height:210,decoration:BoxDecoration(borderRadius:BorderRadius.circular(55),gradient:LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[Colors.white.withValues(alpha:.50),Colors.white.withValues(alpha:.05)]),border:Border.all(color:Colors.white.withValues(alpha:.30))))))]);}
}

class _CircleButton extends StatelessWidget{final IconData icon;final VoidCallback onTap;const _CircleButton({required this.icon,required this.onTap});@override Widget build(BuildContext context)=>Material(color:Colors.white,shape:const CircleBorder(),child:InkWell(onTap:onTap,customBorder:const CircleBorder(),child:SizedBox(width:42,height:42,child:Icon(icon,size:20))));}
class _OverlayButton extends StatelessWidget{final IconData icon;final VoidCallback onTap;const _OverlayButton({required this.icon,required this.onTap});@override Widget build(BuildContext context)=>DecoratedBox(decoration:BoxDecoration(color:Colors.black.withValues(alpha:.28),shape:BoxShape.circle),child:IconButton(onPressed:onTap,icon:Icon(icon,color:Colors.white)));}
class _SectionHeader extends StatelessWidget{final String title;final String? action;const _SectionHeader({required this.title,this.action});@override Widget build(BuildContext context)=>Row(children:[Expanded(child:Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:_ink))),if(action!=null)Text(action!,style:const TextStyle(color:_purple,fontWeight:FontWeight.w800,fontSize:12))]);}
class _PageTitleStyle extends TextStyle{const _PageTitleStyle():super(fontSize:28,fontWeight:FontWeight.w900,color:_ink);}
class _SettingsGroup extends StatelessWidget{final String title;final List<Widget> children;const _SettingsGroup({required this.title,required this.children});@override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(bottom:17),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Padding(padding:const EdgeInsets.only(left:3,bottom:9),child:Text(title,style:const TextStyle(color:_muted,fontWeight:FontWeight.w900))),Container(decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(22)),child:Column(children:children))]));}
class _SettingsTile extends StatelessWidget{final IconData icon;final String title;final String? subtitle;final VoidCallback? onTap;const _SettingsTile({required this.icon,required this.title,this.subtitle,this.onTap});@override Widget build(BuildContext context)=>ListTile(onTap:onTap,leading:CircleAvatar(backgroundColor:_purple.withValues(alpha:.10),child:Icon(icon,color:_purple,size:20)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:subtitle==null?null:Text(subtitle!,maxLines:1,overflow:TextOverflow.ellipsis),trailing:const Icon(Icons.chevron_right_rounded,color:_muted));}
class _SwitchTile extends StatelessWidget{final String title;final bool value;final ValueChanged<bool> onChanged;const _SwitchTile({required this.title,required this.value,required this.onChanged});@override Widget build(BuildContext context)=>SwitchListTile.adaptive(value:value,onChanged:onChanged,title:Text(title,style:const TextStyle(fontWeight:FontWeight.w700)));}
class _LayoutPicker extends StatelessWidget{final String current;final ValueChanged<String>? onChanged;final bool embedded;const _LayoutPicker({required this.current,this.onChanged,this.embedded=false});@override Widget build(BuildContext context){final options={'grid2':'2 sütun','grid3':'3 sütun','list':'Liste','large':'Büyük kart'};return Padding(padding:const EdgeInsets.all(18),child:Column(mainAxisSize:MainAxisSize.min,children:options.entries.map((e)=>ListTile(onTap:(){onChanged?.call(e.key);if(!embedded)Navigator.of(context).pop(e.key);},leading:Icon(e.key==current?Icons.radio_button_checked:Icons.radio_button_off,color:e.key==current?_purple:_muted),title:Text(e.value),trailing:embedded?null:(e.key==current?const Icon(Icons.check,color:_purple):null))).toList()));}}

class Wallpaper{final String id,title,category;final List<String> tags;final List<Color> gradient;const Wallpaper({required this.id,required this.title,required this.category,required this.tags,required this.gradient});}

class ApiService{ApiService({this.baseUrl=_apiBaseUrl});final String baseUrl;Future<bool> checkHealth()async{final c=HttpClient();try{final health=baseUrl.endsWith('/api')?'${baseUrl.substring(0,baseUrl.length-4)}/health':'$baseUrl/health';final r=await c.getUrl(Uri.parse(health));final res=await r.close().timeout(const Duration(seconds:5));return res.statusCode==200;}catch(_){return false;}finally{c.close(force:true);}}}


final _gradientPalette=<List<Color>>[
  const [Color(0xFF7D42F5),Color(0xFFD7B5FF)],
  const [Color(0xFF111426),Color(0xFF5265B6)],
  const [Color(0xFF415E7D),Color(0xFFB8D2E6)],
  const [Color(0xFF171022),Color(0xFF6D4EAF)],
  const [Color(0xFF7E2A2A),Color(0xFFE5A06A)],
  const [Color(0xFF3F245E),Color(0xFFE3B6FF)],
];
List<Color> _gradientFor(int seed) => _gradientPalette[seed.abs()%_gradientPalette.length];

const _categories=['AMOLED','Minimal','Doğa','Uzay','Arabalar','Anime','Soyut','Şehir','Karanlık','Teknoloji','Manzara','Hayvanlar'];
const _demoWallpapers=[
  Wallpaper(id:'1',title:'Mor Işık',category:'Soyut',tags:['mor','minimal'],gradient:[Color(0xFF5D22D4),Color(0xFFE3BFFF)]),
  Wallpaper(id:'2',title:'Gece Ufku',category:'Uzay',tags:['uzay','karanlık'],gradient:[Color(0xFF131733),Color(0xFF6A5AAE)]),
  Wallpaper(id:'3',title:'Mor Zirve',category:'Doğa',tags:['dağ','manzara'],gradient:[Color(0xFF6C4EB0),Color(0xFFEEB2D9)]),
  Wallpaper(id:'4',title:'Sessiz Yol',category:'Minimal',tags:['sade','minimal'],gradient:[Color(0xFF1E2539),Color(0xFF8E9CBC)]),
  Wallpaper(id:'5',title:'Neon Şehir',category:'Şehir',tags:['neon','şehir'],gradient:[Color(0xFF24165F),Color(0xFFE138BB)]),
  Wallpaper(id:'6',title:'Ay Çiçeği',category:'Doğa',tags:['çiçek','mor'],gradient:[Color(0xFF2D1A4B),Color(0xFFAC82DC)]),
];
