import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';

const _purple = Color(0xFF5F2FE8);
const _ink = Color(0xFF171526);
const _surface = Color(0xFFF8F7FC);
const _muted = Color(0xFF777487);
const _apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://10.0.2.2:8000/api',
);

void main() {
  runApp(const WxtraApp());
}

class WxtraApp extends StatelessWidget {
  const WxtraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Wxtra',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: _surface,
        colorScheme: ColorScheme.fromSeed(seedColor: _purple),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: _surface,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
          foregroundColor: _ink,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 1300), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const AppShell()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFFFFFFF), Color(0xFFF1EDFF), Color(0xFFE0D5FF)],
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 112,
                  height: 112,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.78),
                    borderRadius: BorderRadius.circular(34),
                    boxShadow: [
                      BoxShadow(
                        color: _purple.withOpacity(.16),
                        blurRadius: 36,
                        offset: const Offset(0, 14),
                      ),
                    ],
                  ),
                  child: Image.asset('assets/logo.png'),
                ),
                const SizedBox(height: 22),
                const Text(
                  'Wxtra',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.w900,
                    color: _ink,
                  ),
                ),
                const SizedBox(height: 7),
                const Text(
                  'Her Ekran Yeni Bir Hikaye',
                  style: TextStyle(color: _muted, fontSize: 14),
                ),
              ],
            ),
          ),
          const Positioned(
            bottom: 42,
            left: 0,
            right: 0,
            child: Center(
              child: SizedBox(
                width: 84,
                child: LinearProgressIndicator(
                  minHeight: 5,
                  borderRadius: BorderRadius.all(Radius.circular(99)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  int _gridColumns = 2;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onNavigate: (i) => setState(() => _index = i)),
      const CategoriesPage(),
      const DiscoverPage(),
      FavoritesPage(columns: _gridColumns),
      SettingsPage(
        gridColumns: _gridColumns,
        onColumnsChanged: (value) => setState(() => _gridColumns = value),
      ),
    ];

    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _index, children: pages)),
      bottomNavigationBar: NavigationBar(
        height: 73,
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        backgroundColor: Colors.white,
        indicatorColor: _purple.withOpacity(.11),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          return TextStyle(
            fontSize: 11,
            fontWeight: states.contains(WidgetState.selected)
                ? FontWeight.w800
                : FontWeight.w600,
            color: states.contains(WidgetState.selected) ? _purple : _muted,
          );
        }),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Ana Sayfa',
          ),
          NavigationDestination(
            icon: Icon(Icons.grid_view_rounded),
            label: 'Kategoriler',
          ),
          NavigationDestination(
            icon: Icon(Icons.search_rounded),
            selectedIcon: Icon(Icons.search_rounded),
            label: 'Keşfet',
          ),
          NavigationDestination(
            icon: Icon(Icons.favorite_border_rounded),
            selectedIcon: Icon(Icons.favorite_rounded),
            label: 'Favoriler',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings_rounded),
            label: 'Ayarlar',
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final ValueChanged<int> onNavigate;
  const HomePage({super.key, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {},
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 30),
        children: [
          Row(
            children: [
              Container(
                width: 46,
                height: 46,
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Image.asset('assets/logo.png'),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Merhaba, Wxtra 👋',
                      style: TextStyle(
                        color: _ink,
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                      ),
                    ),
                    SizedBox(height: 3),
                    Text(
                      'Bugün hangi tarzı keşfetmek istersin?',
                      style: TextStyle(color: _muted, fontSize: 12),
                    ),
                  ],
                ),
              ),
              _CircleButton(icon: Icons.notifications_none_rounded, onTap: () {}),
              const SizedBox(width: 7),
              _CircleButton(icon: Icons.person_outline_rounded, onTap: () {}),
            ],
          ),
          const SizedBox(height: 18),
          InkWell(
            onTap: () => onNavigate(2),
            borderRadius: BorderRadius.circular(20),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(.035),
                    blurRadius: 18,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: const Row(
                children: [
                  Icon(Icons.search_rounded, color: _muted),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Duvar kağıdı ara...',
                      style: TextStyle(color: _muted),
                    ),
                  ),
                  Icon(Icons.tune_rounded, color: _purple),
                ],
              ),
            ),
          ),
          const SizedBox(height: 22),
          const _SectionHeader(title: 'Günün Duvar Kağıtları'),
          const SizedBox(height: 12),
          SizedBox(
            height: 235,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _demoWallpapers.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (context, index) {
                final item = _demoWallpapers[index];
                return GestureDetector(
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => DetailPage(item: item)),
                  ),
                  child: WallpaperCard(item: item, width: 180),
                );
              },
            ),
          ),
          const SizedBox(height: 24),
          const _SectionHeader(title: 'Trend Olanlar', action: 'Tümünü gör'),
          const SizedBox(height: 12),
          SizedBox(
            height: 180,
            child: Row(
              children: _demoWallpapers.take(3).map((item) {
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => DetailPage(item: item)),
                      ),
                      child: WallpaperCard(item: item),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 22),
          const _SectionHeader(title: 'Popüler Kategoriler'),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: _categories.map((name) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  name,
                  style: const TextStyle(fontWeight: FontWeight.w800, color: _ink),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class CategoriesPage extends StatelessWidget {
  const CategoriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
      children: [
        const Text('Kategoriler', style: _PageTitleStyle()),
        const SizedBox(height: 6),
        const Text('Tarzına uygun koleksiyonu keşfet.', style: TextStyle(color: _muted)),
        const SizedBox(height: 20),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _categories.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.08,
          ),
          itemBuilder: (context, index) {
            final name = _categories[index];
            return InkWell(
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => CategoryDetailPage(category: name)),
              ),
              borderRadius: BorderRadius.circular(24),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      _demoGradients[index % _demoGradients.length].$1,
                      _demoGradients[index % _demoGradients.length].$2,
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(.035),
                      blurRadius: 18,
                      offset: const Offset(0, 7),
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned.fill(child: _SoftShape(seed: index + 2)),
                    Positioned(
                      left: 15,
                      right: 15,
                      bottom: 14,
                      child: Text(
                        name,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                          shadows: [Shadow(blurRadius: 10, color: Colors.black26)],
                        ),
                      ),
                    ),
                    const Positioned(
                      top: 12,
                      right: 12,
                      child: CircleAvatar(
                        radius: 16,
                        backgroundColor: Colors.white24,
                        child: Icon(Icons.chevron_right, color: Colors.white, size: 19),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

class CategoryDetailPage extends StatelessWidget {
  final String category;
  const CategoryDetailPage({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    final items = _demoWallpapers;
    return Scaffold(
      appBar: AppBar(
        title: Text(category, style: const TextStyle(fontWeight: FontWeight.w900)),
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(18),
        itemCount: items.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: .68,
        ),
        itemBuilder: (_, index) => WallpaperCard(item: items[index]),
      ),
    );
  }
}

class DiscoverPage extends StatefulWidget {
  const DiscoverPage({super.key});

  @override
  State<DiscoverPage> createState() => _DiscoverPageState();
}

class _DiscoverPageState extends State<DiscoverPage> {
  final _controller = TextEditingController();
  Timer? _debounce;
  String _query = '';
  String _filter = 'Yeni';

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _search(String value) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () {
      if (mounted) setState(() => _query = value.trim().toLowerCase());
    });
  }

  @override
  Widget build(BuildContext context) {
    final results = _demoWallpapers.where((item) {
      if (_query.isEmpty) return true;
      return item.title.toLowerCase().contains(_query) ||
          item.category.toLowerCase().contains(_query) ||
          item.tags.any((tag) => tag.toLowerCase().contains(_query));
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
          child: TextField(
            controller: _controller,
            onChanged: _search,
            decoration: InputDecoration(
              hintText: 'Duvar kağıdı ara...',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: IconButton(
                onPressed: () {},
                icon: const Icon(Icons.tune_rounded),
              ),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(20),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
        SizedBox(
          height: 42,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            scrollDirection: Axis.horizontal,
            itemCount: const ['Yeni', 'Popüler', 'Trend', 'En çok favorilenen', 'Editör seçimi'].length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (_, index) {
              final label = ['Yeni', 'Popüler', 'Trend', 'En çok favorilenen', 'Editör seçimi'][index];
              return ChoiceChip(
                label: Text(label),
                selected: _filter == label,
                onSelected: (_) => setState(() => _filter = label),
                selectedColor: _purple.withOpacity(.14),
                labelStyle: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: _filter == label ? _purple : _muted,
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 6),
        Expanded(
          child: results.isEmpty
              ? const Center(child: Text('Sonuç bulunamadı.'))
              : GridView.builder(
                  padding: const EdgeInsets.all(18),
                  itemCount: results.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: .68,
                  ),
                  itemBuilder: (_, index) => WallpaperCard(item: results[index]),
                ),
        ),
      ],
    );
  }
}

class FavoritesPage extends StatelessWidget {
  final int columns;
  const FavoritesPage({super.key, required this.columns});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
      children: [
        Row(
          children: [
            const Expanded(child: Text('Favoriler', style: _PageTitleStyle())),
            IconButton(onPressed: () {}, icon: const Icon(Icons.grid_view_rounded)),
            IconButton(onPressed: () {}, icon: const Icon(Icons.view_list_rounded)),
          ],
        ),
        const SizedBox(height: 4),
        const Text('Koleksiyonun burada. Kart dizilimini Ayarlar’dan değiştirebilirsin.', style: TextStyle(color: _muted)),
        const SizedBox(height: 18),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _demoWallpapers.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: columns,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: .68,
          ),
          itemBuilder: (_, index) => WallpaperCard(item: _demoWallpapers[index]),
        ),
      ],
    );
  }
}

class SettingsPage extends StatelessWidget {
  final int gridColumns;
  final ValueChanged<int> onColumnsChanged;
  const SettingsPage({super.key, required this.gridColumns, required this.onColumnsChanged});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
      children: [
        const Text('Ayarlar', style: _PageTitleStyle()),
        const SizedBox(height: 18),
        _SettingsGroup(
          title: 'Profil',
          children: [
            _SettingsTile(icon: Icons.person_outline_rounded, title: 'Profil', subtitle: 'Hesabını yönet', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfilePage()))),
            _SettingsTile(icon: Icons.email_outlined, title: 'E-posta', subtitle: 'kullanici@example.com', onTap: () {}),
            _SettingsTile(icon: Icons.history_rounded, title: 'Görüntüleme geçmişi', subtitle: 'Son hareketlerin', onTap: () {}),
          ],
        ),
        _SettingsGroup(
          title: 'Görünüm',
          children: [
            _SettingsTile(
              icon: Icons.dashboard_customize_outlined,
              title: 'Kart dizilimi',
              subtitle: '${gridColumns} sütun',
              onTap: () async {
                final value = await showModalBottomSheet<int>(
                  context: context,
                  showDragHandle: true,
                  builder: (_) => _GridPicker(current: gridColumns),
                );
                if (value != null) onColumnsChanged(value);
              },
            ),
          ],
        ),
        _SettingsGroup(
          title: 'Bildirimler',
          children: [
            _SwitchTile(title: 'Yeni duvar kağıtları'),
            _SwitchTile(title: 'Favori kategoriler'),
            _SwitchTile(title: 'Öneriler'),
            _SwitchTile(title: 'Editör seçimleri'),
          ],
        ),
        _SettingsGroup(
          title: 'Gizlilik',
          children: [
            _SettingsTile(icon: Icons.privacy_tip_outlined, title: 'Gizlilik politikası', onTap: () {}),
            _SettingsTile(icon: Icons.description_outlined, title: 'Kullanım şartları', onTap: () {}),
            _SettingsTile(icon: Icons.delete_outline_rounded, title: 'Hesabı sil', onTap: () {}),
          ],
        ),
        _SettingsGroup(
          title: 'Hesap',
          children: [
            _SettingsTile(icon: Icons.manage_accounts_outlined, title: 'Profil düzenle', onTap: () {}),
            _SettingsTile(icon: Icons.login_rounded, title: 'Google hesabı', subtitle: 'Google ile devam et', onTap: () {}),
            _SettingsTile(icon: Icons.logout_rounded, title: 'Oturum kapat', onTap: () {}),
          ],
        ),
        _SettingsGroup(
          title: 'Uygulama',
          children: [
            const _SettingsTile(icon: Icons.info_outline_rounded, title: 'Uygulama sürümü', subtitle: '1.0.0'),
            const _SettingsTile(icon: Icons.cloud_outlined, title: 'API durumu', subtitle: _apiBaseUrl),
            _SettingsTile(icon: Icons.cleaning_services_outlined, title: 'Önbelleği temizle', onTap: () {}),
            _SettingsTile(icon: Icons.support_agent_outlined, title: 'Destek', onTap: () {}),
          ],
        ),
      ],
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profilim', style: TextStyle(fontWeight: FontWeight.w900))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const CircleAvatar(
            radius: 48,
            backgroundColor: Colors.white,
            child: Icon(Icons.person, size: 42),
          ),
          const SizedBox(height: 14),
          const Center(child: Text('Wxtra', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
          const SizedBox(height: 4),
          const Center(child: Text('kullanici@example.com', style: TextStyle(color: _muted))),
          const SizedBox(height: 22),
          Row(
            children: const [
              _StatCard(value: '128', label: 'Favori'),
              SizedBox(width: 10),
              _StatCard(value: '2.4K', label: 'Görüntüleme'),
              SizedBox(width: 10),
              _StatCard(value: '12', label: 'Kategori'),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String value;
  final String label;
  const _StatCard({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 17),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          children: [
            Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Text(label, style: const TextStyle(fontSize: 11, color: _muted)),
          ],
        ),
      ),
    );
  }
}

class DetailPage extends StatelessWidget {
  final Wallpaper item;
  const DetailPage({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: item.gradient,
              ),
            ),
            child: _SoftShape(seed: item.id.hashCode),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _OverlayButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
                  Row(
                    children: [
                      _OverlayButton(icon: Icons.favorite_border_rounded, onTap: () {}),
                      const SizedBox(width: 6),
                      _OverlayButton(icon: Icons.share_outlined, onTap: () {}),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 18,
            child: SafeArea(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(25),
                child: Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.92),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: _ink)),
                      const SizedBox(height: 4),
                      Text(item.category, style: const TextStyle(color: _muted, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 9),
                      Text(item.tags.map((e) => '#$e').join('  '), style: const TextStyle(color: _muted)),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          const Expanded(child: Text('Benzer duvar kağıtları', style: TextStyle(fontWeight: FontWeight.w900))),
                          TextButton(onPressed: () {}, child: const Text('Tümünü gör')),
                        ],
                      ),
                      SizedBox(
                        height: 66,
                        child: Row(
                          children: _demoWallpapers.take(4).map((w) => Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(right: 7),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(13),
                                child: DecoratedBox(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(colors: w.gradient),
                                  ),
                                ),
                              ),
                            ),
                          )).toList(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class WallpaperCard extends StatelessWidget {
  final Wallpaper item;
  final double? width;
  const WallpaperCard({super.key, required this.item, this.width});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(21),
        child: Stack(
          fit: StackFit.expand,
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: item.gradient,
                ),
              ),
              child: _SoftShape(seed: item.id.hashCode),
            ),
            Positioned(
              top: 10,
              right: 10,
              child: Container(
                width: 33,
                height: 33,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.2),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white30),
                ),
                child: const Icon(Icons.favorite_border_rounded, size: 18, color: Colors.white),
              ),
            ),
            Positioned(
              left: 11,
              right: 11,
              bottom: 11,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(.28),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Text(
                  item.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SoftShape extends StatelessWidget {
  final int seed;
  const _SoftShape({required this.seed});

  @override
  Widget build(BuildContext context) {
    final offset = (seed % 60).toDouble();
    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned(
          top: -30 + offset / 4,
          left: -30 + offset / 5,
          child: Container(
            width: 160,
            height: 160,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(.22),
            ),
          ),
        ),
        Positioned(
          right: -35,
          bottom: -22,
          child: Container(
            width: 155,
            height: 155,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withOpacity(.12),
            ),
          ),
        ),
        Center(
          child: Transform.rotate(
            angle: -.18,
            child: Container(
              width: 86,
              height: 210,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(55),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.white.withOpacity(.50),
                    Colors.white.withOpacity(.05),
                  ],
                ),
                border: Border.all(color: Colors.white.withOpacity(.30)),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _CircleButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _CircleButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: SizedBox(width: 42, height: 42, child: Icon(icon, size: 20)),
      ),
    );
  }
}

class _OverlayButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _OverlayButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.28),
        shape: BoxShape.circle,
      ),
      child: IconButton(
        onPressed: onTap,
        icon: Icon(icon, color: Colors.white),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String? action;
  const _SectionHeader({required this.title, this.action});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: _ink))),
        if (action != null) Text(action!, style: const TextStyle(color: _purple, fontWeight: FontWeight.w800, fontSize: 12)),
      ],
    );
  }
}

class _PageTitleStyle extends TextStyle {
  const _PageTitleStyle()
      : super(fontSize: 28, fontWeight: FontWeight.w900, color: _ink);
}

class _SettingsGroup extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const _SettingsGroup({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 17),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 3, bottom: 9),
            child: Text(title, style: const TextStyle(color: _muted, fontWeight: FontWeight.w900)),
          ),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(children: children),
          ),
        ],
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback? onTap;
  const _SettingsTile({required this.icon, required this.title, this.subtitle, this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: CircleAvatar(
        radius: 20,
        backgroundColor: _purple.withOpacity(.10),
        child: Icon(icon, color: _purple, size: 20),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: subtitle == null ? null : Text(subtitle!, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: const Icon(Icons.chevron_right_rounded, color: _muted),
    );
  }
}

class _SwitchTile extends StatefulWidget {
  final String title;
  const _SwitchTile({required this.title});

  @override
  State<_SwitchTile> createState() => _SwitchTileState();
}

class _SwitchTileState extends State<_SwitchTile> {
  bool value = true;

  @override
  Widget build(BuildContext context) {
    return SwitchListTile.adaptive(
      value: value,
      onChanged: (next) => setState(() => value = next),
      title: Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w700)),
    );
  }
}

class _GridPicker extends StatelessWidget {
  final int current;
  const _GridPicker({required this.current});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Kart dizilimi', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            ),
            const SizedBox(height: 10),
            for (final value in [2, 3])
              ListTile(
                title: Text('$value sütun'),
                leading: Icon(value == 2 ? Icons.grid_view_rounded : Icons.apps_rounded),
                trailing: current == value ? const Icon(Icons.check_rounded, color: _purple) : null,
                onTap: () => Navigator.pop(context, value),
              ),
          ],
        ),
      ),
    );
  }
}

class Wallpaper {
  final String id;
  final String title;
  final String category;
  final List<String> tags;
  final List<Color> gradient;

  const Wallpaper({
    required this.id,
    required this.title,
    required this.category,
    required this.tags,
    required this.gradient,
  });
}

class ApiService {
  ApiService({this.baseUrl = _apiBaseUrl});

  final String baseUrl;

  Future<List<Wallpaper>> fetchWallpapers() async {
    final client = HttpClient();
    try {
      final request = await client.getUrl(Uri.parse('$baseUrl/wallpapers'));
      final response = await request.close().timeout(const Duration(seconds: 5));
      if (response.statusCode != 200) throw HttpException('API hatası');
      final body = await response.transform(utf8.decoder).join();
      final json = jsonDecode(body) as Map<String, dynamic>;
      final items = (json['items'] as List<dynamic>? ?? <dynamic>[]);
      return items.map((raw) {
        final map = raw as Map<String, dynamic>;
        return Wallpaper(
          id: map['id']?.toString() ?? 'api',
          title: map['title']?.toString() ?? 'Duvar Kağıdı',
          category: map['category']?.toString() ?? 'Soyut',
          tags: List<String>.from(map['tags'] ?? const []),
          gradient: const [_purple, Color(0xFFD6C7FF)],
        );
      }).toList();
    } finally {
      client.close(force: true);
    }
  }
}

const _categories = [
  'AMOLED', 'Minimal', 'Doğa', 'Uzay', 'Arabalar', 'Anime',
  'Soyut', 'Şehir', 'Karanlık', 'Teknoloji', 'Manzara', 'Hayvanlar',
];

const _demoGradients = <(Color, Color)>[
  (Color(0xFF7D42F5), Color(0xFFD7B5FF)),
  (Color(0xFF111426), Color(0xFF5265B6)),
  (Color(0xFF415E7D), Color(0xFFB8D2E6)),
  (Color(0xFF171022), Color(0xFF6D4EAF)),
  (Color(0xFF7E2A2A), Color(0xFFE5A06A)),
  (Color(0xFF3F245E), Color(0xFFE3B6FF)),
];

const _demoWallpapers = [
  Wallpaper(id: '1', title: 'Mor Işık', category: 'Soyut', tags: ['mor', 'minimal'], gradient: [Color(0xFF5D22D4), Color(0xFFE3BFFF)]),
  Wallpaper(id: '2', title: 'Gece Ufku', category: 'Uzay', tags: ['uzay', 'karanlık'], gradient: [Color(0xFF131733), Color(0xFF6A5AAE)]),
  Wallpaper(id: '3', title: 'Mor Zirve', category: 'Doğa', tags: ['dağ', 'manzara'], gradient: [Color(0xFF6C4EB0), Color(0xFFEEB2D9)]),
  Wallpaper(id: '4', title: 'Sessiz Yol', category: 'Minimal', tags: ['sade', 'minimal'], gradient: [Color(0xFF1E2539), Color(0xFF8E9CBC)]),
  Wallpaper(id: '5', title: 'Neon Şehir', category: 'Şehir', tags: ['neon', 'şehir'], gradient: [Color(0xFF24165F), Color(0xFFE138BB)]),
  Wallpaper(id: '6', title: 'Ay Çiçeği', category: 'Doğa', tags: ['çiçek', 'mor'], gradient: [Color(0xFF2D1A4B), Color(0xFFAC82DC)]),
];
