import 'package:flutter_test/flutter_test.dart';
import 'package:wxtra_wallpaper/main.dart';

void main() {
  testWidgets('Wxtra açılış ekranı', (tester) async {
    await tester.pumpWidget(const WxtraApp());
    expect(find.text('Wxtra'), findsOneWidget);
    expect(find.text('Her Ekran Yeni Bir Hikaye'), findsOneWidget);
  });
}
