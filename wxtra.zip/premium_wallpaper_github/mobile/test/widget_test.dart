import 'package:flutter_test/flutter_test.dart';
import 'package:wxtra_wallpaper/main.dart';

void main() {
  testWidgets('Wxtra açılır ve Ayarlar sekmesi çalışır', (tester) async {
    await tester.pumpWidget(const WxtraApp());
    await tester.pumpAndSettle();

    expect(find.text('Ana Sayfa'), findsOneWidget);
    expect(find.text('Ayarlar'), findsWidgets);

    await tester.tap(find.text('Ayarlar').last);
    await tester.pumpAndSettle();
    expect(find.text('Profil'), findsOneWidget);
    expect(find.text('Dil ayarı'), findsOneWidget);
    expect(find.text('Önbellek temizliği'), findsOneWidget);
  });

  testWidgets('Dil seçimi alt sayfayı kapatır, Ayarlar ekranını kapatmaz', (tester) async {
    await tester.pumpWidget(const WxtraApp());
    await tester.pumpAndSettle();
    await tester.tap(find.text('Ayarlar').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Dil ayarı'));
    await tester.pumpAndSettle();
    expect(find.text('English'), findsOneWidget);
    await tester.tap(find.text('English'));
    await tester.pumpAndSettle();
    expect(find.text('Settings'), findsWidgets);
    await tester.pageBack();
    await tester.pumpAndSettle();
    expect(find.text('Home'), findsWidgets);
  });
}
