import 'package:flutter_test/flutter_test.dart';
import 'package:wxtra_wallpaper/main.dart';

void main() {
  testWidgets('Wxtra ayarlar ekranı açılıyor', (tester) async {
    await tester.pumpWidget(const WxtraApp());
    await tester.pumpAndSettle(const Duration(seconds: 2));
    expect(find.text('Ayarlar'), findsOneWidget);
    expect(find.text('Görünüm'), findsOneWidget);
    expect(find.text('Bildirimler'), findsOneWidget);
  });
}
