# WXTRA V1 - Akış Sürümü

Bu ZIP, önceki WXTRA tasarımını temel alır ve ana uygulama akışlarını tek projede birleştirir.

## Hazır akışlar
- Açılış → Ana Sayfa
- Ana Sayfa → Keşfet / wallpaper detay
- Wallpaper detay → önizleme / canlı uygulama / statik uygulama / indirme / paylaşma
- Favoriye ekleme ve Favoriler ekranı
- Canlı wallpaper önizleme → Android canlı wallpaper ayarı
- AI Studio demo akışı → örnek wallpaper / görsel seçme → Düzenle
- Wallpaper editörü demo akışı
- Dinamik wallpaper ayar ekranı
- Koleksiyonlar
- Profil → wallpaper yükleme → editör
- Yan menü → tüm ana bölümlere geçiş
- Premium ekranı

## Gerçek servis bağlantısı gerekenler
- Firebase Authentication / Google giriş
- Firebase Storage + Firestore
- Gerçek AI görüntü üretimi
- Sunucudan wallpaper katalogu
- Google Play Billing
- Creator moderasyon / yükleme backend'i

## Derleme
GitHub Actions workflow'u debug APK üretir ve artifact olarak yükler.
