# WXTRA V1 Interaction Update

This build focuses on a usable offline-first prototype before Firebase integration.

Included:
- Persistent back stack and Android back gesture/button support
- Home, Explore, Detail, Live Preview, AI Studio, Editor, Dynamic, Collections, Favorites, Profile, Premium and Settings flows
- Search dialog and category filtering
- Persistent favorites and collections using SharedPreferences
- Static wallpaper target selection (home/lock/both)
- Gallery download and sharing
- Android live wallpaper launch flow
- Image picker and editor save flow
- Demo wallpaper library (25 images + live video assets)

Firebase/auth/cloud features remain intentionally deferred.
