WXTRA proje durumu

- Başlangıç: 4 ekranlı onboarding, kaydırma ve sinematik geçiş animasyonu.
- Ana Sayfa: uzun/kaydırılabilir, beyaz premium tema, özgün WXTRA düzeni.
- Ana sayfada arama, hero alanı, hızlı aksiyon kartları, Senin İçin, Canlı Duvar Kağıtları, En Son Eklenenler, Koleksiyonlar, hikaye bannerı ve Bugünün modu bölümleri bulunuyor.
- Ana sayfa alt navigasyonu sabit.
- Sayfa geçiş animasyonları korunuyor.
- Firebase/backend henüz eklenmedi; görsel/UX aşamasında.
