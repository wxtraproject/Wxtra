from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

app = FastAPI(title="Wxtra REST API", version="1.0.0")

class Wallpaper(BaseModel):
    id: str
    title: str
    category: str
    image_url: str = ""
    tags: list[str] = Field(default_factory=list)

class Page(BaseModel):
    items: list[Wallpaper]
    page: int
    page_size: int
    has_next: bool

class GoogleAuth(BaseModel):
    id_token: str = Field(min_length=10)

class NotificationSettings(BaseModel):
    new_wallpapers: bool = True
    favorite_categories: bool = True
    recommendations: bool = True
    editor_picks: bool = True

WALLPAPERS = [
    Wallpaper(id="wp-1", title="Mor Işık", category="Soyut", tags=["mor", "minimal"]),
    Wallpaper(id="wp-2", title="Gece Ufku", category="Uzay", tags=["uzay", "karanlık"]),
    Wallpaper(id="wp-3", title="Mor Zirve", category="Doğa", tags=["dağ", "manzara"]),
]

CATEGORIES = [
    "AMOLED", "Minimal", "Doğa", "Uzay", "Arabalar", "Anime",
    "Soyut", "Şehir", "Karanlık", "Teknoloji", "Manzara", "Hayvanlar",
]

def paginate(items: list[Wallpaper], page: int, page_size: int) -> Page:
    start = (page - 1) * page_size
    end = start + page_size
    return Page(items=items[start:end], page=page, page_size=page_size, has_next=end < len(items))

@app.get("/health")
def health():
    return {"status": "ok", "service": "wxtra-api"}

@app.post("/api/auth/google")
def google_auth(payload: GoogleAuth):
    return {"access_token": "development-token", "token_type": "bearer"}

@app.get("/api/wallpapers", response_model=Page)
def wallpapers(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    return paginate(WALLPAPERS, page, page_size)

@app.get("/api/wallpapers/trending", response_model=Page)
def trending(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    return paginate(list(reversed(WALLPAPERS)), page, page_size)

@app.get("/api/wallpapers/latest", response_model=Page)
def latest(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    return paginate(WALLPAPERS, page, page_size)

@app.get("/api/wallpapers/recommended", response_model=Page)
def recommended(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    return paginate(WALLPAPERS, page, page_size)

@app.get("/api/wallpapers/{wallpaper_id}", response_model=Wallpaper)
def wallpaper_detail(wallpaper_id: str):
    for item in WALLPAPERS:
        if item.id == wallpaper_id:
            return item
    raise HTTPException(status_code=404, detail="Duvar kağıdı bulunamadı.")

@app.get("/api/categories")
def categories():
    return [{"id": value.lower(), "name": value, "cover_url": "", "wallpaper_count": 0} for value in CATEGORIES]

@app.get("/api/categories/{category_id}/wallpapers", response_model=Page)
def category_wallpapers(category_id: str, page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    target = category_id.replace("-", " ").lower()
    return paginate([item for item in WALLPAPERS if item.category.lower() == target], page, page_size)

@app.get("/api/search", response_model=Page)
def search(q: str = Query("", max_length=100), sort: str = "new", page: int = 1, page_size: int = 20):
    term = q.strip().lower()
    items = WALLPAPERS if not term else [
        item for item in WALLPAPERS
        if term in item.title.lower() or term in item.category.lower() or any(term in tag.lower() for tag in item.tags)
    ]
    if sort in {"popular", "trend", "favorite"}:
        items = list(reversed(items))
    return paginate(items, page, page_size)

@app.get("/api/favorites", response_model=Page)
def favorites(page: int = 1, page_size: int = 20):
    return paginate(WALLPAPERS[:1], page, page_size)

@app.post("/api/favorites/{wallpaper_id}")
def add_favorite(wallpaper_id: str):
    if wallpaper_id not in {item.id for item in WALLPAPERS}:
        raise HTTPException(status_code=404, detail="Duvar kağıdı bulunamadı.")
    return {"wallpaper_id": wallpaper_id, "favorite": True}

@app.delete("/api/favorites/{wallpaper_id}")
def remove_favorite(wallpaper_id: str):
    return {"wallpaper_id": wallpaper_id, "favorite": False}

@app.get("/api/user")
def user():
    return {"id": "demo-user", "username": "Wxtra", "email": "kullanici@example.com", "favorite_count": 128, "view_count": 2400}

@app.get("/api/notifications")
def notifications():
    return []

@app.put("/api/notifications/settings")
def notification_settings(payload: NotificationSettings):
    return payload
