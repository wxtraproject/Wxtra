import 'package:flutter_test/flutter_test.dart';
import 'package:wxtra_wallpaper/main.dart';

void main() {
  testWidgets('Wxtra açılır ve Ayarlar sekmesi çalışır', (tester) async {
    await tester.pumpWidget(const WxtraApp());
    await tester.pumpAndSettle();

    expect(find.text('Günün Duvar Kağıtları'), findsOneWidget);
    expect(find.text('Ana Sayfa'), findsOneWidget);
    expect(find.text('Ayarlar'), findsWidgets);

    await tester.tap(find.text('Ayarlar'));
    await tester.pumpAndSettle();
    expect(find.text('Profil'), findsOneWidget);
    expect(find.text('Görünüm'), findsOneWidget);
    expect(find.text('Bildirimler'), findsOneWidget);
  });
}
