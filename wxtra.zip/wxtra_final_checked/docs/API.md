# Wxtra REST API sözleşmesi

Base URL: `API_BASE_URL`

## Kimlik doğrulama

Korumalı endpoint'ler production'da:

`Authorization: Bearer <JWT>`

kullanmalıdır.

## İçerik

`GET /api/wallpapers?page=1&page_size=20`

`GET /api/wallpapers/trending`

`GET /api/wallpapers/latest`

`GET /api/wallpapers/recommended`

`GET /api/wallpapers/{id}`

## Kategoriler

`GET /api/categories`

`GET /api/categories/{id}/wallpapers?page=1&page_size=20`

## Arama

`GET /api/search?q=mor&sort=trend&page=1&page_size=20`

Sort değerleri: `new`, `popular`, `trend`, `favorite`, `editor`.

## Favoriler

`GET /api/favorites`

`POST /api/favorites/{id}`

`DELETE /api/favorites/{id}`

## Kullanıcı

`POST /api/auth/google`

`GET /api/user`

## Bildirim

`GET /api/notifications`

`PUT /api/notifications/settings`
