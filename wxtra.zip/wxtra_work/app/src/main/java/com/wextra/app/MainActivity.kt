package com.wextra.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.painterResource

private val Purple = Color(0xFF6336E8)
private val Purple2 = Color(0xFF9A68FF)
private val Bg = Color(0xFFF8F6FF)
private val TextMain = Color(0xFF15142A)
private val TextMuted = Color(0xFF6B6782)
private val Card = Color(0xFFFFFFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAApp() }
    }
}

@Composable
private fun WXTRAApp() {
    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, secondary = Purple2)) {
        Surface(Modifier.fillMaxSize(), color = Bg) { AppShell() }
    }
}

@Composable
private fun AppShell() {
    var page by remember { mutableStateOf("home") }
    var appearance by remember { mutableStateOf(false) }

    if (page == "settings" && appearance) {
        AppearanceScreen(onBack = { appearance = false })
        return
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            when (page) {
                "home" -> HomeScreen()
                "categories" -> SimpleScreen("Kategoriler", "Duvar kâğıtlarını tarzına göre keşfet.")
                "explore" -> SimpleScreen("Keşfet", "Yeni koleksiyonlar ve ilham veren duvar kâğıtları.")
                "profile" -> SimpleScreen("Profil", "Favorilerin ve kişisel tercihlerin burada.")
                "settings" -> SettingsScreen(onAppearance = { appearance = true })
            }
        }
        BottomNav(page) { page = it }
    }
}

@Composable
private fun HomeScreen() {
    val scroll = rememberScrollState()
    Column(
        Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(listOf(Color.White, Color(0xFFE5D9FF))))
                        .border(1.dp, Color.White, RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("W", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Purple2) }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("WXTRA", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Purple)
                    Text("DAHA FAZLA GÖR • DAHA FAZLA HİSSET", fontSize = 8.sp, letterSpacing = 1.sp, color = TextMuted)
                }
            }
            IconButton(onClick = {}) { Icon(Icons.Default.Search, null, tint = TextMain) }
            IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, null, tint = Purple) }
        }

        Spacer(Modifier.height(15.dp))
        ChipRow()

        Spacer(Modifier.height(16.dp))
        Text("Günün Seçimi", fontSize = 27.sp, fontWeight = FontWeight.Black, color = TextMain)
        Text("Bugünün ruhuna eşlik edecek özel seçim", fontSize = 13.sp, color = TextMuted)
        Spacer(Modifier.height(10.dp))

        HeroCard()

        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Senin İçin", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = TextMain)
                Text("Karışık keşif akışı", fontSize = 12.sp, color = TextMuted)
            }
            Text("Tümünü Gör  ›", color = Purple, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(12.dp))
        MixedGrid()

        Spacer(Modifier.height(22.dp))
        Text("Yeni İlhamlar", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = TextMain)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MiniFeature("Rastgele", Icons.Default.Shuffle)
            MiniFeature("Trendler", Icons.Default.Whatshot)
        }
        Spacer(Modifier.height(22.dp))
    }
}

@Composable
private fun ChipRow() {
    val chips = listOf("Tümü", "Doğa", "Şehir", "Minimal", "Anime", "Araçlar", "Sanat")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        chips.forEachIndexed { i, label ->
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = if (i == 0) Purple else Color.White,
                shadowElevation = if (i == 0) 3.dp else 1.dp
            ) {
                Text(label, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    color = if (i == 0) Color.White else TextMuted, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun HeroCard() {
    Box(
        Modifier.fillMaxWidth().height(235.dp).clip(RoundedCornerShape(30.dp))
            .border(1.dp, Color.White, RoundedCornerShape(30.dp))
    ) {
        Image(painterResource(R.drawable.wp_mountain), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(Color(0xDD10102C), Color.Transparent, Color(0x22000000)))
        ))
        Column(Modifier.align(Alignment.CenterStart).padding(20.dp)) {
            Text("✦  01 / 05", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Huzurun\nRenkleri", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, lineHeight = 31.sp)
            Text("Doğanın büyüleyici tonları.", color = Color.White.copy(.9f), fontSize = 13.sp)
            Spacer(Modifier.height(13.dp))
            Surface(shape = RoundedCornerShape(20.dp), color = Color.White) {
                Text("Keşfet  →", color = Purple, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 17.dp, vertical = 9.dp))
            }
        }
        Surface(Modifier.align(Alignment.BottomEnd).padding(14.dp), shape = RoundedCornerShape(50),
            color = Color.Black.copy(.35f)) {
            Icon(Icons.Default.FavoriteBorder, null, tint = Color.White, modifier = Modifier.padding(10.dp))
        }
    }
}

@Composable
private fun MixedGrid() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            WallpaperCard("Sevimli Dostlar", R.drawable.wp_flower, "12.4K", 190, Modifier.weight(1f))
            WallpaperCard("Doğa", R.drawable.wp_mountain2, "8.7K", 250, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            WallpaperCard("Şehir", R.drawable.wp_city, "6.1K", 230, Modifier.weight(1f))
            WallpaperCard("Uzay", R.drawable.wp_space, "7.9K", 205, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            WallpaperCard("Araçlar", R.drawable.wp_car, "11.2K", 215, Modifier.weight(1f))
            WallpaperCard("Soyut", R.drawable.wp_abstract, "5.6K", 185, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            WallpaperCard("Deniz", R.drawable.wp_ocean, "9.3K", 235, Modifier.weight(1f))
            WallpaperCard("Çiçek", R.drawable.wp_flower, "4.8K", 200, Modifier.weight(1f))
        }
    }
}

@Composable
private fun WallpaperCard(title: String, image: Int, likes: String, height: Int, modifier: Modifier) {
    Box(modifier.height(height.dp).clip(RoundedCornerShape(22.dp))) {
        Image(painterResource(image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color.Transparent, Color(0xB0000000)))
        ))
        Icon(Icons.Default.FavoriteBorder, null, tint = Color.White,
            modifier = Modifier.align(Alignment.TopEnd).padding(11.dp))
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("♡ $likes", color = Color.White.copy(.9f), fontSize = 11.sp)
        }
    }
}

@Composable
private fun MiniFeature(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(Modifier.weight(1f), shape = RoundedCornerShape(20.dp), color = Color.White, shadowElevation = 1.dp) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFFEAE2FF)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Purple)
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold, color = TextMain)
                Text("Yeni bir dünya keşfet", fontSize = 10.sp, color = TextMuted)
            }
        }
    }
}

@Composable
private fun BottomNav(current: String, onSelect: (String) -> Unit) {
    val items = listOf(
        Triple("home", "Ana Sayfa", Icons.Default.Home),
        Triple("categories", "Kategoriler", Icons.Default.GridView),
        Triple("explore", "Keşfet", Icons.Default.Explore),
        Triple("profile", "Profil", Icons.Default.Person),
        Triple("settings", "Ayarlar", Icons.Default.Settings)
    )
    Surface(color = Color.White, shadowElevation = 8.dp) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceEvenly) {
            items.forEach { (id, label, icon) ->
                Column(Modifier.weight(1f).clickable { onSelect(id) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(icon, null, tint = if (current == id) Purple else Color(0xFF817AAB), modifier = Modifier.size(24.dp))
                    Text(label, fontSize = 10.sp, fontWeight = if (current == id) FontWeight.Bold else FontWeight.Normal,
                        color = if (current == id) Purple else TextMuted)
                }
            }
        }
    }
}

@Composable
private fun SimpleScreen(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        Text("WXTRA", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Purple)
        Spacer(Modifier.height(8.dp))
        Text(title, fontSize = 32.sp, fontWeight = FontWeight.Black, color = TextMain)
        Text(subtitle, fontSize = 14.sp, color = TextMuted, modifier = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(24.dp))
        Surface(Modifier.fillMaxWidth().height(260.dp), shape = RoundedCornerShape(28.dp), color = Color.White) {
            Box(contentAlignment = Alignment.Center) {
                Text("Bu bölüm bir sonraki aşamada\nayrıntılı olarak tasarlanacak.",
                    color = TextMuted, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    }
}

@Composable
private fun SettingsScreen(onAppearance: () -> Unit) {
    var notifications by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 20.dp)) {
        Text("WXTRA", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Purple)
        Text("A Y A R L A R", fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp, color = Purple)
        Spacer(Modifier.height(22.dp))
        SettingsCard(Icons.Default.Settings, "Görünüm", "Kart dizilimi ayarları", onClick = onAppearance)
        SettingsCard(Icons.Default.Notifications, "Bildirimler", "Bildirim tercihlerini yönet",
            trailing = { Switch(checked = notifications, onCheckedChange = { notifications = it }) })
        SettingsCard(Icons.Default.Language, "Dil", "Uygulama dilini seç", trailingText = "Türkçe")
        SettingsCard(Icons.Default.Security, "Gizlilik", "Gizlilik tercihlerini yönet")
        SettingsCard(Icons.Default.Description, "Kullanım Koşulları", "Koşulları görüntüle")
        SettingsCard(Icons.Default.Info, "Hakkında", "Uygulama hakkında bilgi")
        SettingsCard(Icons.Default.Tune, "Gelişmiş Özellikler", "Daha fazla seçenek")
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun AppearanceScreen(onBack: () -> Unit) {
    var layout by remember { mutableStateOf("Klasik") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri", tint = TextMain) }
            Column { Text("Görünüm", fontSize = 26.sp, fontWeight = FontWeight.Black, color = TextMain)
                Text("Kart dizilimi ayarları", fontSize = 13.sp, color = TextMuted) }
        }
        Column(Modifier.padding(horizontal = 18.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp))
            .background(Brush.verticalGradient(listOf(Color.White, Color(0xFFE9DEFF), Bg))).padding(20.dp)) {
            Text("Kart Dizilimi", fontSize = 22.sp, fontWeight = FontWeight.Black, color = TextMain)
            Text("Ana ekrandaki içeriklerin yerleşimini seç.", color = TextMuted)
            Spacer(Modifier.height(15.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LayoutOption("Klasik", layout == "Klasik") { layout = "Klasik" }
                LayoutOption("Kompakt", layout == "Kompakt") { layout = "Kompakt" }
                LayoutOption("Geniş", layout == "Geniş") { layout = "Geniş" }
            }
        }
    }
}

@Composable
private fun RowScope.LayoutOption(title: String, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.weight(1f).height(145.dp).clip(RoundedCornerShape(20.dp))
        .background(Color.White).border(2.dp, if (selected) Purple2 else Color.White, RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8E0FF)),
            contentAlignment = Alignment.Center) {
            if (title == "Klasik") Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { repeat(3) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { repeat(2) {
                    Box(Modifier.size(24.dp, 15.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFFB9A8F8)))
                }}
            }} else if (title == "Kompakt") Column(verticalArrangement = Arrangement.spacedBy(5.dp)) { repeat(4) {
                Box(Modifier.size(62.dp, 11.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFFB9A8F8)))
            }} else Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Box(Modifier.size(65.dp, 27.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFFB9A8F8)))
                Box(Modifier.size(65.dp, 19.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFFB9A8F8)))
            }
        }
        Text(title, fontWeight = FontWeight.Bold, color = TextMain, modifier = Modifier.padding(top = 9.dp))
        if (selected) Icon(Icons.Default.CheckCircle, null, tint = Purple, modifier = Modifier.size(19.dp))
    }
}

@Composable
private fun SettingsCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, description: String,
    trailingText: String? = null, trailing: (@Composable () -> Unit)? = null, onClick: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 9.dp).clip(RoundedCornerShape(20.dp)).background(Card)
        .border(1.dp, Color.White, RoundedCornerShape(20.dp))
        .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(50.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFFE6DDFF)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(25.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextMain)
            Text(description, fontSize = 12.sp, color = TextMuted)
        }
        if (trailing != null) trailing() else if (trailingText != null) Text(trailingText, color = TextMuted, fontSize = 13.sp)
        else Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
    }
}
