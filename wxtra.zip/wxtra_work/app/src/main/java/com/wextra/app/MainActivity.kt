package com.wextra.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF6336E8)
private val Purple2 = Color(0xFF9A68FF)
private val Blue = Color(0xFF4A8DF8)
private val Bg = Color(0xFFF5F1FF)
private val TextMain = Color(0xFF15142A)
private val TextMuted = Color(0xFF5E5A78)
private val Card = Color(0xFFFDFCFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAApp() }
    }
}

@Composable
private fun WXTRAApp() {
    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, secondary = Blue)) {
        Surface(Modifier.fillMaxSize(), color = Bg) { SettingsApp() }
    }
}

@Composable
private fun SettingsApp() {
    var page by remember { mutableStateOf("settings") }
    if (page == "appearance") {
        AppearanceScreen(onBack = { page = "settings" })
    } else {
        SettingsScreen(onAppearance = { page = "appearance" })
    }
}

@Composable
private fun SettingsScreen(onAppearance: () -> Unit) {
    var notifications by remember { mutableStateOf(true) }
    val scroll = rememberScrollState()

    Column(
        Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 18.dp, vertical = 20.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("WXTRA", fontSize = 34.sp, fontWeight = FontWeight.Black,
                    color = Purple)
                Text("A Y A R L A R", fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    letterSpacing = 4.sp, color = Purple)
                Text("DAHA FAZLA GÖR  •  DAHA FAZLA HİSSET", fontSize = 10.sp,
                    letterSpacing = 1.4.sp, color = TextMuted, modifier = Modifier.padding(top = 5.dp))
            }
            Box(
                Modifier.size(76.dp).clip(RoundedCornerShape(24.dp)).background(
                    Brush.linearGradient(listOf(Color.White, Color(0xFFE8DEFF)))
                ).border(1.dp, Color.White, RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("W", fontSize = 48.sp, fontWeight = FontWeight.Black, color = Purple2)
            }
        }

        Spacer(Modifier.height(22.dp))
        SettingsCard(
            icon = Icons.Default.Settings,
            title = "Görünüm",
            description = "Kart dizilimi ayarları",
            onClick = onAppearance
        )
        SettingsCard(
            icon = Icons.Default.Notifications,
            title = "Bildirimler",
            description = "Bildirim tercihlerini yönet",
            trailing = { Switch(checked = notifications, onCheckedChange = { notifications = it }) }
        )
        SettingsCard(Icons.Default.Language, "Dil", "Uygulama dilini seç", trailingText = "Türkçe")
        SettingsCard(Icons.Default.Security, "Gizlilik", "Gizlilik tercihlerini yönet")
        SettingsCard(Icons.Default.Description, "Kullanım Koşulları", "Koşulları görüntüle")
        SettingsCard(Icons.Default.Info, "Hakkında", "Uygulama hakkında bilgi")
        SettingsCard(Icons.Default.Tune, "Gelişmiş Özellikler", "Daha fazla seçenek")

        Spacer(Modifier.height(10.dp))
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(
                Brush.linearGradient(listOf(Color.White, Color(0xFFE9DEFF), Color(0xFFFDFCFF)))
            ).border(1.dp, Color.White, RoundedCornerShape(24.dp)).padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).clip(RoundedCornerShape(17.dp)).background(Color.White), contentAlignment = Alignment.Center) {
                    Text("W", fontSize = 36.sp, fontWeight = FontWeight.Black, color = Purple2)
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("WXTRA", fontSize = 19.sp, fontWeight = FontWeight.Black, color = TextMain)
                    Text("Sürüm 1.0.0", fontSize = 13.sp, color = TextMuted)
                    Text("Daha fazla gör, daha fazla hisset.", fontSize = 12.sp, color = TextMuted,
                        modifier = Modifier.padding(top = 3.dp))
                }
            }
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun AppearanceScreen(onBack: () -> Unit) {
    var layout by remember { mutableStateOf("Klasik") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri", tint = TextMain) }
            Column(Modifier.padding(start = 4.dp)) {
                Text("Görünüm", fontSize = 26.sp, fontWeight = FontWeight.Black, color = TextMain)
                Text("Kart dizilimi ayarları", fontSize = 13.sp, color = TextMuted)
            }
        }
        Box(Modifier.padding(horizontal = 18.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(
            Brush.verticalGradient(listOf(Color.White, Color(0xFFE9DEFF), Bg))
        ).padding(20.dp)) {
            Column {
                Text("Görünüm", fontSize = 30.sp, fontWeight = FontWeight.Black, color = TextMain)
                Text("Ana ekrandaki içeriklerin kart yapısını seç", color = TextMuted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 22.dp))
                Text("Kart Dizilimi", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = TextMain)
                Text("İçeriklerin ekranda nasıl yerleşeceğini belirle", fontSize = 13.sp, color = TextMuted)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LayoutOption("Klasik", "Dengeli görünüm", layout == "Klasik") { layout = "Klasik" }
                    LayoutOption("Kompakt", "Daha fazla içerik", layout == "Kompakt") { layout = "Kompakt" }
                    LayoutOption("Geniş", "Büyük önizleme", layout == "Geniş") { layout = "Geniş" }
                }
                Spacer(Modifier.height(18.dp))
                Surface(shape = RoundedCornerShape(18.dp), color = Color.White.copy(alpha = .72f)) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, null, tint = Blue, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(12.dp))
                        Text("Seçilen kart dizilimi içeriklerin ana ekrandaki görünümünü belirler.", fontSize = 13.sp, color = TextMuted)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun RowScope.LayoutOption(title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).height(165.dp).clip(RoundedCornerShape(20.dp))
            .background(if (selected) Color.White else Color.White.copy(alpha = .68f))
            .border(2.dp, if (selected) Purple2 else Color.White, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth().height(86.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8E0FF)), contentAlignment = Alignment.Center) {
            if (title == "Klasik") {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) { repeat(3) { Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { repeat(2) { Box(Modifier.size(25.dp, 16.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFFB9A8F8))) } } } }
            } else if (title == "Kompakt") {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) { repeat(4) { Box(Modifier.size(66.dp, 12.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFFB9A8F8))) } }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) { Box(Modifier.size(68.dp, 29.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFFB9A8F8))); Box(Modifier.size(68.dp, 20.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFFB9A8F8))) }
            }
        }
        Text(title, fontWeight = FontWeight.Bold, color = TextMain, modifier = Modifier.padding(top = 10.dp))
        Text(subtitle, fontSize = 11.sp, color = TextMuted)
        if (selected) Icon(Icons.Default.CheckCircle, null, tint = Purple, modifier = Modifier.size(20.dp).padding(top = 2.dp))
    }
}

@Composable
private fun SettingsCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    trailingText: String? = null,
    trailing: (@Composable () -> Unit)? = null,
    onClick: (() -> Unit)? = null
) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 9.dp).clip(RoundedCornerShape(20.dp))
            .background(Card.copy(alpha = .92f)).border(1.dp, Color.White, RoundedCornerShape(20.dp))
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(14.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(50.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFFE6DDFF)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(25.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextMain)
            Text(description, fontSize = 12.sp, color = TextMuted, modifier = Modifier.padding(top = 2.dp))
        }
        if (trailing != null) trailing() else if (trailingText != null) Text(trailingText, color = TextMuted, fontSize = 13.sp) else Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
    }
}
