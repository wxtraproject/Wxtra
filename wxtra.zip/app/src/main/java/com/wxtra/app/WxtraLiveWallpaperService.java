package com.wxtra.app;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

public class WxtraLiveWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine(){ return new WxtraEngine(); }
    class WxtraEngine extends Engine {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); Handler h=new Handler(); float phase=0; boolean visible=true;
        Runnable draw=new Runnable(){public void run(){drawFrame();}};
        @Override public void onVisibilityChanged(boolean v){visible=v;if(v)drawFrame();else h.removeCallbacksAndMessages(null);}
        void drawFrame(){ if(!visible)return; SurfaceHolder sh=getSurfaceHolder(); Canvas c=null; try{c=sh.lockCanvas(); if(c!=null){int w=c.getWidth(),hh=c.getHeight();
                    for(int y=0;y<hh;y++){float t=y/(float)hh; int r=(int)(8+12*t),g=(int)(16+28*t),b=(int)(48+60*t);p.setColor(Color.rgb(r,g,b));c.drawRect(0,y,w,y+1,p);}
                    p.setColor(Color.rgb(210,225,255));c.drawCircle(w*0.72f,hh*0.23f,hh*0.09f,p);
                    p.setColor(Color.rgb(16,22,42));c.drawCircle(w*0.72f+hh*0.025f,hh*0.23f-hh*0.01f,hh*0.09f,p);
                    p.setColor(Color.rgb(40,130,255));for(int i=0;i<34;i++){float x=(i*83+phase*1.7f)%w;float y=(i*137)%hh; c.drawCircle(x,y,2.2f,p);} 
                    p.setColor(Color.rgb(12,15,28)); c.drawRect(0,hh*0.76f,w,hh,p); p.setColor(Color.rgb(255,40,90)); c.drawRoundRect(w*0.37f,hh*0.70f,w*0.63f,hh*0.80f,22,22,p);
                }} finally{if(c!=null)sh.unlockCanvasAndPost(c);} phase=(phase+1)%1000; h.removeCallbacks(draw);h.postDelayed(draw,45); }
        @Override public void onSurfaceDestroyed(SurfaceHolder hld){visible=false;h.removeCallbacksAndMessages(null);super.onSurfaceDestroyed(hld);}
        @Override public void onSurfaceChanged(SurfaceHolder hld,int format,int w,int hh){drawFrame();}
    }
}
