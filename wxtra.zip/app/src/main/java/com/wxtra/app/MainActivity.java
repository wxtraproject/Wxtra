package com.wxtra.app;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ContentValues;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    WxtraView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(248,249,253));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        view = new WxtraView(this);
        setContentView(view);
    }

    public void applyStatic(int resId) {
        try {
            WallpaperManager.getInstance(this).setResource(resId);
            Toast.makeText(this, "Duvar kağıdı uygulandı ✓", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Duvar kağıdı uygulanamadı", Toast.LENGTH_SHORT).show();
        }
    }

    public void openLive() {
        try {
            Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(this, WxtraLiveWallpaperService.class));
            startActivity(i);
        } catch (Exception e) {
            try { startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)); }
            catch (Exception ignored) { Toast.makeText(this, "Canlı duvar kağıdı desteklenmiyor", Toast.LENGTH_SHORT).show(); }
        }
    }

    public void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, 1001);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            view.selectedUri = data.getData();
            view.page = WxtraView.EDITOR;
            view.invalidate();
        }
    }

    public void downloadStatic(int resId, String title) {
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), resId);
        if (bitmap == null) return;
        try {
            String safe = title.replaceAll("[^a-zA-Z0-9_-]", "_");
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "WXTRA_" + safe + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/WXTRA");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("uri");
            OutputStream out = getContentResolver().openOutputStream(uri);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out);
            if (out != null) out.close();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
            }
            Toast.makeText(this, "Galerine kaydedildi ✓", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "İndirme başarısız oldu", Toast.LENGTH_SHORT).show();
        }
    }

    public void shareWallpaper(int resId, String title) {
        try {
            Bitmap b = BitmapFactory.decodeResource(getResources(), resId);
            String path = MediaStore.Images.Media.insertImage(getContentResolver(), b, "WXTRA " + title, "WXTRA wallpaper");
            if (path == null) throw new Exception();
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("image/*");
            send.putExtra(Intent.EXTRA_STREAM, Uri.parse(path));
            startActivity(Intent.createChooser(send, "WXTRA ile paylaş"));
        } catch (Exception e) {
            Toast.makeText(this, "Paylaşım başlatılamadı", Toast.LENGTH_SHORT).show();
        }
    }

    static class Item {
        String title, category;
        int img;
        boolean live;
        Item(String t, String c, int i, boolean l) { title=t; category=c; img=i; live=l; }
    }

    public class WxtraView extends View {
        final float density = getResources().getDisplayMetrics().density;
        float W(){ return getWidth()/density; }
        float H(){ return getHeight()/density; }
        static final int SPLASH=0, HOME=1, EXPLORE=2, DETAIL=3, LIVE=4, AI=5, EDITOR=6,
                DYNAMIC=7, COLLECTIONS=8, FAVORITES=9, PROFILE=10, PREMIUM=11;

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int page = SPLASH, selected = 0, activeCategory = 0;
        boolean side = false;
        Uri selectedUri;
        float downX, downY;
        int blue=Color.rgb(54,105,244), purple=Color.rgb(143,75,225);
        int text=Color.rgb(20,26,49), muted=Color.rgb(103,111,136), bg=Color.rgb(248,250,253);
        Bitmap[] imgs = new Bitmap[8];
        List<Item> items = new ArrayList<>();
        Set<Integer> favorites = new HashSet<>();
        String[] names={"Serenity","Night Drive","Moon Forest","Aurora Dream","Wild Mountain","Neon Pulse","Deep Space","Luxury Dark"};
        int[] res={R.drawable.wall_mountain,R.drawable.wall_neon,R.drawable.wall_forest,R.drawable.wall_aurora,
                R.drawable.wall_ocean,R.drawable.wall_anime,R.drawable.wall_space,R.drawable.wall_luxury};
        String[] cats={"Tümü","Canlı","4K/8K","Minimal","Anime","Doğa","Uzay","Arabalar"};

        public WxtraView(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            for(int i=0;i<8;i++) imgs[i]=BitmapFactory.decodeResource(getResources(),res[i]);
            items.add(new Item(names[0],"Doğa",res[0],true));
            items.add(new Item(names[1],"Arabalar",res[1],true));
            items.add(new Item(names[2],"Doğa",res[2],true));
            items.add(new Item(names[3],"Minimal",res[3],true));
            items.add(new Item(names[4],"4K/8K",res[4],false));
            items.add(new Item(names[5],"Anime",res[5],true));
            items.add(new Item(names[6],"Uzay",res[6],false));
            items.add(new Item(names[7],"Luxury",res[7],false));
        }

        void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){
            p.setColor(color); p.setTextSize(size); p.setTypeface(bold ? android.graphics.Typeface.DEFAULT_BOLD : android.graphics.Typeface.DEFAULT);
            p.setStyle(Paint.Style.FILL); c.drawText(s,x,y,p);
        }
        void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(l,t,r,b),rad,rad,p);}
        void image(Canvas c, Bitmap b, RectF r){ if(b!=null)c.drawBitmap(b,null,r,p); }
        void header(Canvas c,String title,String sub){
            text(c,"☰",20,42,22,text,false); text(c,title,56,40,25,text,true);
            if(sub!=null) text(c,sub,56,61,11,muted,false);
        }
        void nav(Canvas c,int active){
            float y=H()-74; p.setColor(Color.WHITE); c.drawRect(0,y,W(),H(),p);
            String[] a={"⌂","⌕","✦","♡","◉"}; String[] b={"Ana Sayfa","Keşfet","AI","Favoriler","Profil"};
            for(int i=0;i<5;i++){float x=(i+.5f)*W()/5f;int col=i==active?blue:muted;text(c,a[i],x-9,y+27,21,col,true);text(c,b[i],x-28,y+49,9,col,false);}
        }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            c.save();
            c.scale(density, density);
            c.drawColor(bg);
            if(page==SPLASH) drawSplash(c); else if(page==HOME) drawHome(c); else if(page==EXPLORE) drawExplore(c);
            else if(page==DETAIL) drawDetail(c); else if(page==LIVE) drawLive(c); else if(page==AI) drawAI(c); else if(page==EDITOR) drawEditor(c);
            else if(page==DYNAMIC) drawDynamic(c); else if(page==COLLECTIONS) drawCollections(c); else if(page==FAVORITES) drawFavorites(c);
            else if(page==PROFILE) drawProfile(c); else if(page==PREMIUM) drawPremium(c); else drawHome(c);
            if(side && page!=SPLASH) drawSide(c);
            c.restore();
        }

        void drawSplash(Canvas c){
            // Clean onboarding screen
            text(c,"W",W()/2-48,245,78,purple,true);
            text(c,"XTRA",W()/2-4,245,44,text,true);
            text(c,"Senin duvarın. Senin hikayen.",W()/2-105,277,12,muted,false);
            round(c,26,430,W()-26,484,28,blue);
            text(c,"Keşfetmeye Başla  →",W()/2-78,464,14,Color.WHITE,true);
            text(c,"4K/8K   •   CANLI   •   AI   •   DİNAMİK",W()/2-122,518,9,muted,true);
        }

        void drawHome(Canvas c){
            // Premium WXTRA home — designed in dp so it scales correctly on every phone.
            text(c,"Günaydın 👋",20,34,24,text,true);
            text(c,"⌕",W()-82,35,25,text,false);
            text(c,"◉",W()-43,34,20,text,false);

            round(c,18,50,W()-18,96,23,Color.WHITE);
            text(c,"⌕",31,79,18,muted,true);
            text(c,"Duvar kağıdı ara...",55,78,12,muted,false);

            String[] chip={"🔥 Popüler","✦ Canlı","AI","4K/8K","✦ Yeni"};
            float[] cw={76,65,48,68,61};
            float cx=18;
            for(int i=0;i<chip.length;i++){
                round(c,cx,108,cx+cw[i],141,17,i==0?Color.rgb(255,243,220):Color.WHITE);
                text(c,chip[i],cx+10,130,9,i==0?Color.rgb(210,123,24):muted,true);
                cx+=cw[i]+7;
            }

            // Hero card
            float heroTop=157, heroBottom=335;
            round(c,18,heroTop,W()-18,heroBottom,24,Color.rgb(21,25,48));
            image(c,imgs[1],new RectF(18,heroTop,W()-18,heroBottom));
            round(c,18,heroTop+92,W()-18,heroBottom,24,Color.argb(165,5,8,20));
            text(c,"GÜNÜN ÖNE ÇIKANI",36,heroTop+119,10,Color.rgb(202,205,255),true);
            text(c,"Neon Gece",36,heroTop+145,22,Color.WHITE,true);
            text(c,"Sınırlı sayıda canlı deneyim",36,heroTop+162,10,Color.WHITE,false);
            round(c,36,heroTop+137,W()/2,heroTop+171,17,Color.WHITE);
            text(c,"Keşfet  →",52,heroTop+159,11,text,true);

            text(c,"Senin için",18,369,20,text,true);
            text(c,"Tümü  ›",W()-54,369,10,blue,true);

            // Horizontal recommendation cards
            float cardW=(W()-56)/3f;
            for(int i=0;i<3;i++){
                float x=18+i*(cardW+10);
                round(c,x,383,x+cardW,505,18,Color.WHITE);
                image(c,imgs[(i+3)%8],new RectF(x,383,x+cardW,505));
                round(c,x+7,391,x+48,414,11,Color.argb(190,20,24,40));
                text(c,items.get((i+3)%8).live?"LIVE":"4K",x+15,407,8,Color.WHITE,true);
                text(c,"♡",x+cardW-25,410,18,Color.WHITE,true);
            }

            // Daily mode card
            round(c,18,523,W()-18,587,20,Color.WHITE);
            round(c,29,535,59,565,15,Color.rgb(239,243,255));
            text(c,"✦",37,558,17,blue,true);
            text(c,"Bugünün modu",72,549,12,text,true);
            text(c,"Ruh haline göre duvar kağıtları keşfet",72,568,9,muted,false);
            text(c,"›",W()-39,559,20,muted,false);

            nav(c,0);
        }

        void drawExplore(Canvas c){
            header(c,"Keşfet","Kategorilerle sınırsız keşif.");
            float x=20; for(int i=0;i<cats.length;i++){float w=p.measureText(cats[i])+25;round(c,x,82,x+w,116,17,i==activeCategory?blue:Color.WHITE);text(c,cats[i],x+10,104,10,i==activeCategory?Color.WHITE:muted,true);x+=w+7;if(x>W()-90){break;}}
            int top=130; for(int r=0;r<3;r++)for(int col=0;col<2;col++){int idx=(r*2+col)%8;float left=18+col*(W()-43)/2f;float w=(W()-55)/2f;float y=top+r*170;round(c,left,y,left+w,y+148,18,Color.WHITE);image(c,imgs[idx],new RectF(left,y,left+w,y+148));if(items.get(idx).live){round(c,left+8,y+8,left+50,y+31,12,Color.argb(215,255,255,255));text(c,"LIVE",left+17,y+24,9,Color.rgb(221,48,104),true);}if(favorites.contains(idx))text(c,"♥",left+w-31,y+29,20,Color.rgb(235,65,105),true);else text(c,"♡",left+w-31,y+29,20,Color.WHITE,true);}
            nav(c,1);
        }

        void drawDetail(Canvas c){
            text(c,"‹",18,43,34,text,false); text(c,items.get(selected).title,60,40,22,text,true);text(c,favorites.contains(selected)?"♥":"♡",W()-58,41,28,Color.rgb(230,74,112),true);
            image(c,imgs[selected],new RectF(14,67,W()-14,414));
            round(c,24,350,W()-24,485,25,Color.WHITE); text(c,items.get(selected).title,46,381,23,text,true);text(c,(items.get(selected).live?"Canlı":"Statik")+"   •   4K   •   28.7 MB",46,405,11,muted,false);text(c,"@wxtra  ·  Wallpaper Creator",46,431,11,text,true);
            text(c,"♡ 12.4K",46,458,11,muted,false);text(c,"⇩ 3.2K",135,458,11,muted,false);text(c,"↗ Paylaş",220,458,11,muted,false);
            round(c,22,510,(W()-30)/2f,565,20,Color.WHITE);text(c,"Önizle",54,545,14,text,true);
            round(c,(W()+8)/2f,510,W()-22,565,20,blue);text(c,items.get(selected).live?"Canlı Uygula":"Duvar Kağıdı Yap",(W()+20)/2f,545,11,Color.WHITE,true);
            round(c,22,578,(W()-30)/2f,628,18,Color.WHITE);text(c,"⇩  İndir",48,610,13,text,true);
            round(c,(W()+8)/2f,578,W()-22,628,18,Color.WHITE);text(c,"↗  Paylaş",(W()+30)/2f,610,13,text,true);
            nav(c,1);
        }

        void drawLive(Canvas c){
            text(c,"‹",18,43,34,text,false); text(c,"Canlı Önizleme",60,40,22,text,true);
            round(c,24,70,W()-24,435,28,Color.BLACK);image(c,imgs[selected],new RectF(40,90,W()-40,418));
            text(c,"9:41",W()/2-35,218,34,Color.WHITE,true);text(c,"Pazartesi, 2 Eylül",W()/2-53,240,11,Color.WHITE,false);
            round(c,18,458,W()-18,640,24,Color.WHITE);text(c,"Hareket",38,490,13,text,true);text(c,"Parçacık",38,530,11,muted,false);text(c,"●",W()-57,530,19,blue,true);text(c,"Derinlik",38,563,11,muted,false);text(c,"●",W()-57,563,19,blue,true);text(c,"Pil Dostu Mod",38,596,11,muted,false);text(c,"●",W()-57,596,19,blue,true);
            round(c,26,662,W()-26,716,22,purple);text(c,"Canlı Duvar Kağıdını Uygula",W()/2-94,696,13,Color.WHITE,true);
        }

        void drawAI(Canvas c){
            header(c,"AI Studio","Hayal et, WXTRA oluştursun.");
            round(c,20,82,W()-20,177,22,Color.WHITE);text(c,"Hayalindeki duvar kağıdını tarif et...",38,111,13,muted,false);text(c,"Gece İstanbul, yağmur, neon ışıklar, sinematik",38,136,10,muted,false);
            String[] s={"Sinematik","Anime","Minimal","Doğa"};for(int i=0;i<4;i++){round(c,20+i*91,192,103+i*91,226,17,i==0?blue:Color.WHITE);text(c,s[i],31+i*91,214,9,i==0?Color.WHITE:text,true);}
            round(c,20,245,W()-20,300,22,blue);text(c,"Oluştur  ✦",W()/2-40,279,14,Color.WHITE,true);
            text(c,"Örnekler",20,337,19,text,true);for(int i=0;i<4;i++)image(c,imgs[i],new RectF(20+i*92,353,104+i*92,442));
            round(c,20,468,W()-20,522,20,Color.WHITE);text(c,"▣  Görselden oluştur",38,502,13,text,true);
            round(c,20,542,W()-20,598,20,Color.WHITE);text(c,"⚡  AI + Canlı hareket",38,576,13,text,true);
        }

        void drawEditor(Canvas c){
            header(c,"Düzenle","Hazır görseli bile kişiselleştir.");round(c,24,82,W()-24,420,24,Color.WHITE);
            if(selectedUri==null)image(c,imgs[selected],new RectF(42,99,W()-42,402)); else try{Bitmap b=BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedUri));image(c,b,new RectF(42,99,W()-42,402));}catch(Exception ignored){}
            String[] a={"Kırp","Renk","Efekt","Metin","Işık"};for(int i=0;i<5;i++){text(c,a[i],28+i*70,466,10,text,true);}
            round(c,24,495,W()-24,548,20,blue);text(c,"Kaydet",W()/2-25,529,14,Color.WHITE,true);
            round(c,24,565,W()-24,618,20,Color.WHITE);text(c,"✦  Canlıya dönüştür",38,599,13,text,true);
        }

        void drawDynamic(Canvas c){
            header(c,"Dinamik Duvar Kağıtları","Zamana, havaya ve duruma göre.");
            String[] rows={"Günün Saatine Göre","Hava Durumuna Göre","Şarj Durumuna Göre","Konuma Göre","Otomatik Rotasyon"};String[] sub={"Sabah, öğlen, akşam, gece","Yağmur, kar, güneş...","Düşük bataryada sade mod","Bulunduğun şehre özel","Belirli aralıklarla değiştir"};
            for(int i=0;i<5;i++){float y=88+i*77;round(c,20,y,W()-20,y+61,18,Color.WHITE);text(c,i==0?"☀":i==1?"☁":i==2?"▣":i==3?"⌖":"↻",34,y+37,20,blue,true);text(c,rows[i],70,y+25,12,text,true);text(c,sub[i],70,y+44,9,muted,false);text(c,"●",W()-55,y+36,18,blue,true);}
            round(c,20,495,W()-20,550,20,blue);text(c,"Dinamiği Uygula",W()/2-50,529,14,Color.WHITE,true);
        }

        void drawCollections(Canvas c){
            header(c,"Koleksiyonlar","Özenle hazırlanmış temalar.");String[] n={"Cyber City","Nature","Minimal","Anime","Luxury"};int[] ii={1,0,7,5,7};
            for(int i=0;i<5;i++){float y=83+i*101;round(c,20,y,W()-20,y+86,20,Color.WHITE);image(c,imgs[ii[i]],new RectF(20,y,W()-20,y+86));round(c,20,y,W()-20,y+86,20,Color.argb(65,0,0,0));text(c,n[i],38,y+39,16,Color.WHITE,true);text(c,(128+i*64)+" Duvar Kağıdı",38,y+60,9,Color.WHITE,false);}nav(c,1);
        }

        void drawFavorites(Canvas c){
            header(c,"Favoriler","Beğendiklerin her zaman yanında.");
            if(favorites.isEmpty()){text(c,"Henüz favorin yok",W()/2-67,220,16,text,true);text(c,"Keşfet'ten kalp ikonuna dokun.",W()/2-92,246,11,muted,false);}else{int pos=0;for(Integer idx:favorites){int col=pos%3,row=pos/3;float x=20+col*118,y=90+row*158;round(c,x,y,x+106,y+140,18,Color.WHITE);image(c,imgs[idx],new RectF(x,y,x+106,y+140));text(c,"♥",x+77,y+29,20,Color.rgb(235,65,105),true);pos++;if(pos>=9)break;}}
            nav(c,3);
        }

        void drawProfile(Canvas c){
            header(c,"Profil","Kendi dünyanı oluştur, paylaş.");round(c,20,82,W()-20,184,24,Color.WHITE);text(c,"wextra ✓",42,119,21,text,true);text(c,"Wallpaper Creator",42,141,11,muted,false);text(c,"128     12.4K     3",42,168,14,text,true);text(c,"Duvar Kağıdı     Takipçi     Koleksiyon",42,181,8,muted,false);
            String[] m={"＋  Wallpaper yükle","Paylaşımlarım","İstatistikler","Koleksiyonlarım","İndirilenler","Ayarlar"};for(int i=0;i<m.length;i++){float y=213+i*51;round(c,20,y,W()-20,y+42,17,Color.WHITE);text(c,m[i],42,y+27,12,text,true);text(c,"›",W()-47,y+27,17,muted,true);}nav(c,4);
        }

        void drawPremium(Canvas c){
            text(c,"‹",18,43,34,text,false);text(c,"Premium",58,40,26,text,true);round(c,20,78,W()-20,221,26,Color.rgb(24,29,52));text(c,"WXTRA PREMIUM",43,117,23,Color.WHITE,true);text(c,"Reklamsız. Sınırsız. Daha özel.",43,144,12,Color.WHITE,false);round(c,43,169,W()-43,210,21,Color.WHITE);text(c,"Premium'a Geç  →",88,195,13,text,true);
            text(c,"Premium ile açılanlar",20,270,19,text,true);String[] a={"4K/8K Ultra Kalite","Sınırsız canlı wallpaper","AI Studio üretimleri","Özel koleksiyonlar","Gelişmiş kişiselleştirme","Öncelikli yeni içerikler"};for(int i=0;i<a.length;i++){text(c,"✓",27,312+i*45,16,blue,true);text(c,a[i],53,312+i*45,13,text,true);}
        }

        void drawSide(Canvas c){
            round(c,0,0,W()*0.84f,H(),0,Color.WHITE);text(c,"W",25,61,40,purple,true);text(c,"XTRA",66,59,23,text,true);text(c,"Senin duvarın. Senin hikayen.",25,80,9,muted,false);
            String[] m={"Ana Sayfa","Keşfet","AI Studio","Koleksiyonlar","Dinamik Duvar Kağıtları","Favoriler","Profil","Premium","Ayarlar"};
            int[] pg={HOME,EXPLORE,AI,COLLECTIONS,DYNAMIC,FAVORITES,PROFILE,PREMIUM,PROFILE};
            for(int i=0;i<m.length;i++){float y=124+i*45;text(c,m[i],35,y,13,page==pg[i]?blue:text,true);}
            round(c,22,H()-106,W()*0.84f-22,H()-55,20,Color.rgb(246,240,255));text(c,"♛  Premium'a Geç",40,H()-75,12,purple,true);
        }

        void go(int target){page=target;side=false;invalidate();}
        void toggleFavorite(){if(favorites.contains(selected))favorites.remove(selected);else favorites.add(selected);invalidate();}

        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();return true;}
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            float x=e.getX()/density,y=e.getY()/density;

            if(side){
                if(x<W()*0.84f){
                    if(y>95&&y<145)go(HOME);else if(y<190)go(EXPLORE);else if(y<235)go(AI);else if(y<280)go(COLLECTIONS);else if(y<325)go(DYNAMIC);else if(y<370)go(FAVORITES);else if(y<415)go(PROFILE);else if(y<460)go(PREMIUM);
                    else {side=false;invalidate();}
                } else {side=false;invalidate();}
                return true;
            }

            if(page==SPLASH){if(y>390)go(HOME);return true;}
            if(y<65&&x<55){side=true;invalidate();return true;}
            if(y>H()-90 && page!=LIVE && page!=PREMIUM){int n=(int)(x/(W()/5f));go(n==0?HOME:n==1?EXPLORE:n==2?AI:n==3?FAVORITES:PROFILE);return true;}

            if(page==HOME){
                if(y>165&&y<360){selected=1;go(DETAIL);} else if(y>390&&y<520){selected=(int)Math.min(7,3+(x/118));go(DETAIL);} else if(y>520){go(DYNAMIC);} else if(y>105&&y<160&&x>85&&x<180)go(EXPLORE);
            } else if(page==EXPLORE){
                if(y>125&&y<650){int row=(int)((y-130)/170),col=x>W()/2?1:0;selected=Math.max(0,Math.min(7,row*2+col));go(DETAIL);} else if(y<120){activeCategory=0;invalidate();}
            } else if(page==DETAIL){
                if(y<65&&x>W()-90){toggleFavorite();}
                else if(y>500&&y<570&&x<W()/2f){go(LIVE);}
                else if(y>500&&y<570&&x>=W()/2f){if(items.get(selected).live)go(LIVE);else applyStatic(items.get(selected).img);}
                else if(y>570&&y<640&&x<W()/2f){downloadStatic(items.get(selected).img,items.get(selected).title);}
                else if(y>570&&y<640){shareWallpaper(items.get(selected).img,items.get(selected).title);}
                else if(y>65&&y<500&&x>W()-80){toggleFavorite();}
            } else if(page==LIVE){if(y>645)openLive();}
            else if(page==AI){if(y>235&&y<310){selected=3;go(DETAIL);}else if(y>450&&y<535){pickImage();}}
            else if(page==EDITOR){if(y>480&&y<555)Toast.makeText(getContext(),"Düzenleme kaydedildi ✓",Toast.LENGTH_SHORT).show();else if(y>555&&y<630)Toast.makeText(getContext(),"Canlı efekt hazırlandı ✓",Toast.LENGTH_SHORT).show();}
            else if(page==DYNAMIC){if(y>480&&y<570)Toast.makeText(getContext(),"Dinamik wallpaper ayarlandı ✓",Toast.LENGTH_SHORT).show();}
            else if(page==COLLECTIONS){if(y>75&&y<600){selected=Math.max(0,Math.min(7,(int)((y-83)/101)));go(EXPLORE);}}
            else if(page==FAVORITES){if(y>75&&y<650&&!favorites.isEmpty()){int pos=(int)((y-90)/158)*3+(int)(x/118);int[] f=new int[favorites.size()];int k=0;for(Integer v:favorites)f[k++]=v;if(pos>=0&&pos<f.length){selected=f[pos];go(DETAIL);}}}
            else if(page==PROFILE){if(y>205&&y<265)pickImage();}
            else if(page==PREMIUM){if(y>155&&y<225)Toast.makeText(getContext(),"Premium ekranı hazır — ödeme bağlantısı sonraki aşamada.",Toast.LENGTH_SHORT).show();}
            invalidate();return true;
        }
    }
}
