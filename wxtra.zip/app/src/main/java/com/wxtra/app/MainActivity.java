package com.wxtra.app;

import android.app.*;
import android.app.WallpaperManager;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;

public class MainActivity extends Activity {
    WxtraView view;
    static final int PICK_IMAGE = 1001;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        view = new WxtraView(this);
        setContentView(view);
    }

    @Override public void onBackPressed() {
        if (view != null && view.goBack()) return;
        super.onBackPressed();
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    void applyStatic(int resId, boolean lock) {
        try {
            WallpaperManager wm = WallpaperManager.getInstance(this);
            if (Build.VERSION.SDK_INT >= 24) wm.setResource(resId, lock ? WallpaperManager.FLAG_LOCK : WallpaperManager.FLAG_SYSTEM);
            else wm.setResource(resId);
            toast(lock ? "Kilit ekranına uygulandı ✓" : "Ana ekrana uygulandı ✓");
        } catch (Exception e) { toast("Duvar kağıdı uygulanamadı"); }
    }

    void chooseStaticTarget() {
        final String[] options = {"Ana ekran", "Kilit ekranı", "İkisi de"};
        new AlertDialog.Builder(this).setTitle("Nereye uygulansın?").setItems(options, (d, which) -> {
            if (which == 0) applyStatic(view.items.get(view.selected).img, false);
            else if (which == 1) applyStatic(view.items.get(view.selected).img, true);
            else {
                applyStatic(view.items.get(view.selected).img, false);
                if (Build.VERSION.SDK_INT >= 24) applyStatic(view.items.get(view.selected).img, true);
            }
        }).show();
    }

    void openLive() {
        try {
            Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, new ComponentName(this, WxtraLiveWallpaperService.class));
            startActivity(i);
        } catch (Exception e) {
            try { startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)); }
            catch (Exception ignored) { toast("Canlı duvar kağıdı desteklenmiyor"); }
        }
    }

    void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_IMAGE);
    }

    void searchDialog() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("neon, doğa, anime...");
        new AlertDialog.Builder(this).setTitle("WXTRA'da ara").setView(input)
                .setNegativeButton("İptal", null)
                .setPositiveButton("Ara", (d, w) -> { view.query = input.getText().toString().trim(); view.page = WxtraView.EXPLORE; view.scroll = 0; view.invalidate(); })
                .show();
        input.requestFocus();
        input.postDelayed(() -> ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(input, InputMethodManager.SHOW_IMPLICIT), 200);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try { getContentResolver().takePersistableUriPermission(data.getData(), Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            view.selectedUri = data.getData();
            view.push(WxtraView.EDITOR);
        }
    }

    void downloadStatic(int resId, String title) {
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), resId);
        if (bitmap == null) return;
        try {
            String safe = title.replaceAll("[^a-zA-Z0-9_-]", "_");
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "WXTRA_" + safe + ".jpg");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/WXTRA");
                v.put(MediaStore.Images.Media.IS_PENDING, 1);
            }
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new Exception();
            try (OutputStream out = getContentResolver().openOutputStream(uri)) { bitmap.compress(Bitmap.CompressFormat.JPEG, 94, out); }
            if (Build.VERSION.SDK_INT >= 29) { ContentValues done = new ContentValues(); done.put(MediaStore.Images.Media.IS_PENDING, 0); getContentResolver().update(uri, done, null, null); }
            view.downloads++; view.saveState(); toast("WXTRA klasörüne kaydedildi ✓");
        } catch (Exception e) { toast("İndirme başarısız oldu"); }
    }

    void shareWallpaper(int resId, String title) {
        try {
            Bitmap b = BitmapFactory.decodeResource(getResources(), resId);
            String path = MediaStore.Images.Media.insertImage(getContentResolver(), b, "WXTRA " + title, "WXTRA wallpaper");
            if (path == null) throw new Exception();
            Intent send = new Intent(Intent.ACTION_SEND); send.setType("image/*"); send.putExtra(Intent.EXTRA_STREAM, Uri.parse(path));
            startActivity(Intent.createChooser(send, "WXTRA ile paylaş"));
        } catch (Exception e) { toast("Paylaşım başlatılamadı"); }
    }

    void saveUriToGallery(Uri source, String title) {
        try (InputStream in = getContentResolver().openInputStream(source)) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "WXTRA_" + title.replaceAll("[^a-zA-Z0-9_-]", "_") + ".jpg");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) { v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/WXTRA"); v.put(MediaStore.Images.Media.IS_PENDING, 1); }
            Uri outUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (outUri == null) throw new Exception();
            try (OutputStream out = getContentResolver().openOutputStream(outUri)) {
                byte[] buf = new byte[8192]; int n; while ((n=in.read(buf)) > 0) out.write(buf,0,n);
            }
            if (Build.VERSION.SDK_INT >= 29) { ContentValues done = new ContentValues(); done.put(MediaStore.Images.Media.IS_PENDING, 0); getContentResolver().update(outUri, done, null, null); }
            toast("Düzenlenmiş görsel kaydedildi ✓");
        } catch (Exception e) { toast("Kaydetme başarısız oldu"); }
    }

    static class Item {
        String title, category, creator; int img; boolean live;
        Item(String t,String c,int i,boolean l,String cr){title=t;category=c;img=i;live=l;creator=cr;}
    }

    public class WxtraView extends View {
        static final int SPLASH=0, HOME=1, EXPLORE=2, DETAIL=3, LIVE=4, AI=5, EDITOR=6, DYNAMIC=7, COLLECTIONS=8, FAVORITES=9, PROFILE=10, PREMIUM=11, SETTINGS=12;
        final float density=getResources().getDisplayMetrics().density;
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        final android.content.SharedPreferences prefs;
        final ArrayList<Integer> history=new ArrayList<>();
        final HashSet<Integer> favorites=new HashSet<>(), collection=new HashSet<>();
        final ArrayList<Item> items=new ArrayList<>();
        Bitmap[] imgs=new Bitmap[25];
        int page=SPLASH, selected=0, activeCategory=0, scroll=0, downloads=0;
        boolean side=false, lockApply=false; Uri selectedUri; String query="";
        float downX,downY,lastY;
        int blue=Color.rgb(66,93,245), purple=Color.rgb(145,78,229), pink=Color.rgb(228,67,135), text=Color.rgb(21,27,48), muted=Color.rgb(103,111,136), bg=Color.rgb(247,249,253);
        final String[] names={"Serenity","Night Drive","Moon Forest","Aurora Dream","Wild Mountain","Neon Pulse","Deep Space","Luxury Dark","Velvet Sunset","Midnight City","Blue Horizon","Cosmic Ring","Moonlit Forest","Cyber Lines","Dark Orbit","Neon Halo","Desert Glow","Future Avenue","Lunar Echo","Hidden Woods","Rose Mountain","Electric Rain","Deep Ocean","Soft Eclipse","Violet Pulse"};
        final int[] res={R.drawable.wall_mountain,R.drawable.wall_neon,R.drawable.wall_forest,R.drawable.wall_aurora,R.drawable.wall_ocean,R.drawable.wall_anime,R.drawable.wall_space,R.drawable.wall_luxury,R.drawable.wall_9_velvet_sunset,R.drawable.wall_10_midnight_city,R.drawable.wall_11_blue_horizon,R.drawable.wall_12_cosmic_ring,R.drawable.wall_13_moonlit_forest,R.drawable.wall_14_cyber_lines,R.drawable.wall_15_dark_orbit,R.drawable.wall_16_neon_halo,R.drawable.wall_17_desert_glow,R.drawable.wall_18_future_avenue,R.drawable.wall_19_lunar_echo,R.drawable.wall_20_hidden_woods,R.drawable.wall_21_rose_mountain,R.drawable.wall_22_electric_rain,R.drawable.wall_23_deep_ocean,R.drawable.wall_24_soft_eclipse,R.drawable.wall_25_violet_pulse};
        final String[] cats={"Tümü","Canlı","4K/8K","Minimal","Anime","Doğa","Uzay","Arabalar","Cyber","Şehir"};
        final String[] itemCats={"Doğa","Arabalar","Doğa","Minimal","4K/8K","Anime","Uzay","Luxury","Doğa","Şehir","Deniz","Uzay","Doğa","Cyber","Minimal","Canlı","Doğa","Arabalar","Uzay","Doğa","Doğa","Cyber","Deniz","Minimal","Canlı"};
        final boolean[] liveFlags={true,true,true,true,false,true,false,false,false,true,false,true,true,true,false,true,false,true,true,true,false,true,false,false,true};

        WxtraView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);prefs=getSharedPreferences("wxtra",MODE_PRIVATE);downloads=prefs.getInt("downloads",0);loadSet("favorites",favorites);loadSet("collection",collection);for(int i=0;i<25;i++){imgs[i]=BitmapFactory.decodeResource(getResources(),res[i]);items.add(new Item(names[i],itemCats[i],res[i],liveFlags[i],i%3==0?"WXTRA Studio":i%3==1?"Nova Art":"Mert Design"));}}
        void loadSet(String key,Set<Integer> set){for(String s:prefs.getStringSet(key,new HashSet<>()))try{set.add(Integer.parseInt(s));}catch(Exception ignored){}}
        void saveState(){Set<String>a=new HashSet<>();for(Integer i:favorites)a.add(String.valueOf(i));Set<String>b=new HashSet<>();for(Integer i:collection)b.add(String.valueOf(i));prefs.edit().putStringSet("favorites",a).putStringSet("collection",b).putInt("downloads",downloads).apply();}
        float W(){return getWidth()/density;} float H(){return getHeight()/density;}
        void t(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setTypeface(bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);p.setTextSize(size);p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawText(s,x,y,p);}
        void rr(Canvas c,float l,float top,float r,float b,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(l,top,r,b),rad,rad,p);}
        void im(Canvas c,Bitmap b,RectF r){if(b!=null)c.drawBitmap(b,null,r,p);}
        void line(Canvas c,float a,float b,float d,float e,int col,float sw){p.setColor(col);p.setStrokeWidth(sw);p.setStyle(Paint.Style.STROKE);c.drawLine(a,b,d,e,p);p.setStyle(Paint.Style.FILL);}
        void push(int next){if(page!=next){history.add(page);page=next;side=false;scroll=0;invalidate();}}
        void goRoot(int next){history.clear();page=next;side=false;scroll=0;invalidate();}
        boolean goBack(){if(side){side=false;invalidate();return true;}if(page==SPLASH)return false;if(!history.isEmpty()){page=history.remove(history.size()-1);scroll=0;invalidate();return true;}if(page!=HOME){page=HOME;scroll=0;invalidate();return true;}return false;}

        @Override protected void onDraw(Canvas raw){super.onDraw(raw);raw.save();raw.scale(density,density);raw.drawColor(bg);switch(page){case SPLASH:drawSplash(raw);break;case HOME:drawHome(raw);break;case EXPLORE:drawExplore(raw);break;case DETAIL:drawDetail(raw);break;case LIVE:drawLive(raw);break;case AI:drawAI(raw);break;case EDITOR:drawEditor(raw);break;case DYNAMIC:drawDynamic(raw);break;case COLLECTIONS:drawCollections(raw);break;case FAVORITES:drawFavorites(raw);break;case PROFILE:drawProfile(raw);break;case PREMIUM:drawPremium(raw);break;case SETTINGS:drawSettings(raw);break;}if(side)drawSide(raw);raw.restore();}
        void header(Canvas c,String title,String sub,boolean back){if(back){t(c,"‹",18,39,34,text,false);t(c,title,58,38,22,text,true);}else{t(c,"WXTRA",18,36,22,text,true);if(sub!=null)t(c,sub,18,62,11,muted,false);t(c,"⌕",W()-76,37,24,text,false);t(c,"◉",W()-40,36,20,text,false);}}
        void nav(Canvas c,int active){float y=H()-68;p.setColor(Color.WHITE);c.drawRect(0,y,W(),H(),p);line(c,0,y,W(),y,Color.rgb(233,235,242),1);String[]a={"⌂","⌕","✦","♡","◉"},b={"Ana","Keşfet","AI","Favoriler","Profil"};for(int i=0;i<5;i++){float x=(i+.5f)*W()/5f;int col=i==active?blue:muted;t(c,a[i],x-8,y+25,21,col,true);t(c,b[i],x-17,y+46,9,col,i==active);}}
        void pill(Canvas c,String s,float x,float y,float w,boolean active){rr(c,x,y,x+w,y+34,17,active?blue:Color.WHITE);t(c,s,x+11,y+22,10,active?Color.WHITE:muted,true);}
        void card(Canvas c,int idx,float l,float top,float r,float bottom){rr(c,l,top,r,bottom,20,Color.WHITE);im(c,imgs[idx],new RectF(l,top,r,bottom));}
        void badge(Canvas c,String s,float x,float y){rr(c,x,y,x+Math.max(46,s.length()*6+18),y+24,12,Color.argb(215,255,255,255));t(c,s,x+10,y+16,9,pink,true);}

        void drawSplash(Canvas c){float cx=W()/2;t(c,"W",cx-58,250,86,purple,true);t(c,"XTRA",cx-2,250,46,text,true);t(c,"Senin duvarın. Senin hikayen.",cx-107,282,12,muted,false);rr(c,26,390,W()-26,450,30,blue);t(c,"WXTRA'ya Başla  →",W()/2-62,427,14,Color.WHITE,true);t(c,"4K / 8K   •   CANLI   •   AI   •   DİNAMİK",W()/2-121,485,9,muted,true);card(c,12,20,510,W()-20,690);rr(c,20,510,W()-20,690,0,Color.argb(45,0,0,0));t(c,"Keşfet. Kaydet. Kendine göre yaşat.",36,548,15,Color.WHITE,true);}
        void drawHome(Canvas c){int s=scroll;t(c,"Günaydın 👋",18,35,24,text,true);t(c,"⌕",W()-76,35,24,text,false);t(c,"◉",W()-40,35,20,text,false);rr(c,18,53-s,W()-18,99-s,23,Color.WHITE);t(c,"⌕",32,82-s,18,muted,true);t(c,"Duvar kağıdı ara...",56,81-s,12,muted,false);String[]ch={"🔥 Popüler","✦ Canlı","AI","4K/8K","Yeni"};float x=18;float[]ww={80,67,47,68,57};for(int i=0;i<5;i++){pill(c,ch[i],x,111-s,ww[i],i==0);x+=ww[i]+7;}float hero=154-s;rr(c,18,hero,W()-18,350-s,25,Color.DKGRAY);im(c,imgs[1],new RectF(18,hero,W()-18,350-s));rr(c,18,hero+112,W()-18,350-s,25,Color.argb(165,8,10,24));t(c,"GÜNÜN ÖNE ÇIKANI",34,hero+137,10,Color.rgb(208,211,255),true);t(c,"Night Drive",34,hero+164,23,Color.WHITE,true);t(c,"Canlı • 4K • Sınırlı seri",34,hero+184,10,Color.WHITE,false);rr(c,34,hero+199,135,hero+237,19,Color.WHITE);t(c,"Görüntüle →",47,hero+224,11,text,true);t(c,"Senin İçin",18,382-s,20,text,true);t(c,"Tümü  ›",W()-53,382-s,10,blue,true);float cw=(W()-58)/3f;for(int i=0;i<3;i++){float l=18+i*(cw+11);int idx=(i+3)%25;card(c,idx,l,397-s,l+cw,530-s);if(items.get(idx).live)badge(c,"LIVE",l+7,405-s);t(c,favorites.contains(idx)?"♥":"♡",l+cw-28,424-s,19,favorites.contains(idx)?pink:Color.WHITE,true);}t(c,"Temana göre keşfet",18,566-s,20,text,true);String[]ct={"Cyber","Doğa","Uzay","Minimal"};int[]ci={13,2,6,23};for(int i=0;i<4;i++){float l=18+i*((W()-61)/4f+9),w=(W()-61)/4f;card(c,ci[i],l,582-s,l+w,690-s);rr(c,l,644-s,l+w,690-s,16,Color.argb(105,0,0,0));t(c,ct[i],l+10,676-s,10,Color.WHITE,true);}rr(c,18,723-s,W()-18,792-s,21,Color.WHITE);t(c,"✦",34,755-s,18,purple,true);t(c,"Bugünün modu",66,749-s,12,text,true);t(c,"Ruh haline göre seçilmiş wallpaper'lar",66,769-s,9,muted,false);t(c,"›",W()-39,758-s,21,muted,false);nav(c,0);}
        List<Integer> filtered(){List<Integer>o=new ArrayList<>();for(int i=0;i<items.size();i++){Item it=items.get(i);boolean ok=true;if(query.length()>0)ok=it.title.toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT))||it.category.toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT))||it.creator.toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT));if(ok&&activeCategory==1)ok=it.live;if(ok&&activeCategory==2)ok=!it.live;if(ok&&activeCategory>=3)ok=it.category.equals(cats[activeCategory]);if(ok)o.add(i);}return o;}
        void drawExplore(Canvas c){header(c,"Keşfet",query.isEmpty()?"İlhamını bul, anında önizle.":"Arama: "+query,false);int s=scroll;float x=18;for(int i=0;i<cats.length;i++){float ww=Math.max(52,c.measureText(cats[i])+24);if(x+ww>W()-16)break;pill(c,cats[i],x,91-s,ww,i==activeCategory);x+=ww+7;}List<Integer>list=filtered();if(list.isEmpty()){t(c,"Sonuç bulunamadı",W()/2-70,300,16,text,true);t(c,"Başka bir kelime veya kategori dene.",W()/2-105,328,10,muted,false);}int pos=0;for(Integer idx:list){int col=pos%2,row=pos/2;float ww=(W()-55)/2f,l=18+col*(ww+19),y=137-s+row*183;card(c,idx,l,y,l+ww,y+158);if(items.get(idx).live)badge(c,"LIVE",l+8,y+8);else badge(c,"4K",l+8,y+8);t(c,favorites.contains(idx)?"♥":"♡",l+ww-32,y+31,20,favorites.contains(idx)?pink:Color.WHITE,true);t(c,items.get(idx).title,l+9,y+176,11,text,true);t(c,items.get(idx).category,l+9,y+193,9,muted,false);pos++;}nav(c,1);}
        void drawDetail(Canvas c){Item it=items.get(selected);t(c,"‹",18,39,34,text,false);t(c,it.title,58,36,21,text,true);t(c,favorites.contains(selected)?"♥":"♡",W()-56,36,28,favorites.contains(selected)?pink:muted,true);rr(c,12,58,W()-12,407,25,Color.WHITE);im(c,imgs[selected],new RectF(12,58,W()-12,407));if(it.live)badge(c,"LIVE WALLPAPER",26,72);rr(c,26,318,W()-26,393,22,Color.argb(165,8,10,24));t(c,it.title,41,348,22,Color.WHITE,true);t(c,it.creator+"  •  "+it.category,41,370,10,Color.WHITE,false);t(c,it.title,20,437,23,text,true);t(c,(it.live?"Canlı":"Statik")+"  •  4K  •  Android",20,460,10,muted,false);t(c,"Favori: "+(favorites.contains(selected)?"Evet":"Hayır")+"   •   "+downloads+" indirme",20,484,10,muted,false);rr(c,20,505,(W()-27)/2f,561,19,Color.WHITE);t(c,"Önizle",53,540,13,text,true);rr(c,(W()+8)/2f,505,W()-20,561,19,it.live?purple:blue);t(c,it.live?"Canlı Uygula":"Duvar Kağıdı Yap",(W()+20)/2f,540,11,Color.WHITE,true);rr(c,20,575,(W()-27)/2f,628,18,Color.WHITE);t(c,"⇩  İndir",49,608,13,text,true);rr(c,(W()+8)/2f,575,W()-20,628,18,Color.WHITE);t(c,"↗  Paylaş",(W()+29)/2f,608,13,text,true);rr(c,20,642,(W()-27)/2f,694,18,Color.WHITE);t(c,collection.contains(selected)?"✓ Koleksiyonda":"＋ Koleksiyona ekle",34,674,10,text,true);rr(c,(W()+8)/2f,642,W()-20,694,18,Color.WHITE);t(c,"❤️ Favori",(W()+28)/2f,674,11,favorites.contains(selected)?pink:text,true);t(c,"Benzer keşifler",20,730,18,text,true);for(int i=0;i<3;i++){int idx=(selected+1+i)%25;card(c,idx,20+i*118,746,126+i*118,860);}}
        void drawLive(Canvas c){t(c,"‹",18,39,34,text,false);t(c,"Canlı Önizleme",58,36,21,text,true);t(c,"● LIVE",W()-74,36,9,pink,true);rr(c,22,58,W()-22,420,27,Color.BLACK);im(c,imgs[selected],new RectF(35,72,W()-35,407));t(c,"9:41",W()/2-32,220,34,Color.WHITE,true);t(c,"Pazartesi, 2 Eylül",W()/2-54,242,10,Color.WHITE,false);rr(c,18,441,W()-18,625,23,Color.WHITE);t(c,"Hareket yoğunluğu",36,472,12,text,true);String[]la={"Düşük","Orta","Yüksek"};for(int i=0;i<3;i++){rr(c,36+i*91,489,118+i*91,525,18,i==1?blue:Color.rgb(242,244,248));t(c,la[i],48+i*91,512,9,i==1?Color.WHITE:muted,true);}t(c,"Parçacık efektleri",36,558,11,muted,false);t(c,"ON",W()-57,558,10,blue,true);t(c,"Pil Dostu Mod",36,594,11,muted,false);t(c,"ON",W()-57,594,10,blue,true);rr(c,24,645,W()-24,701,22,purple);t(c,"Canlı Duvar Kağıdını Uygula",W()/2-92,679,12,Color.WHITE,true);}
        void drawAI(Canvas c){header(c,"AI Studio","Fikri yaz, stilini seç, sonucu üret.",false);rr(c,20,102,W()-20,205,22,Color.WHITE);t(c,"Hayalindeki sahneyi anlat...",36,131,13,muted,false);t(c,"Yağmurlu İstanbul, neon ışıklar, sinematik",36,156,10,muted,false);t(c,"telefon duvar kağıdı, derinlikli ve canlı",36,175,10,muted,false);String[]st={"Sinematik","Anime","Minimal","Cyber"};for(int i=0;i<4;i++)pill(c,st[i],20+i*89,220,78,i==0);rr(c,20,270,W()-20,326,22,blue);t(c,"✦  Wallpaper Oluştur",W()/2-67,305,14,Color.WHITE,true);t(c,"Son çalışmalar",20,366,19,text,true);for(int i=0;i<4;i++)card(c,i,20+i*91,382,105+i*91,491);rr(c,20,518,W()-20,573,20,Color.WHITE);t(c,"▣  Fotoğraftan stil oluştur",38,552,12,text,true);rr(c,20,588,W()-20,643,20,Color.WHITE);t(c,"⚡  AI + Canlı deneyime dönüştür",38,622,12,text,true);nav(c,2);}
        void drawEditor(Canvas c){t(c,"‹",18,39,34,text,false);t(c,"Düzenle",58,36,22,text,true);t(c,"Kaydet",W()-62,36,11,blue,true);rr(c,20,58,W()-20,395,26,Color.WHITE);Bitmap b=imgs[selected];if(selectedUri!=null)try{b=BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedUri));}catch(Exception ignored){}im(c,b,new RectF(35,72,W()-35,380));t(c,"Ayarlamalar",20,429,18,text,true);String[]tools={"Kırp","Renk","Işık","Efekt","Metin"};for(int i=0;i<5;i++){rr(c,20+i*70,451,80+i*70,505,18,Color.WHITE);t(c,tools[i],31+i*70,483,9,text,true);}rr(c,20,525,W()-20,578,20,blue);t(c,"Değişiklikleri Kaydet",W()/2-63,558,13,Color.WHITE,true);rr(c,20,592,W()-20,645,20,Color.WHITE);t(c,"✦  Canlı wallpaper'a dönüştür",38,626,12,text,true);}
        void drawDynamic(Canvas c){header(c,"Dinamik","Telefonuna göre kendini değiştirsin.",true);String[]a={"Günün Saatine Göre","Hava Durumuna Göre","Şarj Durumuna Göre","Konuma Göre","Otomatik Rotasyon"};String[]b={"Sabah • öğlen • akşam • gece","Yağmur • kar • güneş","Düşük bataryada sade mod","Şehre göre tema","Belirli aralıklarla değiştir"};for(int i=0;i<5;i++){float y=104+i*76;rr(c,20,y,W()-20,y+60,19,Color.WHITE);t(c,"✦",34,y+36,19,blue,true);t(c,a[i],68,y+25,12,text,true);t(c,b[i],68,y+44,9,muted,false);t(c,i<3?"ON":"OFF",W()-61,y+35,9,i<3?blue:muted,true);}rr(c,20,505,W()-20,560,20,blue);t(c,"Dinamiği Uygula",W()/2-51,539,13,Color.WHITE,true);t(c,"Önizleme",20,602,18,text,true);card(c,1,20,620,W()-20,806);}
        void drawCollections(Canvas c){header(c,"Koleksiyonlar","Hazır temalar ve kişisel klasörlerin.",true);String[]n={"Cyber City","Nature","Minimal","Anime","Luxury"};int[]ii={1,0,23,5,7};for(int i=0;i<5;i++){float y=105+i*104;card(c,ii[i],20,y,W()-20,y+88);rr(c,20,y,W()-20,y+88,20,Color.argb(90,0,0,0));t(c,n[i],38,y+40,16,Color.WHITE,true);t(c,(64+i*23)+" wallpaper",38,y+61,9,Color.WHITE,false);t(c,"›",W()-46,y+51,20,Color.WHITE,false);}nav(c,1);}
        void drawFavorites(Canvas c){header(c,"Favoriler","Kaydettiklerin burada.",true);ArrayList<Integer>list=new ArrayList<>(favorites);Collections.sort(list);if(list.isEmpty()){t(c,"Henüz favorin yok",W()/2-65,245,16,text,true);t(c,"Keşfet'te kalp simgesine dokun.",W()/2-93,272,11,muted,false);}else{for(int pos=0;pos<list.size()&&pos<18;pos++){int idx=list.get(pos),col=pos%3,row=pos/3;float ww=(W()-62)/3f,l=18+col*(ww+13),y=111+row*164;card(c,idx,l,y,l+ww,y+142);t(c,"♥",l+ww-30,y+27,19,pink,true);t(c,items.get(idx).title,l+7,y+157,9,text,true);}}nav(c,3);}
        void drawProfile(Canvas c){header(c,"Profil","Kendi dünyanı oluştur.",true);rr(c,18,101,W()-18,204,24,Color.WHITE);t(c,"WXTRA",35,135,22,text,true);t(c,"Wallpaper Creator",35,157,10,muted,false);t(c,String.valueOf(items.size()),35,185,15,text,true);t(c,"Wallpaper",35,198,8,muted,false);t(c,String.valueOf(downloads),105,185,15,text,true);t(c,"İndirme",103,198,8,muted,false);t(c,"128",172,185,15,text,true);t(c,"Takipçi",170,198,8,muted,false);String[]m={"＋  Wallpaper yükle","Paylaşımlarım","İstatistikler","Koleksiyonlarım","İndirilenler","Ayarlar"};for(int i=0;i<m.length;i++){float y=225+i*54;rr(c,20,y,W()-20,y+44,17,Color.WHITE);t(c,m[i],41,y+28,12,text,true);t(c,"›",W()-47,y+28,17,muted,true);}nav(c,4);}
        void drawPremium(Canvas c){t(c,"‹",18,39,34,text,false);t(c,"Premium",58,36,23,text,true);rr(c,20,68,W()-20,206,27,Color.rgb(24,28,52));t(c,"WXTRA PREMIUM",40,110,22,Color.WHITE,true);t(c,"Daha iyi wallpaper. Daha az sınır.",40,137,11,Color.WHITE,false);rr(c,40,157,W()-40,196,21,Color.WHITE);t(c,"Premium'a Geç  →",82,182,12,text,true);t(c,"Premium ile açılanlar",20,250,19,text,true);String[]a={"4K / 8K Ultra kalite","Sınırsız canlı wallpaper","AI Studio üretimleri","Özel koleksiyonlar","Gelişmiş kişiselleştirme","Reklamsız deneyim"};for(int i=0;i<a.length;i++){t(c,"✓",28,291+i*44,15,blue,true);t(c,a[i],55,291+i*44,12,text,true);}rr(c,20,565,W()-20,621,20,purple);t(c,"Premium'u incele",W()/2-50,599,13,Color.WHITE,true);}
        void drawSettings(Canvas c){t(c,"‹",18,39,34,text,false);t(c,"Ayarlar",58,36,22,text,true);String[]m={"Bildirimler","Otomatik indirme","Canlı wallpaper kalite","Gizlilik","Hakkımızda","Yardım"};for(int i=0;i<m.length;i++){float y=82+i*59;rr(c,20,y,W()-20,y+46,17,Color.WHITE);t(c,m[i],38,y+29,12,text,true);t(c,i<3?"ON":"›",W()-59,y+29,10,i<3?blue:muted,true);}}
        void drawSide(Canvas c){p.setColor(Color.argb(80,0,0,0));c.drawRect(0,0,W(),H(),p);rr(c,0,0,W()*0.86f,H(),0,Color.WHITE);t(c,"W",24,61,39,purple,true);t(c,"XTRA",67,59,23,text,true);t(c,"Senin duvarın. Senin hikayen.",24,81,9,muted,false);String[]m={"Ana Sayfa","Keşfet","AI Studio","Koleksiyonlar","Dinamik Wallpaper","Favoriler","Profil","Premium","Ayarlar"};int[]pg={HOME,EXPLORE,AI,COLLECTIONS,DYNAMIC,FAVORITES,PROFILE,PREMIUM,SETTINGS};for(int i=0;i<m.length;i++){float y=126+i*44;t(c,m[i],34,y,13,page==pg[i]?blue:text,true);}rr(c,22,H()-95,W()*0.86f-22,H()-48,19,Color.rgb(246,240,255));t(c,"♛  Premium'a Geç",41,H()-65,11,purple,true);}

        @Override public boolean onTouchEvent(MotionEvent e){float x=e.getX()/density,y=e.getY()/density;if(e.getAction()==MotionEvent.ACTION_DOWN){downX=x;downY=y;lastY=y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){float dy=y-lastY;if(page==HOME||page==EXPLORE){scroll-=dy;scroll=Math.max(0,Math.min(scroll,520));invalidate();}lastY=y;return true;}if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            if(side){if(x>W()*.86f){side=false;invalidate();return true;}if(y>100&&y<535){int n=(int)((y-104)/44);int[]pg={HOME,EXPLORE,AI,COLLECTIONS,DYNAMIC,FAVORITES,PROFILE,PREMIUM,SETTINGS};if(n>=0&&n<pg.length)goRoot(pg[n]);}return true;}
            if(page==SPLASH){if(y>360)goRoot(HOME);return true;}
            if(y<65&&x<55){goBack();return true;}
            if(page==HOME && y<58&&x>W()-110){searchDialog();return true;}
            if((page==EXPLORE||page==HOME)&&y>H()-78){int n=(int)(x/(W()/5f));goRoot(n==0?HOME:n==1?EXPLORE:n==2?AI:n==3?FAVORITES:PROFILE);return true;}
            if(page==HOME){float yy=y+scroll;if(yy>150&&yy<355){selected=1;push(DETAIL);}else if(yy>395&&yy<545){int idx=3+(int)((x-18)/((W()-58)/3f+11));if(idx>=3&&idx<6){selected=idx;push(DETAIL);}}else if(yy>570&&yy<710){push(EXPLORE);}else if(yy>720)push(DYNAMIC);}
            else if(page==EXPLORE){float yy=y+scroll;if(yy>85&&yy<140){float xx=18;for(int i=0;i<cats.length;i++){float ww=Math.max(52,p.measureText(cats[i])+24);if(x>=xx&&x<=xx+ww){activeCategory=i;scroll=0;invalidate();break;}if(xx+ww>W()-16)break;xx+=ww+7;}}else if(yy>130){List<Integer>list=filtered();int col=x>W()/2?1:0,row=(int)((yy-137)/183),pos=row*2+col;if(pos>=0&&pos<list.size()){selected=list.get(pos);push(DETAIL);}}}
            else if(page==DETAIL){if(y<65&&x>W()-90)toggleFav();else if(y>500&&y<570){if(items.get(selected).live)push(LIVE);else chooseStaticTarget();}else if(y>575&&y<640&&x<W()/2)downloadStatic(items.get(selected).img,items.get(selected).title);else if(y>575&&y<640)shareWallpaper(items.get(selected).img,items.get(selected).title);else if(y>642&&y<700&&x<W()/2){if(collection.contains(selected))collection.remove(selected);else collection.add(selected);saveState();invalidate();}else if(y>642&&y<700)toggleFav();}
            else if(page==LIVE){if(y>635)openLive();}
            else if(page==AI){if(y>270&&y<340){selected=4;push(DETAIL);}else if(y>500&&y<575)pickImage();}
            else if(page==EDITOR){if(y>35&&y<65&&x>W()-100){if(selectedUri!=null)saveUriToGallery(selectedUri,"edited");else downloadStatic(items.get(selected).img,"edited");}else if(y>420&&y<515)toast("Araç seçildi — önizleme güncellendi ✓");else if(y>515&&y<590){if(selectedUri!=null)saveUriToGallery(selectedUri,"edited");else downloadStatic(items.get(selected).img,"edited");}else if(y>590)toast("Canlı efekt hazırlanıyor ✓");}
            else if(page==DYNAMIC){if(y>480&&y<570)toast("Dinamik wallpaper ayarlandı ✓");}
            else if(page==COLLECTIONS){if(y>95&&y<650){selected=Math.max(0,Math.min(24,(int)((y-105)/104)));push(EXPLORE);}}
            else if(page==FAVORITES){if(y>100&&y<650&&!favorites.isEmpty()){float ww=(W()-62)/3f;int col=Math.max(0,Math.min(2,(int)((x-18)/(ww+13)))),row=(int)((y-111)/164),pos=row*3+col;ArrayList<Integer>list=new ArrayList<>(favorites);Collections.sort(list);if(pos>=0&&pos<list.size()){selected=list.get(pos);push(DETAIL);}}}
            else if(page==PROFILE){if(y>220&&y<280)pickImage();else if(y>450&&y<510)push(SETTINGS);}
            else if(page==PREMIUM){if(y>145&&y<215)toast("Premium ödeme bağlantısı Firebase/Play Billing aşamasında bağlanacak.");}
            else if(page==SETTINGS){if(y>70&&y<500)toast("Ayar kaydedildi ✓");}
            return true;}
        void toggleFav(){if(favorites.contains(selected))favorites.remove(selected);else favorites.add(selected);saveState();invalidate();}
    }
}
