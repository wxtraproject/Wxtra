package com.wextra.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF7B3FF2)
private val Blue = Color(0xFF6D74FF)
private val Bg = Color(0xFFF7F5FF)
private val TextMain = Color(0xFF171326)
private val TextMuted = Color(0xFF706A82)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAApp() }
    }
}

@Composable
private fun WXTRAApp() {
    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, secondary = Blue)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            SettingsScreen()
        }
    }
}

@Composable
private fun SettingsScreen() {
    var notifications by remember { mutableStateOf(true) }
    var autoDownload by remember { mutableStateOf(false) }
    var darkMode by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Text("Ayarlar", fontSize = 30.sp, fontWeight = FontWeight.Black, color = TextMain)
        Text("WXTRA uygulama tercihleri", color = TextMuted, modifier = Modifier.padding(top = 4.dp, bottom = 24.dp))

        SettingsSection("Genel") {
            SettingSwitch(
                icon = Icons.Default.Notifications,
                title = "Bildirimler",
                description = "Yeni duvar kâğıtlarından haberdar ol",
                checked = notifications,
                onCheckedChange = { notifications = it }
            )
            SettingSwitch(
                icon = Icons.Default.Download,
                title = "Otomatik indirme",
                description = "Seçilen içerikleri otomatik indir",
                checked = autoDownload,
                onCheckedChange = { autoDownload = it }
            )
            SettingSwitch(
                icon = Icons.Default.DarkMode,
                title = "Koyu tema",
                description = "Koyu görünümü kullan",
                checked = darkMode,
                onCheckedChange = { darkMode = it }
            )
        }

        SettingsSection("Uygulama") {
            SettingAction(Icons.Default.Language, "Dil", "Türkçe")
            SettingAction(Icons.Default.Palette, "Tema", "WXTRA")
            SettingAction(Icons.Default.Storage, "Depolama", "Yerel kullanım")
        }

        SettingsSection("Hakkında") {
            SettingAction(Icons.Default.Info, "WXTRA hakkında", "Sürüm 1.0")
            SettingAction(Icons.Default.PrivacyTip, "Gizlilik", "Gizlilik tercihleri")
            SettingAction(Icons.Default.Description, "Kullanım koşulları", "Koşulları görüntüle")
        }

        Spacer(Modifier.height(20.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFFB98BFF), Purple, Color(0xFFE2D5FF))))
                .padding(20.dp)
        ) {
            Column {
                Text("WXTRA", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("Server bağlantısı sonraki aşamada eklenecek.", color = Color.White.copy(alpha = .85f), modifier = Modifier.padding(top = 4.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextMuted, modifier = Modifier.padding(bottom = 8.dp))
    Surface(
        Modifier.fillMaxWidth().padding(bottom = 22.dp),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        shadowElevation = 1.dp
    ) {
        Column(content = content)
    }
}

@Composable
private fun SettingSwitch(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Purple, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = TextMain)
            Text(description, fontSize = 12.sp, color = TextMuted)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String
) {
    Row(
        Modifier.fillMaxWidth().padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Purple, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = TextMain)
            Text(description, fontSize = 12.sp, color = TextMuted)
        }
        Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
    }
}
