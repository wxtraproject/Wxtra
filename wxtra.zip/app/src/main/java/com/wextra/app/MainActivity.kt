package com.wextra.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF3278F6)
private val Purple = Color(0xFF7A5AF8)
private val Bg = Color(0xFFF7F8FC)

data class Wallpaper(val title: String, val image: Int, val category: String)

private val wallpapers = listOf(
    Wallpaper("Renkli Kuş", R.drawable.wallpaper_0, "Hayvanlar"),
    Wallpaper("Gece Sürüşü", R.drawable.wallpaper_1, "Arabalar"),
    Wallpaper("Yeşil Papağan", R.drawable.wallpaper_2, "Hayvanlar"),
    Wallpaper("Gül Bahçesi", R.drawable.wallpaper_3, "Doğa"),
    Wallpaper("Neon Akış", R.drawable.wallpaper_4, "Abstract"),
    Wallpaper("Pink BMW", R.drawable.wallpaper_5, "Arabalar"),
    Wallpaper("Çiçek Vadisi", R.drawable.wallpaper_6, "Doğa"),
    Wallpaper("Kırmızı Çiçek", R.drawable.wallpaper_7, "Çiçekler"),
    Wallpaper("Colorful Nature", R.drawable.wallpaper_8, "Doğa")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAApp() }
    }
}

@Composable
fun WXTRAApp() {
    var selected by remember { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<Wallpaper?>(null) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Bg)) {
        if (detail != null) {
            DetailScreen(detail!!) { detail = null }
        } else {
            Scaffold(
                containerColor = Bg,
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        val labels = listOf("Ana Sayfa", "Keşfet", "AI", "Favoriler", "Profil")
                        val icons = listOf(Icons.Default.Home, Icons.Default.Explore, Icons.Default.AutoAwesome, Icons.Default.FavoriteBorder, Icons.Default.Person)
                        labels.forEachIndexed { i, label ->
                            NavigationBarItem(
                                selected = selected == i,
                                onClick = { selected = i },
                                icon = { Icon(icons[i], null) },
                                label = { Text(label, fontSize = 10.sp) }
                            )
                        }
                    }
                }
            ) { pad ->
                when (selected) {
                    0 -> HomeScreen(pad) { detail = it }
                    1 -> ExploreScreen(pad) { detail = it }
                    2 -> AIStudioScreen(pad)
                    3 -> FavoritesScreen(pad) { detail = it }
                    else -> ProfileScreen(pad)
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = Color.Gray, fontSize = 13.sp)
        }
        IconButton(onClick = {}) { Icon(Icons.Default.Search, "Ara") }
        IconButton(onClick = {}) { Icon(Icons.Default.PersonOutline, "Profil") }
    }
}

@Composable
fun HomeScreen(pad: PaddingValues, open: (Wallpaper) -> Unit) {
    Column(Modifier.padding(pad)) {
        Header("Günaydın 👋", "Bugün senin için harika duvar kâğıtları var.")
        OutlinedTextField(
            value = "", onValueChange = {}, readOnly = true,
            placeholder = { Text("Duvar kâğıdı ara...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            shape = RoundedCornerShape(18.dp)
        )
        Spacer(Modifier.height(14.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(listOf("🔥 Popüler", "✨ Yeni", "4K/8K", "🎨 Minimal", "🌿 Doğa")) { c ->
                AssistChip(onClick = {}, label = { Text(c) })
            }
        }
        Text("Senin için", fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp, 18.dp, 20.dp, 8.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(wallpapers) { _, w -> WallpaperCard(w, open) }
        }
    }
}

@Composable
fun ExploreScreen(pad: PaddingValues, open: (Wallpaper) -> Unit) {
    Column(Modifier.padding(pad)) {
        Header("Keşfet", "Kategorilerle sınırsız keşif.")
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf("Tümü", "Canlı", "4K/8K", "Minimal", "Anime", "Araba", "Uzay")) { Text(it, modifier = Modifier.clip(CircleShape).background(if (it == "Tümü") Blue else Color.White).clickable {}.padding(horizontal = 16.dp, vertical = 9.dp), color = if (it == "Tümü") Color.White else Color.DarkGray) }
        }
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(wallpapers + wallpapers.reversed()) { _, w -> WallpaperCard(w, open) }
        }
    }
}

@Composable
fun WallpaperCard(w: Wallpaper, open: (Wallpaper) -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(18.dp)).background(Color.White).clickable { open(w) }) {
        Image(painterResource(w.image), null, Modifier.fillMaxWidth().height(220.dp), contentScale = ContentScale.Crop)
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(w.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(w.category, color = Color.Gray, fontSize = 11.sp)
            }
            Icon(Icons.Default.FavoriteBorder, null, tint = Color.Gray)
        }
    }
}

@Composable
fun DetailScreen(w: Wallpaper, back: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(w.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Row(Modifier.fillMaxWidth().padding(top = 34.dp, start = 12.dp, end = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            FilledIconButton(onClick = back, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White.copy(.85f))) { Icon(Icons.Default.ArrowBack, null) }
            Row {
                FilledIconButton(onClick = {}, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White.copy(.85f))) { Icon(Icons.Default.FavoriteBorder, null) }
                Spacer(Modifier.width(8.dp))
                FilledIconButton(onClick = {}, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White.copy(.85f))) { Icon(Icons.Default.MoreVert, null) }
            }
        }
        Card(Modifier.align(Alignment.BottomCenter).fillMaxWidth(), shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(20.dp)) {
                Text(w.title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("WXTRA Creator  •  ${w.category}", color = Color.Gray, modifier = Modifier.padding(top = 4.dp))
                Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = {}, Modifier.weight(1f)) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(6.dp)); Text("İndir") }
                    Button(onClick = {}, Modifier.weight(1f)) { Icon(Icons.Default.Wallpaper, null); Spacer(Modifier.width(6.dp)); Text("Duvar Kâğıdı Yap") }
                }
            }
        }
    }
}

@Composable
fun AIStudioScreen(pad: PaddingValues) {
    Column(Modifier.padding(pad)) {
        Header("AI Stüdyo", "Hayalindeki duvar kâğıdını oluştur.")
        Card(Modifier.padding(20.dp).fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Metinden Oluştur", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = "", onValueChange = {}, placeholder = { Text("Örn: Neon Tokyo, yağmurlu gece...") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
                Spacer(Modifier.height(12.dp))
                Button(onClick = {}, Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Oluştur")
                }
            }
        }
    }
}

@Composable
fun FavoritesScreen(pad: PaddingValues, open: (Wallpaper) -> Unit) {
    Column(Modifier.padding(pad)) {
        Header("Favoriler", "Beğendiğin duvar kâğıtları burada.")
        LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(wallpapers) { _, w -> WallpaperCard(w, open) }
        }
    }
}

@Composable
fun ProfileScreen(pad: PaddingValues) {
    Column(Modifier.padding(pad)) {
        Header("Profil")
        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(92.dp).clip(CircleShape).background(Color(0xFFE8ECFF)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, null, Modifier.size(48.dp), tint = Blue)
            }
            Text("WXTRA Kullanıcısı", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
            Text("Duvarın. Senin tarzın.", color = Color.Gray)
            Spacer(Modifier.height(20.dp))
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column {
                    listOf("Koleksiyonlar", "İndirilenler", "Ayarlar", "Yardım & Destek").forEach {
                        ListItem(headlineContent = { Text(it) }, trailingContent = { Icon(Icons.Default.ChevronRight, null) })
                    }
                }
            }
        }
    }
}
