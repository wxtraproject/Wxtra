package com.wextra.app

import android.app.WallpaperManager
import android.content.Context
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.widget.Toast
import java.util.Calendar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val defaultBg = Color(0xFF070A12)
private val defaultCard = Color(0xFF121827)
private val defaultCard2 = Color(0xFF171D2D)
private val defaultPurple = Color(0xFFB34DFF)
private val defaultBlue = Color(0xFF4C8DFF)
private var Bg by mutableStateOf(defaultBg)
private var Card by mutableStateOf(defaultCard)
private var Card2 by mutableStateOf(defaultCard2)
private var Purple by mutableStateOf(defaultPurple)
private var Blue by mutableStateOf(defaultBlue)
private var TextMain by mutableStateOf(Color(0xFFF5F3FF))
private var TextMuted by mutableStateOf(Color(0xFFA5A7BC))
private var Accent by mutableStateOf(Brush.horizontalGradient(listOf(Color(0xFFE53CFF), Color(0xFF596CFF))))
private var appBackgroundBrush by mutableStateOf<Brush?>(null)
private var layoutMode by mutableStateOf(0)
private var appLanguage by mutableStateOf("tr")
private fun L(tr: String, en: String): String = if (appLanguage == "en") en else tr
private fun T(text: String): String = if (appLanguage == "tr") text else mapOf(
    "GÜNÜN ÖNERİSİ" to "TODAY'S PICK", "Geceye Farklı Bak" to "See the Night Differently",
    "Her duvar, başka bir sen." to "Every wall, a different you.", "Keşfet" to "Explore",
    "Keşfet  →" to "Explore  →", "Duvar kâğıdı ara..." to "Search wallpapers...",
    "Duvar kağıdı ara…" to "Search wallpapers…", "WXTRA İLE" to "WITH WXTRA",
    "Daha Fazlasını Hisset" to "Feel More", "Senin tarzın. Senin duvarın. Senin hikayen." to "Your style. Your wall. Your story.",
    "Sıradan duvar kâğıtlarının ötesine geç." to "Go beyond ordinary wallpapers.",
    "YENİ UFUKLAR" to "NEW HORIZONS", "Farklı Dünyaları Keşfet" to "Explore Different Worlds",
    "Her ekran, yeni bir hikâye." to "Every screen, a new story.", "Keşfetmeye Başla →" to "Start Exploring →",
    "Bu Haftanın Özel Seçkisi" to "This Week's Special Picks", "WXTRA ekibinin seçtiği favoriler." to "Favorites selected by the WXTRA team.",
    "Henüz favorin yok" to "No favorites yet", "Beğendiğin duvar kâğıtları burada görünecek." to "Wallpapers you like will appear here.",
    "Sizin için özel seçildi." to "Selected especially for you.", "Özel seçki" to "Special pick",
    "Sonuç bulunamadı." to "No results found.", "WXTRA'ya hoş geldin!" to "Welcome to WXTRA!",
    "Yeni duvar kâğıtları ve koleksiyonlar burada görünecek." to "New wallpapers and collections will appear here.",
    "Sıradan duvar kâğıtlarına veda." to "Say goodbye to ordinary wallpapers.",
    "Her gün yeni bir hikâye. WXTRA, telefonunu kişiselleştirmek için seçilmiş duvar kâğıtlarını tek yerde sunar." to "A new story every day. WXTRA brings selected wallpapers together to personalize your phone.",
    "Duvar Kâğıdını Nereye Uygula?" to "Where should the wallpaper be applied?",
    "İki ekrana birden otomatik uygulanmayacak. Bir seçenek seç:" to "It will not be applied to both screens automatically. Choose one:",
    "Ana ekran" to "Home screen", "Kilit ekranı" to "Lock screen", "Ana ekran + Kilit ekranı" to "Home screen + Lock screen",
    "Güzel duvar kâğıtları, daha güzel hikâyeler." to "Beautiful wallpapers, better stories.",
    "Daha fazla özellik, daha fazla özgürlük." to "More features, more freedom.", "Yakında  ›" to "Coming soon  ›",
    "🔥  Popüler Şu An" to "🔥  Trending Now", "🔥 Popüler Şu An" to "🔥 Trending Now",
    "✨  Senin Ruh Hâlin" to "✨  Your Mood", "🎨  Senin İçin Seçtiklerimiz" to "🎨  Selected For You",
    "📈 Yükselenler" to "📈 Rising", "🎨 Tarzına Göre" to "🎨 By Style", "👑 Haftanın Seçimleri" to "👑 Weekly Picks",
    "👤 Senin İçin" to "👤 For You", "Tümünü Gör" to "See All",
    "Doğa" to "Nature", "Anime" to "Anime", "Arabalar" to "Cars", "Uzay" to "Space",
    "Sakin" to "Calm", "Enerjik" to "Energetic", "Melankolik" to "Melancholic", "Odak" to "Focus", "Mutlu" to "Happy",
    "Renkli Kuş" to "Colorful Bird", "Kırmızı Dokunuş" to "Crimson Touch", "Saklı Bahçe" to "Hidden Garden",
    "Pembe Efsane" to "Pink Legend", "Gece Sürüşü" to "Night Drive", "Doğanın İçinde" to "Into Nature",
    "Zarif Dokunuş" to "Elegant Touch", "Akış" to "Flow", "Renkli Akşamlar" to "Colorful Evenings",
    "Şehir" to "City", "Gece" to "Night", "Minimal" to "Minimal", "Sanat" to "Art", "Karanlık" to "Dark", "Renkli" to "Colorful",
    "Koleksiyonlarım" to "My Collections", "4K Ultra HD" to "4K Ultra HD", "Etkileyici Manzaralar" to "Stunning Landscapes",
    "Karanlık Mod" to "Dark Mode", "Anime Dünyası" to "Anime World", "WXTRA Hakkında" to "About WXTRA",
    "Profilim" to "My Profile", "Favorilerim" to "My Favorites", "Ayarlar" to "Settings", "Bildirimler" to "Notifications",
    "Tema Arka Planı" to "Theme Background", "Tema Yazı Rengi" to "Theme Text Color", "Tema Dizilimi" to "Theme Layout",
    "GÖRÜNÜM" to "APPEARANCE", "BİLDİRİMLER" to "NOTIFICATIONS", "UYGULAMA" to "APP", "DESTEK" to "SUPPORT", "HAKKIMDA" to "ABOUT",
    "Önbellek" to "Cache", "Temizle" to "Clear", "Ayarları varsayılana döndür" to "Reset settings to default",
    "Sıfırla" to "Reset", "Sorun bildir" to "Report a problem", "Bize ulaş" to "Contact us",
    "Gizlilik politikası" to "Privacy Policy", "Kullanım koşulları" to "Terms of Use", "Sürüm bilgisi" to "Version info",
    "WXTRA hakkında" to "About WXTRA", "Sürüm ve bilgiler" to "Version and information", "Veri ve gizlilik" to "Data and privacy",
    "Kurallar" to "Rules", "Dil" to "Language", "Türkçe" to "Turkish", "İngilizce" to "English",
    "Uygulama bildirimleri" to "App notifications", "Günlük öneri bildirimi" to "Daily wallpaper notification",
    "Kişiselleştirilmiş öneriler" to "Personalized recommendations", "Yeni duvar kâğıdı" to "New wallpaper",
    "Bize yardımcı ol" to "Help us improve", "WXTRA destek" to "WXTRA support", "Sürüm 0.1.0" to "Version 0.1.0",
    "Sıradan duvar kâğıtlarına veda." to "Say goodbye to ordinary wallpapers."
).getOrDefault(text, text)

    "Profili düzenle" to "Edit profile", "Kaydet" to "Save", "İptal" to "Cancel",
    "Profil fotoğrafını seç" to "Choose profile photo", "Hesabına giriş yap" to "Sign in to your account",
    "Hesabını bağla ve favorilerini senkronize et." to "Connect your account and sync your favorites.",
    "G  Google ile devam et" to "G  Continue with Google", "E-posta ile devam et" to "Continue with email",
    "Vazgeç" to "Cancel", "E-posta hesabı" to "Email account", "E-posta" to "Email",
    "Şifre" to "Password", "Giriş Yap" to "Sign in", "Kayıt Ol" to "Sign up",
    "Profilim" to "My Profile", "Beğeni" to "Likes", "Koleksiyon" to "Collections", "Takipçi" to "Followers", "Takip" to "Following",
    "Güzel duvar kâğıtları, daha güzel hikâyeler." to "Beautiful wallpapers, better stories.",
    "Hesap İşlemleri" to "Account", "Google ile Giriş Yap" to "Sign in with Google", "Hesabını bağla" to "Connect your account",
    "E-posta ile Giriş Yap / Kayıt Ol" to "Sign in / Sign up with email", "Kendi hesabını oluştur" to "Create your own account",
    "Hesap Bağlı" to "Account connected", "Hesabın bu cihazda aktif" to "Your account is active on this device",
    "Hesap Bilgilerini Düzenle" to "Edit account details", "Adını ve kullanıcı adını değiştir" to "Change your name and username",
    "Veri ve Yedekleme" to "Data & Backup", "Hesabımı Yedekle" to "Back up my account", "Yedeklendi ✓" to "Backed up ✓",
    "Geri Yükle" to "Restore", "Yedekten Geri Yükle" to "Restore from backup", "Geri Yüklendi ✓" to "Restored ✓",
    "Profili Sıfırla" to "Reset profile", "Diğer İşlemler" to "Other", "Bildirim ve Uygulama Ayarları" to "Notifications & App Settings",
    "Görünüm ve kişiselleştirme" to "Appearance and personalization", "Yardım ve Destek" to "Help & Support",
    "WXTRA kullanımı hakkında" to "About using WXTRA", "Çıkış Yap" to "Sign out", "Hesaptan çıkış yap" to "Sign out of your account",
    "Oluşturduklarım" to "Created", "Son Görüntülenenler" to "Recently viewed", "Hesabını bağla" to "Connect account",
    "Duvar kâğıdı ara..." to "Search wallpapers...", "Notifications" to "Notifications",
    "Bugün" to "Today", "Senin Ruh Hâlin" to "Your Mood",
    "Günün Önerisi" to "Today's Pick", "Her duvar, başka bir sen." to "Every wall, a different you.",
    "Arama" to "Search"

private val backgroundPresets = listOf(
    listOf(Color(0xFF0B0A12), Color(0xFF3B1D5A), Color(0xFFF1E9FF)),
    listOf(Color(0xFF121016), Color(0xFF6B5140), Color(0xFFFFF5E8)),
    listOf(Color(0xFF100B18), Color(0xFF573A78), Color(0xFFF0E4FF)),
    listOf(Color(0xFF081512), Color(0xFF176B5A), Color(0xFFDFFFEF)),
    listOf(Color(0xFF170B13), Color(0xFF7B3D66), Color(0xFFFFE4F0)),
    listOf(Color(0xFF17120B), Color(0xFF7A5B2B), Color(0xFFFFF1CF)),
    listOf(Color(0xFF0A1117), Color(0xFF3A665F), Color(0xFFE4FFF8)),
    listOf(Color(0xFF0C1020), Color(0xFF493B78), Color(0xFFE5D8FF)),
    listOf(Color(0xFF111217), Color(0xFF586071), Color(0xFFF3F5FA)),
    listOf(Color(0xFF160B14), Color(0xFF8A466C), Color(0xFFFFE1EC)),
    listOf(Color(0xFF10151A), Color(0xFF52697C), Color(0xFFE9F4FF)),
    listOf(Color(0xFF160F18), Color(0xFF6C4961), Color(0xFFFFE9F2)),
    listOf(Color(0xFF080916), Color(0xFF241D4B), Color(0xFF100B25)),
    listOf(Color(0xFF10071B), Color(0xFF6B20A8), Color(0xFF1A0A38)),
    listOf(Color(0xFF080A0F), Color(0xFF1D2530), Color(0xFF050608))
)
private val backgroundNames = listOf(
    "Pure White", "Soft Beige", "Lavender Haze", "Mint Breeze", "Rose Quartz",
    "Champagne", "Sky Glow", "Aurora", "Crystal", "Sakura", "Misty Mountain",
    "Ocean Blush", "Cosmic", "Neon Dream", "Dark Pearl"
)
private val textPresets = listOf(
    Color(0xFF11111A), Color(0xFF2B2530), Color(0xFF30234A), Color(0xFF16352C), Color(0xFF4A2435),
    Color(0xFF4A3822), Color(0xFF21354A), Color(0xFF302B46), Color(0xFF25334A), Color(0xFF3E2430),
    Color(0xFF20293A), Color(0xFF4A2A22), Color(0xFFF7F3FF), Color(0xFFFFFFFF), Color(0xFFEAF1FF)
)
private val textNames = listOf(
    "Obsidian Ink", "Warm Graphite", "Lavender Ink", "Mint Ink", "Rose Ink",
    "Champagne Ink", "Sky Ink", "Crystal Ink", "Sapphire Ink", "Sakura Ink",
    "Mountain Ink", "Ocean Ink", "Pearl White", "Pure White", "Moon White"
)

private fun applyThemePreferences(context: Context) {
    val prefs = context.getSharedPreferences("wxtra_settings", Context.MODE_PRIVATE)
    appLanguage = prefs.getString("language", "tr") ?: "tr"
    val bgMode = prefs.getInt("bgMode", 0).coerceIn(0, 14)
    val textMode = prefs.getInt("textMode", 0).coerceIn(0, 14)
    val layout = prefs.getInt("layoutMode", 0).coerceIn(0, 13)
    val base = backgroundPresets[bgMode]
    Bg = base[0]
    Card = base[1].copy(alpha = 0.42f)
    Card2 = base[2].copy(alpha = 0.62f)
    Purple = Color(0xFF8A4DFF)
    Blue = Color(0xFF7C8CFF)
    Accent = Brush.linearGradient(backgroundPresets[bgMode])
    appBackgroundBrush = Brush.linearGradient(colors = backgroundPresets[bgMode])
    layoutMode = layout
}

private fun layoutColumns(): Int = when (layoutMode) {
    0, 5, 10 -> 4
    1, 6, 11 -> 3
    2, 3, 7, 8, 12 -> 2
    else -> 1
}
private fun layoutAspectRatio(): Float = when (layoutMode) {
    0, 5, 10 -> 0.74f
    1, 6, 11 -> 0.68f
    2, 7, 12 -> 0.78f
    3, 8 -> 0.66f
    4, 13 -> 0.62f
    9 -> 0.70f
    else -> 0.72f
}

private fun layoutOptionNames(): List<String> = if (appLanguage == "en") listOf(
    "4 Balanced", "3 Balanced", "2 Large", "2 Showcase", "Single Cinematic", "4 Tight", "3 Card",
    "2 Portrait", "2 Showcase+", "Single Focus", "4 Compact", "3 Airy", "2 Cinematic", "Single Portrait"
) else listOf(
    "4'lü Dengeli", "3'lü Dengeli", "2'li Büyük", "2'li Vitrin", "Tekli Sinematik", "4'lü Sıkı", "3'lü Kart",
    "2'li Portre", "2'li Vitrin+", "Tekli Odak", "4'lü Kompakt", "3'lü Ferah", "2'li Sinematik", "Tekli Portre"
)

private val wallpapers = listOf(
    R.drawable.wallpaper_0, R.drawable.wallpaper_1, R.drawable.wallpaper_2,
    R.drawable.wallpaper_3, R.drawable.wallpaper_4, R.drawable.wallpaper_5,
    R.drawable.wallpaper_6, R.drawable.wallpaper_7, R.drawable.wallpaper_8
)

private val names = listOf(
    "Renkli Kuş", "Kırmızı Dokunuş", "Saklı Bahçe", "Pembe Efsane",
    "Gece Sürüşü", "Doğanın İçinde", "Zarif Dokunuş", "Akış", "Renkli Akşamlar"
)

private sealed class Screen {
    data object Home : Screen()
    data object Explore : Screen()
    data object Favorites : Screen()
    data object Profile : Screen()
    data object Search : Screen()
    data object Notifications : Screen()
    data class Listing(val title: String, val indices: List<Int>) : Screen()
    data object Settings : Screen()
    data object About : Screen()
    data object Categories : Screen()
    data object Collections : Screen()
    data class Detail(val index: Int) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAApp() }
    }
}

@Composable
private fun WXTRAApp() {
    val context = LocalContext.current
    LaunchedEffect(Unit) { applyThemePreferences(context) }
    var backStack by remember { mutableStateOf(listOf<Screen>(Screen.Home)) }
    var search by remember { mutableStateOf("") }
    var liked by remember { mutableStateOf(setOf<Int>()) }

    val screen = backStack.last()
    fun push(next: Screen) { backStack = backStack + next }
    fun pop() {
        if (backStack.size > 1) backStack = backStack.dropLast(1)
    }
    fun selectRoot(next: Screen) { backStack = listOf(next) }

    BackHandler(enabled = backStack.size > 1) { pop() }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Purple)) {
        Box(Modifier.fillMaxSize().then(if (appBackgroundBrush != null) Modifier.background(appBackgroundBrush!!) else Modifier.background(Bg))) {
            when (val s = screen) {
                Screen.Home -> MainScaffold(0, { selectRoot(it) }, screen) {
                    HomeScreen(
                        open = { push(Screen.Detail(it)) },
                        openSearch = { push(Screen.Search) },
                        openNotifications = { push(Screen.Notifications) },
                        openListing = { title, indices -> push(Screen.Listing(title, indices)) },
                        liked = liked,
                        toggleLike = { i -> liked = if (i in liked) liked - i else liked + i },
                    )
                }
                Screen.Categories -> MainScaffold(1, { selectRoot(it) }, screen) {
                    CategoriesScreen(back = { pop() }, openListing = { title, indices -> push(Screen.Listing(title, indices)) })
                }
                Screen.Explore -> MainScaffold(2, { selectRoot(it) }, screen) {
                    ExploreScreen(
                        open = { push(Screen.Detail(it)) },
                        openCategories = { push(Screen.Categories) },
                        openSearch = { push(Screen.Search) },
                        openNotifications = { push(Screen.Notifications) },
                        openListing = { title, indices -> push(Screen.Listing(title, indices)) }
                    )
                }
                Screen.Profile -> MainScaffold(3, { selectRoot(it) }, screen) {
                    ProfileScreen(
                        liked = liked,
                        setLiked = { liked = it },
                        openFavorites = { push(Screen.Favorites) },
                        openSettings = { push(Screen.Settings) },
                        openCollections = { push(Screen.Collections) },
                        openAbout = { push(Screen.About) }
                    )
                }
                Screen.Search -> SearchScreen(search, { search = it }, { push(Screen.Detail(it)) })
                Screen.Notifications -> NotificationsScreen { pop() }
                is Screen.Listing -> ListingScreen(s.title, s.indices, { push(Screen.Detail(it)) })
                Screen.Settings -> MainScaffold(4, { selectRoot(it) }, screen) {
                    SettingsScreen { pop() }
                }
                Screen.About -> AboutScreen { pop() }
                Screen.Collections -> CollectionsScreen { pop() }
                Screen.Favorites -> FavoritesScreen(liked, { push(Screen.Detail(it)) }, toggleLike = { i -> liked = liked - i })
                is Screen.Detail -> DetailScreen(
                    index = s.index,
                    liked = s.index in liked,
                    toggleLike = { liked = if (s.index in liked) liked - s.index else liked + s.index },
                    back = { pop() },
                )
            }
        }
    }
}

@Composable
private fun MainScaffold(
    selected: Int,
    onScreen: (Screen) -> Unit,
    screen: Screen,
    content: @Composable () -> Unit
) {
    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = { BottomNav(selected) { idx ->
            onScreen(when (idx) {
                0 -> Screen.Home
                1 -> Screen.Categories
                2 -> Screen.Explore
                3 -> Screen.Profile
                else -> Screen.Settings
            })
        } }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) { content() }
    }
}

@Composable
private fun TopHeader(onSearch: () -> Unit, onProfile: () -> Unit, onNotifications: () -> Unit = {}, title: String = "WXTRA", subtitle: String = "Duvar kâğıtlarını keşfet.") {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(T(title), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = TextMain)
            Text(T(subtitle), color = TextMuted, fontSize = 13.sp)
        }
        IconButton(onClick = onSearch) { Icon(Icons.Default.Search, null, tint = TextMain) }
        IconButton(onClick = onNotifications) { Icon(Icons.Default.Notifications, null, tint = TextMain) }
        Box(Modifier.size(40.dp).clip(CircleShape).background(Accent).clickable { onProfile() }, contentAlignment = Alignment.Center) {
            Text(T("W"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun HomeScreen(
    open: (Int) -> Unit,
    openSearch: () -> Unit,
    openNotifications: () -> Unit,
    openListing: (String, List<Int>) -> Unit,
    liked: Set<Int>,
    toggleLike: (Int) -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "WXTRA", color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.Black,
                    letterSpacing = 5.sp, modifier = Modifier.weight(1f)
                )
                Box(Modifier.size(42.dp).clip(CircleShape).background(Card).clickable { openNotifications() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Notifications, contentDescription = T("Bildirimler"), tint = TextMain, modifier = Modifier.size(22.dp))
                }
            }
        }
        // Ana sayfa arama çubuğu
        item {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 5.dp).fillMaxWidth().height(50.dp).clip(RoundedCornerShape(25.dp))
                .background(Brush.horizontalGradient(listOf(Card, Card2))).clickable { openSearch() }.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = Purple, modifier = Modifier.size(21.dp)); Spacer(Modifier.width(10.dp))
                Text(T("Duvar kâğıdı ara..."), color = TextMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
            }
        }
        // Günün üst seçkisi: her gün uygulamadaki duvar kâğıtlarından 3 farklı görsel.
        // Kullanıcı yatay kaydırarak üç görselin tamamını görebilir.
        item {
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val heroPool = listOf(0, 2, 3, 4, 5, 7, 8, 1, 6)
                val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
                val startIndex = (day * 3) % heroPool.size
                val todayHeroes = List(3) { offset -> heroPool[(startIndex + offset) % heroPool.size] }
                val heroHeight = maxWidth * (622f / 853f)

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 0.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    lazyItems(todayHeroes) { heroIndex ->
                        Box(
                            Modifier
                                .width(maxWidth)
                                .height(heroHeight)
                                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                                .clickable { open(heroIndex) }
                        ) {
                            Image(
                                painter = painterResource(wallpapers[heroIndex]),
                                contentDescription = "Günün önerisi",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            Box(
                                Modifier.fillMaxSize().background(
                                    Brush.verticalGradient(
                                        listOf(Color.Black.copy(alpha = 0.08f), Color.Black.copy(alpha = 0.78f))
                                    )
                                )
                            )
                            Column(
                                Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(start = 24.dp, end = 24.dp, bottom = 22.dp)
                            ) {
                                Text(T("GÜNÜN ÖNERİSİ"), color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(T("Geceye Farklı Bak"), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                                Text(T("Her duvar, başka bir sen."), color = Color.White.copy(alpha = 0.86f), fontSize = 13.sp)
                                Row(
                                    Modifier.padding(top = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier
                                            .clip(RoundedCornerShape(50))
                                            .background(Color.Black.copy(alpha = 0.45f))
                                            .padding(horizontal = 13.dp, vertical = 7.dp)
                                    ) {
                                        Text(T("Keşfet  →"), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(Modifier.weight(1f))
                                    Text(
                                        "${todayHeroes.indexOf(heroIndex) + 1} / 3",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Ana sayfa kategorileri
        item {
            LazyRow(
                Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                lazyItems(listOf(2 to "Doğa", 3 to "Anime", 4 to "Arabalar", 8 to "Uzay")) { item ->
                    CategoryTile(
                        item.first,
                        item.second,
                        Modifier.width(138.dp).height(112.dp),
                        open = { open(item.first) }
                    )
                }
            }
        }

        item {
            SectionTitle("🔥  Popüler Şu An", "Tümünü Gör") {
                openListing("Popüler Şu An", listOf(4, 0, 3, 2, 8, 5))
            }
        }
        item { WallpaperRow(listOf(4, 0, 3, 2, 8, 5), open, liked, toggleLike) }

        item {
            SectionTitle("✨  Senin Ruh Hâlin", "Tümünü Gör") {
                openListing("Senin Ruh Hâlin", listOf(2, 8, 4, 7, 6, 1))
            }
        }
        item { WallpaperRow(listOf(2, 8, 4, 7, 6, 1), open, liked, toggleLike) }

        item {
            SectionTitle("🎨  Senin İçin Seçtiklerimiz", "Tümünü Gör") {
                openListing("Senin İçin Seçtiklerimiz", listOf(3, 0, 4, 7, 8, 2))
            }
        }
        item { WallpaperRow(listOf(3, 0, 4, 7, 8, 2), open, liked, toggleLike) }

        // Alt tanıtım bannerı
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(128.dp)
                    .padding(horizontal = 18.dp, vertical = 18.dp)
                    .clip(RoundedCornerShape(24.dp))
            ) {
                Image(painterResource(R.drawable.home_banner), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF180B2A).copy(.94f), Color.Transparent))))
                Column(Modifier.align(Alignment.CenterStart).padding(start = 18.dp)) {
                    Text(T("WXTRA İLE"), color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(T("Daha Fazlasını Hisset"), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Text(T("Senin tarzın. Senin duvarın. Senin hikayen."), color = Color.White.copy(.78f), fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
                }
            }
        }
    }
}

@Composable
private fun WallpaperRow(indices: List<Int>, open: (Int) -> Unit, liked: Set<Int>, toggleLike: (Int) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val count = layoutColumns().coerceAtLeast(1)
        val cardWidth = if (count == 1) (maxWidth - 36.dp) else ((maxWidth - 36.dp - 12.dp * (count - 1)) / count.toFloat()).coerceAtLeast(56.dp)
        LazyRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            lazyItems(indices) { i ->
                ImageCard(
                    index = i,
                    open = open,
                    liked = i in liked,
                    onLike = { toggleLike(i) },
                    modifier = Modifier.width(cardWidth)
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(T(title), color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        action?.let { Text(T(it), color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onAction?.invoke() }) }
    }
}

@Composable
private fun SearchBar(value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier, readOnly: Boolean = false) {
    OutlinedTextField(value = value, onValueChange = onValue, readOnly = readOnly, modifier = modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text(T("Duvar kağıdı ara…")) }, colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Card, focusedContainerColor = Card2, unfocusedBorderColor = Color.Transparent, focusedBorderColor = Purple))
}

@Composable
private fun Pill(text: String, selected: Boolean = false) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(if (selected) Purple else Card2).padding(horizontal = 16.dp, vertical = 10.dp)) { Text(T(text), color = Color.White, fontSize = 12.sp) }
}

@Composable
private fun ChipRow(chips: List<String>) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (chips.isNotEmpty()) Pill(chips[0], selected = true)
        for (i in 1 until chips.size) Pill(chips[i], selected = false)
    }
}

@Composable
private fun CategoryTile(index: Int, title: String, modifier: Modifier, open: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(18.dp)).clickable { open() }) {
        Image(painterResource(wallpapers[index]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.7f)))))
        Text(T(title), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomStart).padding(12.dp))
    }
}

@Composable
private fun ProfileAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp).clip(RoundedCornerShape(16.dp)).background(Card).clickable { onClick() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = TextMain)
        Text(T(title), color = TextMain, modifier = Modifier.weight(1f).padding(start = 14.dp))
        Icon(Icons.Default.ArrowForward, null, tint = TextMuted)
    }
}

@Composable
private fun SettingsSection(title: String, items: List<String>) {
    Text(T(title), color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp))
    if (items.isNotEmpty()) SettingsRow(items[0])
    if (items.size > 1) SettingsRow(items[1])
    if (items.size > 2) SettingsRow(items[2])
    if (items.size > 3) SettingsRow(items[3])
} 

@Composable
private fun SettingsRow(item: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(Card).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(T(item), color = TextMain, modifier = Modifier.weight(1f)); Text(T("›"), color = TextMuted)
    }
}

@Composable
private fun CollectionCard(title: String, index: Int) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp).clip(RoundedCornerShape(18.dp)).background(Card).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(wallpapers[index]), null, Modifier.size(74.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
        Column(Modifier.padding(start = 12.dp)) { Text(T(title), color = TextMain, fontWeight = FontWeight.Bold); Text(T("Sizin için özel seçildi."), color = TextMuted, fontSize = 12.sp) }
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(T(value), color = TextMain, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(T(label), color = TextMuted, fontSize = 11.sp) }
}

@Composable
private fun TopBar(title: String, back: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 34.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(T(title), color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xF2090C16)) {
        NavigationBarItem(
            selected = selected == 0,
            onClick = { onSelect(0) },
            icon = { Icon(Icons.Default.Home, null) },
            label = { Text(L("Anasayfa", "Home")) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 1,
            onClick = { onSelect(1) },
            icon = { Icon(Icons.Default.Wallpaper, null) },
            label = { Text(L("Kategori", "Categories")) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 2,
            onClick = { onSelect(2) },
            icon = { Icon(Icons.Default.Explore, null) },
            label = { Text(L("Keşfet", "Explore")) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 3,
            onClick = { onSelect(3) },
            icon = { Icon(Icons.Default.Person, null) },
            label = { Text(L("Profil", "Profile")) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 4,
            onClick = { onSelect(4) },
            icon = { Icon(Icons.Default.Settings, null) },
            label = { Text(L("Ayarlar", "Settings")) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
    }
}

@Composable
private fun ImageCard(
    index: Int,
    open: (Int) -> Unit,
    liked: Boolean,
    onLike: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.clickable { open(index) }) {
        Box(Modifier.fillMaxWidth().aspectRatio(layoutAspectRatio()).clip(RoundedCornerShape(16.dp))) {
            Image(painterResource(wallpapers[index]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            IconButton(onClick = onLike, modifier = Modifier.align(Alignment.TopEnd)) {
                Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (liked) Color(0xFFFF4D72) else Color.White)
            }
        }
        Text(T(names[index]), color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp))
    }
}

@Composable
private fun CollectionHomeCard(index: Int, title: String, open: (Int) -> Unit) {
    Box(Modifier.width(210.dp).height(120.dp).clip(RoundedCornerShape(18.dp)).clickable { open(index) }) {
        Image(painterResource(wallpapers[index]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.8f)))))
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            Text(T(title), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(T("Özel seçki"), color = Color.White.copy(.75f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun ExploreImageRow(indices: List<Int>, open: (Int) -> Unit, columns: Int) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val gap = 10.dp
        val totalGap = gap * (columns - 1)
        val cardWidth = ((maxWidth - 36.dp - totalGap) / columns.toFloat()).coerceAtLeast(72.dp)
        LazyRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(gap)) {
            lazyItems(indices) { i ->
                ImageCard(i, open, false, {}, Modifier.width(cardWidth))
            }
        }
    }
}

@Composable
private fun ExploreScreen(open: (Int) -> Unit, openCategories: () -> Unit, openSearch: () -> Unit, openNotifications: () -> Unit, openListing: (String, List<Int>) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(T("Keşfet"), fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = TextMain)
                    Text(T("Sıradan duvar kâğıtlarının ötesine geç."), color = TextMuted, fontSize = 13.sp)
                }
                IconButton(onClick = openNotifications) { Icon(Icons.Default.Notifications, null, tint = TextMain) }
            }
        }
        item {
            Box(Modifier.padding(horizontal = 18.dp, vertical = 8.dp).fillMaxWidth().height(150.dp).clip(RoundedCornerShape(22.dp)).clickable { open(2) }) {
                Image(painterResource(wallpapers[2]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(.78f), Color.Transparent))))
                Column(Modifier.align(Alignment.CenterStart).padding(18.dp)) {
                    Text(T("YENİ UFUKLAR"), color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(T("Farklı Dünyaları Keşfet"), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 4.dp))
                    Text(T("Her ekran, yeni bir hikâye."), color = Color.White.copy(.82f), fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
                    Box(Modifier.padding(top = 10.dp).clip(RoundedCornerShape(50)).background(Purple.copy(.95f)).padding(horizontal = 14.dp, vertical = 8.dp)) {
                        Text(T("Keşfetmeye Başla →"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }
        item { SectionTitle("🔥 Popüler Şu An", "Tümünü Gör") { openListing("Popüler Şu An", listOf(4, 3, 5, 8, 2, 7)) } }
        item { ExploreImageRow(listOf(4, 3, 5), open, 3) }
        item { SectionTitle("✨ Yeni Gelenler", "Tümünü Gör") { openListing("Yeni Gelenler", listOf(0, 6, 7, 8, 1, 5)) } }
        item { ExploreImageRow(listOf(0, 6, 7, 8), open, 4) }
        item { SectionTitle("📈 Yükselenler", "Tümünü Gör") { openListing("Yükselenler", listOf(7, 3, 5, 2, 4)) } }
        item { ExploreImageRow(listOf(7, 3, 5, 2), open, 4) }
        item { SectionTitle("🎨 Tarzına Göre", "Tümünü Gör") { openCategories() } }
        item {
            LazyRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                lazyItems(listOf(3 to "Anime", 5 to "Doğa", 2 to "Uzay", 4 to "Arabalar", 7 to "Minimal", 8 to "Karanlık", 0 to "Renkli")) { item ->
                    CategoryTile(item.first, item.second, Modifier.size(width = 112.dp, height = 90.dp)) { open(item.first) }
                }
            }
        }
        item { SectionTitle("👑 Haftanın Seçimleri", "Tümünü Gör") { openListing("Haftanın Seçimleri", listOf(3, 7, 5, 2, 8)) } }
        item {
            Box(Modifier.padding(horizontal = 18.dp).fillMaxWidth().height(132.dp).clip(RoundedCornerShape(20.dp)).clickable { open(3) }) {
                Image(painterResource(wallpapers[3]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(.78f), Color.Transparent))))
                Column(Modifier.align(Alignment.CenterStart).padding(16.dp)) {
                    Text(T("Bu Haftanın Özel Seçkisi"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    Text(T("WXTRA ekibinin seçtiği favoriler."), color = Color.White.copy(.8f), fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                }
            }
        }
        item { SectionTitle("👤 Senin İçin", "Tümünü Gör") { openListing("Senin İçin", listOf(4, 3, 0, 5, 7)) } }
        item { ExploreImageRow(listOf(4, 3, 0, 5), open, 4) }
    }
}

@Composable
private fun FavoritesScreen(liked: Set<Int>, open: (Int) -> Unit, toggleLike: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar(L("Favoriler","Favorites"), { }) }
        if (liked.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(50.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FavoriteBorder, null, tint = Purple, modifier = Modifier.size(54.dp))
                    Text(T("Henüz favorin yok"), color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp))
                    Text(T("Beğendiğin duvar kâğıtları burada görünecek."), color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        } else {
            item {
                LazyVerticalGrid(columns = GridCells.Fixed(layoutColumns()), modifier = Modifier.height(560.dp), contentPadding = PaddingValues(18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    gridItems(liked.toList()) { i -> ImageCard(i, open, true, { toggleLike(i) }, Modifier.fillMaxWidth()) }
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen(
    liked: Set<Int>,
    setLiked: (Set<Int>) -> Unit,
    openFavorites: () -> Unit,
    openSettings: () -> Unit,
    openCollections: () -> Unit,
    openAbout: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("wxtra_profile", Context.MODE_PRIVATE) }
    var signedIn by remember { mutableStateOf(prefs.getBoolean("signedIn", false)) }
    var accountEmail by remember { mutableStateOf(prefs.getString("email", "") ?: "") }
    var displayName by remember { mutableStateOf(prefs.getString("name", "wextra") ?: "wextra") }
    var username by remember { mutableStateOf(prefs.getString("username", "wextra") ?: "wextra") }
    var avatarIndex by remember { mutableStateOf(prefs.getInt("avatar", 3).coerceIn(wallpapers.indices)) }
    var showLogin by remember { mutableStateOf(false) }
    var showEmailLogin by remember { mutableStateOf(false) }
    var showEditProfile by remember { mutableStateOf(false) }
    var showAvatarPicker by remember { mutableStateOf(false) }
    var showBackupInfo by remember { mutableStateOf(false) }
    var emailInput by remember { mutableStateOf(accountEmail) }
    var passwordInput by remember { mutableStateOf("") }
    var backupDone by remember { mutableStateOf(false) }
    var restoreDone by remember { mutableStateOf(false) }

    fun saveProfile() {
        prefs.edit()
            .putBoolean("signedIn", signedIn)
            .putString("email", accountEmail)
            .putString("name", displayName)
            .putString("username", username)
            .putInt("avatar", avatarIndex)
            .apply()
    }

    if (showLogin) {
        AlertDialog(
            onDismissRequest = { showLogin = false },
            title = { Text(T("Hesabına giriş yap"), color = TextMain) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(T("Hesabını bağla ve favorilerini senkronize et."), color = TextMuted)
                    Button(
                        onClick = {
                            signedIn = true
                            accountEmail = "Google hesabı"
                            saveProfile()
                            showLogin = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                    ) { Text(T("G  Google ile devam et"), fontWeight = FontWeight.Bold) }
                    OutlinedButton(onClick = { showEmailLogin = true; showLogin = false }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Email, null); Spacer(Modifier.width(8.dp)); Text(T("E-posta ile devam et"))
                    }
                    TextButton(onClick = { showLogin = false }) { Text(T("Vazgeç"), color = TextMuted) }
                }
            },
            confirmButton = {}, dismissButton = {}, containerColor = Card2
        )
    }

    if (showEmailLogin) {
        AlertDialog(
            onDismissRequest = { showEmailLogin = false },
            title = { Text(T("E-posta hesabı"), color = TextMain) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = emailInput, onValueChange = { emailInput = it }, label = { Text(T("E-posta")) }, singleLine = true)
                    OutlinedTextField(value = passwordInput, onValueChange = { passwordInput = it }, label = { Text(T("Şifre")) }, singleLine = true)
                    Text(T("Bu sürümde hesap bilgileri cihaz üzerinde yerel olarak saklanır."), color = TextMuted, fontSize = 11.sp)
                    Button(
                        onClick = {
                            if (emailInput.contains("@") && passwordInput.length >= 4) {
                                signedIn = true
                                accountEmail = emailInput.trim()
                                saveProfile()
                                showEmailLogin = false
                                passwordInput = ""
                            }
                        }, modifier = Modifier.fillMaxWidth()
                    ) { Text(T("Giriş Yap / Kayıt Ol")) }
                }
            },
            confirmButton = {}, containerColor = Card2
        )
    }

    if (showEditProfile) {
        AlertDialog(
            onDismissRequest = { showEditProfile = false },
            title = { Text(T("Profili düzenle"), color = TextMain) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = displayName, onValueChange = { displayName = it }, label = { Text(T("Ad")) }, singleLine = true)
                    OutlinedTextField(value = username, onValueChange = { username = it.filter { c -> c.isLetterOrDigit() || c == '_' } }, label = { Text(T("Kullanıcı adı")) }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = { saveProfile(); showEditProfile = false }) { Text(T("Kaydet"), color = Purple) }
            },
            dismissButton = { TextButton(onClick = { showEditProfile = false }) { Text(T("İptal"), color = TextMuted) } },
            containerColor = Card2
        )
    }

    if (showAvatarPicker) {
        AlertDialog(
            onDismissRequest = { showAvatarPicker = false },
            title = { Text(T("Profil fotoğrafını seç"), color = TextMain) },
            text = {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.height(260.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    gridItems(wallpapers.indices.toList()) { i ->
                        Image(
                            painterResource(wallpapers[i]), null,
                            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)).clickable {
                                avatarIndex = i
                                saveProfile()
                                showAvatarPicker = false
                            },
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            },
            confirmButton = {}, containerColor = Card2
        )
    }

    if (showBackupInfo) {
        AlertDialog(
            onDismissRequest = { showBackupInfo = false },
            title = { Text(T("Yedekleme"), color = TextMain) },
            text = { Text(T("Favoriler ve profil bilgilerin bu cihazdaki WXTRA yedeğine kaydedildi. Gerçek bulut senkronizasyonu için ileride bir hesap sunucusu bağlanabilir."), color = TextMuted) },
            confirmButton = { TextButton(onClick = { showBackupInfo = false }) { Text(L("Tamam","Done"), color = Purple) } },
            containerColor = Card2
        )
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 30.dp)) {
        item {
            Box(Modifier.fillMaxWidth().height(250.dp)) {
                Image(painterResource(wallpapers[avatarIndex]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(.10f), Bg.copy(.98f)))))
                Row(Modifier.align(Alignment.TopEnd).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = { showEditProfile = true }) {
                        Icon(Icons.Default.Edit, null, tint = Color.White)
                    }
                    IconButton(onClick = openSettings) {
                        Icon(Icons.Default.Settings, null, tint = Color.White)
                    }
                }
                Row(Modifier.align(Alignment.BottomStart).padding(horizontal = 22.dp, vertical = 18.dp), verticalAlignment = Alignment.Bottom) {
                    Box(Modifier.size(92.dp).clip(CircleShape).background(Accent).clickable { showAvatarPicker = true }, contentAlignment = Alignment.Center) {
                        Image(painterResource(wallpapers[avatarIndex]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Box(Modifier.align(Alignment.BottomEnd).size(30.dp).clip(CircleShape).background(Card2), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Edit, null, tint = TextMain, modifier = Modifier.size(16.dp))
                        }
                    }
                    Column(Modifier.padding(start = 14.dp).weight(1f)) {
                        Text(displayName + if (signedIn) "  ✓" else "", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text(if (signedIn) accountEmail else "@$username", color = TextMuted, fontSize = 13.sp)
                        Text(T("Güzel duvar kâğıtları, daha güzel hikâyeler."), color = TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 8.dp).clip(RoundedCornerShape(18.dp)).background(Card).padding(vertical = 13.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat(liked.size.toString(), "Beğeni"); Stat("8", "Koleksiyon"); Stat("0", "Takipçi"); Stat("0", "Takip")
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp).clip(RoundedCornerShape(18.dp)).background(Accent).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(T("👑"), fontSize = 30.sp)
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(T("WXTRA Pro"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(T("Daha fazla özellik, daha fazla özgürlük."), color = Color.White.copy(.78f), fontSize = 12.sp)
                }
                Text(T("Yakında  ›"), color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ProfileMini("♡", "Favorilerim") { openFavorites() }
                ProfileMini("▣", "Koleksiyonlarım", openCollections)
                ProfileMini("▧", "Oluşturduklarım") { showBackupInfo = true }
                ProfileMini("◷", "Son Görüntülenenler") { showBackupInfo = true }
            }
        }
        item { ProfileSectionTitle("Hesap İşlemleri", Icons.Default.Person) }
        item {
            if (!signedIn) {
                ProfileLargeAction("Google ile Giriş Yap", "Hesabını bağla", "G", { showLogin = true })
                ProfileLargeAction("E-posta ile Giriş Yap / Kayıt Ol", "Kendi hesabını oluştur", "✉", { showEmailLogin = true })
            } else {
                ProfileLargeAction("Hesap Bağlı", accountEmail.ifBlank { "Hesabın bu cihazda aktif" }, "✓", { showEditProfile = true })
                ProfileLargeAction("Hesap Bilgilerini Düzenle", "Adını ve kullanıcı adını değiştir", "✎", { showEditProfile = true })
            }
        }
        item { ProfileSectionTitle("Veri ve Yedekleme", Icons.Default.CloudUpload) }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ProfileMini("☁↑", if (backupDone) "Yedeklendi ✓" else "Hesabımı Yedekle") {
                    prefs.edit().putString("liked", liked.sorted().joinToString(",")).apply()
                    saveProfile(); backupDone = true; restoreDone = false; showBackupInfo = true
                }
                ProfileMini("☁↓", if (restoreDone) "Geri Yüklendi ✓" else "Yedekten Geri Yükle") {
                    val saved = prefs.getString("liked", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.filter { it in wallpapers.indices }.toSet()
                    setLiked(saved); restoreDone = true; backupDone = false
                }
                ProfileMini("⟳", "Profili Sıfırla") {
                    displayName = "wextra"; username = "wextra"; avatarIndex = 3; saveProfile()
                }
            }
        }
        item { ProfileSectionTitle("Diğer İşlemler", Icons.Default.Settings) }
        item {
            ProfileLargeAction("Bildirim ve Uygulama Ayarları", "Görünüm ve kişiselleştirme", "⚙", openSettings)
            ProfileLargeAction("Yardım ve Destek", "WXTRA kullanımı hakkında", "?", { showBackupInfo = true })
            if (signedIn) ProfileLargeAction("Çıkış Yap", "Hesaptan çıkış yap", "↪", {
                signedIn = false; accountEmail = ""; saveProfile()
            }, destructive = true)
        }
        item { ProfileAction("WXTRA Hakkında", Icons.Default.Info, openAbout) }
    }
}

@Composable
private fun ProfileSectionTitle(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.padding(horizontal = 22.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Purple, modifier = Modifier.size(25.dp))
        Text(T(title), color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp))
    }
}

@Composable
private fun RowScope.ProfileMini(label: String, title: String, onClick: () -> Unit = {}) {
    Column(
        Modifier.weight(1f).height(102.dp).clip(RoundedCornerShape(17.dp)).background(Card).clickable { onClick() }.padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(label, color = Purple, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(T(title), color = TextMain, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp))
    }
}

@Composable
private fun ProfileLargeAction(title: String, subtitle: String, mark: String, onClick: () -> Unit, destructive: Boolean = false) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 2.dp).clip(RoundedCornerShape(13.dp)).background(Card).clickable { onClick() }.padding(horizontal = 15.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(36.dp), contentAlignment = Alignment.Center) { Text(mark, color = if (destructive) Color(0xFFFF4D5F) else TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(T(title), color = if (destructive) Color(0xFFFF4D5F) else TextMain, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(T(subtitle), color = TextMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.ArrowForward, null, tint = if (destructive) Color(0xFFFF4D5F) else TextMuted, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun SearchScreen(value: String, onValue: (String) -> Unit, open: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp)) {
        item { TopBar(L("Ara","Search"), { }) }
        item { SearchBar(value, onValue, Modifier.padding(bottom = 18.dp)) }
        val results = if (value.isBlank()) (0..8).toList() else (0..8).filter { names[it].contains(value, true) }
        item {
            if (results.isEmpty()) Text(T("Sonuç bulunamadı."), color = TextMuted, modifier = Modifier.padding(20.dp))
            else LazyVerticalGrid(columns = GridCells.Fixed(layoutColumns()), modifier = Modifier.height(600.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                gridItems(results) { i -> ImageCard(i, open, false, {}, Modifier.fillMaxWidth()) }
            }
        }
    }
}

@Composable
private fun NotificationsScreen(back: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar(L("Bildirimler","Notifications"), back) }
        item {
            Column(Modifier.padding(18.dp).clip(RoundedCornerShape(18.dp)).background(Card).padding(18.dp)) {
                Icon(Icons.Default.Notifications, null, tint = Purple, modifier = Modifier.size(30.dp))
                Text(T("WXTRA'ya hoş geldin!"), color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                Text(T("Yeni duvar kâğıtları ve koleksiyonlar burada görünecek."), color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
            }
        }
    }
}

@Composable
private fun ListingScreen(title: String, indices: List<Int>, open: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar(title, { }) }
        item {
            LazyVerticalGrid(columns = GridCells.Fixed(layoutColumns()), modifier = Modifier.height(720.dp), contentPadding = PaddingValues(18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                gridItems(indices) { i -> ImageCard(i, open, false, {}, Modifier.fillMaxWidth()) }
            }
        }
    }
}

private fun cacheSizeBytes(file: java.io.File): Long {
    if (!file.exists()) return 0L
    return if (file.isFile) file.length() else file.listFiles()?.sumOf { cacheSizeBytes(it) } ?: 0L
}

@Composable
private fun SettingsScreen(back: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("wxtra_settings", Context.MODE_PRIVATE) }
    var notifications by remember { mutableStateOf(prefs.getBoolean("notifications", true)) }
    var dailyWallpaper by remember { mutableStateOf(prefs.getBoolean("dailyWallpaper", true)) }
    var recommendations by remember { mutableStateOf(prefs.getBoolean("recommendations", true)) }
    var language by remember { mutableStateOf(prefs.getString("language", "tr") ?: "tr") }
    var bgMode by remember { mutableStateOf(prefs.getInt("bgMode", 0).coerceIn(0, 14)) }
    var textMode by remember { mutableStateOf(prefs.getInt("textMode", 0).coerceIn(0, 14)) }
    var layout by remember { mutableStateOf(prefs.getInt("layoutMode", 0).coerceIn(0, 13)) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var infoDialog by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        applyThemePreferences(context)
    }
    fun save(key: String, value: Any) {
        prefs.edit().apply {
            when (value) {
                is Boolean -> putBoolean(key, value)
                is Int -> putInt(key, value)
                is String -> putString(key, value)
            }
        }.apply()
        refresh()
    }

    when (dialog) {
        "background" -> ChoiceDialog(L("Tema Arka Planı","Theme Background"), backgroundNames, bgMode, {
            bgMode = it; save("bgMode", it); dialog = null
        }) { dialog = null }
        "text" -> ChoiceDialog(L("Tema Yazı Rengi","Theme Text Color"), textNames, textMode, {
            textMode = it; save("textMode", it); dialog = null
        }) { dialog = null }
        "layout" -> ChoiceDialog(L("Tema Dizilimi","Theme Layout"), layoutOptionNames(), layout, {
            layout = it; save("layoutMode", it); dialog = null
        }) { dialog = null }
        "language" -> ChoiceDialog(L("Dil","Language"), listOf("Türkçe", "English"), if (language == "tr") 0 else 1, {
            language = if (it == 0) "tr" else "en"; appLanguage = language; save("language", language); dialog = null
            Toast.makeText(context, if (language == "tr") "Dil Türkçe olarak ayarlandı" else "Language set to English", Toast.LENGTH_SHORT).show()
        }) { dialog = null }
        null -> Unit
    }

    infoDialog?.let { message ->
        AlertDialog(
            onDismissRequest = { infoDialog = null },
            title = { Text(message.substringBefore("\n\n"), color = TextMain, fontWeight = FontWeight.Bold) },
            text = { Text(message.substringAfter("\n\n", ""), color = TextMuted, lineHeight = 20.sp) },
            confirmButton = { TextButton(onClick = { infoDialog = null }) { Text(L("Tamam","Done"), color = Purple) } },
            containerColor = Card2
        )
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { TopBar(L("Ayarlar","Settings"), back) }
        item { Text(L("GÖRÜNÜM","APPEARANCE"), color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) }
        item { SettingsActionRow(L("Tema Arka Planı","Theme Background"), backgroundNames[bgMode]) { dialog = "background" } }
        item { SettingsActionRow(L("Tema Yazı Rengi","Theme Text Color"), textNames[textMode]) { dialog = "text" } }
        item { SettingsActionRow(L("Tema Dizilimi","Theme Layout"), layoutOptionNames()[layout]) { dialog = "layout" } }

        item { Text(L("BİLDİRİMLER","NOTIFICATIONS"), color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) }
        item { SettingsSwitchRow(L("Bildirimler","Notifications"), L("Uygulama bildirimleri","App notifications"), notifications) { notifications = it; save("notifications", it) } }
        item { SettingsSwitchRow(L("Günlük yeni duvar kâğıdı","Daily new wallpaper"), L("Günlük öneri bildirimi","Daily wallpaper notification"), dailyWallpaper) { dailyWallpaper = it; save("dailyWallpaper", it) } }
        item { SettingsSwitchRow(L("Öneriler","Recommendations"), L("Kişiselleştirilmiş öneriler","Personalized recommendations"), recommendations) { recommendations = it; save("recommendations", it) } }

        item { Text(L("UYGULAMA","APP"), color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) }
        item { SettingsActionRow(L("Dil","Language"), if (language == "tr") "Türkçe" else "English") { dialog = "language" } }
        item { SettingsActionRow(L("Önbellek","Cache"), L("Temizle","Clear")) {
            val cache = context.cacheDir
            val before = cacheSizeBytes(cache)
            cache.listFiles()?.forEach { it.deleteRecursively() }
            val after = cacheSizeBytes(cache)
            Toast.makeText(context, if (appLanguage == "en") "Cache cleared • ${(before / 1024 / 1024)} MB → ${(after / 1024 / 1024)} MB" else "Önbellek temizlendi • ${(before / 1024 / 1024)} MB → ${(after / 1024 / 1024)} MB", Toast.LENGTH_LONG).show()
        } }
        item { SettingsActionRow(L("Ayarları varsayılana döndür","Reset settings to default"), "Sıfırla") {
            prefs.edit().clear().apply(); notifications = true; dailyWallpaper = true; recommendations = true; language = "tr"; bgMode = 0; textMode = 0; layout = 0; refresh()
            Toast.makeText(context, "Ayarlar varsayılana döndürüldü", Toast.LENGTH_SHORT).show()
        } }

        item { Text(L("DESTEK","SUPPORT"), color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) }
        item { SettingsActionRow(L("Sorun bildir","Report a problem"), "Bize yardımcı ol") { infoDialog = "Sorun Bildir\n\nKarşılaştığın sorunu ve mümkünse ekran görüntüsünü WXTRA destek ekibine iletebilirsin.\n\ndestek@wxtra.app" } }
        item { SettingsActionRow(L("Bize ulaş","Contact us"), "WXTRA destek") { infoDialog = "Bize Ulaş\n\nE-posta: destek@wxtra.app\n\nMesajında cihaz modelini ve uygulama sürümünü belirtmen sorunu daha hızlı çözmemize yardımcı olur." } }

        item { Text(L("HAKKIMDA","ABOUT"), color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) }
        item { SettingsActionRow(L("WXTRA hakkında","About WXTRA"), "Sürüm ve bilgiler") { infoDialog = "WXTRA hakkında\n\nDuvar kâğıtlarını keşfetmek ve telefonunu kişiselleştirmek için tasarlanan WXTRA.\n\nSürüm 0.1.0" } }
        item { SettingsActionRow(L("Gizlilik politikası","Privacy Policy"), "Veri ve gizlilik") { infoDialog = "Gizlilik Politikası\n\nWXTRA, uygulama ayarlarını ve yerel profil verilerini cihazında saklar. Hesap senkronizasyonu için sunucu bağlantısı ayrıca yapılandırılır.\n\nBu ekran bilgilendirme amaçlıdır." } }
        item { SettingsActionRow(L("Kullanım koşulları","Terms of Use"), "Kurallar") { infoDialog = "Kullanım Koşulları\n\nWXTRA içeriğini yalnızca yasal amaçlarla kullan. Uygulamadaki içeriklerin kullanım haklarına ve üçüncü taraf hizmetlerin koşullarına uy." } }
        item { SettingsActionRow(L("Sürüm bilgisi","Version info"), "0.1.0") { infoDialog = "Sürüm 0.1.0\n\nWXTRA Android uygulamasının mevcut geliştirme sürümü." } }
    }
}

@Composable
private fun SettingsActionRow(title: String, value: String, enabled: Boolean = true, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(Card).clickable(enabled = enabled) { onClick() }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(T(title), color = if (enabled) TextMain else TextMuted, modifier = Modifier.weight(1f))
        Text(T(value), color = TextMuted, fontSize = 12.sp)
        Spacer(Modifier.width(7.dp)); Text(T("›"), color = TextMuted)
    }
}

@Composable
private fun SettingsSwitchRow(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(Card).padding(horizontal = 15.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(T(title), color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(T(subtitle), color = TextMuted, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked, colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Purple))
    }
}

@Composable
private fun ChoiceDialog(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(T(title), color = TextMain, fontWeight = FontWeight.Bold) },
        text = { LazyColumn(
            modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(options.size) { index ->
                val option = options[index]
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (selected == index) Purple.copy(.18f) else Card).clickable { onSelect(index) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = selected == index, onClick = { onSelect(index) }, colors = RadioButtonDefaults.colors(selectedColor = Purple))
                    Text(option, color = TextMain, modifier = Modifier.padding(start = 6.dp))
                }
            }
        } },
        confirmButton = {},
        containerColor = Card2
    )
}

@Composable
private fun AboutScreen(back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        TopBar(L("WXTRA Hakkında","About WXTRA"), back)
        Spacer(Modifier.height(30.dp))
        Text(T("Sıradan duvar kâğıtlarına veda."), color = Purple, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Text(T("Her gün yeni bir hikâye. WXTRA, telefonunu kişiselleştirmek için seçilmiş duvar kâğıtlarını tek yerde sunar."), color = TextMuted, fontSize = 14.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 14.dp))
        Text(T("Sürüm 0.1.0"), color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 30.dp))
    }
}

@Composable
private fun CategoriesScreen(back: () -> Unit, openListing: (String, List<Int>) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar(L("Kategoriler","Categories"), back) }
        item {
            val cats = listOf(
                Triple(0, "Doğa", listOf(2, 5, 8)), Triple(1, "Şehir", listOf(1, 4, 7)),
                Triple(2, "Uzay", listOf(0, 2, 7)), Triple(3, "Anime", listOf(3, 8, 1)),
                Triple(4, "Gece", listOf(4, 7, 2)), Triple(5, "Minimal", listOf(5, 6, 2)),
                Triple(6, "Sanat", listOf(6, 3, 0)), Triple(7, "Karanlık", listOf(4, 7, 3)),
                Triple(8, "Renkli", listOf(0, 1, 8))
            )
            LazyVerticalGrid(columns = GridCells.Fixed(layoutColumns()), modifier = Modifier.height(680.dp), contentPadding = PaddingValues(18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                gridItems(cats) { item ->
                    CategoryTile(item.first, item.second, Modifier.fillMaxWidth().height(145.dp)) {
                        openListing(item.second, item.third)
                    }
                }
            }
        }
    }
}

@Composable
private fun CollectionsScreen(back: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar("Koleksiyonlarım", back) }
        item { CollectionCard("4K Ultra HD", 0) }
        item { CollectionCard("Etkileyici Manzaralar", 2) }
        item { CollectionCard("Karanlık Mod", 7) }
        item { CollectionCard("Anime Dünyası", 8) }
    }
}

@Composable
private fun DetailScreen(index: Int, liked: Boolean, toggleLike: () -> Unit, back: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var applied by remember { mutableStateOf(false) }
    var applying by remember { mutableStateOf(false) }
    var showWallpaperChoice by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (showWallpaperChoice) {
        AlertDialog(
            onDismissRequest = { if (!applying) showWallpaperChoice = false },
            title = { Text(T("Duvar Kâğıdını Nereye Uygula?"), color = TextMain, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(T("İki ekrana birden otomatik uygulanmayacak. Bir seçenek seç:"), color = TextMuted, fontSize = 12.sp)
                    listOf("Ana ekran" to WallpaperManager.FLAG_SYSTEM, "Kilit ekranı" to WallpaperManager.FLAG_LOCK, "Ana ekran + Kilit ekranı" to (WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)).forEach { (label, flag) ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Card).clickable(enabled = !applying) {
                            applying = true
                            scope.launch {
                                val success = withContext(Dispatchers.IO) {
                                    try {
                                        val wm = WallpaperManager.getInstance(context)
                                        val drawable = androidx.core.content.ContextCompat.getDrawable(context, wallpapers[index])
                                        if (drawable is BitmapDrawable) {
                                            wm.setBitmap(drawable.bitmap, null, true, flag)
                                            true
                                        } else false
                                    } catch (_: Exception) { false }
                                }
                                applied = success
                                applying = false
                                showWallpaperChoice = false
                            }
                        }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Wallpaper, null, tint = Purple)
                            Text(T(label), color = TextMain, modifier = Modifier.padding(start = 12.dp))
                        }
                    }
                }
            },
            confirmButton = {},
            containerColor = Card2
        )
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(painterResource(wallpapers[index]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(.10f), Color.Transparent, Color.Black.copy(.58f)))))

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp)) {
            Text(names[index], color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp))
            Text(T("WXTRA seçkisi  •  Telefonuna uygun"), color = Color.White.copy(.82f), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
            Row(
                Modifier.padding(top = 10.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color.Black.copy(.46f)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(Modifier.size(50.dp).clip(CircleShape).background(Color.White.copy(.12f)).clickable { }) {
                    Icon(Icons.Default.Info, null, tint = Color.White, modifier = Modifier.align(Alignment.Center))
                }
                Box(Modifier.weight(1f).height(50.dp).clip(RoundedCornerShape(20.dp)).background(Accent).clickable(enabled = !applying) { showWallpaperChoice = true }) {
                    Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.Wallpaper, null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text(if (applied) "Duvar Kâğıdı Hazır ✓" else "Duvar Kâğıdı Yap", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                Box(Modifier.size(50.dp).clip(CircleShape).background(Color.White.copy(.12f)).clickable { toggleLike() }) {
                    Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (liked) Color(0xFFFF4D72) else Color.White, modifier = Modifier.align(Alignment.Center))
                }
            }
        }
    }
}
