package com.wextra.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

private val Background = Brush.linearGradient(
    listOf(Color(0xFF080A14), Color(0xFF15102D), Color(0xFF240C3C))
)
private val Purple = Color(0xFF9B4DFF)
private val wallpapers = listOf(
    R.drawable.wallpaper_0, R.drawable.wallpaper_1, R.drawable.wallpaper_2,
    R.drawable.wallpaper_3, R.drawable.wallpaper_4, R.drawable.wallpaper_5,
    R.drawable.wallpaper_6, R.drawable.wallpaper_7, R.drawable.wallpaper_8
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAResetApp() }
    }
}

@Composable
private fun WXTRAResetApp() {
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Int?>(null) }

    BackHandler(enabled = selected != null) { selected = null }

    MaterialTheme(colorScheme = darkColorScheme(background = Color(0xFF080A14))) {
        if (selected != null) {
            FullWallpaper(selected!!, { selected = null })
        } else {
            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = { BottomNav(tab) { tab = it } }
            ) { padding ->
                Box(Modifier.fillMaxSize().background(Background)) {
                    GalleryPage(tab, padding) { selected = it }
                }
            }
        }
    }
}

@Composable
private fun GalleryPage(tab: Int, padding: PaddingValues, open: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding)) {
        if (tab == 0) {
            Box(Modifier.fillMaxWidth().height(245.dp).padding(14.dp).clip(RoundedCornerShape(28.dp)).clickable { open(0) }) {
                Image(painterResource(wallpapers[0]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.35f)))))
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(wallpapers) { resId ->
                Image(
                    painterResource(resId), null,
                    Modifier.fillMaxWidth().height(235.dp).clip(RoundedCornerShape(22.dp)).clickable { open(resId) },
                    contentScale = ContentScale.Crop
                )
            }
        }
    }
}

@Composable
private fun FullWallpaper(resId: Int, back: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(painterResource(resId), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        TextButton(onClick = back, modifier = Modifier.align(Alignment.TopStart).padding(top = 24.dp, start = 10.dp)) {
            Text("‹", color = Color.White)
        }
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xF2090A13)) {
        val labels = listOf("Ana Sayfa", "Keşfet", "AI", "Favoriler", "Profil")
        val icons = listOf(Icons.Default.Home, Icons.Default.Explore, Icons.Default.AutoAwesome, Icons.Default.FavoriteBorder, Icons.Default.Person)
        labels.forEachIndexed { index, label ->
            NavigationBarItem(
                selected = selected == index,
                onClick = { onSelect(index) },
                icon = { Icon(icons[index], null) },
                label = { Text(label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Purple,
                    selectedTextColor = Purple,
                    unselectedIconColor = Color(0xFFAAA7BF),
                    unselectedTextColor = Color(0xFFAAA7BF),
                    indicatorColor = Color.Transparent
                )
            )
        }
    }
}
