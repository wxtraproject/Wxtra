package com.wextra.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070A12)
private val Card = Color(0xFF121827)
private val Card2 = Color(0xFF171D2D)
private val Purple = Color(0xFFB34DFF)
private val Blue = Color(0xFF4C8DFF)
private val TextMain = Color(0xFFF5F3FF)
private val TextMuted = Color(0xFFA5A7BC)
private val Accent = Brush.horizontalGradient(listOf(Color(0xFFE53CFF), Color(0xFF596CFF)))

private val wallpapers = listOf(
    R.drawable.wallpaper_0, R.drawable.wallpaper_1, R.drawable.wallpaper_2,
    R.drawable.wallpaper_3, R.drawable.wallpaper_4, R.drawable.wallpaper_5,
    R.drawable.wallpaper_6, R.drawable.wallpaper_7, R.drawable.wallpaper_8
)

private val names = listOf(
    "Renkli Kuş", "Kırmızı Dokunuş", "Saklı Bahçe", "Pembe Efsane",
    "Gece Sürüşü", "Doğanın İçinde", "Zarif Dokunuş", "Akış", "Renkli Akşamlar"
)

private sealed class Screen {
    data object Home : Screen()
    data object Explore : Screen()
    data object Favorites : Screen()
    data object Profile : Screen()
    data object Search : Screen()
    data object Notifications : Screen()
    data class Listing(val title: String, val indices: List<Int>) : Screen()
    data object Settings : Screen()
    data object About : Screen()
    data object Categories : Screen()
    data object Collections : Screen()
    data class Detail(val index: Int) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAApp() }
    }
}

@Composable
private fun WXTRAApp() {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var search by remember { mutableStateOf("") }
    var liked by remember { mutableStateOf(setOf<Int>()) }

    BackHandler(enabled = screen !is Screen.Home) { screen = Screen.Home }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Purple)) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            when (val s = screen) {
                Screen.Home -> MainScaffold(0, { screen = it }, screen) {
                    HomeScreen(
                        open = { screen = Screen.Detail(it) },
                        goSearch = { screen = Screen.Search },
                        openNotifications = { screen = Screen.Notifications },
                        openListing = { title, indices -> screen = Screen.Listing(title, indices) },
                        liked = liked,
                        toggleLike = { i -> liked = if (i in liked) liked - i else liked + i },
                        openProfile = { screen = Screen.Profile },
                    )
                }
                Screen.Explore -> MainScaffold(1, { screen = it }, screen) {
                    ExploreScreen(open = { screen = Screen.Detail(it) }, openCategories = { screen = Screen.Categories }, openSearch = { screen = Screen.Search }, openNotifications = { screen = Screen.Notifications })
                }
                Screen.Favorites -> MainScaffold(2, { screen = it }, screen) {
                    FavoritesScreen(liked, { screen = Screen.Detail(it) }, toggleLike = { i -> liked = liked - i })
                }
                Screen.Profile -> MainScaffold(3, { screen = it }, screen) {
                    ProfileScreen(
                        openSettings = { screen = Screen.Settings },
                        openCollections = { screen = Screen.Collections },
                        openAbout = { screen = Screen.About }
                    )
                }
                Screen.Search -> SearchScreen(search, { search = it }, { screen = Screen.Detail(it) })
                Screen.Notifications -> NotificationsScreen { screen = Screen.Home }
                is Screen.Listing -> ListingScreen(s.title, s.indices, { screen = Screen.Detail(it) })
                Screen.Settings -> SettingsScreen { screen = Screen.Profile }
                Screen.About -> AboutScreen { screen = Screen.Profile }
                Screen.Categories -> CategoriesScreen { screen = Screen.Explore }
                Screen.Collections -> CollectionsScreen { screen = Screen.Profile }
                is Screen.Detail -> DetailScreen(
                    index = s.index,
                    liked = s.index in liked,
                    toggleLike = { liked = if (s.index in liked) liked - s.index else liked + s.index },
                    back = { screen = Screen.Home },
                )
            }
        }
    }
}

@Composable
private fun MainScaffold(
    selected: Int,
    onScreen: (Screen) -> Unit,
    screen: Screen,
    content: @Composable () -> Unit
) {
    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = { BottomNav(selected) { idx -> onScreen(if (idx == 0) Screen.Home else if (idx == 1) Screen.Explore else if (idx == 2) Screen.Favorites else Screen.Profile) } }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) { content() }
    }
}

@Composable
private fun TopHeader(onSearch: () -> Unit, onProfile: () -> Unit, title: String = "WXTRA", subtitle: String = "Duvar kâğıtlarını keşfet.") {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = TextMain)
            Text(subtitle, color = TextMuted, fontSize = 13.sp)
        }
        IconButton(onClick = onSearch) { Icon(Icons.Default.Search, null, tint = TextMain) }
        IconButton(onClick = {}) { Icon(Icons.Default.Notifications, null, tint = TextMain) }
        Box(Modifier.size(40.dp).clip(CircleShape).background(Accent).clickable { onProfile() }, contentAlignment = Alignment.Center) {
            Text("W", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun HomeScreen(open: (Int) -> Unit, goSearch: () -> Unit, openNotifications: () -> Unit, openListing: (String, List<Int>) -> Unit, liked: Set<Int>, toggleLike: (Int) -> Unit, openProfile: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("WXTRA", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = TextMain)
                    Text("Her duvarda başka bir hikaye.", color = TextMuted, fontSize = 13.sp)
                }
                IconButton(onClick = goSearch) { Icon(Icons.Default.Search, null, tint = TextMain) }
                IconButton(onClick = openNotifications) { Icon(Icons.Default.Notifications, null, tint = TextMain) }
                Box(
                    Modifier.size(42.dp).clip(CircleShape).background(Accent).clickable { openProfile() },
                    contentAlignment = Alignment.Center
                ) { Text("W", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            }
        }
        item {
            SearchBar(value = "", onValue = {}, modifier = Modifier.padding(horizontal = 18.dp).clickable { goSearch() }, readOnly = true)
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(0.9f)) {
                    Text("Bugün", color = Purple, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("Senin Ruh Halin\nHangisi?", color = TextMain, fontSize = 25.sp, lineHeight = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Her duvar, başka bir sen.", color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
                    Box(
                        Modifier.padding(top = 12.dp).clip(RoundedCornerShape(16.dp)).background(Accent).clickable { open(3) }.padding(horizontal = 18.dp, vertical = 11.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("Hemen Keşfet  →", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                }
                Box(Modifier.weight(1.5f).height(190.dp).clip(RoundedCornerShape(24.dp)).clickable { open(3) }) {
                    Image(painterResource(wallpapers[3]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.55f)))))
                    Text("1/3", color = Color.White, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp).clip(CircleShape).background(Color.Black.copy(.45f)).padding(horizontal = 8.dp, vertical = 4.dp))
                }
            }
        }
        item { SectionTitle("Senin İçin Seçtiklerimiz", "Tümünü Gör") { openListing("Senin İçin Seçtiklerimiz", listOf(0,4,3,5,2,8)) } }
        item { WallpaperRow(indices = listOf(0, 4, 3, 5, 2, 8), open, liked, toggleLike) }
        item { SectionTitle("Senin İçin Favoriler", "Tümünü Gör") { openListing("Senin İçin Favoriler", listOf(5,7,4,8,2)) } }
        item { WallpaperRow(indices = listOf(5, 7, 4, 8, 2), open, liked, toggleLike) }
        item { SectionTitle("Popüler Koleksiyonlar", "Tümünü Gör") { openListing("Popüler Koleksiyonlar", listOf(0,2,7,8)) } }
        item {
            LazyRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                lazyItems(listOf(0 to "4K Ultra HD", 2 to "Etkileyici Manzaralar", 7 to "Karanlık Mod", 8 to "Anime Dünyası")) { item ->
                    CollectionHomeCard(item.first, item.second, open)
                }
            }
        }
        item { SectionTitle("Bugünün Favorileri", "Tümünü Gör") { openListing("Bugünün Favorileri", listOf(6,1,7,3,4)) } }
        item { WallpaperRow(indices = listOf(6, 1, 7, 3, 4), open, liked, toggleLike) }
        item {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 22.dp)) {
                Text("WXTRA", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Text("Daha fazlası, sadece bir duvar kağıdı değil.", color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
private fun WallpaperRow(indices: List<Int>, open: (Int) -> Unit, liked: Set<Int>, toggleLike: (Int) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val cardWidth = ((maxWidth - 72.dp) / 4f).coerceAtLeast(68.dp)
        LazyRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            lazyItems(indices) { i ->
                ImageCard(
                    index = i,
                    open = open,
                    liked = i in liked,
                    onLike = { toggleLike(i) },
                    modifier = Modifier.width(cardWidth)
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        action?.let { Text(it, color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onAction?.invoke() }) }
    }
}

@Composable
private fun SearchBar(value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier, readOnly: Boolean = false) {
    OutlinedTextField(value = value, onValueChange = onValue, readOnly = readOnly, modifier = modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text("Duvar kağıdı ara…") }, colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Card, focusedContainerColor = Card2, unfocusedBorderColor = Color.Transparent, focusedBorderColor = Purple))
}

@Composable
private fun Pill(text: String, selected: Boolean = false) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(if (selected) Purple else Card2).padding(horizontal = 16.dp, vertical = 10.dp)) { Text(text, color = Color.White, fontSize = 12.sp) }
}

@Composable
private fun ChipRow(chips: List<String>) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (chips.isNotEmpty()) Pill(chips[0], selected = true)
        for (i in 1 until chips.size) Pill(chips[i], selected = false)
    }
}

@Composable
private fun CategoryTile(index: Int, title: String, modifier: Modifier, open: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(18.dp)).clickable { open() }) {
        Image(painterResource(wallpapers[index]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.7f)))))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomStart).padding(12.dp))
    }
}

@Composable
private fun ProfileAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp).clip(RoundedCornerShape(16.dp)).background(Card).clickable { onClick() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = TextMain)
        Text(title, color = TextMain, modifier = Modifier.weight(1f).padding(start = 14.dp))
        Icon(Icons.Default.ArrowForward, null, tint = TextMuted)
    }
}

@Composable
private fun SettingsSection(title: String, items: List<String>) {
    Text(title, color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp))
    if (items.isNotEmpty()) SettingsRow(items[0])
    if (items.size > 1) SettingsRow(items[1])
    if (items.size > 2) SettingsRow(items[2])
    if (items.size > 3) SettingsRow(items[3])
} 

@Composable
private fun SettingsRow(item: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(Card).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(item, color = TextMain, modifier = Modifier.weight(1f)); Text("›", color = TextMuted)
    }
}

@Composable
private fun CollectionCard(title: String, index: Int) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp).clip(RoundedCornerShape(18.dp)).background(Card).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(wallpapers[index]), null, Modifier.size(74.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
        Column(Modifier.padding(start = 12.dp)) { Text(title, color = TextMain, fontWeight = FontWeight.Bold); Text("Sizin için özel seçildi.", color = TextMuted, fontSize = 12.sp) }
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(value, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(label, color = TextMuted, fontSize = 11.sp) }
}

@Composable
private fun TopBar(title: String, back: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null, tint = TextMain) }
        Text(title, color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xF2090C16)) {
        NavigationBarItem(selected = selected == 0, onClick = { onSelect(0) }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Ana Sayfa") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent))
        NavigationBarItem(selected = selected == 1, onClick = { onSelect(1) }, icon = { Icon(Icons.Default.Explore, null) }, label = { Text("Keşfet") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent))
        NavigationBarItem(selected = selected == 2, onClick = { onSelect(2) }, icon = { Icon(Icons.Default.FavoriteBorder, null) }, label = { Text("Favoriler") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent))
        NavigationBarItem(selected = selected == 3, onClick = { onSelect(3) }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Profil") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent))
    }
}
