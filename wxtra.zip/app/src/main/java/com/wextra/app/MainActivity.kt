package com.wextra.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

private val Bg = Color(0xFF080A12)
private val Purple = Color(0xFF9B4DFF)
private val Pink = Color(0xFFEC4899)
private val Blue = Color(0xFF3B82F6)
private val Nav = Color(0xF20B0E19)
private val Gradient = Brush.linearGradient(listOf(Purple, Pink, Blue))

data class Wallpaper(val image: Int)

private val wallpapers = listOf(
    Wallpaper(R.drawable.wallpaper_0), Wallpaper(R.drawable.wallpaper_1), Wallpaper(R.drawable.wallpaper_2),
    Wallpaper(R.drawable.wallpaper_3), Wallpaper(R.drawable.wallpaper_4), Wallpaper(R.drawable.wallpaper_5),
    Wallpaper(R.drawable.wallpaper_6), Wallpaper(R.drawable.wallpaper_7), Wallpaper(R.drawable.wallpaper_8)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAResetApp() }
    }
}

@Composable
fun WXTRAResetApp() {
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Wallpaper?>(null) }

    BackHandler(enabled = selected != null || tab != 0) {
        if (selected != null) selected = null else tab = 0
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Bg, primary = Purple)) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            if (selected != null) {
                WallpaperDetail(selected!!, onBack = { selected = null })
            } else {
                Box(Modifier.fillMaxSize().padding(bottom = 78.dp)) {
                    WallpaperGallery(tab = tab, open = { selected = it })
                }
                BottomNav(tab) { tab = it }
            }
        }
    }
}

@Composable
private fun WallpaperGallery(tab: Int, open: (Wallpaper) -> Unit) {
    val list = when (tab) {
        0 -> wallpapers
        1 -> wallpapers.reversed()
        2 -> wallpapers.shuffled()
        3 -> wallpapers.filterIndexed { i, _ -> i % 2 == 0 }
        else -> wallpapers.filterIndexed { i, _ -> i % 2 == 1 }
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(list) { wallpaper ->
            Box(
                Modifier.fillMaxWidth().height(245.dp).clip(RoundedCornerShape(20.dp)).clickable { open(wallpaper) }
            ) {
                Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, Color.Black.copy(alpha = .18f)))))
                Box(
                    Modifier.align(Alignment.TopEnd).padding(8.dp).size(34.dp).clip(CircleShape)
                        .background(Color.Black.copy(alpha = .28f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.FavoriteBorder, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
private fun WallpaperDetail(wallpaper: Wallpaper, onBack: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(.25f), Color.Transparent, Color.Black.copy(.45f)))))
        IconButton(onClick = onBack, modifier = Modifier.padding(top = 18.dp, start = 10.dp).align(Alignment.TopStart)) {
            Icon(Icons.Default.ArrowBack, null, tint = Color.White)
        }
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Nav, modifier = Modifier.align(Alignment.BottomCenter).height(78.dp)) {
        val icons = listOf(Icons.Default.Home, Icons.Default.Explore, Icons.Default.AutoAwesome, Icons.Default.FavoriteBorder, Icons.Default.Person)
        icons.forEachIndexed { index, icon ->
            NavigationBarItem(
                selected = selected == index,
                onClick = { onSelect(index) },
                icon = {
                    if (index == 2) Box(Modifier.size(44.dp).clip(CircleShape).background(Gradient), contentAlignment = Alignment.Center) {
                        Icon(icon, null, tint = Color.White)
                    } else Icon(icon, null)
                },
                label = null,
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Purple,
                    unselectedIconColor = Color(0xFFB8B7C8),
                    indicatorColor = Color.Transparent
                )
            )
        }
    }
}
