package com.wextra.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF8B3DFF)
private val Purple2 = Color(0xFFB98AFF)
private val Magenta = Color(0xFFEC4899)
private val Blue = Color(0xFF3882F6)
private val Ink = Color(0xFFF8F7FF)
private val Muted = Color(0xFFAAA7BF)
private val Soft = Color(0x16FFFFFF)
private val Line = Color(0x22FFFFFF)
private val AppGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF070A14), Color(0xFF11162B), Color(0xFF29104C), Color(0xFF120D2B), Color(0xFF070A14))
)
private val ButtonGradient = Brush.horizontalGradient(listOf(Purple, Magenta, Blue))

data class Wallpaper(val title: String, val subtitle: String, val image: Int)
data class Category(val title: String, val count: String, val image: Int)

enum class ExtraScreen { None, Search, Categories, Notifications, Collections, Uploads, Settings, About }

private val wallpapers = listOf(
    Wallpaper("Renkli Kuş", "Doğanın renkleri", R.drawable.wallpaper_0),
    Wallpaper("Kırmızı Dokunuş", "Çiçeklerin hikâyesi", R.drawable.wallpaper_1),
    Wallpaper("Saklı Bahçe", "Renklerin içinde", R.drawable.wallpaper_2),
    Wallpaper("Pembe Efsane", "Otomobil tutkusu", R.drawable.wallpaper_3),
    Wallpaper("Gece Sürüşü", "Şehir ışıkları", R.drawable.wallpaper_4),
    Wallpaper("Doğanın İçinde", "Canlı yaşam", R.drawable.wallpaper_5),
    Wallpaper("Zarif Dokunuş", "Minimal çiçekler", R.drawable.wallpaper_6),
    Wallpaper("Akış", "Soyut evren", R.drawable.wallpaper_7),
    Wallpaper("Renkli Akşamlar", "Yollar seni bekliyor", R.drawable.wallpaper_8)
)

private val categories = listOf(
    Category("Doğa", "1.2K+", R.drawable.wallpaper_5),
    Category("Arabalar", "980+", R.drawable.wallpaper_4),
    Category("Anime", "1.1K+", R.drawable.wallpaper_3),
    Category("Minimal", "750+", R.drawable.wallpaper_6),
    Category("Uzay", "680+", R.drawable.wallpaper_7),
    Category("Şehir", "920+", R.drawable.wallpaper_4),
    Category("Oyun", "540+", R.drawable.wallpaper_3),
    Category("Soyut", "610+", R.drawable.wallpaper_8),
    Category("Siyah", "480+", R.drawable.wallpaper_2)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAApp() }
    }
}

@Composable
fun WXTRAApp() {
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Wallpaper?>(null) }
    var showPro by remember { mutableStateOf(false) }
    var extra by remember { mutableStateOf(ExtraScreen.None) }
    var showApply by remember { mutableStateOf(false) }

    // System back / gesture navigation follows the in-app navigation stack
    // instead of closing the activity while the user is inside a screen.
    BackHandler(enabled = selected != null || showApply || showPro || extra != ExtraScreen.None || tab != 0) {
        when {
            showApply -> showApply = false
            selected != null -> selected = null
            showPro -> showPro = false
            extra != ExtraScreen.None -> extra = ExtraScreen.None
            tab != 0 -> tab = 0
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Color(0xFF070A14), surface = Color(0xFF11162A), onBackground = Ink, onSurface = Ink)) {
        when {
            selected != null -> DetailScreen(selected!!, { selected = null }, { showApply = true })
            showApply -> ApplyWallpaperSheet({ showApply = false })
            showPro -> ProScreen { showPro = false }
            extra != ExtraScreen.None -> ExtraScreenHost(extra, { extra = ExtraScreen.None }, { selected = it })
            else -> Scaffold(
                containerColor = Color.Transparent,
                bottomBar = { WXTRANav(tab) { tab = it } }
            ) { padding ->
                Box(Modifier.fillMaxSize().background(AppGradient)) {
                    when (tab) {
                        0 -> HomeScreen(padding, { selected = it }, { showPro = true }, { extra = it }, { tab = 4 }, { tab = 1 })
                        1 -> ExploreScreen(padding, { selected = it }, { extra = it })
                        2 -> AIStudioScreen(padding, { showPro = true })
                        3 -> FavoritesScreen(padding, { selected = it })
                        else -> ProfileScreen(padding, { showPro = true }, { extra = it })
                    }
                }
            }
        }
    }
}

@Composable
fun WXTRANav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xEE090C18), modifier = Modifier.height(82.dp)) {
        val labels = listOf("Ana Sayfa", "Keşfet", "AI", "Favoriler", "Profil")
        val icons = listOf(Icons.Default.Home, Icons.Default.Explore, Icons.Default.AutoAwesome, Icons.Default.FavoriteBorder, Icons.Default.Person)
        labels.forEachIndexed { index, label ->
            NavigationBarItem(
                selected = selected == index,
                onClick = { onSelect(index) },
                icon = {
                    if (index == 2) Box(Modifier.size(44.dp).clip(CircleShape).background(ButtonGradient), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Color.White)
                    } else Icon(icons[index], null)
                },
                label = { Text(label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple2, selectedTextColor = Purple2, indicatorColor = Color(0x221C1236), unselectedIconColor = Muted, unselectedTextColor = Muted)
            )
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null, action: (() -> Unit)? = null, actionIcon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.NotificationsNone) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 17.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 30.sp, fontWeight = FontWeight.Black, color = Ink)
            if (subtitle != null) Text(subtitle, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        }
        if (action != null) IconButton(onClick = action) { Icon(actionIcon, null, tint = Ink) }
    }
}

@Composable
fun HomeScreen(padding: PaddingValues, open: (Wallpaper) -> Unit, pro: () -> Unit, extra: (ExtraScreen) -> Unit, profile: () -> Unit, explore: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 17.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("WXTRA", fontSize = 32.sp, fontWeight = FontWeight.Black, color = Ink, letterSpacing = 1.2.sp)
                Text("MORE THAN WALLPAPERS", fontSize = 8.sp, color = Muted, letterSpacing = 2.sp)
            }
            IconButton(onClick = { extra(ExtraScreen.Search) }) { Icon(Icons.Default.Search, null, tint = Ink) }
            IconButton(onClick = { extra(ExtraScreen.Notifications) }) { Icon(Icons.Default.NotificationsNone, null, tint = Ink) }
            IconButton(onClick = profile) { Avatar() }
        }

        // Günün Seçimi ayrı bir bölüm olarak kalır.
        SectionTitle("Günün Seçimi", "Bugünün öne çıkan duvar kâğıdı")
        HeroCard(wallpapers[7], open)

        // Başlıksız bağımsız wallpaper galerisi.
        Spacer(Modifier.height(18.dp))
        val gallery = wallpapers.filterIndexed { index, _ -> index != 7 }
        gallery.chunked(2).forEach { row ->
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                row.forEach { wallpaper ->
                    ImageCard(
                        wallpaper,
                        0.dp,
                        235.dp,
                        open,
                        modifier = Modifier.weight(1f),
                        showText = false
                    )
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun HeroCard(wallpaper: Wallpaper, open: (Wallpaper) -> Unit) {
    Box(Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(295.dp).clip(RoundedCornerShape(28.dp)).clickable { open(wallpaper) }) {
        Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .9f)))))
        Surface(Modifier.align(Alignment.TopStart).padding(15.dp), shape = RoundedCornerShape(12.dp), color = Color(0xCC17122B)) {
            Text("✦  GÜNÜN SEÇKİSİ", modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp), color = Purple2, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
            Text("Sınır Yok", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text("Sadece Senin Tarzın", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(9.dp))
            Button(onClick = { open(wallpaper) }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Keşfet  →") }
        }
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String, onAll: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 23.dp, bottom = 11.dp), verticalAlignment = Alignment.Bottom) {
        Column(Modifier.weight(1f)) { Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink); Text(subtitle, fontSize = 11.sp, color = Muted) }
        Text("Tümü  ›", color = Purple2, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, modifier = Modifier.clickable(enabled = onAll != null) { onAll?.invoke() })
    }
}

@Composable
fun Avatar() { Box(Modifier.size(38.dp).clip(CircleShape).background(ButtonGradient), contentAlignment = Alignment.Center) { Text("W", color = Color.White, fontWeight = FontWeight.Black) } }

@Composable
fun ImageCard(wallpaper: Wallpaper, width: androidx.compose.ui.unit.Dp, height: androidx.compose.ui.unit.Dp, open: (Wallpaper) -> Unit, modifier: Modifier = Modifier, showText: Boolean = true) {
    Column((if (width > 0.dp) modifier.width(width) else modifier).clickable { open(wallpaper) }) {
        Box(Modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(20.dp))) {
            Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .25f)))))
            Surface(Modifier.align(Alignment.TopEnd).padding(9.dp), shape = CircleShape, color = Color.Black.copy(alpha = .25f)) { Icon(Icons.Default.FavoriteBorder, null, tint = Color.White, modifier = Modifier.padding(7.dp).size(17.dp)) }
        }
        if (showText) {
            Text(wallpaper.title, modifier = Modifier.padding(top = 7.dp, start = 2.dp), color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
            Text(wallpaper.subtitle, modifier = Modifier.padding(start = 2.dp), color = Muted, fontSize = 10.sp, maxLines = 1)
        }
    }
}

@Composable fun SmallRow(list: List<Wallpaper>, open: (Wallpaper) -> Unit) { LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(list) { ImageCard(it, 126.dp, 185.dp, open, showText = false) } } }

@Composable
fun ProBanner(onClick: () -> Unit) {
    Row(Modifier.padding(20.dp).fillMaxWidth().height(132.dp).clip(RoundedCornerShape(25.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF16102B), Purple, Color(0xFF8C4BFF)))).padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(51.dp).clip(CircleShape).background(Color.White.copy(alpha = .13f)), contentAlignment = Alignment.Center) { Text("♛", color = Color(0xFFFFD66E), fontSize = 26.sp) }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) { Text("Özel Seçkiler", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text("Özel seçkiler, AI ve daha fazlası.", color = Color.White.copy(alpha = .82f), fontSize = 10.sp); Spacer(Modifier.height(6.dp)); Text("Sınırsız ilham.", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
        Button(onClick = onClick, shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Purple)) { Text("Aç") }
    }
}

@Composable
fun ExploreScreen(padding: PaddingValues, open: (Wallpaper) -> Unit, extra: (ExtraScreen) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Keşfet", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Ink); Text("Yeni favorini bul.", color = Muted, fontSize = 11.sp) }
            IconButton(onClick = { extra(ExtraScreen.Search) }) { Icon(Icons.Default.Search, null, tint = Ink) }
            IconButton(onClick = { extra(ExtraScreen.Notifications) }) { Icon(Icons.Default.NotificationsNone, null, tint = Ink) }
            Box(Modifier.clickable { extra(ExtraScreen.About) }) { Avatar() }
        }
        SearchBar("Duvar kâğıdı ara...", Modifier.fillMaxWidth().height(43.dp)) { extra(ExtraScreen.Search) }
        Row(Modifier.fillMaxWidth().height(38.dp).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("Tümü", "Popüler", "Trendler", "Yeni").forEachIndexed { i, text ->
                Surface(Modifier.weight(1f), shape = RoundedCornerShape(13.dp), color = if (i == 0) Purple else Color(0x18FFFFFF)) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(text, color = if (i == 0) Color.White else Muted, fontSize = 10.sp, fontWeight = if (i == 0) FontWeight.Bold else FontWeight.Normal) }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().height(145.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ExploreFeatureCard(wallpapers[2], "Doğanın", "Büyüsü", Modifier.weight(1.15f), open)
            ExploreFeatureCard(wallpapers[3], "Araba", "Tutkunlarına", Modifier.weight(.85f), open)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().height(73.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            categories.take(6).forEach { category -> ExploreCategoryBox(category, Modifier.weight(1f)) { extra(ExtraScreen.Categories) } }
        }
        ExploreSection("🔥  Trend Olanlar", wallpapers.take(4), open, "Şu anda en çok ilgi görenler")
        ExploreSection("❤️  Sana Özel", wallpapers.drop(2).take(4), open, "Beğenilerine göre seçildi")
        ExploreSection("✨  Yeni Eklenenler", wallpapers.takeLast(4), open, "En yeni duvar kâğıtlarını keşfet")
    }
}

@Composable
fun ExploreFeatureCard(wallpaper: Wallpaper, line1: String, line2: String, modifier: Modifier, open: (Wallpaper) -> Unit) {
    Box(modifier.clip(RoundedCornerShape(20.dp)).clickable { open(wallpaper) }) {
        Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD050714)))))
        Column(Modifier.align(Alignment.BottomStart).padding(11.dp)) {
            Text(line1, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Text(line2, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black)
            Text("Keşfet  →", color = Purple2, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ExploreCategoryBox(category: Category, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(13.dp)).clickable { onClick() }) {
        Image(painterResource(category.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .34f)))
        Text(category.title, Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp), color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ExploreSection(title: String, list: List<Wallpaper>, open: (Wallpaper) -> Unit, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Row(Modifier.fillMaxWidth().height(23.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
            Text("Tümü  ›", color = Purple2, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(subtitle, color = Muted, fontSize = 8.sp, modifier = Modifier.padding(bottom = 4.dp))
        Row(Modifier.fillMaxWidth().height(62.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            list.forEach { wallpaper ->
                Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(11.dp)).clickable { open(wallpaper) }) {
                    Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Surface(Modifier.align(Alignment.BottomStart).padding(4.dp), shape = RoundedCornerShape(5.dp), color = Color.Black.copy(alpha = .72f)) { Text("4K", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)) }
                    Icon(Icons.Default.FavoriteBorder, null, tint = Color.White, modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).size(16.dp))
                }
            }
        }
    }
}

@Composable fun SearchBar(text: String, modifier: Modifier = Modifier, click: (() -> Unit)? = null) { Row(modifier.fillMaxWidth().height(49.dp).clip(RoundedCornerShape(17.dp)).background(Color(0x18FFFFFF)).clickable(enabled = click != null) { click?.invoke() }.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Search, null, tint = Muted); Spacer(Modifier.width(9.dp)); Text(text, color = Muted, fontSize = 12.sp) } }
@Composable fun Chip(text: String, selected: Boolean) { Surface(shape = RoundedCornerShape(14.dp), color = if (selected) Purple else Color(0x18FFFFFF)) { Text(text, modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp), color = if (selected) Color.White else Muted, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) } }

@Composable
fun AIStudioScreen(padding: PaddingValues, pro: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 17.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("AI Stüdyo", fontSize = 30.sp, fontWeight = FontWeight.Black); Text("Hayal et, WXTRA oluştursun.", color = Muted, fontSize = 12.sp) }; Surface(shape = RoundedCornerShape(10.dp), color = Color(0x332B174F)) { Text("♛ PRO", color = Purple2, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)) } }
        Box(Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(190.dp).clip(RoundedCornerShape(25.dp))) { Image(painterResource(wallpapers[7].image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop); Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD090A18))))) ; Text("AI WALLPAPER LAB", Modifier.align(Alignment.BottomStart).padding(18.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
        Card(Modifier.padding(20.dp).fillMaxWidth(), shape = RoundedCornerShape(25.dp), colors = CardDefaults.cardColors(containerColor = Color(0x16FFFFFF))) {
            Column(Modifier.padding(17.dp)) {
                Text("Ne görmek istersin?", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Fikri yaz, stilini seç, gerisini AI'ya bırak.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
                Spacer(Modifier.height(12.dp)); Box(Modifier.fillMaxWidth().height(112.dp).clip(RoundedCornerShape(17.dp)).background(Color(0x18FFFFFF)).padding(14.dp)) { Text("Örn. mor gökyüzü, dağlar, neon şehir...", color = Muted, fontSize = 12.sp) }
                Spacer(Modifier.height(12.dp)); Text("Oran Seç", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(Modifier.padding(top = 7.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("9:16", "1:1", "16:9", "4:3").forEachIndexed { i, s -> Box(Modifier.weight(1f).height(39.dp).clip(RoundedCornerShape(12.dp)).background(if (i == 0) Purple else Color(0x18FFFFFF)), contentAlignment = Alignment.Center) { Text(s, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) } } }
                Spacer(Modifier.height(13.dp)); Text("Stil Seç", fontWeight = FontWeight.SemiBold, fontSize = 12.sp); Row(Modifier.padding(top = 7.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) { listOf("Gerçekçi", "Anime", "Minimal", "Sinematik", "Sanatsal").forEach { Chip(it, it == "Gerçekçi") } }
                Spacer(Modifier.height(14.dp)); Button(onClick = pro, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Oluştur  ✨") }
            }
        }
        SectionTitle("İlham AI", "Bir fikri seç ve dönüştür")
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(wallpapers.take(5)) { ImageCard(it, 145.dp, 182.dp, {}) } }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun FavoritesScreen(padding: PaddingValues, open: (Wallpaper) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding)) { Header("Favoriler", "Kaydettiğin ilhamlar burada."); Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Color(0x18FFFFFF)).padding(4.dp)) { Box(Modifier.weight(1f).height(36.dp).clip(RoundedCornerShape(12.dp)).background(Purple), contentAlignment = Alignment.Center) { Text("Duvar Kâğıtların", fontSize = 11.sp, fontWeight = FontWeight.Bold) }; Box(Modifier.weight(1f).height(36.dp), contentAlignment = Alignment.Center) { Text("Koleksiyonların", fontSize = 11.sp, color = Muted) } }; LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(wallpapers) { ImageCard(it, 0.dp, 215.dp, open, Modifier.fillMaxWidth()) } } }
}

@Composable
fun ProfileScreen(padding: PaddingValues, pro: () -> Unit, extra: (ExtraScreen) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
        Header("Profil", null, { extra(ExtraScreen.Settings) }, Icons.Default.Settings)
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(88.dp).clip(CircleShape).background(ButtonGradient), contentAlignment = Alignment.Center) { Text("W", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black) }; Text("wextra", fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 11.dp)); Text("Kendi duvarını, kendi tarzını oluştur.", color = Muted, fontSize = 11.sp); Row(Modifier.fillMaxWidth().padding(vertical = 19.dp), horizontalArrangement = Arrangement.SpaceEvenly) { Stat("124", "Favori"); Stat("36", "Yükleme"); Stat("12", "Koleksiyon") } }
        ProfileRow(Icons.Default.FavoriteBorder, "Favorilerim", "Kaydettiğin duvar kâğıtları")
        ProfileRow(Icons.Default.CollectionsBookmark, "Koleksiyonlarım", "Kendi seçkilerini oluştur") { extra(ExtraScreen.Collections) }
        ProfileRow(Icons.Default.CloudUpload, "Yüklemelerim", "Paylaştığın içerikler") { extra(ExtraScreen.Uploads) }
        ProfileRow(Icons.Default.AutoAwesome, "AI Geçmişim", "Ürettiğin çalışmalar")
        ProfileRow(Icons.Default.Settings, "Ayarlar", "Uygulama tercihleri") { extra(ExtraScreen.Settings) }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable fun Stat(value: String, label: String) { Column(Modifier.width(92.dp).clip(RoundedCornerShape(15.dp)).background(Color(0x14FFFFFF)).padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 10.sp) } }
@Composable fun ProfileRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, click: (() -> Unit)? = null) { Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Soft).clickable(enabled = click != null) { click?.invoke() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Purple2, modifier = Modifier.size(21.dp)); Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 10.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) } }

@Composable
fun ProScreen(back: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null) }; Text("WXTRA PRO", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        Box(Modifier.padding(20.dp).fillMaxWidth().height(250.dp).clip(RoundedCornerShape(30.dp)).background(Brush.radialGradient(listOf(Color(0xFF8E46FF), Color(0xFF1A123A), Color(0xFF090B17))))) { Column(Modifier.align(Alignment.BottomStart).padding(22.dp)) { Text("♛", color = Color(0xFFFFD66E), fontSize = 30.sp); Text("WXTRA PRO", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Black); Text("Daha fazla özellik, daha fazla ilham.", color = Color.White.copy(alpha = .84f), fontSize = 12.sp) } }
        Text("Premium dünyayı aç", fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 20.dp)); Text("Sınırsız AI, özel koleksiyonlar ve reklamsız deneyim.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        listOf("Sınırsız AI görsel oluşturma", "Özel koleksiyonlar", "Reklamsız deneyim", "4K / 8K özel içerikler", "Yeni duvar kâğıtlarına erken erişim", "Bulut yedekleme", "Premium temalar").forEach { FeatureRow(it) }
        Row(Modifier.padding(20.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { PlanCard("Aylık", "₺29,99", false, Modifier.weight(1f)); PlanCard("Yıllık", "₺199,99", true, Modifier.weight(1f)) }
        Button(onClick = {}, modifier = Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(55.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("PRO'ya Geç  ✦") }
        Spacer(Modifier.height(25.dp))
    }
}
@Composable fun FeatureRow(text: String) { Row(Modifier.padding(horizontal = 20.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(23.dp).clip(CircleShape).background(Color(0x3328D17C)), contentAlignment = Alignment.Center) { Text("✓", color = Color(0xFF8BFFBF), fontSize = 12.sp, fontWeight = FontWeight.Bold) }; Spacer(Modifier.width(10.dp)); Text(text, fontSize = 12.sp) } }
@Composable fun PlanCard(name: String, price: String, selected: Boolean, modifier: Modifier = Modifier) { Column(modifier.height(102.dp).clip(RoundedCornerShape(17.dp)).background(if (selected) Color(0x22A78BFA) else Color(0x14FFFFFF)).padding(14.dp)) { Text(name, color = Muted, fontSize = 11.sp); Text(price, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)); if (selected) Text("%44 Tasarruf", color = Purple2, fontSize = 9.sp) } }

@Composable
fun DetailScreen(wallpaper: Wallpaper, back: () -> Unit, apply: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(wallpaper.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .08f), Color.Transparent, Color.Black.copy(alpha = .86f)))))
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp, start = 12.dp, end = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) { FilledIconButton(onClick = back, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White.copy(alpha = .9f))) { Icon(Icons.Default.ArrowBack, null) }; FilledIconButton(onClick = {}, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White.copy(alpha = .9f))) { Icon(Icons.Default.FavoriteBorder, null) } }
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(20.dp)) {
            Text(wallpaper.title, fontSize = 27.sp, fontWeight = FontWeight.Black, color = Color.White); Text(wallpaper.subtitle, color = Color.White.copy(alpha = .78f), fontSize = 12.sp); Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Tag("9:16"); Tag("4K"); Tag("WXTRA") }; Spacer(Modifier.height(14.dp)); Button(onClick = apply, modifier = Modifier.fillMaxWidth().height(53.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Icon(Icons.Default.Wallpaper, null); Spacer(Modifier.width(8.dp)); Text("Duvar Kâğıdı Yap") }; Spacer(Modifier.height(6.dp)); Text("İndirme yok • doğrudan ekranına uygula.", color = Color.White.copy(alpha = .65f), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}
@Composable fun Tag(text: String) { Surface(shape = RoundedCornerShape(10.dp), color = Color(0x33202035)) { Text(text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.SemiBold) } }

@Composable
fun ApplyWallpaperSheet(close: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0x99000000)), contentAlignment = Alignment.BottomCenter) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp)).background(Color(0xFF111527)).padding(20.dp)) {
            Text("Duvar Kâğıdı Olarak Ayarla", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("Nereye uygulamak istersin?", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp, bottom = 14.dp))
            ApplyOption(Icons.Default.Home, "Ana Ekran", "Sadece ana ekran"); ApplyOption(Icons.Default.Lock, "Kilit Ekranı", "Sadece kilit ekranı"); ApplyOption(Icons.Default.Phonelink, "Ana Ekran ve Kilit Ekranı", "İkisine birden")
            TextButton(onClick = close, modifier = Modifier.fillMaxWidth().padding(top = 5.dp)) { Text("İptal", color = Muted) }
        }
    }
}
@Composable fun ApplyOption(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String) { Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(15.dp)).background(Color(0x14FFFFFF)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Purple2); Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(sub, color = Muted, fontSize = 10.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) } }

@Composable
fun ExtraScreenHost(screen: ExtraScreen, back: () -> Unit, open: (Wallpaper) -> Unit) {
    when (screen) {
        ExtraScreen.Search -> SearchScreen(back, open)
        ExtraScreen.Categories -> CategoriesScreen(back)
        ExtraScreen.Notifications -> NotificationsScreen(back)
        ExtraScreen.Collections -> CollectionsScreen(back)
        ExtraScreen.Uploads -> UploadsScreen(back, open)
        ExtraScreen.Settings -> SettingsScreen(back)
        ExtraScreen.About -> AboutScreen(back)
        else -> Unit
    }
}

@Composable fun ExtraTop(title: String, back: () -> Unit) { Row(Modifier.fillMaxWidth().statusBarsPadding().padding(10.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null) }; Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold) } }

@Composable fun SearchScreen(back: () -> Unit, open: (Wallpaper) -> Unit) { Column(Modifier.fillMaxSize()) { ExtraTop("Arama", back); SearchBar("mor", Modifier.padding(horizontal = 20.dp)); LazyRow(contentPadding = PaddingValues(20.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) { items(listOf("mor", "mor gökyüzü", "mor anime", "mor araba")) { Chip(it, it == "mor") } }; LazyVerticalGrid(columns = GridCells.Fixed(3), contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { items(wallpapers) { Image(painterResource(it.image), null, Modifier.fillMaxWidth().height(175.dp).clip(RoundedCornerShape(15.dp)).clickable { open(it) }, contentScale = ContentScale.Crop) } } } }

@Composable fun CategoriesScreen(back: () -> Unit) { Column(Modifier.fillMaxSize()) { ExtraTop("Kategoriler", back); Text("Tarzını seç, keşfetmeye başla.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 2.dp)); LazyVerticalGrid(columns = GridCells.Fixed(3), contentPadding = PaddingValues(20.dp), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { items(categories) { CategoryCard(it) } } } }
@Composable fun CategoryCard(c: Category) { Box(Modifier.fillMaxWidth().height(155.dp).clip(RoundedCornerShape(18.dp))) { Image(painterResource(c.image), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop); Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .85f))))); Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) { Text(c.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(c.count, color = Color.White.copy(alpha = .72f), fontSize = 9.sp) } } }

@Composable fun NotificationsScreen(back: () -> Unit) { Column(Modifier.fillMaxSize()) { ExtraTop("Bildirimler", back); listOf("Yeni Duvar Kâğıtları", "Trend Koleksiyonlar", "AI Önerileri", "Uygulama Güncellemeleri", "Özel Kampanyalar").forEachIndexed { i, s -> ToggleRow(s, "Yeni içerik ve gelişmeler", i < 4) } } }
@Composable fun ToggleRow(title: String, sub: String, checked: Boolean) { Row(Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0x14FFFFFF)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(sub, color = Muted, fontSize = 10.sp) }; Switch(checked = checked, onCheckedChange = {}, colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Purple)) } }

@Composable fun CollectionsScreen(back: () -> Unit) { Column(Modifier.fillMaxSize()) { ExtraTop("Koleksiyonlarım", back); Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(48.dp).clip(RoundedCornerShape(15.dp)).background(Color(0x18FFFFFF)).clickable {}.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Add, null, tint = Purple2); Spacer(Modifier.width(9.dp)); Text("Yeni Koleksiyon Oluştur", fontWeight = FontWeight.SemiBold) }; Spacer(Modifier.height(12.dp)); listOf("Favori", "Doğa", "Uzay", "Arabalar", "Anime").forEachIndexed { i, name -> CollectionRow(name, "${24 - i * 3} öğe", wallpapers[i % wallpapers.size]) } } }
@Composable fun CollectionRow(name: String, count: String, wallpaper: Wallpaper) { Row(Modifier.padding(horizontal = 20.dp, vertical = 5.dp).fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Color(0x14FFFFFF)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) { Image(painterResource(wallpaper.image), null, Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(name, fontWeight = FontWeight.SemiBold); Text(count, color = Muted, fontSize = 10.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) } }

@Composable fun UploadsScreen(back: () -> Unit, open: (Wallpaper) -> Unit) { Column(Modifier.fillMaxSize()) { ExtraTop("Yüklemelerim", back); Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(48.dp).clip(RoundedCornerShape(15.dp)).background(Color(0x18FFFFFF)).clickable {}.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CloudUpload, null, tint = Purple2); Spacer(Modifier.width(9.dp)); Text("Yeni duvar kâğıdı yükle", fontWeight = FontWeight.SemiBold) }; LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { items(wallpapers.take(6)) { ImageCard(it, 0.dp, 215.dp, open, Modifier.fillMaxWidth()) } } } }

@Composable fun SettingsScreen(back: () -> Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) { ExtraTop("Ayarlar", back); SettingsGroup("Hesap", listOf("Hesap Bilgileri", "Bildirimler", "Gizlilik")); SettingsGroup("Uygulama", listOf("Tema     Sistem", "Dil     Türkçe", "Önbellek Temizle     12.4 MB")); SettingsGroup("Hakkında", listOf("Sürüm     v1.0.0", "Bize Ulaşın", "Değerlendir")); Spacer(Modifier.height(20.dp)) } }
@Composable fun SettingsGroup(title: String, rows: List<String>) { Text(title, color = Purple2, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)); rows.forEach { Row(Modifier.padding(horizontal = 20.dp, vertical = 3.dp).fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Color(0x14FFFFFF)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ChevronRight, null, tint = Muted, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(10.dp)); Text(it, fontSize = 12.sp, modifier = Modifier.weight(1f)) } } }

@Composable
fun AboutScreen(back: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ExtraTop("Hakkında", back)
        Box(
            modifier = Modifier
                .padding(20.dp)
                .fillMaxWidth()
                .height(300.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.radialGradient(
                        listOf(Purple, Color(0xFF15152F), Color(0xFF090B17))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("WXTRA", fontSize = 43.sp, fontWeight = FontWeight.Black)
                Text("MORE THAN WALLPAPERS", fontSize = 9.sp, color = Muted, letterSpacing = 2.sp)
                Spacer(Modifier.height(25.dp))
                Text("Daha güzel bir dünya için. ✦", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
            }
        }
        listOf("Değerlendir", "Gizlilik Politikası", "Kullanım Şartları", "İletişim", "Bize Ulaşın").forEach {
            Row(
                Modifier
                    .padding(horizontal = 20.dp, vertical = 4.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(15.dp))
                    .background(Color(0x14FFFFFF))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(it, Modifier.weight(1f), fontSize = 12.sp)
                Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
        }
    }
}
