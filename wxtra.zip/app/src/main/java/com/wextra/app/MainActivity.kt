package com.wextra.app

import android.app.WallpaperManager
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070A12)
private val Card = Color(0xFF121827)
private val Card2 = Color(0xFF171D2D)
private val Purple = Color(0xFFB34DFF)
private val Blue = Color(0xFF4C8DFF)
private val TextMain = Color(0xFFF5F3FF)
private val TextMuted = Color(0xFFA5A7BC)
private val Accent = Brush.horizontalGradient(listOf(Color(0xFFE53CFF), Color(0xFF596CFF)))

private val wallpapers = listOf(
    R.drawable.wallpaper_0, R.drawable.wallpaper_1, R.drawable.wallpaper_2,
    R.drawable.wallpaper_3, R.drawable.wallpaper_4, R.drawable.wallpaper_5,
    R.drawable.wallpaper_6, R.drawable.wallpaper_7, R.drawable.wallpaper_8
)

private val names = listOf(
    "Renkli Kuş", "Kırmızı Dokunuş", "Saklı Bahçe", "Pembe Efsane",
    "Gece Sürüşü", "Doğanın İçinde", "Zarif Dokunuş", "Akış", "Renkli Akşamlar"
)

private sealed class Screen {
    data object Home : Screen()
    data object Explore : Screen()
    data object Favorites : Screen()
    data object Profile : Screen()
    data object Search : Screen()
    data object Notifications : Screen()
    data class Listing(val title: String, val indices: List<Int>) : Screen()
    data object Settings : Screen()
    data object About : Screen()
    data object Categories : Screen()
    data object Collections : Screen()
    data class Detail(val index: Int) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WXTRAApp() }
    }
}

@Composable
private fun WXTRAApp() {
    var backStack by remember { mutableStateOf(listOf<Screen>(Screen.Home)) }
    var search by remember { mutableStateOf("") }
    var liked by remember { mutableStateOf(setOf<Int>()) }

    val screen = backStack.last()
    fun push(next: Screen) { backStack = backStack + next }
    fun pop() {
        if (backStack.size > 1) backStack = backStack.dropLast(1)
    }
    fun selectRoot(next: Screen) { backStack = listOf(next) }

    BackHandler(enabled = backStack.size > 1) { pop() }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Purple)) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            when (val s = screen) {
                Screen.Home -> MainScaffold(0, { selectRoot(it) }, screen) {
                    HomeScreen(
                        open = { push(Screen.Detail(it)) },
                        openNotifications = { push(Screen.Notifications) },
                        openListing = { title, indices -> push(Screen.Listing(title, indices)) },
                        liked = liked,
                        toggleLike = { i -> liked = if (i in liked) liked - i else liked + i },
                    )
                }
                Screen.Categories -> MainScaffold(1, { selectRoot(it) }, screen) {
                    CategoriesScreen(back = { pop() }, openListing = { title, indices -> push(Screen.Listing(title, indices)) })
                }
                Screen.Explore -> MainScaffold(2, { selectRoot(it) }, screen) {
                    ExploreScreen(
                        open = { push(Screen.Detail(it)) },
                        openCategories = { push(Screen.Categories) },
                        openSearch = { push(Screen.Search) },
                        openNotifications = { push(Screen.Notifications) },
                        openListing = { title, indices -> push(Screen.Listing(title, indices)) }
                    )
                }
                Screen.Profile -> MainScaffold(3, { selectRoot(it) }, screen) {
                    ProfileScreen(
                        openSettings = { push(Screen.Settings) },
                        openCollections = { push(Screen.Collections) },
                        openAbout = { push(Screen.About) }
                    )
                }
                Screen.Search -> SearchScreen(search, { search = it }, { push(Screen.Detail(it)) })
                Screen.Notifications -> NotificationsScreen { pop() }
                is Screen.Listing -> ListingScreen(s.title, s.indices, { push(Screen.Detail(it)) })
                Screen.Settings -> MainScaffold(4, { selectRoot(it) }, screen) {
                    SettingsScreen { pop() }
                }
                Screen.About -> AboutScreen { pop() }
                Screen.Collections -> CollectionsScreen { pop() }
                Screen.Favorites -> FavoritesScreen(liked, { push(Screen.Detail(it)) }, toggleLike = { i -> liked = liked - i })
                is Screen.Detail -> DetailScreen(
                    index = s.index,
                    liked = s.index in liked,
                    toggleLike = { liked = if (s.index in liked) liked - s.index else liked + s.index },
                    back = { pop() },
                )
            }
        }
    }
}

@Composable
private fun MainScaffold(
    selected: Int,
    onScreen: (Screen) -> Unit,
    screen: Screen,
    content: @Composable () -> Unit
) {
    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = { BottomNav(selected) { idx ->
            onScreen(when (idx) {
                0 -> Screen.Home
                1 -> Screen.Categories
                2 -> Screen.Explore
                3 -> Screen.Profile
                else -> Screen.Settings
            })
        } }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) { content() }
    }
}

@Composable
private fun TopHeader(onSearch: () -> Unit, onProfile: () -> Unit, onNotifications: () -> Unit = {}, title: String = "WXTRA", subtitle: String = "Duvar kâğıtlarını keşfet.") {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = TextMain)
            Text(subtitle, color = TextMuted, fontSize = 13.sp)
        }
        IconButton(onClick = onSearch) { Icon(Icons.Default.Search, null, tint = TextMain) }
        IconButton(onClick = onNotifications) { Icon(Icons.Default.Notifications, null, tint = TextMain) }
        Box(Modifier.size(40.dp).clip(CircleShape).background(Accent).clickable { onProfile() }, contentAlignment = Alignment.Center) {
            Text("W", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun HomeScreen(
    open: (Int) -> Unit,
    openNotifications: () -> Unit,
    openListing: (String, List<Int>) -> Unit,
    liked: Set<Int>,
    toggleLike: (Int) -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Ana sayfa üst görseli: tasarımdaki üst bölüm tek parça ve ekran genişliğini tamamen kaplar.
        item {
            BoxWithConstraints(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            ) {
                val heroHeight = maxWidth * (622f / 853f)
                Image(
                    painter = painterResource(R.drawable.home_hero),
                    contentDescription = "Günün önerisi",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(heroHeight)
                        .clickable { open(4) },
                    contentScale = ContentScale.FillBounds
                )
            }
        }

        // Ana sayfa kategorileri
        item {
            LazyRow(
                Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                lazyItems(listOf(2 to "Doğa", 3 to "Anime", 4 to "Arabalar", 8 to "Uzay")) { item ->
                    CategoryTile(
                        item.first,
                        item.second,
                        Modifier.width(138.dp).height(112.dp),
                        open = { open(item.first) }
                    )
                }
            }
        }

        item {
            SectionTitle("🔥  Popüler Şu An", "Tümünü Gör") {
                openListing("Popüler Şu An", listOf(4, 0, 3, 2, 8, 5))
            }
        }
        item { WallpaperRow(listOf(4, 0, 3, 2, 8, 5), open, liked, toggleLike) }

        item {
            SectionTitle("✨  Senin Ruh Hâlin", "Tümünü Gör") {
                openListing("Senin Ruh Hâlin", listOf(2, 8, 4, 7, 6, 1))
            }
        }
        item {
            LazyRow(
                Modifier.padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                lazyItems(listOf(
                    2 to "Sakin", 8 to "Enerjik", 4 to "Melankolik",
                    7 to "Odak", 6 to "Mutlu", 1 to "Keşfet"
                )) { item ->
                    Box(
                        Modifier.width(100.dp).height(112.dp).clip(RoundedCornerShape(14.dp))
                            .clickable { open(item.first) }
                    ) {
                        Image(painterResource(wallpapers[item.first]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.72f)))))
                        Text(item.second, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomStart).padding(9.dp))
                    }
                }
            }
        }

        item {
            SectionTitle("🎨  Senin İçin Seçtiklerimiz", "Tümünü Gör") {
                openListing("Senin İçin Seçtiklerimiz", listOf(3, 0, 4, 7, 8, 2))
            }
        }
        item { WallpaperRow(listOf(3, 0, 4, 7, 8, 2), open, liked, toggleLike) }

        // Alt tanıtım bannerı
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(128.dp)
                    .padding(horizontal = 18.dp, vertical = 18.dp)
                    .clip(RoundedCornerShape(24.dp))
            ) {
                Image(painterResource(R.drawable.home_banner), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF180B2A).copy(.94f), Color.Transparent))))
                Column(Modifier.align(Alignment.CenterStart).padding(start = 18.dp)) {
                    Text("WXTRA İLE", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("Daha Fazlasını Hisset", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Senin tarzın. Senin duvarın. Senin hikayen.", color = Color.White.copy(.78f), fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
                }
            }
        }
    }
}

@Composable
private fun WallpaperRow(indices: List<Int>, open: (Int) -> Unit, liked: Set<Int>, toggleLike: (Int) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val cardWidth = ((maxWidth - 72.dp) / 4f).coerceAtLeast(68.dp)
        LazyRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            lazyItems(indices) { i ->
                ImageCard(
                    index = i,
                    open = open,
                    liked = i in liked,
                    onLike = { toggleLike(i) },
                    modifier = Modifier.width(cardWidth)
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        action?.let { Text(it, color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onAction?.invoke() }) }
    }
}

@Composable
private fun SearchBar(value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier, readOnly: Boolean = false) {
    OutlinedTextField(value = value, onValueChange = onValue, readOnly = readOnly, modifier = modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text("Duvar kağıdı ara…") }, colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Card, focusedContainerColor = Card2, unfocusedBorderColor = Color.Transparent, focusedBorderColor = Purple))
}

@Composable
private fun Pill(text: String, selected: Boolean = false) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(if (selected) Purple else Card2).padding(horizontal = 16.dp, vertical = 10.dp)) { Text(text, color = Color.White, fontSize = 12.sp) }
}

@Composable
private fun ChipRow(chips: List<String>) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (chips.isNotEmpty()) Pill(chips[0], selected = true)
        for (i in 1 until chips.size) Pill(chips[i], selected = false)
    }
}

@Composable
private fun CategoryTile(index: Int, title: String, modifier: Modifier, open: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(18.dp)).clickable { open() }) {
        Image(painterResource(wallpapers[index]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.7f)))))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomStart).padding(12.dp))
    }
}

@Composable
private fun ProfileAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp).clip(RoundedCornerShape(16.dp)).background(Card).clickable { onClick() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = TextMain)
        Text(title, color = TextMain, modifier = Modifier.weight(1f).padding(start = 14.dp))
        Icon(Icons.Default.ArrowForward, null, tint = TextMuted)
    }
}

@Composable
private fun SettingsSection(title: String, items: List<String>) {
    Text(title, color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp))
    if (items.isNotEmpty()) SettingsRow(items[0])
    if (items.size > 1) SettingsRow(items[1])
    if (items.size > 2) SettingsRow(items[2])
    if (items.size > 3) SettingsRow(items[3])
} 

@Composable
private fun SettingsRow(item: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(Card).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(item, color = TextMain, modifier = Modifier.weight(1f)); Text("›", color = TextMuted)
    }
}

@Composable
private fun CollectionCard(title: String, index: Int) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp).clip(RoundedCornerShape(18.dp)).background(Card).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(wallpapers[index]), null, Modifier.size(74.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
        Column(Modifier.padding(start = 12.dp)) { Text(title, color = TextMain, fontWeight = FontWeight.Bold); Text("Sizin için özel seçildi.", color = TextMuted, fontSize = 12.sp) }
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(value, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(label, color = TextMuted, fontSize = 11.sp) }
}

@Composable
private fun TopBar(title: String, back: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 22.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xF2090C16)) {
        NavigationBarItem(
            selected = selected == 0,
            onClick = { onSelect(0) },
            icon = { Icon(Icons.Default.Home, null) },
            label = { Text("Anasayfa") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 1,
            onClick = { onSelect(1) },
            icon = { Icon(Icons.Default.Wallpaper, null) },
            label = { Text("Kategori") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 2,
            onClick = { onSelect(2) },
            icon = { Icon(Icons.Default.Explore, null) },
            label = { Text("Keşfet") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 3,
            onClick = { onSelect(3) },
            icon = { Icon(Icons.Default.Person, null) },
            label = { Text("Profil") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 4,
            onClick = { onSelect(4) },
            icon = { Icon(Icons.Default.Settings, null) },
            label = { Text("Ayarlar") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = Color.Transparent)
        )
    }
}

@Composable
private fun ImageCard(
    index: Int,
    open: (Int) -> Unit,
    liked: Boolean,
    onLike: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.clickable { open(index) }) {
        Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(16.dp))) {
            Image(painterResource(wallpapers[index]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            IconButton(onClick = onLike, modifier = Modifier.align(Alignment.TopEnd)) {
                Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (liked) Color(0xFFFF4D72) else Color.White)
            }
        }
        Text(names[index], color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp))
    }
}

@Composable
private fun CollectionHomeCard(index: Int, title: String, open: (Int) -> Unit) {
    Box(Modifier.width(210.dp).height(120.dp).clip(RoundedCornerShape(18.dp)).clickable { open(index) }) {
        Image(painterResource(wallpapers[index]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.8f)))))
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Özel seçki", color = Color.White.copy(.75f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun ExploreImageRow(indices: List<Int>, open: (Int) -> Unit, columns: Int) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val gap = 10.dp
        val totalGap = gap * (columns - 1)
        val cardWidth = ((maxWidth - 36.dp - totalGap) / columns.toFloat()).coerceAtLeast(72.dp)
        LazyRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(gap)) {
            lazyItems(indices) { i ->
                ImageCard(i, open, false, {}, Modifier.width(cardWidth))
            }
        }
    }
}

@Composable
private fun ExploreScreen(open: (Int) -> Unit, openCategories: () -> Unit, openSearch: () -> Unit, openNotifications: () -> Unit, openListing: (String, List<Int>) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Keşfet", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = TextMain)
                    Text("Sıradan duvar kâğıtlarının ötesine geç.", color = TextMuted, fontSize = 13.sp)
                }
                IconButton(onClick = openNotifications) { Icon(Icons.Default.Notifications, null, tint = TextMain) }
            }
        }
        item {
            Box(Modifier.padding(horizontal = 18.dp, vertical = 8.dp).fillMaxWidth().height(150.dp).clip(RoundedCornerShape(22.dp)).clickable { open(2) }) {
                Image(painterResource(wallpapers[2]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(.78f), Color.Transparent))))
                Column(Modifier.align(Alignment.CenterStart).padding(18.dp)) {
                    Text("YENİ UFUKLAR", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Farklı Dünyaları Keşfet", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 4.dp))
                    Text("Her ekran, yeni bir hikâye.", color = Color.White.copy(.82f), fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
                    Box(Modifier.padding(top = 10.dp).clip(RoundedCornerShape(50)).background(Purple.copy(.95f)).padding(horizontal = 14.dp, vertical = 8.dp)) {
                        Text("Keşfetmeye Başla →", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }
        item { SectionTitle("🔥 Popüler Şu An", "Tümünü Gör") { openListing("Popüler Şu An", listOf(4, 3, 5, 8, 2, 7)) } }
        item { ExploreImageRow(listOf(4, 3, 5), open, 3) }
        item { SectionTitle("✨ Yeni Gelenler", "Tümünü Gör") { openListing("Yeni Gelenler", listOf(0, 6, 7, 8, 1, 5)) } }
        item { ExploreImageRow(listOf(0, 6, 7, 8), open, 4) }
        item { SectionTitle("📈 Yükselenler", "Tümünü Gör") { openListing("Yükselenler", listOf(7, 3, 5, 2, 4)) } }
        item {
            Row(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1.5f).height(210.dp).clip(RoundedCornerShape(18.dp)).clickable { open(7) }) {
                    Image(painterResource(wallpapers[7]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.7f)))))
                    Text(names[7], color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomStart).padding(12.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(3, 5).forEach { i ->
                        Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(18.dp)).clickable { open(i) }) {
                            Image(painterResource(wallpapers[i]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            Box(Modifier.fillMaxSize().background(Color.Black.copy(.2f)))
                        }
                    }
                }
            }
        }
        item { SectionTitle("🎨 Tarzına Göre", "Tümünü Gör") { openCategories() } }
        item {
            LazyRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                lazyItems(listOf(3 to "Anime", 5 to "Doğa", 2 to "Uzay", 4 to "Arabalar", 7 to "Minimal", 8 to "Karanlık", 0 to "Renkli")) { item ->
                    CategoryTile(item.first, item.second, Modifier.size(width = 112.dp, height = 90.dp)) { open(item.first) }
                }
            }
        }
        item { SectionTitle("👑 Haftanın Seçimleri", "Tümünü Gör") { openListing("Haftanın Seçimleri", listOf(3, 7, 5, 2, 8)) } }
        item {
            Box(Modifier.padding(horizontal = 18.dp).fillMaxWidth().height(132.dp).clip(RoundedCornerShape(20.dp)).clickable { open(3) }) {
                Image(painterResource(wallpapers[3]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(.78f), Color.Transparent))))
                Column(Modifier.align(Alignment.CenterStart).padding(16.dp)) {
                    Text("Bu Haftanın Özel Seçkisi", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    Text("WXTRA ekibinin seçtiği favoriler.", color = Color.White.copy(.8f), fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                }
            }
        }
        item { SectionTitle("👤 Senin İçin", "Tümünü Gör") { openListing("Senin İçin", listOf(4, 3, 0, 5, 7)) } }
        item { ExploreImageRow(listOf(4, 3, 0, 5), open, 4) }
    }
}

@Composable
private fun FavoritesScreen(liked: Set<Int>, open: (Int) -> Unit, toggleLike: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar("Favoriler", { }) }
        if (liked.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(50.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FavoriteBorder, null, tint = Purple, modifier = Modifier.size(54.dp))
                    Text("Henüz favorin yok", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp))
                    Text("Beğendiğin duvar kâğıtları burada görünecek.", color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        } else {
            item {
                LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.height(560.dp), contentPadding = PaddingValues(18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    gridItems(liked.toList()) { i -> ImageCard(i, open, true, { toggleLike(i) }, Modifier.fillMaxWidth()) }
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen(openSettings: () -> Unit, openCollections: () -> Unit, openAbout: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Column(Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(82.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) { Text("W", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold) }
                Text("WXTRA Kullanıcısı", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                Text("Duvar kâğıdı tutkunu", color = TextMuted, fontSize = 13.sp)
                Row(Modifier.padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(36.dp)) { Stat("0", "Favori"); Stat("9", "Duvar kâğıdı"); Stat("0", "Koleksiyon") }
            }
        }
        item { ProfileAction("Koleksiyonlarım", Icons.Default.Wallpaper, openCollections) }
        item { ProfileAction("Ayarlar", Icons.Default.Settings, openSettings) }
        item { ProfileAction("WXTRA Hakkında", Icons.Default.Info, openAbout) }
    }
}

@Composable
private fun SearchScreen(value: String, onValue: (String) -> Unit, open: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp)) {
        item { TopBar("Ara", { }) }
        item { SearchBar(value, onValue, Modifier.padding(bottom = 18.dp)) }
        val results = if (value.isBlank()) (0..8).toList() else (0..8).filter { names[it].contains(value, true) }
        item {
            if (results.isEmpty()) Text("Sonuç bulunamadı.", color = TextMuted, modifier = Modifier.padding(20.dp))
            else LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.height(600.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                gridItems(results) { i -> ImageCard(i, open, false, {}, Modifier.fillMaxWidth()) }
            }
        }
    }
}

@Composable
private fun NotificationsScreen(back: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar("Bildirimler", back) }
        item {
            Column(Modifier.padding(18.dp).clip(RoundedCornerShape(18.dp)).background(Card).padding(18.dp)) {
                Icon(Icons.Default.Notifications, null, tint = Purple, modifier = Modifier.size(30.dp))
                Text("WXTRA'ya hoş geldin!", color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                Text("Yeni duvar kâğıtları ve koleksiyonlar burada görünecek.", color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
            }
        }
    }
}

@Composable
private fun ListingScreen(title: String, indices: List<Int>, open: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar(title, { }) }
        item {
            LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.height(720.dp), contentPadding = PaddingValues(18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                gridItems(indices) { i -> ImageCard(i, open, false, {}, Modifier.fillMaxWidth()) }
            }
        }
    }
}

@Composable
private fun SettingsScreen(back: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { TopBar("Ayarlar", back) }
        item { SettingsSection("GENEL", listOf("Bildirimler", "Görünüm", "Dil")) }
        item { SettingsSection("HESAP", listOf("Profil bilgileri", "Gizlilik", "Çıkış yap")) }
        item { SettingsSection("DESTEK", listOf("Yardım", "Geri bildirim", "WXTRA Hakkında")) }
    }
}

@Composable
private fun AboutScreen(back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        TopBar("WXTRA Hakkında", back)
        Spacer(Modifier.height(30.dp))
        Text("Sıradan duvar kâğıtlarına veda.", color = Purple, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Text("Her gün yeni bir hikâye. WXTRA, telefonunu kişiselleştirmek için seçilmiş duvar kâğıtlarını tek yerde sunar.", color = TextMuted, fontSize = 14.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 14.dp))
        Text("Sürüm 0.1.0", color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 30.dp))
    }
}

@Composable
private fun CategoriesScreen(back: () -> Unit, openListing: (String, List<Int>) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar("Kategoriler", back) }
        item {
            val cats = listOf(
                Triple(0, "Doğa", listOf(2, 5, 8)), Triple(1, "Şehir", listOf(1, 4, 7)),
                Triple(2, "Uzay", listOf(0, 2, 7)), Triple(3, "Anime", listOf(3, 8, 1)),
                Triple(4, "Gece", listOf(4, 7, 2)), Triple(5, "Minimal", listOf(5, 6, 2)),
                Triple(6, "Sanat", listOf(6, 3, 0)), Triple(7, "Karanlık", listOf(4, 7, 3)),
                Triple(8, "Renkli", listOf(0, 1, 8))
            )
            LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.height(680.dp), contentPadding = PaddingValues(18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                gridItems(cats) { item ->
                    CategoryTile(item.first, item.second, Modifier.fillMaxWidth().height(145.dp)) {
                        openListing(item.second, item.third)
                    }
                }
            }
        }
    }
}

@Composable
private fun CollectionsScreen(back: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { TopBar("Koleksiyonlarım", back) }
        item { CollectionCard("4K Ultra HD", 0) }
        item { CollectionCard("Etkileyici Manzaralar", 2) }
        item { CollectionCard("Karanlık Mod", 7) }
        item { CollectionCard("Anime Dünyası", 8) }
    }
}

@Composable
private fun DetailScreen(index: Int, liked: Boolean, toggleLike: () -> Unit, back: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var applied by remember { mutableStateOf(false) }
    var applying by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(painterResource(wallpapers[index]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(.10f), Color.Transparent, Color.Black.copy(.58f)))))

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp)) {
            Text(names[index], color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp))
            Text("WXTRA seçkisi  •  Telefonuna uygun", color = Color.White.copy(.82f), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
            Row(
                Modifier.padding(top = 10.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color.Black.copy(.46f)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(Modifier.size(50.dp).clip(CircleShape).background(Color.White.copy(.12f)).clickable { }) {
                    Icon(Icons.Default.Info, null, tint = Color.White, modifier = Modifier.align(Alignment.Center))
                }
                Box(Modifier.weight(1f).height(50.dp).clip(RoundedCornerShape(20.dp)).background(Accent).clickable(enabled = !applying) {
                    applying = true
                    scope.launch {
                        val success = withContext(Dispatchers.IO) {
                            try {
                                val wm = WallpaperManager.getInstance(context)
                                val drawable = androidx.core.content.ContextCompat.getDrawable(context, wallpapers[index])
                                if (drawable is BitmapDrawable) {
                                    wm.setBitmap(drawable.bitmap)
                                    true
                                } else false
                            } catch (_: Exception) {
                                false
                            }
                        }
                        applied = success
                        applying = false
                    }
                }) {
                    Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.Wallpaper, null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text(when { applying -> "Uygulanıyor…"; applied -> "Uygulandı ✓"; else -> "Duvar Kâğıdı Yap" }, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                Box(Modifier.size(50.dp).clip(CircleShape).background(Color.White.copy(.12f)).clickable { toggleLike() }) {
                    Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (liked) Color(0xFFFF4D72) else Color.White, modifier = Modifier.align(Alignment.Center))
                }
            }
        }
    }
}
