import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wallpaper_manager_flutter/wallpaper_manager_flutter.dart';

const _purple = Color(0xFF5F2FE8);
const _purple2 = Color(0xFF8A63F5);
const _ink = Color(0xFF171526);
const _surface = Color(0xFFF8F7FC);
const _muted = Color(0xFF777487);
const _dark = Color(0xFF11111A);
const _apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://10.0.2.2:8000/api',
);

void main() => runApp(const WxtraApp());

class AppSettings {
  final ThemeMode themeMode;
  final int accentColor;
  final String? backgroundImagePath;
  final String cardLayout;
  final bool notificationsEnabled;
  final bool newWallpapers;
  final bool favoriteCategories;
  final bool recommendations;
  final bool editorPicks;
  final bool launchEnabled;
  final bool launchNewWallpapers;
  final bool launchFavoriteCategory;
  final bool launchRecommendations;
  final bool launchEditorPicks;
  final String launchFrequency;
  final bool googleConnected;
  final String language;

  const AppSettings({
    this.themeMode = ThemeMode.system,
    this.accentColor = 0xFF5F2FE8,
    this.backgroundImagePath,
    this.cardLayout = 'grid2',
    this.notificationsEnabled = true,
    this.newWallpapers = true,
    this.favoriteCategories = true,
    this.recommendations = true,
    this.editorPicks = true,
    this.launchEnabled = false,
    this.launchNewWallpapers = true,
    this.launchFavoriteCategory = true,
    this.launchRecommendations = true,
    this.launchEditorPicks = true,
    this.launchFrequency = 'Her açılışta',
    this.googleConnected = false,
    this.language = 'tr',
  });

  Color get accent => Color(accentColor);

  AppSettings copyWith({
    ThemeMode? themeMode,
    int? accentColor,
    String? backgroundImagePath,
    bool clearBackground = false,
    String? cardLayout,
    bool? notificationsEnabled,
    bool? newWallpapers,
    bool? favoriteCategories,
    bool? recommendations,
    bool? editorPicks,
    bool? launchEnabled,
    bool? launchNewWallpapers,
    bool? launchFavoriteCategory,
    bool? launchRecommendations,
    bool? launchEditorPicks,
    String? launchFrequency,
    bool? googleConnected,
    String? language,
  }) {
    return AppSettings(
      themeMode: themeMode ?? this.themeMode,
      accentColor: accentColor ?? this.accentColor,
      backgroundImagePath: clearBackground ? null : (backgroundImagePath ?? this.backgroundImagePath),
      cardLayout: cardLayout ?? this.cardLayout,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      newWallpapers: newWallpapers ?? this.newWallpapers,
      favoriteCategories: favoriteCategories ?? this.favoriteCategories,
      recommendations: recommendations ?? this.recommendations,
      editorPicks: editorPicks ?? this.editorPicks,
      launchEnabled: launchEnabled ?? this.launchEnabled,
      launchNewWallpapers: launchNewWallpapers ?? this.launchNewWallpapers,
      launchFavoriteCategory: launchFavoriteCategory ?? this.launchFavoriteCategory,
      launchRecommendations: launchRecommendations ?? this.launchRecommendations,
      launchEditorPicks: launchEditorPicks ?? this.launchEditorPicks,
      launchFrequency: launchFrequency ?? this.launchFrequency,
      googleConnected: googleConnected ?? this.googleConnected,
      language: language ?? this.language,
    );
  }

  static Future<AppSettings> load() async {
    final p = await SharedPreferences.getInstance();
    return AppSettings(
      themeMode: ThemeMode.values.firstWhere(
        (m) => m.name == (p.getString('themeMode') ?? 'system'),
        orElse: () => ThemeMode.system,
      ),
      accentColor: p.getInt('accentColor') ?? 0xFF5F2FE8,
      backgroundImagePath: p.getString('backgroundImagePath'),
      cardLayout: p.getString('cardLayout') ?? 'grid2',
      notificationsEnabled: p.getBool('notificationsEnabled') ?? true,
      newWallpapers: p.getBool('newWallpapers') ?? true,
      favoriteCategories: p.getBool('favoriteCategories') ?? true,
      recommendations: p.getBool('recommendations') ?? true,
      editorPicks: p.getBool('editorPicks') ?? true,
      launchEnabled: p.getBool('launchEnabled') ?? false,
      launchNewWallpapers: p.getBool('launchNewWallpapers') ?? true,
      launchFavoriteCategory: p.getBool('launchFavoriteCategory') ?? true,
      launchRecommendations: p.getBool('launchRecommendations') ?? true,
      launchEditorPicks: p.getBool('launchEditorPicks') ?? true,
      launchFrequency: p.getString('launchFrequency') ?? 'Her açılışta',
      googleConnected: p.getBool('googleConnected') ?? false,
      language: p.getString('language') ?? 'tr',
    );
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('themeMode', themeMode.name);
    await p.setInt('accentColor', accentColor);
    if (backgroundImagePath == null) {
      await p.remove('backgroundImagePath');
    } else {
      await p.setString('backgroundImagePath', backgroundImagePath!);
    }
    await p.setString('cardLayout', cardLayout);
    await p.setBool('notificationsEnabled', notificationsEnabled);
    await p.setBool('newWallpapers', newWallpapers);
    await p.setBool('favoriteCategories', favoriteCategories);
    await p.setBool('recommendations', recommendations);
    await p.setBool('editorPicks', editorPicks);
    await p.setBool('launchEnabled', launchEnabled);
    await p.setBool('launchNewWallpapers', launchNewWallpapers);
    await p.setBool('launchFavoriteCategory', launchFavoriteCategory);
    await p.setBool('launchRecommendations', launchRecommendations);
    await p.setBool('launchEditorPicks', launchEditorPicks);
    await p.setString('launchFrequency', launchFrequency);
    await p.setBool('googleConnected', googleConnected);
    await p.setString('language', language);
  }
}

class FavoritesStore extends ChangeNotifier {
  static const _key = 'favorite_ids';
  final Set<String> _ids = <String>{};

  bool contains(String id) => _ids.contains(id);
  Set<String> get ids => Set.unmodifiable(_ids);

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    _ids
      ..clear()
      ..addAll(p.getStringList(_key) ?? const <String>[]);
    notifyListeners();
  }

  Future<void> clear() async {
    _ids.clear();
    final p = await SharedPreferences.getInstance();
    await p.remove(_key);
    notifyListeners();
  }

  Future<void> toggle(String id) async {
    if (_ids.contains(id)) {
      _ids.remove(id);
    } else {
      _ids.add(id);
    }
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_key, _ids.toList());
    notifyListeners();
  }
}


final Map<String, String> _categoryImages = {};

class CatalogStore {
  static const _wallpapersKey = 'wxtra_custom_wallpapers';
  static const _categoriesKey = 'wxtra_categories';
  static const _categoryImagesKey = 'wxtra_category_images';

  static Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_wallpapersKey);
    if (raw != null && raw.isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          for (final value in decoded) {
            if (value is Map) {
              final item = Wallpaper.fromJson(Map<String, dynamic>.from(value));
              _publishedWallpapers.removeWhere((w) => w.id == item.id);
              _publishedWallpapers.add(item);
            }
          }
        }
      } catch (_) {}
    }
    final savedCategories = prefs.getStringList(_categoriesKey);
    if (savedCategories != null && savedCategories.isNotEmpty) {
      _categories
        ..clear()
        ..addAll(savedCategories);
    }
    final savedImages = prefs.getString(_categoryImagesKey);
    if (savedImages != null && savedImages.isNotEmpty) {
      try {
        final decoded = jsonDecode(savedImages);
        if (decoded is Map) {
          _categoryImages
            ..clear()
            ..addAll(Map<String, dynamic>.from(decoded).map(
              (key, value) => MapEntry(key, value.toString()),
            ));
        }
      } catch (_) {}
    }
  }

  static Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    final custom = _publishedWallpapers
        .where((w) => w.id.startsWith('custom-'))
        .map((w) => w.toJson())
        .toList();
    await prefs.setString(_wallpapersKey, jsonEncode(custom));
    await prefs.setStringList(_categoriesKey, _categories);
    await prefs.setString(_categoryImagesKey, jsonEncode(_categoryImages));
  }
}

class UsageStats {
  static Future<void> increment(String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(key, (prefs.getInt(key) ?? 0) + 1);
  }

  static Future<int> read(String key) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(key) ?? 0;
  }
}

class AdminSchedule {
  final String id;
  final String wallpaperId;
  final String type;
  final DateTime publishAt;

  const AdminSchedule({
    required this.id,
    required this.wallpaperId,
    required this.type,
    required this.publishAt,
  });

  bool get published => !publishAt.isAfter(DateTime.now());

  Map<String, dynamic> toJson() => {
        'id': id,
        'wallpaperId': wallpaperId,
        'type': type,
        'publishAt': publishAt.toIso8601String(),
      };

  static AdminSchedule fromJson(Map<String, dynamic> json) => AdminSchedule(
        id: json['id'] as String,
        wallpaperId: json['wallpaperId'] as String,
        type: json['type'] as String,
        publishAt: DateTime.parse(json['publishAt'] as String),
      );
}

class AdminStore {
  static const _scheduleKey = 'wxtra_admin_schedules';
  static const _announcementKey = 'wxtra_admin_announcements';
  static const _contentKey = 'wxtra_admin_content';
  static const _maintenanceKey = 'wxtra_admin_maintenance';

  static Future<List<AdminSchedule>> schedules() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_scheduleKey);
    if (raw == null || raw.isEmpty) return [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      return decoded.whereType<Map>().map((e) =>
          AdminSchedule.fromJson(Map<String, dynamic>.from(e))).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveSchedules(List<AdminSchedule> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _scheduleKey,
      jsonEncode(items.map((e) => e.toJson()).toList()),
    );
  }

  static Future<List<String>> announcements() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(_announcementKey) ?? [];
  }

  static Future<void> addAnnouncement(String text) async {
    final prefs = await SharedPreferences.getInstance();
    final values = prefs.getStringList(_announcementKey) ?? [];
    values.insert(0, text);
    await prefs.setStringList(_announcementKey, values);
  }

  static Future<String?> content(String key) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_contentKey);
    if (raw == null) return null;
    try {
      return Map<String, dynamic>.from(jsonDecode(raw))[key] as String?;
    } catch (_) {
      return null;
    }
  }

  static Future<void> setContent(String key, String? wallpaperId) async {
    final prefs = await SharedPreferences.getInstance();
    var map = <String, dynamic>{};
    final raw = prefs.getString(_contentKey);
    if (raw != null) {
      try {
        map = Map<String, dynamic>.from(jsonDecode(raw));
      } catch (_) {}
    }
    if (wallpaperId == null) {
      map.remove(key);
    } else {
      map[key] = wallpaperId;
    }
    await prefs.setString(_contentKey, jsonEncode(map));
  }

  static Future<bool> maintenance() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_maintenanceKey) ?? false;
  }

  static Future<void> setMaintenance(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_maintenanceKey, value);
  }
}

class WxtraApp extends StatefulWidget {
  const WxtraApp({super.key});
  @override
  State<WxtraApp> createState() => _WxtraAppState();
}

class _WxtraAppState extends State<WxtraApp> {
  AppSettings _settings = const AppSettings();
  final FavoritesStore _favorites = FavoritesStore();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final values = await Future.wait([
      AppSettings.load(),
      _favorites.load(),
      CatalogStore.load(),
    ]);
    if (!mounted) return;
    setState(() {
      _settings = values.first as AppSettings;
      _loaded = true;
    });
  }

  Future<void> _updateSettings(AppSettings next) async {
    setState(() => _settings = next);
    await next.save();
  }

  ThemeData _theme(Brightness brightness) {
    final scheme = ColorScheme.fromSeed(seedColor: _purple, brightness: brightness);
    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: brightness == Brightness.dark ? _dark : _surface,
      appBarTheme: AppBarTheme(
        backgroundColor: brightness == Brightness.dark ? _dark : _surface,
        foregroundColor: brightness == Brightness.dark ? Colors.white : _ink,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: brightness == Brightness.dark ? const Color(0xFF2B2935) : _ink,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: _theme(Brightness.light),
        home: const Scaffold(body: Center(child: CircularProgressIndicator())),
      );
    }
    return AnimatedBuilder(
      animation: _favorites,
      builder: (_, __) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Wxtra',
        theme: _theme(Brightness.light),
        themeMode: ThemeMode.light,
        home: AppShell(
          settings: _settings,
          favorites: _favorites,
          onSettingsChanged: _updateSettings,
        ),
      ),
    );
  }
}

class AppShell extends StatefulWidget {
  final AppSettings settings;
  final FavoritesStore favorites;
  final ValueChanged<AppSettings> onSettingsChanged;
  const AppShell({super.key, required this.settings, required this.favorites, required this.onSettingsChanged});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  bool _launchShown = false;
  static const _launchLastShownKey = 'launchLastShownAt';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_launchShown || !widget.settings.launchEnabled) return;
    _launchShown = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _maybeShowLaunchSheet();
    });
  }

  Future<void> _maybeShowLaunchSheet() async {
    if (!widget.settings.launchEnabled) return;
    if (widget.settings.launchFrequency == 'Günde bir kez') {
      final prefs = await SharedPreferences.getInstance();
      final last = prefs.getInt(_launchLastShownKey);
      final now = DateTime.now();
      if (last != null) {
        final previous = DateTime.fromMillisecondsSinceEpoch(last);
        if (previous.year == now.year && previous.month == now.month && previous.day == now.day) return;
      }
    }
    await _showLaunchSheet();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_launchLastShownKey, DateTime.now().millisecondsSinceEpoch);
  }

  Future<void> _showLaunchSheet() async {
    final candidates = <Wallpaper>[];
    if (widget.settings.launchNewWallpapers) candidates.add(_publishedWallpapers[0]);
    if (widget.settings.launchFavoriteCategory) {
      candidates.add(_publishedWallpapers.firstWhere((w) => w.category == 'Doğa', orElse: () => _publishedWallpapers[2]));
    }
    if (widget.settings.launchRecommendations) candidates.add(_publishedWallpapers[1]);
    if (widget.settings.launchEditorPicks) candidates.add(_publishedWallpapers[4]);
    if (candidates.isEmpty) return;
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: false,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Bugünün seçkisi', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              SizedBox(
                height: 135,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: candidates.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (_, i) => SizedBox(
                    width: 104,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.of(sheetContext).pop();
                        if (!mounted) return;
                        Navigator.of(context).push(MaterialPageRoute(builder: (_) => DetailPage(item: candidates[i], favorites: widget.favorites)));
                      },
                      child: WallpaperCard(item: candidates[i], favorites: widget.favorites, variant: i % 4),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onNavigate: (i) => setState(() => _index = i), favorites: widget.favorites),
      CategoriesPage(favorites: widget.favorites, layout: widget.settings.cardLayout),
      DiscoverPage(favorites: widget.favorites, layout: widget.settings.cardLayout),
      FavoritesPage(layout: widget.settings.cardLayout, favorites: widget.favorites),
      SettingsPage(
        settings: widget.settings,
        favorites: widget.favorites,
        onChanged: widget.onSettingsChanged,
        onCatalogChanged: () {
          if (mounted) setState(() {});
        },
      ),
    ];
    return PopScope<void>(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop && _index != 0 && mounted) {
          setState(() => _index = 0);
        }
      },
      child: Scaffold(
        body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFBFAFF), Color(0xFFF3F0FF), Color(0xFFF8F7FC)],
          ),
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            const Positioned(top: -90, right: -80, child: _BackgroundOrb(size: 230)),
            const Positioned(bottom: 40, left: -120, child: _BackgroundOrb(size: 260)),
            SafeArea(child: IndexedStack(index: _index, children: pages)),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (v) => setState(() => _index = v),
        height: 74,
        destinations: [
          NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home_rounded), label: AppStrings.of(widget.settings.language, 'home')),
          NavigationDestination(icon: const Icon(Icons.grid_view_outlined), selectedIcon: const Icon(Icons.grid_view_rounded), label: AppStrings.of(widget.settings.language, 'categories')),
          NavigationDestination(icon: const Icon(Icons.search_outlined), selectedIcon: const Icon(Icons.search_rounded), label: AppStrings.of(widget.settings.language, 'discover')),
          NavigationDestination(icon: const Icon(Icons.favorite_border_rounded), selectedIcon: const Icon(Icons.favorite_rounded), label: AppStrings.of(widget.settings.language, 'favorites')),
          NavigationDestination(icon: const Icon(Icons.settings_outlined), selectedIcon: const Icon(Icons.settings_rounded), label: AppStrings.of(widget.settings.language, 'settings')),
        ],
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final ValueChanged<int> onNavigate;
  final FavoritesStore favorites;
  const HomePage({super.key, required this.onNavigate, required this.favorites});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final PageController _heroController = PageController(viewportFraction: .93);
  int _heroIndex = 0;
  Map<String, String> _contentIds = {};

  @override
  void initState() {
    super.initState();
    _loadContentSelections();
  }

  Future<void> _loadContentSelections() async {
    final keys = const ['daily', 'featured', 'editor', 'popular', 'latest'];
    final values = <String, String>{};
    for (final key in keys) {
      final id = await AdminStore.content(key);
      if (id != null) values[key] = id;
    }
    if (mounted) setState(() => _contentIds = values);
  }

  Wallpaper _contentWallpaper(String key, int fallbackIndex) {
    final targetId = _contentIds[key];
    if (targetId != null) {
      final matches = _publishedWallpapers.where((w) => w.id == targetId).toList();
      if (matches.isNotEmpty) return matches.first;
    }
    final items = _publishedWallpapers;
    return items[(fallbackIndex.abs()) % items.length];
  }

  @override
  void dispose() {
    _heroController.dispose();
    super.dispose();
  }

  void _openDetail(Wallpaper item) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => DetailPage(item: item, favorites: widget.favorites)));
  }

  @override
  Widget build(BuildContext context) {
    final daily = _contentWallpaper('daily', 0);
    final featured = <Wallpaper>[
      daily,
      ..._publishedWallpapers.where((w) => w.id != daily.id).take(2),
    ];
    final popularSeed = _contentWallpaper('popular', _publishedWallpapers.length - 1);
    final popular = <Wallpaper>[
      popularSeed,
      ..._publishedWallpapers.where((w) => w.id != popularSeed.id).toList().reversed,
    ];
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 26),
      children: [
        _HomeHeader(
          onSearch: () => widget.onNavigate(2),
          onMenu: () => _showHomeMenu(context),
        ),
        const SizedBox(height: 18),
        SizedBox(
          height: 228,
          child: PageView.builder(
            controller: _heroController,
            itemCount: featured.length,
            onPageChanged: (value) => setState(() => _heroIndex = value),
            itemBuilder: (_, index) {
              final item = featured[index];
              return Padding(
                padding: const EdgeInsets.only(right: 10),
                child: GestureDetector(
                  onTap: () => _openDetail(item),
                  child: _HomeHero(item: item, index: index),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 9),
        _ActiveDots(count: featured.length, current: _heroIndex),
        const SizedBox(height: 22),
        Row(
          children: [
            const Expanded(child: _SectionHeader(title: 'Hızlı Keşfet')),
            TextButton(onPressed: () => widget.onNavigate(2), child: const Text('Tümünü gör')),
          ],
        ),
        const SizedBox(height: 7),
        SizedBox(
          height: 86,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: _homeQuickCategories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, index) {
              final entry = _homeQuickCategories[index];
              return _QuickCategory(
                title: entry.$1,
                icon: entry.$2,
                seed: index + 20,
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CategoryDetailPage(category: entry.$1, favorites: widget.favorites, layout: 'grid2'))),
              );
            },
          ),
        ),
        const SizedBox(height: 22),
        Row(
          children: [
            const Expanded(child: _SectionHeader(title: 'Senin İçin')),
            TextButton(onPressed: () => widget.onNavigate(2), child: const Text('Daha fazlası')),
          ],
        ),
        const SizedBox(height: 9),
        SizedBox(
          height: 270,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: _publishedWallpapers.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, index) => SizedBox(
              width: 178,
              child: GestureDetector(
                onTap: () => _openDetail(_publishedWallpapers[index]),
                child: WallpaperCard(item: _publishedWallpapers[index], variant: index % 4, favorites: widget.favorites),
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        InkWell(
          onTap: () => _openDetail(_publishedWallpapers[_heroIndex % _publishedWallpapers.length]),
          borderRadius: BorderRadius.circular(26),
          child: const _CollectionBanner(),
        ),
        const SizedBox(height: 22),
        Row(
          children: [
            const Expanded(child: _SectionHeader(title: 'Popüler Duvar Kağıtları')),
            TextButton(onPressed: () => widget.onNavigate(2), child: const Text('Tümünü gör')),
          ],
        ),
        const SizedBox(height: 9),
        SizedBox(
          height: 118,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: popular.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, index) {
              final item = popular[index];
              return SizedBox(
                width: 154,
                child: GestureDetector(
                  onTap: () => _openDetail(item),
                  child: _MiniWallpaperCard(item: item),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Future<void> _showHomeMenu(BuildContext context) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.auto_awesome_rounded), title: const Text('Günün seçkisi'), onTap: () { Navigator.of(sheetContext).pop(); _openDetail(_publishedWallpapers.first); }),
          ListTile(leading: const Icon(Icons.search_rounded), title: const Text('Keşfet'), onTap: () { Navigator.of(sheetContext).pop(); widget.onNavigate(2); }),
          ListTile(leading: const Icon(Icons.favorite_rounded), title: const Text('Favoriler'), onTap: () { Navigator.of(sheetContext).pop(); widget.onNavigate(3); }),
          ListTile(leading: const Icon(Icons.settings_rounded), title: const Text('Ayarlar'), onTap: () { Navigator.of(sheetContext).pop(); widget.onNavigate(4); }),
          const SizedBox(height: 10),
        ]),
      ),
    );
  }
}

const _homeQuickCategories = <(String, IconData)>[
  ('Doğa', Icons.eco_rounded),
  ('Şehir', Icons.location_city_rounded),
  ('Anime', Icons.face_retouching_natural_rounded),
  ('Uzay', Icons.nightlight_round),
  ('Minimal', Icons.auto_awesome_rounded),
  ('Arabalar', Icons.directions_car_rounded),
];

class _HomeHero extends StatelessWidget {
  final Wallpaper item;
  final int index;
  const _HomeHero({required this.item, required this.index});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: Stack(
        fit: StackFit.expand,
        children: [
          DecoratedBox(
            decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: item.gradient)),
            child: _SoftShape(seed: item.id.hashCode + 31),
          ),
          Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black.withValues(alpha: .58)])))),
          Positioned(top: 16, left: 16, child: _HeroPill(text: index == 0 ? 'Günün seçkisi' : 'Özel koleksiyon')),
          Positioned(top: 16, right: 16, child: _HeroIcon(icon: Icons.arrow_forward_rounded)),
          Positioned(left: 18, right: 18, bottom: 18, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(item.title, style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Text('${item.category} · 4K', style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w700)),
          ])),
        ],
      ),
    );
  }
}

class _HeroPill extends StatelessWidget {
  final String text;
  const _HeroPill({required this.text});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18), borderRadius: BorderRadius.circular(99), border: Border.all(color: Colors.white.withValues(alpha: .22))), child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900)));
}

class _HeroIcon extends StatelessWidget {
  final IconData icon;
  const _HeroIcon({required this.icon});
  @override
  Widget build(BuildContext context) => Container(width: 38, height: 38, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18), shape: BoxShape.circle, border: Border.all(color: Colors.white.withValues(alpha: .22))), child: Icon(icon, color: Colors.white, size: 19));
}

class _QuickCategory extends StatelessWidget {
  final String title;
  final IconData icon;
  final int seed;
  final VoidCallback onTap;

  const _QuickCategory({
    required this.title,
    required this.icon,
    required this.seed,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        width: 82,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: _purple.withValues(alpha: .07),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 39,
              height: 39,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: _gradientFor(seed)),
                borderRadius: BorderRadius.circular(13),
              ),
              child: Icon(icon, color: Colors.white, size: 19),
            ),
            const SizedBox(height: 6),
            Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 10.5,
                fontWeight: FontWeight.w900,
                color: _ink,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CollectionBanner extends StatelessWidget {
  const _CollectionBanner();
  @override
  Widget build(BuildContext context) => Container(height: 108, padding: const EdgeInsets.all(15), decoration: BoxDecoration(borderRadius: BorderRadius.circular(26), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [_purple, _purple2]), boxShadow: [BoxShadow(color: _purple.withValues(alpha: .18), blurRadius: 24, offset: const Offset(0, 12))]), child: Row(children: [Container(width: 60, height: 60, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .16), borderRadius: BorderRadius.circular(20)), child: const Icon(Icons.layers_rounded, color: Colors.white, size: 29)), const SizedBox(width: 13), const Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Özel koleksiyonlar', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)), SizedBox(height: 4), Text('Sadece WXTRA’da keşfedebileceğin seçkiler.', style: TextStyle(color: Colors.white70, fontSize: 11.5))])), Container(width: 40, height: 40, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .15), shape: BoxShape.circle), child: const Icon(Icons.arrow_forward_rounded, color: Colors.white))]));
}

class _MiniWallpaperCard extends StatelessWidget {
  final Wallpaper item;
  const _MiniWallpaperCard({required this.item});
  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (item.imagePath != null)
            Positioned.fill(
              child: Image.file(
                File(item.imagePath!),
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: item.gradient,
                    ),
                  ),
                  child: _SoftShape(seed: item.id.hashCode + 91),
                ),
              ),
            )
          else
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: item.gradient,
                ),
              ),
              child: _SoftShape(seed: item.id.hashCode + 91),
            ),
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Colors.black.withValues(alpha: .62)],
                ),
              ),
            ),
          ),
          Positioned(
            left: 11,
            right: 11,
            bottom: 10,
            child: Text(
              item.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BackgroundOrb extends StatelessWidget {
  final double size;
  const _BackgroundOrb({required this.size});
  @override
  Widget build(BuildContext context) => IgnorePointer(child: Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [const Color(0xFFDCCBFF).withValues(alpha: .30), Colors.transparent]))));
}

class _HomeHeader extends StatelessWidget {
  final VoidCallback onSearch;
  final VoidCallback onMenu;
  const _HomeHeader({required this.onSearch, required this.onMenu});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(
        width: 48, height: 48, padding: const EdgeInsets.all(5),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17), boxShadow: [BoxShadow(color: _purple.withValues(alpha: .11), blurRadius: 18, offset: const Offset(0, 7))]),
        child: ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.asset('assets/logo.png', fit: BoxFit.cover)),
      ),
      const SizedBox(width: 11),
      Expanded(
        child: ShaderMask(
          shaderCallback: (r) => LinearGradient(
            colors: [Theme.of(context).colorScheme.primary, Theme.of(context).colorScheme.secondary],
          ).createShader(r),
          child: const Text('WXTRA', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 3.6)),
        ),
      ),
      _CircleButton(icon: Icons.search_rounded, onTap: onSearch),
      const SizedBox(width: 7),
      _CircleButton(icon: Icons.menu_rounded, onTap: onMenu),
    ]);
  }
}

class _HeroBrandCard extends StatelessWidget {
  const _HeroBrandCard();
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 188,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white, Color(0xFFF1EDFF), Color(0xFFE2D7FF)]),
        border: Border.all(color: Colors.white.withValues(alpha: .88)),
        boxShadow: [BoxShadow(color: _purple.withValues(alpha: .13), blurRadius: 28, offset: const Offset(0, 14))],
      ),
      child: Stack(children: [
        const Positioned.fill(child: _FineWaveTexture()),
        Positioned(right: 10, top: 10, child: Image.asset('assets/logo.png', width: 126, height: 126)),
        const Positioned(left: 20, top: 22, child: Text('Daha Fazlası.', style: TextStyle(fontSize: 27, height: 1.05, fontWeight: FontWeight.w900, color: _ink))),
        const Positioned(left: 20, top: 82, child: SizedBox(width: 205, child: Text('Sadece bir duvar kâğıdı değil, ekranına ilham.', style: TextStyle(color: _muted, fontSize: 12.5, height: 1.35, fontWeight: FontWeight.w600)))),
        Positioned(left: 20, bottom: 18, child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: _purple.withValues(alpha: .09), borderRadius: BorderRadius.circular(99)), child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.auto_awesome_rounded, size: 14, color: _purple), SizedBox(width: 6), Text('Günün seçkisi', style: TextStyle(color: _purple, fontSize: 11, fontWeight: FontWeight.w900))]))),
      ]),
    );
  }
}

class _GlassFeatureCard extends StatelessWidget {
  const _GlassFeatureCard();
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(25), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [_purple, _purple2]), boxShadow: [BoxShadow(color: _purple.withValues(alpha: .18), blurRadius: 24, offset: const Offset(0, 12))]),
      child: const Row(children: [
        _FeatureIcon(icon: Icons.auto_awesome_rounded),
        SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Ekranını değiştir', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)), SizedBox(height: 3), Text('Seçtiğin duvar kâğıdını telefonunda uygula.', style: TextStyle(color: Colors.white70, fontSize: 11.5, height: 1.3))])),
        Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 24),
      ]),
    );
  }
}

class _FeatureIcon extends StatelessWidget {
  final IconData icon;
  const _FeatureIcon({required this.icon});
  @override
  Widget build(BuildContext context) => Container(width: 54, height: 54, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .16), borderRadius: BorderRadius.circular(18)), child: Icon(icon, color: Colors.white, size: 26));
}

class _TinyPill extends StatelessWidget {
  final String label;
  const _TinyPill({required this.label});
  @override
  Widget build(BuildContext context) => DecoratedBox(decoration: BoxDecoration(color: _purple.withValues(alpha: .08), borderRadius: BorderRadius.circular(99)), child: Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), child: Text(label, style: const TextStyle(color: _purple, fontSize: 10, fontWeight: FontWeight.w900))));
}

class _ActiveDots extends StatelessWidget {
  final int count;
  final int current;
  const _ActiveDots({required this.count, required this.current});
  @override
  Widget build(BuildContext context) => Row(mainAxisAlignment: MainAxisAlignment.center, children: [for (int i = 0; i < count; i++) AnimatedContainer(duration: const Duration(milliseconds: 220), width: i == current ? 20 : 6, height: 6, margin: const EdgeInsets.symmetric(horizontal: 3), decoration: BoxDecoration(color: i == current ? _purple : _purple.withValues(alpha: .18), borderRadius: BorderRadius.circular(99)))]);
}

class _FineWaveTexture extends StatelessWidget {
  const _FineWaveTexture();
  @override
  Widget build(BuildContext context) => CustomPaint(painter: _WavePainter());
}
class _WavePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.stroke..strokeWidth = 1..color = _purple.withValues(alpha: .08);
    for (double y = -40; y < size.height + 80; y += 44) {
      final path = Path()..moveTo(-20, y);
      path.cubicTo(size.width * .20, y - 34, size.width * .52, y + 36, size.width + 20, y - 20);
      canvas.drawPath(path, paint);
    }
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class CategoriesPage extends StatelessWidget {
  final FavoritesStore favorites;
  final String layout;
  const CategoriesPage({super.key, required this.favorites, required this.layout});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 30), children: [
      const Text('Kategoriler', style: _PageTitleStyle()),
      const SizedBox(height: 6),
      const Text('Tarzına uygun koleksiyonu keşfet.', style: TextStyle(color: _muted)),
      const SizedBox(height: 18),
      GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _categories.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.05),
        itemBuilder: (_, index) {
          final name = _categories[index];
          return _CategorySquareCard(
            name: name,
            seed: index + 10,
            imagePath: _categoryImages[name],
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CategoryDetailPage(
                  category: name,
                  favorites: favorites,
                  layout: layout,
                ),
              ),
            ),
          );
        },
      ),
    ]);
  }
}

class _CategorySquareCard extends StatelessWidget {
  final String name;
  final int seed;
  final String? imagePath;
  final VoidCallback onTap;

  const _CategorySquareCard({
    required this.name,
    required this.seed,
    this.imagePath,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (imagePath != null)
              Image.file(
                File(imagePath!),
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: _gradientFor(seed),
                    ),
                  ),
                  child: _SoftShape(seed: seed),
                ),
              )
            else
              DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: _gradientFor(seed),
                  ),
                ),
                child: _SoftShape(seed: seed),
              ),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Colors.black.withValues(alpha: .52)],
                  ),
                ),
              ),
            ),
            Positioned(
              left: 14,
              bottom: 14,
              child: Text(
                name,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            Positioned(
              right: 10,
              top: 10,
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: .20),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.arrow_forward_rounded,
                  color: Colors.white,
                  size: 18,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CategoryDetailPage extends StatelessWidget {
  final String category;
  final FavoritesStore favorites;
  final String layout;
  const CategoryDetailPage({super.key, required this.category, required this.favorites, this.layout = 'grid2'});
  @override
  Widget build(BuildContext context) {
    final items = _publishedWallpapers.where((w) => w.category == category).toList();
    final shown = items.isEmpty ? _publishedWallpapers : items;
    return Scaffold(
      appBar: AppBar(title: Text(category, style: const TextStyle(fontWeight: FontWeight.w900))),
      body: layout == 'list'
          ? ListView.builder(
              padding: const EdgeInsets.all(18),
              itemCount: shown.length,
              itemBuilder: (_, i) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: SizedBox(
                  height: 180,
                  child: GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: shown[i], favorites: favorites))),
                    child: WallpaperCard(item: shown[i], variant: 2, favorites: favorites),
                  ),
                ),
              ),
            )
          : GridView.builder(
              padding: const EdgeInsets.all(18),
              itemCount: shown.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: layout == 'grid3' ? 3 : 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: layout == 'large' ? .72 : .68,
              ),
              itemBuilder: (_, i) => GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: shown[i], favorites: favorites))),
                child: WallpaperCard(item: shown[i], variant: layout == 'large' ? 3 : i % 4, favorites: favorites),
              ),
            ),
    );
  }
}

class DiscoverPage extends StatefulWidget {
  final FavoritesStore favorites;
  final String layout;
  const DiscoverPage({super.key, required this.favorites, required this.layout});
  @override State<DiscoverPage> createState() => _DiscoverPageState();
}
class _DiscoverPageState extends State<DiscoverPage> {
  final _controller = TextEditingController();
  Timer? _debounce;
  String _query = '';
  String _filter = 'Yeni';
  @override void dispose() { _debounce?.cancel(); _controller.dispose(); super.dispose(); }
  void _search(String value) { _debounce?.cancel(); _debounce = Timer(const Duration(milliseconds: 300), () { if (mounted) setState(() => _query = value.trim().toLowerCase()); }); }
  @override
  Widget build(BuildContext context) {
    List<Wallpaper> results = _publishedWallpapers.where((item) => _query.isEmpty || item.title.toLowerCase().contains(_query) || item.category.toLowerCase().contains(_query) || item.tags.any((tag) => tag.toLowerCase().contains(_query))).toList();
    if (_filter == 'Trend' || _filter == 'Popüler' || _filter == 'En çok favorilenen') results = List.of(results.reversed);
    if (_filter == 'Editör seçimi') results = results.take(4).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(18, 18, 18, 10), child: Container(height: 56, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: _purple.withValues(alpha: .06), blurRadius: 18, offset: const Offset(0, 7))]), child: TextField(controller: _controller, onChanged: _search, decoration: InputDecoration(hintText: 'Duvar kağıdı ara...', prefixIcon: const Icon(Icons.search_rounded), suffixIcon: IconButton(onPressed: () => _controller.clear(), icon: const Icon(Icons.close_rounded)), border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(vertical: 17))))),
      SizedBox(height: 46, child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 18), scrollDirection: Axis.horizontal, itemCount: 5, separatorBuilder: (_, __) => const SizedBox(width: 8), itemBuilder: (_, i) { final label = ['Yeni', 'Popüler', 'Trend', 'En çok favorilenen', 'Editör seçimi'][i]; final selected = _filter == label; return ChoiceChip(label: Text(label), selected: selected, onSelected: (_) => setState(() => _filter = label), selectedColor: _purple, backgroundColor: Colors.white, labelStyle: TextStyle(color: selected ? Colors.white : _muted, fontWeight: FontWeight.w800), side: BorderSide(color: selected ? _purple : _purple.withValues(alpha: .12))); })),
      const SizedBox(height: 6),
      Expanded(
        child: results.isEmpty
            ? const Center(child: Text('Sonuç bulunamadı.'))
            : widget.layout == 'list'
                ? ListView.builder(
                    padding: const EdgeInsets.fromLTRB(18, 6, 18, 24),
                    itemCount: results.length,
                    itemBuilder: (_, index) {
                      final item = results[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: SizedBox(
                          height: 170,
                          child: GestureDetector(
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: item, favorites: widget.favorites))),
                            child: WallpaperCard(item: item, variant: 2, favorites: widget.favorites),
                          ),
                        ),
                      );
                    },
                  )
                : GridView.builder(
                    padding: const EdgeInsets.fromLTRB(18, 6, 18, 24),
                    itemCount: results.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: widget.layout == 'grid3' ? 3 : 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: widget.layout == 'large' ? .72 : .68,
                    ),
                    itemBuilder: (_, index) {
                      final item = results[index];
                      return GestureDetector(
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: item, favorites: widget.favorites))),
                        child: WallpaperCard(item: item, variant: widget.layout == 'large' ? 3 : index % 4, favorites: widget.favorites),
                      );
                    },
                  ),
      ),
    ]);
  }
}

class FavoritesPage extends StatelessWidget {
  final String layout;
  final FavoritesStore favorites;
  const FavoritesPage({super.key, required this.layout, required this.favorites});
  @override
  Widget build(BuildContext context) {
    final items = _publishedWallpapers.where((w) => favorites.contains(w.id)).toList();
    final count = layout == 'grid3' ? 3 : 2;
    return ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 30), children: [
      const Text('Favoriler', style: _PageTitleStyle()),
      const SizedBox(height: 6),
      const Text('Sevdiklerin burada.', style: TextStyle(color: _muted)),
      const SizedBox(height: 16),
      if (items.isEmpty)
        const _EmptyFavorites()
      else if (layout == 'list')
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          itemBuilder: (_, index) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: SizedBox(
              height: 180,
              child: GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: items[index], favorites: favorites))),
                child: WallpaperCard(item: items[index], variant: 2, favorites: favorites),
              ),
            ),
          ),
        )
      else
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: count,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: layout == 'large' ? .72 : (count == 3 ? .62 : .68),
          ),
          itemBuilder: (_, index) => GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: items[index], favorites: favorites))),
            child: WallpaperCard(item: items[index], variant: layout == 'large' ? 3 : index % 4, favorites: favorites),
          ),
        ),
    ]);
  }
}
class _EmptyFavorites extends StatelessWidget { const _EmptyFavorites(); @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(28), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)), child: const Column(children: [Icon(Icons.favorite_border_rounded, size: 44, color: _purple), SizedBox(height: 10), Text('Henüz favorin yok', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), SizedBox(height: 4), Text('Beğendiğin duvar kağıtlarının kalp simgesine dokun.', textAlign: TextAlign.center, style: TextStyle(color: _muted))])); }

class AppStrings {
  static String of(String lang, String key) {
    const tr = {
      'home': 'Ana Sayfa', 'categories': 'Kategoriler', 'discover': 'Keşfet', 'favorites': 'Favoriler', 'settings': 'Ayarlar',
      'profile': 'Profil', 'language': 'Dil ayarı', 'theme': 'Tema', 'cache': 'Önbellek temizliği', 'about': 'Wxtra hakkında',
      'privacy': 'Wxtra gizlilik politikası', 'terms': 'Wxtra kullanım koşulları', 'version': 'Sürüm ve API bilgisi', 'support': 'Destek',
      'reset': 'Ayarları sıfırla', 'language_sub': 'Türkçe', 'theme_sub': 'Bölümlerde kullanılacak kart dizilimi',
    };
    const en = {
      'home': 'Home', 'categories': 'Categories', 'discover': 'Discover', 'favorites': 'Favorites', 'settings': 'Settings',
      'profile': 'Profile', 'language': 'Language', 'theme': 'Theme', 'cache': 'Clear cache', 'about': 'About Wxtra',
      'privacy': 'Wxtra privacy policy', 'terms': 'Wxtra terms of use', 'version': 'Version & API', 'support': 'Support',
      'reset': 'Reset settings', 'language_sub': 'English', 'theme_sub': 'Card layout used in sections',
    };
    const zh = {
      'home': '首页', 'categories': '分类', 'discover': '发现', 'favorites': '收藏', 'settings': '设置',
      'profile': '个人资料', 'language': '语言设置', 'theme': '主题', 'cache': '清除缓存', 'about': '关于 Wxtra',
      'privacy': 'Wxtra 隐私政策', 'terms': 'Wxtra 使用条款', 'version': '版本与 API', 'support': '支持',
      'reset': '重置设置', 'language_sub': '中文', 'theme_sub': '各版块使用的卡片布局',
    };
    final table = lang == 'en' ? en : lang == 'zh' ? zh : tr;
    return table[key] ?? key;
  }

  static String languageName(String lang) => lang == 'en' ? 'English' : lang == 'zh' ? '中文' : 'Türkçe';
}

class SettingsPage extends StatefulWidget {
  final AppSettings settings;
  final FavoritesStore favorites;
  final ValueChanged<AppSettings> onChanged;
  final VoidCallback? onCatalogChanged;

  const SettingsPage({
    super.key,
    required this.settings,
    required this.favorites,
    required this.onChanged,
    this.onCatalogChanged,
  });

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late AppSettings s;
  int _secretTaps = 0;
  DateTime? _lastSecretTap;
  static const String _adminPassword = 'WXTRA';

  @override
  void initState() {
    super.initState();
    s = widget.settings;
  }

  @override
  void didUpdateWidget(covariant SettingsPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.settings != widget.settings) s = widget.settings;
  }

  void _save(AppSettings next) {
    setState(() => s = next);
    widget.onChanged(next);
  }

  void _tapSecretTitle() {
    final now = DateTime.now();
    if (_lastSecretTap == null || now.difference(_lastSecretTap!) > const Duration(seconds: 3)) {
      _secretTaps = 0;
    }
    _lastSecretTap = now;
    _secretTaps++;
    if (_secretTaps >= 10) {
      _secretTaps = 0;
      _openAdminLock();
    }
  }

  Future<void> _openAdminLock() async {
    final controller = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Gizli yönetim'),
        content: TextField(
          controller: controller,
          autofocus: true,
          obscureText: true,
          decoration: const InputDecoration(labelText: 'Şifre', hintText: 'Yönetim şifresini gir'),
          onSubmitted: (_) => Navigator.of(dialogContext).pop(controller.text == _adminPassword),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.of(dialogContext).pop(controller.text == _adminPassword), child: const Text('Aç')),
        ],
      ),
    );
    controller.dispose();
    if (ok == true && mounted) {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => AdminPage(onChanged: widget.onCatalogChanged),
        ),
      );
      widget.onCatalogChanged?.call();
    } else if (ok == false && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Şifre hatalı.')));
    }
  }

  Future<void> _selectLanguage() async {
    final value = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          _languageChoice('tr', 'Türkçe', 'TR', sheetContext),
          _languageChoice('en', 'English', 'EN', sheetContext),
          _languageChoice('zh', '中文', '中', sheetContext),
          const SizedBox(height: 12),
        ]),
      ),
    );
    if (value != null) _save(s.copyWith(language: value));
  }

  Widget _languageChoice(String value, String label, String badge, BuildContext sheetContext) => ListTile(
        leading: CircleAvatar(backgroundColor: _purple.withValues(alpha: .10), child: Text(badge, style: const TextStyle(color: _purple, fontWeight: FontWeight.w900))),
        title: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
        trailing: s.language == value ? const Icon(Icons.check_circle_rounded, color: _purple) : null,
        onTap: () => Navigator.of(sheetContext).pop(value),
      );

  Future<void> _clearCache() async {
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
    try {
      final temp = Directory.systemTemp;
      await for (final entity in temp.list()) {
        if (entity is File && entity.path.contains('wxtra_') && entity.path.endsWith('.png')) {
          try {
            await entity.delete();
          } catch (_) {
            // Bazı geçici dosyalar işletim sistemi tarafından kilitli olabilir.
          }
        }
      }
    } catch (_) {
      // Image cache temizliği yine de tamamlanmış sayılır.
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(AppStrings.of(s.language, 'cache') + ' ✓')));
  }

  Future<void> _resetSettings() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Ayarlar sıfırlansın mı?'),
        content: const Text('Kart dizilimi, dil ve diğer yerel ayarlar varsayılan değerlere dönecek. Favorilerin silinmez.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Sıfırla')),
        ],
      ),
    );
    if (ok == true) _save(const AppSettings());
  }

  void _about() => _dialog('Wxtra hakkında', 'Wxtra; yüksek kaliteli duvar kağıtlarını keşfetmek, favorilemek ve cihazında kullanmak için tasarlanmış bir uygulamadır.\n\nSürüm 1.0.0');
  void _privacy() => _dialog('Wxtra gizlilik politikası', 'Wxtra; hesabını, favorilerini ve uygulama tercihlerini hizmeti sunmak amacıyla işler. Gereksiz kişisel veri toplamamaya odaklanır.');
  void _terms() => _dialog('Wxtra kullanım koşulları', 'Uygulamadaki duvar kağıtlarını yalnızca izin verilen kullanım amaçları için kullan. Telif hakkı ve üçüncü taraf haklarına saygı göster.');

  Future<void> _versionApi() async {
    final online = await ApiService().checkHealth();
    if (!mounted) return;
    _dialog('Sürüm ve API bilgisi', 'Wxtra 1.0.0\n\nAPI: $_apiBaseUrl\nDurum: ${online ? 'Çevrimiçi' : 'Bağlantı yok'}');
  }

  Future<void> _support() async {
    try {
      final ok = await launchUrl(Uri(scheme: 'mailto', path: 'destek@wxtra.app', queryParameters: {'subject': 'Wxtra destek'}));
      if (!ok && mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('E-posta uygulaması açılamadı.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('E-posta uygulaması açılamadı.')));
    }
  }

  void _dialog(String title, String body) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(child: Text(body)),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Kapat'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final lang = s.language;
    final t = (String key) => AppStrings.of(lang, key);
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 30),
      children: [
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _tapSecretTitle,
          child: const Padding(
            padding: EdgeInsets.only(bottom: 4),
            child: Text('Ayarlar', style: _PageTitleStyle()),
          ),
        ),
        const Text('Wxtra deneyimini kendine göre düzenle.', style: TextStyle(color: _muted)),
        const SizedBox(height: 18),
        _SettingsGroup(title: 'HESAP', children: [
          _SettingsTile(
            icon: Icons.person_rounded,
            title: t('profile'),
            subtitle: s.googleConnected ? 'Google hesabı bağlı' : 'Google ile giriş yap',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(settings: s, onChanged: _save))),
          ),
        ]),
        _SettingsGroup(title: 'KİŞİSELLEŞTİRME', children: [
          _SettingsTile(
            icon: Icons.dashboard_rounded,
            title: t('theme'),
            subtitle: '${_layoutLabel(s.cardLayout)} · ${t('theme_sub')}',
            onTap: () async {
              final value = await showModalBottomSheet<String>(context: context, showDragHandle: true, builder: (_) => _LayoutPicker(current: s.cardLayout));
              if (value != null) _save(s.copyWith(cardLayout: value));
            },
          ),
          _SettingsTile(icon: Icons.translate_rounded, title: t('language'), subtitle: AppStrings.languageName(lang), onTap: _selectLanguage),
        ]),
        _SettingsGroup(title: 'BAKIM', children: [
          _SettingsTile(icon: Icons.cleaning_services_rounded, title: t('cache'), subtitle: 'Geçici görsel verilerini temizle', onTap: _clearCache),
          _SettingsTile(icon: Icons.restart_alt_rounded, title: t('reset'), subtitle: 'Yerel ayarları varsayılana döndür', onTap: _resetSettings),
        ]),
        _SettingsGroup(title: 'WXTRA', children: [
          _SettingsTile(icon: Icons.auto_awesome_rounded, title: t('about'), subtitle: 'Uygulama hakkında', onTap: _about),
          _SettingsTile(icon: Icons.lock_rounded, title: t('privacy'), subtitle: 'Verilerin nasıl işlendiğini öğren', onTap: _privacy),
          _SettingsTile(icon: Icons.gavel_rounded, title: t('terms'), subtitle: 'Kullanım kuralları', onTap: _terms),
          _SettingsTile(icon: Icons.info_rounded, title: t('version'), subtitle: '1.0.0 · API bağlantısını kontrol et', onTap: _versionApi),
          _SettingsTile(icon: Icons.support_agent_rounded, title: t('support'), subtitle: 'Yardım ve geri bildirim', onTap: _support),
        ]),
        const SizedBox(height: 8),
        Center(child: Text('Wxtra · Daha güzel duvarlar, daha güzel günler.', style: TextStyle(color: _muted.withValues(alpha: .8), fontSize: 12, fontWeight: FontWeight.w600))),
      ],
    );
  }

  String _layoutLabel(String v) => {'grid2': '2 sütun', 'grid3': '3 sütun', 'list': 'Liste', 'large': 'Büyük kart'}[v] ?? '2 sütun';
}

class AppearancePage extends StatefulWidget {
  final AppSettings settings; final ValueChanged<AppSettings> onChanged;
  const AppearancePage({super.key, required this.settings, required this.onChanged});
  @override State<AppearancePage> createState()=>_AppearancePageState();
}
class _AppearancePageState extends State<AppearancePage>{
  late AppSettings s; final ImagePicker _picker=ImagePicker();
  @override void initState(){super.initState();s=widget.settings;}
  void _save(AppSettings next) {
    setState(() => s = next);
    widget.onChanged(next);
  }
  Future<void> _pick() async {
    try {
      final picked = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
      if (picked == null) return;
      final directory = await getApplicationDocumentsDirectory();
      final target = File('${directory.path}/wxtra_background.jpg');
      await File(picked.path).copy(target.path);
      _save(s.copyWith(backgroundImagePath: target.path));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Arka plan resmi seçilemedi.')));
      }
    }
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Görünüm',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Tema',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:10),
    Row(children:ThemeMode.values.map((m){final active=s.themeMode==m;final label=m==ThemeMode.system?'Sistem':m==ThemeMode.light?'Açık':'Koyu';return Expanded(child:Padding(padding:const EdgeInsets.only(right:8),child:ChoiceChip(label:Text(label),selected:active,onSelected:(_)=>_save(s.copyWith(themeMode:m)),labelStyle:TextStyle(color:active?Colors.white:_muted,fontWeight:FontWeight.w800),selectedColor:_purple)));}).toList()),
    const SizedBox(height:22),
    const Text('Vurgu rengi',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
    const SizedBox(height:10),
    Wrap(
      spacing:12,
      runSpacing:10,
      children:[
        for(final color in const [0xFF5F2FE8,0xFF2563EB,0xFFE83E8C,0xFFFF9F1C,0xFF16A34A,0xFF06B6D4])
          GestureDetector(
            onTap:()=>_save(s.copyWith(accentColor:color)),
            child:Container(
              width:42,height:42,
              decoration:BoxDecoration(
                color:Color(color),shape:BoxShape.circle,
                border:Border.all(color:s.accentColor==color?Colors.white:_surface,width:3),
                boxShadow:[if(s.accentColor==color) BoxShadow(color:Color(color).withValues(alpha:.30),blurRadius:10)],
              ),
              child:s.accentColor==color?const Icon(Icons.check_rounded,color:Colors.white,size:20):null,
            ),
          ),
      ],
    ),
    const SizedBox(height:22),const Text('Arka plan',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:10),
    Container(height:130,decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xFFF2EDFF),Color(0xFFE2D7FF)])),child:s.backgroundImagePath==null?const Center(child:Text('Varsayılan arka plan',style:TextStyle(color:_muted,fontWeight:FontWeight.w800))):ClipRRect(borderRadius:BorderRadius.circular(24),child:Image.file(File(s.backgroundImagePath!),fit:BoxFit.cover,errorBuilder:(_, __, ___)=>const Center(child:Text('Resim bulunamadı',style:TextStyle(color:_muted,fontWeight:FontWeight.w800)))))),
    const SizedBox(height:10),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:_pick,icon:const Icon(Icons.image_rounded),label:const Text('Resim seç'))),const SizedBox(width:10),OutlinedButton(onPressed:s.backgroundImagePath==null?null:()=>_save(s.copyWith(clearBackground:true)),child:const Text('Kaldır'))]),
    const SizedBox(height:22),const Text('Kart dizilimi',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:10),_LayoutPicker(current:s.cardLayout,onChanged:(v)=>_save(s.copyWith(cardLayout:v)),embedded:true),
  ]));
}

class LaunchSettingsPage extends StatefulWidget {
  final AppSettings settings;
  final ValueChanged<AppSettings> onChanged;
  const LaunchSettingsPage({super.key, required this.settings, required this.onChanged});

  @override
  State<LaunchSettingsPage> createState() => _LaunchSettingsPageState();
}

class _LaunchSettingsPageState extends State<LaunchSettingsPage> {
  late AppSettings s;

  @override
  void initState() {
    super.initState();
    s = widget.settings;
  }

  void _save(AppSettings next) {
    setState(() => s = next);
    widget.onChanged(next);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Açılır ekran', style: TextStyle(fontWeight: FontWeight.w900))),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            SwitchListTile.adaptive(
              value: s.launchEnabled,
              onChanged: (v) => _save(s.copyWith(launchEnabled: v)),
              title: const Text('Açılır ekranı etkinleştir'),
            ),
            const SizedBox(height: 8),
            const Text('Gösterilecek içerikler', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            _SwitchTile(title: 'Yeni duvar kağıtları', value: s.launchNewWallpapers, onChanged: (v) => _save(s.copyWith(launchNewWallpapers: v))),
            _SwitchTile(title: 'Favori kategori', value: s.launchFavoriteCategory, onChanged: (v) => _save(s.copyWith(launchFavoriteCategory: v))),
            _SwitchTile(title: 'Öneriler', value: s.launchRecommendations, onChanged: (v) => _save(s.copyWith(launchRecommendations: v))),
            _SwitchTile(title: 'Editör seçimleri', value: s.launchEditorPicks, onChanged: (v) => _save(s.copyWith(launchEditorPicks: v))),
            const SizedBox(height: 12),
            ListTile(
              title: const Text('Gösterim sıklığı'),
              trailing: DropdownButton<String>(
                value: s.launchFrequency,
                items: const [
                  DropdownMenuItem(value: 'Her açılışta', child: Text('Her açılışta')),
                  DropdownMenuItem(value: 'Günde bir kez', child: Text('Günde bir kez')),
                ],
                onChanged: (v) {
                  if (v != null) _save(s.copyWith(launchFrequency: v));
                },
              ),
            ),
          ],
        ),
      );
}

class ProfilePage extends StatefulWidget {
  final AppSettings settings;
  final ValueChanged<AppSettings> onChanged;
  const ProfilePage({super.key, required this.settings, required this.onChanged});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late AppSettings s;

  @override
  void initState() {
    super.initState();
    s = widget.settings;
  }

  void _toggleGoogle() {
    final next = s.copyWith(googleConnected: !s.googleConnected);
    setState(() => s = next);
    widget.onChanged(next);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Profil', style: TextStyle(fontWeight: FontWeight.w900))),
        body: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              const CircleAvatar(
                radius: 48,
                backgroundColor: Color(0xFFE8E0FF),
                child: Icon(Icons.person_rounded, size: 52, color: _purple),
              ),
              const SizedBox(height: 14),
              Text(
                s.googleConnected ? 'Google hesabı bağlı' : 'Hesabını bağla',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 4),
              const Text('Favorilerini ve tercihlerini senkronize et', style: TextStyle(color: _muted)),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _toggleGoogle,
                  icon: const Text('G', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
                  label: Text(s.googleConnected ? 'Google bağlantısını kaldır' : 'Google ile giriş yap'),
                ),
              ),
              const SizedBox(height: 18),
              const _ProfileFeature(icon: Icons.favorite_rounded, title: 'Favorilerini sakla', subtitle: 'Cihazlar arasında eşitle'),
              const _ProfileFeature(icon: Icons.sync_rounded, title: 'Senkronizasyon', subtitle: 'Hesabınla devam eder'),
              const _ProfileFeature(icon: Icons.auto_awesome_rounded, title: 'Sana özel öneriler', subtitle: 'Beğenilerine göre içerik'),
            ],
          ),
        ),
      );
}

class _ProfileFeature extends StatelessWidget{final IconData icon;final String title,subtitle;const _ProfileFeature({required this.icon,required this.title,required this.subtitle});@override Widget build(BuildContext context)=>ListTile(leading:CircleAvatar(backgroundColor:_purple.withValues(alpha:.1),child:Icon(icon,color:_purple)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text(subtitle));}


class AdminPage extends StatefulWidget {
  final VoidCallback? onChanged;

  const AdminPage({super.key, this.onChanged});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  int _section = 0;
  bool _loading = true;
  bool _apiOnline = false;
  bool _maintenance = false;
  List<AdminSchedule> _schedules = [];
  List<String> _announcements = [];

  static const _sections = [
    ('Genel', Icons.dashboard_rounded),
    ('Duvar Kağıtları', Icons.photo_library_rounded),
    ('İçerik Yönetimi', Icons.auto_awesome_rounded),
    ('Kategoriler', Icons.category_rounded),
    ('İçerik Planlayıcı', Icons.calendar_month_rounded),
    ('İstatistikler', Icons.bar_chart_rounded),
    ('Sistem', Icons.settings_rounded),
    ('Duyurular', Icons.campaign_rounded),
  ];

  @override
  void initState() {
    super.initState();
    _loadAdmin();
  }

  Future<void> _loadAdmin() async {
    try {
      _schedules = await AdminStore.schedules();
      _announcements = await AdminStore.announcements();
      _maintenance = await AdminStore.maintenance();
      _apiOnline = await ApiService().checkHealth();
    } catch (_) {
      _apiOnline = false;
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _persistCatalog() async {
    await CatalogStore.save();
    widget.onChanged?.call();
    if (mounted) setState(() {});
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _addWallpaper() async {
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 92,
      );
      if (picked == null || !mounted) return;

      final form = await _wallpaperForm();
      if (form == null) return;

      final docs = await getApplicationDocumentsDirectory();
      final directory = Directory('${docs.path}/wxtra_wallpapers');
      await directory.create(recursive: true);

      final id = 'custom-${DateTime.now().millisecondsSinceEpoch}';
      final ext = picked.path.toLowerCase().endsWith('.png') ? 'png' : 'jpg';
      final target = File('${directory.path}/$id.$ext');
      await File(picked.path).copy(target.path);

      _demoWallpapers.add(
        Wallpaper(
          id: id,
          title: form.$1,
          category: form.$2,
          tags: form.$3,
          gradient: _gradientFor(_demoWallpapers.length + 30),
          imagePath: target.path,
          published: true,
        ),
      );

      await _persistCatalog();
      _toast('Duvar kağıdı eklendi.');
    } catch (_) {
      _toast('Duvar kağıdı eklenemedi.');
    }
  }

  Future<(String, String, List<String>)?> _wallpaperForm({Wallpaper? item}) async {
    final title = TextEditingController(text: item?.title ?? '');
    final category = TextEditingController(text: item?.category ?? _categories.first);
    final tags = TextEditingController(text: item?.tags.join(', ') ?? '');

    final result = await showDialog<(String, String, List<String>)>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(item == null ? 'Yeni duvar kağıdı' : 'Duvar kağıdını düzenle'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: title,
                decoration: const InputDecoration(labelText: 'İsim'),
              ),
              TextField(
                controller: category,
                decoration: const InputDecoration(labelText: 'Kategori'),
              ),
              TextField(
                controller: tags,
                decoration: const InputDecoration(
                  labelText: 'Etiketler (virgülle ayır)',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () {
              final t = title.text.trim();
              if (t.isEmpty) return;
              final c = category.text.trim().isEmpty ? _categories.first : category.text.trim();
              final tagList = tags.text
                  .split(',')
                  .map((e) => e.trim())
                  .where((e) => e.isNotEmpty)
                  .toList();
              Navigator.of(dialogContext).pop((t, c, tagList));
            },
            child: const Text('Kaydet'),
          ),
        ],
      ),
    );

    title.dispose();
    category.dispose();
    tags.dispose();
    return result;
  }

  Future<void> _editWallpaper(Wallpaper item) async {
    final form = await _wallpaperForm(item: item);
    if (form == null) return;
    final index = _demoWallpapers.indexWhere((w) => w.id == item.id);
    if (index == -1) return;
    _demoWallpapers[index] = item.copyWith(
      title: form.$1,
      category: form.$2,
      tags: form.$3,
    );
    await _persistCatalog();
    _toast('Duvar kağıdı güncellendi.');
  }

  Future<void> _togglePublish(Wallpaper item) async {
    final index = _demoWallpapers.indexWhere((w) => w.id == item.id);
    if (index == -1) return;
    if (item.published && _publishedWallpapers.length <= 1) {
      _toast('En az bir duvar kağıdı yayında kalmalı.');
      return;
    }
    _demoWallpapers[index] = item.copyWith(published: !item.published);
    await _persistCatalog();
    _toast(item.published ? 'Yayından kaldırıldı.' : 'Yayına alındı.');
  }

  Future<void> _deleteWallpaper(Wallpaper item) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Duvar kağıdı silinsin mi?'),
        content: Text('“${item.title}” kaldırılacak.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Sil'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    if (_demoWallpapers.length <= 1) {
      _toast('En az bir duvar kağıdı bulunmalı.');
      return;
    }

    _demoWallpapers.removeWhere((w) => w.id == item.id);
    if (item.imagePath != null) {
      try {
        await File(item.imagePath!).delete();
      } catch (_) {}
    }
    await _persistCatalog();
    _toast('Duvar kağıdı silindi.');
  }

  Future<void> _chooseContent(String key, String title) async {
    if (_publishedWallpapers.isEmpty) return;
    final id = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => ListView(
        shrinkWrap: true,
        children: _publishedWallpapers
            .map(
              (w) => ListTile(
                title: Text(w.title),
                subtitle: Text(w.category),
                onTap: () => Navigator.of(sheetContext).pop(w.id),
              ),
            )
            .toList(),
      ),
    );
    if (id == null) return;
    await AdminStore.setContent(key, id);
    if (mounted) setState(() {});
    _toast('$title güncellendi.');
  }

  Future<void> _addCategory() async {
    final controller = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Kategori oluştur'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: 'Kategori adı'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () {
              final v = controller.text.trim();
              if (v.isNotEmpty) Navigator.of(dialogContext).pop(v);
            },
            child: const Text('Ekle'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value == null || value.isEmpty || _categories.contains(value)) return;
    _categories.add(value);
    await _persistCatalog();
  }

  Future<void> _pickCategoryImage(int index) async {
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 90,
      );
      if (picked == null) return;
      final docs = await getApplicationDocumentsDirectory();
      final dir = Directory('${docs.path}/wxtra_categories');
      await dir.create(recursive: true);
      final safe = _categories[index]
          .replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
      final target = File('${dir.path}/${safe}_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await File(picked.path).copy(target.path);
      _categoryImages[_categories[index]] = target.path;
      await _persistCatalog();
      _toast('Kategori görseli güncellendi.');
    } catch (_) {
      _toast('Kategori görseli seçilemedi.');
    }
  }

  Future<void> _editCategory(int index) async {
    final controller = TextEditingController(text: _categories[index]);
    final value = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Kategori düzenle'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: 'Kategori adı'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () {
              final v = controller.text.trim();
              if (v.isNotEmpty) Navigator.of(dialogContext).pop(v);
            },
            child: const Text('Kaydet'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value == null || value.isEmpty) return;

    final old = _categories[index];
    _categories[index] = value;

    for (var i = 0; i < _demoWallpapers.length; i++) {
      if (_demoWallpapers[i].category == old) {
        _demoWallpapers[i] = _demoWallpapers[i].copyWith(category: value);
      }
    }
    await _persistCatalog();
  }

  Future<void> _deleteCategory(int index) async {
    if (_categories.length <= 1) {
      _toast('En az bir kategori kalmalı.');
      return;
    }
    final name = _categories[index];
    _categories.removeAt(index);
    _categoryImages.remove(name);
    await _persistCatalog();
    _toast('“$name” kategorisi silindi.');
  }

  Future<void> _moveCategory(int index, int direction) async {
    final target = index + direction;
    if (target < 0 || target >= _categories.length) return;
    final value = _categories.removeAt(index);
    _categories.insert(target, value);
    await _persistCatalog();
  }

  Future<void> _planContent() async {
    if (_publishedWallpapers.isEmpty) {
      _toast('Planlamak için yayınlanmış içerik yok.');
      return;
    }

    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      firstDate: now,
      lastDate: DateTime(now.year + 3),
      initialDate: now,
    );
    if (date == null || !mounted) return;

    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (time == null || !mounted) return;

    final type = await showDialog<String>(
      context: context,
      builder: (dialogContext) => SimpleDialog(
        title: const Text('İçerik türü'),
        children: const [
          'Günün Seçkisi',
          'Editör Seçimi',
          'Öne Çıkan',
        ]
            .map(
              (label) => SimpleDialogOption(
                onPressed: () => Navigator.of(dialogContext).pop(label),
                child: Text(label),
              ),
            )
            .toList(),
      ),
    );
    if (type == null) return;

    final wallpaperId = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => ListView(
        shrinkWrap: true,
        children: _publishedWallpapers
            .map(
              (w) => ListTile(
                title: Text(w.title),
                subtitle: Text(w.category),
                onTap: () => Navigator.of(sheetContext).pop(w.id),
              ),
            )
            .toList(),
      ),
    );
    if (wallpaperId == null) return;

    _schedules.insert(
      0,
      AdminSchedule(
        id: 'schedule-${DateTime.now().millisecondsSinceEpoch}',
        wallpaperId: wallpaperId,
        type: type,
        publishAt: DateTime(
          date.year,
          date.month,
          date.day,
          time.hour,
          time.minute,
        ),
      ),
    );
    await AdminStore.saveSchedules(_schedules);
    if (mounted) setState(() {});
    _toast('İçerik planlandı.');
  }

  Future<void> _removeSchedule(AdminSchedule item) async {
    _schedules.removeWhere((e) => e.id == item.id);
    await AdminStore.saveSchedules(_schedules);
    if (mounted) setState(() {});
  }

  Future<void> _createAnnouncement(String type) async {
    final controller = TextEditingController();
    final message = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(type),
        content: TextField(
          controller: controller,
          maxLines: 4,
          decoration: const InputDecoration(labelText: 'Duyuru metni'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () {
              final value = controller.text.trim();
              if (value.isNotEmpty) Navigator.of(dialogContext).pop(value);
            },
            child: const Text('Yayınla'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (message == null) return;
    await AdminStore.addAnnouncement('$type · $message');
    _announcements = await AdminStore.announcements();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gizli Yönetim', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(onPressed: _loadAdmin, icon: const Icon(Icons.refresh_rounded)),
          IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.logout_rounded),
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          if (constraints.maxWidth < 760) {
            return Column(
              children: [
                SizedBox(
                  height: 52,
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    scrollDirection: Axis.horizontal,
                    itemCount: _sections.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 7),
                    itemBuilder: (_, i) => ChoiceChip(
                      label: Text(_sections[i].$1),
                      selected: i == _section,
                      onSelected: (_) => setState(() => _section = i),
                    ),
                  ),
                ),
                const Divider(height: 1),
                Expanded(child: _buildSection()),
              ],
            );
          }

          return Row(
            children: [
              NavigationRail(
                selectedIndex: _section,
                onDestinationSelected: (v) => setState(() => _section = v),
                labelType: NavigationRailLabelType.all,
                destinations: _sections
                    .map(
                      (e) => NavigationRailDestination(
                        icon: Icon(e.$2),
                        selectedIcon: Icon(e.$2, color: _purple),
                        label: Text(e.$1),
                      ),
                    )
                    .toList(),
              ),
              const VerticalDivider(width: 1),
              Expanded(child: _buildSection()),
            ],
          );
        },
      ),
    );
  }

  Widget _buildSection() {
    switch (_section) {
      case 1:
        return _wallpaperSection();
      case 2:
        return _contentSection();
      case 3:
        return _categorySection();
      case 4:
        return _plannerSection();
      case 5:
        return _statsSection();
      case 6:
        return _systemSection();
      case 7:
        return _announcementSection();
      default:
        return _dashboardSection();
    }
  }

  Widget _dashboardSection() => ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [_purple, _purple2]),
              borderRadius: BorderRadius.circular(26),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Yönetim merkezi',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'WXTRA içeriklerini doğrudan APK içinden yönet.',
                  style: TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              _metric('Duvar kağıdı', '${_demoWallpapers.length}', Icons.photo_library_rounded),
              _metric('Kategori', '${_categories.length}', Icons.category_rounded),
              _metric('Plan', '${_schedules.length}', Icons.calendar_month_rounded),
              _metric('API', _apiOnline ? 'Çevrimiçi' : 'Kapalı', Icons.cloud_done_rounded),
            ],
          ),
          const SizedBox(height: 18),
          _AdminActionCard(
            title: 'Hızlı işlemler',
            buttons: [
              _AdminActionButton('Duvar kağıdı ekle', Icons.add_photo_alternate_rounded, _addWallpaper),
              _AdminActionButton('İçerik yönet', Icons.auto_awesome_rounded, () => setState(() => _section = 2)),
              _AdminActionButton('İçerik planla', Icons.calendar_month_rounded, _planContent),
              _AdminActionButton('Duyuru oluştur', Icons.campaign_rounded, () => _createAnnouncement('Uygulama içi duyuru')),
            ],
          ),
        ],
      );

  Widget _wallpaperSection() => ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Row(
            children: [
              const Expanded(child: Text('Duvar Kağıtları', style: _PageTitleStyle())),
              FilledButton.icon(
                onPressed: _addWallpaper,
                icon: const Icon(Icons.add_rounded),
                label: const Text('Yeni ekle'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ..._demoWallpapers.map(
            (item) => Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: SizedBox(
                  width: 54,
                  height: 54,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: item.imagePath == null
                        ? DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: item.gradient),
                            ),
                            child: _SoftShape(seed: item.id.hashCode),
                          )
                        : Image.file(
                            File(item.imagePath!),
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_rounded),
                          ),
                  ),
                ),
                title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text(
                  '${item.category} · ${item.published ? 'Yayında' : 'Yayından kaldırıldı'}',
                ),
                trailing: PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'edit') _editWallpaper(item);
                    if (value == 'publish') _togglePublish(item);
                    if (value == 'delete') _deleteWallpaper(item);
                  },
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: 'edit', child: Text('Düzenle')),
                    PopupMenuItem(
                      value: 'publish',
                      child: Text(item.published ? 'Yayından kaldır' : 'Yayına al'),
                    ),
                    const PopupMenuItem(value: 'delete', child: Text('Sil')),
                  ],
                ),
              ),
            ),
          ),
        ],
      );

  Widget _contentSection() {
    const roles = [
      ('Günün Seçkisi', 'daily'),
      ('Öne Çıkanlar', 'featured'),
      ('Editör Seçimleri', 'editor'),
      ('Popüler Duvar Kağıtları', 'popular'),
      ('Yeni Eklenenler', 'latest'),
    ];

    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('İçerik Yönetimi', style: _PageTitleStyle()),
        const SizedBox(height: 8),
        const Text(
          'Uygulamadaki içerik bölümlerini yönet.',
          style: TextStyle(color: _muted),
        ),
        const SizedBox(height: 14),
        ...roles.map(
          (role) => FutureBuilder<String?>(
            future: AdminStore.content(role.$2),
            builder: (context, snapshot) {
              final matches =
                  _demoWallpapers.where((w) => w.id == snapshot.data).toList();
              final selected = matches.isEmpty ? null : matches.first;
              return Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.star_rounded)),
                  title: Text(role.$1),
                  subtitle: Text(selected?.title ?? 'Seçim yapılmadı'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => _chooseContent(role.$2, role.$1),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _categorySection() => ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Row(
            children: [
              const Expanded(child: Text('Kategoriler', style: _PageTitleStyle())),
              FilledButton.icon(
                onPressed: _addCategory,
                icon: const Icon(Icons.add_rounded),
                label: const Text('Yeni kategori'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          for (var i = 0; i < _categories.length; i++)
            Card(
              child: ListTile(
                leading: CircleAvatar(child: Text('${i + 1}')),
                title: Text(
                  _categories[i],
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                trailing: Wrap(
                  children: [
                    IconButton(
                      onPressed: i == 0 ? null : () => _moveCategory(i, -1),
                      icon: const Icon(Icons.keyboard_arrow_up_rounded),
                    ),
                    IconButton(
                      onPressed: i == _categories.length - 1
                          ? null
                          : () => _moveCategory(i, 1),
                      icon: const Icon(Icons.keyboard_arrow_down_rounded),
                    ),
                    IconButton(
                      onPressed: () => _pickCategoryImage(i),
                      icon: const Icon(Icons.image_rounded),
                      tooltip: 'Kategori görseli',
                    ),
                    IconButton(
                      onPressed: () => _editCategory(i),
                      icon: const Icon(Icons.edit_rounded),
                    ),
                    IconButton(
                      onPressed: () => _deleteCategory(i),
                      icon: const Icon(Icons.delete_outline_rounded),
                    ),
                  ],
                ),
              ),
            ),
        ],
      );

  Widget _plannerSection() => ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Row(
            children: [
              const Expanded(child: Text('İçerik Planlayıcı', style: _PageTitleStyle())),
              FilledButton.icon(
                onPressed: _planContent,
                icon: const Icon(Icons.add_rounded),
                label: const Text('Planla'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'Tarih ve saat ile önceden içerik planla.',
            style: TextStyle(color: _muted),
          ),
          const SizedBox(height: 14),
          if (_schedules.isEmpty)
            const _EmptyAdminCard(text: 'Henüz planlanmış içerik yok.')
          else
            ..._schedules.map(
              (item) {
                final matches =
                    _demoWallpapers.where((w) => w.id == item.wallpaperId).toList();
                final wallpaper = matches.isEmpty ? null : matches.first;
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: CircleAvatar(child: Text('${item.publishAt.day}')),
                    title: Text(item.type, style: const TextStyle(fontWeight: FontWeight.w900)),
                    subtitle: Text(
                      '${wallpaper?.title ?? 'Silinmiş içerik'} · '
                      '${item.publishAt.day}.${item.publishAt.month}.${item.publishAt.year} '
                      '${item.publishAt.hour.toString().padLeft(2, '0')}:'
                      '${item.publishAt.minute.toString().padLeft(2, '0')}',
                    ),
                    trailing: Wrap(
                      spacing: 4,
                      children: [
                        Chip(label: Text(item.published ? 'Yayında' : 'Bekliyor')),
                        IconButton(
                          onPressed: () => _removeSchedule(item),
                          icon: const Icon(Icons.delete_outline_rounded),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
        ],
      );

  Widget _statsSection() => FutureBuilder<List<int>>(
        future: Future.wait([
          UsageStats.read('views'),
          UsageStats.read('wallpaperUses'),
          UsageStats.read('shares'),
        ]),
        builder: (context, snapshot) {
          final values = snapshot.data ?? const [0, 0, 0];
          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              const Text('İstatistikler', style: _PageTitleStyle()),
              const SizedBox(height: 14),
              _statCard('Toplam duvar kağıdı', '${_demoWallpapers.length}', Icons.photo_library_rounded),
              _statCard('Toplam kategori', '${_categories.length}', Icons.category_rounded),
              _statCard('Favoriler', 'Kullanıcı cihazı / Drive', Icons.favorite_rounded),
              _statCard('Görüntülenme', '${values[0]}', Icons.visibility_rounded),
              _statCard('Duvar kağıdı yapma', '${values[1]}', Icons.wallpaper_rounded),
              _statCard('Paylaşım', '${values[2]}', Icons.share_rounded),
            ],
          );
        },
      );

  Widget _systemSection() => ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Sistem', style: _PageTitleStyle()),
          const SizedBox(height: 14),
          _statusTile('API durumu', _apiOnline ? 'Çevrimiçi' : 'Bağlantı yok', _apiOnline),
          _statusTile('Sunucu durumu', _apiOnline ? 'Çalışıyor' : 'Kontrol gerekli', _apiOnline),
          _statusTile('Storage / CDN', 'Hazır', true),
          _statusTile('Cache', 'Yerel', true),
          const _SettingsTile(
            icon: Icons.system_update_alt_rounded,
            title: 'Uygulama sürümü',
            subtitle: '1.0.0',
            onTap: null,
          ),
          SwitchListTile.adaptive(
            value: _maintenance,
            onChanged: (value) async {
              await AdminStore.setMaintenance(value);
              if (mounted) setState(() => _maintenance = value);
            },
            title: const Text('Bakım modu', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text('Bakım sırasında kullanıcıya bilgi göstermek için kullanılabilir.'),
          ),
          ListTile(
            leading: const Icon(Icons.refresh_rounded, color: _purple),
            title: const Text('API durumunu yenile'),
            onTap: _loadAdmin,
          ),
        ],
      );

  Widget _announcementSection() => ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Row(
            children: [
              const Expanded(child: Text('Duyurular', style: _PageTitleStyle())),
              PopupMenuButton<String>(
                onSelected: _createAnnouncement,
                itemBuilder: (_) => const [
                  PopupMenuItem(
                    value: 'Uygulama içi duyuru',
                    child: Text('Uygulama içi duyuru'),
                  ),
                  PopupMenuItem(
                    value: 'Yeni sürüm duyurusu',
                    child: Text('Yeni sürüm duyurusu'),
                  ),
                  PopupMenuItem(
                    value: 'Bakım bildirimi',
                    child: Text('Bakım bildirimi'),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_announcements.isEmpty)
            const _EmptyAdminCard(text: 'Henüz duyuru oluşturulmadı.')
          else
            ..._announcements.map(
              (text) => Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.campaign_rounded)),
                  title: Text(text, maxLines: 4, overflow: TextOverflow.ellipsis),
                ),
              ),
            ),
        ],
      );

  Widget _metric(String title, String value, IconData icon) => SizedBox(
        width: 170,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: _purple.withValues(alpha: .10),
                  child: Icon(icon, color: _purple),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(color: _muted, fontSize: 11)),
                      Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );

  Widget _statusTile(String title, String value, bool ok) => Card(
        child: ListTile(
          leading: Icon(
            ok ? Icons.check_circle_rounded : Icons.error_rounded,
            color: ok ? Colors.green : Colors.red,
          ),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          trailing: Text(
            value,
            style: TextStyle(
              color: ok ? Colors.green : Colors.red,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      );

  Widget _statCard(String title, String value, IconData icon) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: _purple.withValues(alpha: .10),
            child: Icon(icon, color: _purple),
          ),
          title: Text(title),
          trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
        ),
      );
}

class _AdminActionButton {
  final String title;
  final IconData icon;
  final VoidCallback onTap;
  const _AdminActionButton(this.title, this.icon, this.onTap);
}

class _AdminActionCard extends StatelessWidget {
  final String title;
  final List<_AdminActionButton> buttons;

  const _AdminActionCard({
    required this.title,
    required this.buttons,
  });

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              ...buttons.map(
                (button) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: OutlinedButton.icon(
                    onPressed: button.onTap,
                    icon: Icon(button.icon),
                    label: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(button.title),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
}

class _EmptyAdminCard extends StatelessWidget {
  final String text;
  const _EmptyAdminCard({required this.text});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Center(child: Text(text, style: const TextStyle(color: _muted))),
      );
}

class DetailPage extends StatefulWidget {
  final Wallpaper item;
  final FavoritesStore favorites;
  const DetailPage({super.key, required this.item, required this.favorites});
  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  bool get isFavorite => widget.favorites.contains(widget.item.id);

  @override
  void initState() {
    super.initState();
    UsageStats.increment('views');
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (widget.item.imagePath != null)
            Positioned.fill(
              child: Image.file(
                File(widget.item.imagePath!),
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: widget.item.gradient,
                    ),
                  ),
                  child: _SoftShape(seed: widget.item.id.hashCode),
                ),
              ),
            )
          else
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: widget.item.gradient,
                ),
              ),
              child: _SoftShape(seed: widget.item.id.hashCode),
            ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _OverlayButton(
                    icon: Icons.arrow_back_rounded,
                    onTap: () => Navigator.pop(context),
                  ),
                  Row(
                    children: [
                      _OverlayButton(
                        icon: isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                        onTap: () async {
                          await widget.favorites.toggle(widget.item.id);
                          setState(() {});
                        },
                      ),
                      const SizedBox(width: 7),
                      _OverlayButton(icon: Icons.share_outlined, onTap: _share),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 18,
            child: SafeArea(
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: .92),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.item.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: _ink)),
                    const SizedBox(height: 4),
                    Text(widget.item.category, style: const TextStyle(color: _muted, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: _applyWallpaper,
                            icon: const Icon(Icons.wallpaper_rounded),
                            label: const Text('Duvar kağıdı yap'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        IconButton(
                          onPressed: _share,
                          icon: const Icon(Icons.share_rounded, color: _purple),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<Uint8List> _renderWallpaper() async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder, const Rect.fromLTWH(0, 0, 1080, 1920));
    final paint = Paint()
      ..shader = ui.Gradient.linear(
        const Offset(0, 0),
        const Offset(1080, 1920),
        widget.item.gradient,
      );
    canvas.drawRect(const Rect.fromLTWH(0, 0, 1080, 1920), paint);
    final picture = recorder.endRecording();
    final image = await picture.toImage(1080, 1920);
    final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    return bytes!.buffer.asUint8List();
  }

  Future<String> _makeTempFile() async {
    final bytes = await _renderWallpaper();
    final file = File('${Directory.systemTemp.path}/wxtra_${widget.item.id}.png');
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }

  Future<void> _share() async {
    try {
      final path = await _makeTempFile();
      await Share.shareXFiles(
        [XFile(path, mimeType: 'image/png')],
        text: '${widget.item.title} · ${widget.item.category}',
        subject: widget.item.title,
        fileNameOverrides: ['${widget.item.title}.png'],
      );
      await UsageStats.increment('shares');
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Paylaşım başlatılamadı.')),
        );
      }
    }
  }

  Future<void> _applyWallpaper() async {
    try {
      final choice = await showModalBottomSheet<int>(
        context: context,
        showDragHandle: true,
        builder: (sheetContext) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(title: const Text('Ana ekran'), onTap: () => Navigator.of(sheetContext).pop(WallpaperManagerFlutter.homeScreen)),
              ListTile(title: const Text('Kilit ekranı'), onTap: () => Navigator.of(sheetContext).pop(WallpaperManagerFlutter.lockScreen)),
              ListTile(title: const Text('İkisi birden'), onTap: () => Navigator.of(sheetContext).pop(WallpaperManagerFlutter.bothScreens)),
              const SizedBox(height: 10),
            ],
          ),
        ),
      );
      if (choice == null) return;
      final path = await _makeTempFile();
      final ok = await WallpaperManagerFlutter().setWallpaper(File(path), choice);
      if (ok) await UsageStats.increment('wallpaperUses');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(ok ? 'Duvar kağıdı uygulandı.' : 'Duvar kağıdı uygulanamadı.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Duvar kağıdı uygulanamadı.')),
        );
      }
    }
  }
}

class WallpaperCard extends StatelessWidget {
  final Wallpaper item;
  final double? width;
  final int variant;
  final FavoritesStore? favorites;

  const WallpaperCard({
    super.key,
    required this.item,
    this.width,
    this.variant = 0,
    this.favorites,
  });

  @override
  Widget build(BuildContext context) {
    final active = favorites?.contains(item.id) ?? false;
    final radius = switch (variant) {
      3 => 32.0,
      2 => 18.0,
      _ => 25.0,
    };

    return SizedBox(
      width: width,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (item.imagePath != null)
              Positioned.fill(
                child: Image.file(
                  File(item.imagePath!),
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: item.gradient,
                      ),
                    ),
                    child: _SoftShape(seed: item.id.hashCode + variant * 7),
                  ),
                ),
              )
            else
              DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: item.gradient,
                  ),
                ),
                child: _SoftShape(seed: item.id.hashCode + variant * 7),
              ),
            Positioned(
              top: 10,
              right: 10,
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: favorites == null ? null : () => favorites!.toggle(item.id),
                  customBorder: const CircleBorder(),
                  child: Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: .20),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white.withValues(alpha: .35)),
                    ),
                    child: Icon(
                      active ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                      size: 18,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 10,
              right: 10,
              bottom: 10,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(17),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
                  color: Colors.black.withValues(alpha: .25),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        item.category,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SoftShape extends StatelessWidget{
  final int seed; const _SoftShape({required this.seed});
  @override Widget build(BuildContext context){final o=(seed.abs()%60).toDouble();return Stack(fit:StackFit.expand,children:[Positioned(top:-30+o/4,left:-30+o/5,child:Container(width:160,height:160,decoration:BoxDecoration(shape:BoxShape.circle,color:Colors.white.withValues(alpha:.22)))),Positioned(right:-35,bottom:-22,child:Container(width:155,height:155,decoration:BoxDecoration(shape:BoxShape.circle,color:Colors.black.withValues(alpha:.12)))),Center(child:Transform.rotate(angle:-.18,child:Container(width:86,height:210,decoration:BoxDecoration(borderRadius:BorderRadius.circular(55),gradient:LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[Colors.white.withValues(alpha:.50),Colors.white.withValues(alpha:.05)]),border:Border.all(color:Colors.white.withValues(alpha:.30))))))]);}
}

class _CircleButton extends StatelessWidget{final IconData icon;final VoidCallback onTap;const _CircleButton({required this.icon,required this.onTap});@override Widget build(BuildContext context)=>Material(color:Colors.white,shape:const CircleBorder(),child:InkWell(onTap:onTap,customBorder:const CircleBorder(),child:SizedBox(width:42,height:42,child:Icon(icon,size:20))));}
class _OverlayButton extends StatelessWidget{final IconData icon;final VoidCallback onTap;const _OverlayButton({required this.icon,required this.onTap});@override Widget build(BuildContext context)=>DecoratedBox(decoration:BoxDecoration(color:Colors.black.withValues(alpha:.28),shape:BoxShape.circle),child:IconButton(onPressed:onTap,icon:Icon(icon,color:Colors.white)));}
class _SectionHeader extends StatelessWidget{final String title;final String? action;const _SectionHeader({required this.title,this.action});@override Widget build(BuildContext context)=>Row(children:[Expanded(child:Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:_ink))),if(action!=null)Text(action!,style:const TextStyle(color:_purple,fontWeight:FontWeight.w800,fontSize:12))]);}
class _PageTitleStyle extends TextStyle{const _PageTitleStyle():super(fontSize:28,fontWeight:FontWeight.w900,color:_ink);}
class _SettingsGroup extends StatelessWidget{final String title;final List<Widget> children;const _SettingsGroup({required this.title,required this.children});@override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(bottom:17),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Padding(padding:const EdgeInsets.only(left:3,bottom:9),child:Text(title,style:const TextStyle(color:_muted,fontWeight:FontWeight.w900))),Container(decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(22)),child:Column(children:children))]));}
class _SettingsTile extends StatelessWidget{final IconData icon;final String title;final String? subtitle;final VoidCallback? onTap;const _SettingsTile({required this.icon,required this.title,this.subtitle,this.onTap});@override Widget build(BuildContext context)=>ListTile(onTap:onTap,leading:CircleAvatar(backgroundColor:_purple.withValues(alpha:.10),child:Icon(icon,color:_purple,size:20)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:subtitle==null?null:Text(subtitle!,maxLines:1,overflow:TextOverflow.ellipsis),trailing:const Icon(Icons.chevron_right_rounded,color:_muted));}
class _SwitchTile extends StatelessWidget{final String title;final bool value;final ValueChanged<bool> onChanged;const _SwitchTile({required this.title,required this.value,required this.onChanged});@override Widget build(BuildContext context)=>SwitchListTile.adaptive(value:value,onChanged:onChanged,title:Text(title,style:const TextStyle(fontWeight:FontWeight.w700)));}
class _LayoutPicker extends StatelessWidget{final String current;final ValueChanged<String>? onChanged;final bool embedded;const _LayoutPicker({required this.current,this.onChanged,this.embedded=false});@override Widget build(BuildContext context){final options={'grid2':'2 sütun','grid3':'3 sütun','list':'Liste','large':'Büyük kart'};return Padding(padding:const EdgeInsets.all(18),child:Column(mainAxisSize:MainAxisSize.min,children:options.entries.map((e)=>ListTile(onTap:(){onChanged?.call(e.key);if(!embedded)Navigator.of(context).pop(e.key);},leading:Icon(e.key==current?Icons.radio_button_checked:Icons.radio_button_off,color:e.key==current?_purple:_muted),title:Text(e.value),trailing:embedded?null:(e.key==current?const Icon(Icons.check,color:_purple):null))).toList()));}}

class Wallpaper {
  final String id;
  final String title;
  final String category;
  final List<String> tags;
  final List<Color> gradient;
  final String? imagePath;
  final bool published;

  const Wallpaper({
    required this.id,
    required this.title,
    required this.category,
    required this.tags,
    required this.gradient,
    this.imagePath,
    this.published = true,
  });

  Wallpaper copyWith({
    String? title,
    String? category,
    List<String>? tags,
    List<Color>? gradient,
    String? imagePath,
    bool? published,
  }) {
    return Wallpaper(
      id: id,
      title: title ?? this.title,
      category: category ?? this.category,
      tags: tags ?? this.tags,
      gradient: gradient ?? this.gradient,
      imagePath: imagePath ?? this.imagePath,
      published: published ?? this.published,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'category': category,
        'tags': tags,
        'colors': gradient.map((c) => c.value).toList(),
        'imagePath': imagePath,
        'published': published,
      };

  static Wallpaper fromJson(Map<String, dynamic> json) {
    final rawColors = json['colors'] as List? ?? const [0xFF5F2FE8, 0xFFE3BFFF];
    return Wallpaper(
      id: json['id'] as String,
      title: json['title'] as String,
      category: json['category'] as String,
      tags: List<String>.from(json['tags'] as List? ?? const []),
      gradient: rawColors.map((e) => Color(e as int)).toList(),
      imagePath: json['imagePath'] as String?,
      published: json['published'] as bool? ?? true,
    );
  }
}


class ApiService{ApiService({this.baseUrl=_apiBaseUrl});final String baseUrl;Future<bool> checkHealth()async{final c=HttpClient();try{final health=baseUrl.endsWith('/api')?'${baseUrl.substring(0,baseUrl.length-4)}/health':'$baseUrl/health';final r=await c.getUrl(Uri.parse(health));final res=await r.close().timeout(const Duration(seconds:5));return res.statusCode==200;}catch(_){return false;}finally{c.close(force:true);}}}


final _gradientPalette=<List<Color>>[
  const [Color(0xFF7D42F5),Color(0xFFD7B5FF)],
  const [Color(0xFF111426),Color(0xFF5265B6)],
  const [Color(0xFF415E7D),Color(0xFFB8D2E6)],
  const [Color(0xFF171022),Color(0xFF6D4EAF)],
  const [Color(0xFF7E2A2A),Color(0xFFE5A06A)],
  const [Color(0xFF3F245E),Color(0xFFE3B6FF)],
];
List<Color> _gradientFor(int seed) => _gradientPalette[seed.abs()%_gradientPalette.length];

final _categories=['AMOLED','Minimal','Doğa','Uzay','Arabalar','Anime','Soyut','Şehir','Karanlık','Teknoloji','Manzara','Hayvanlar'];
final List<Wallpaper> _demoWallpapers=[
  const Wallpaper(id:'1',title:'Mor Işık',category:'Soyut',tags:['mor','minimal'],gradient:[Color(0xFF5D22D4),Color(0xFFE3BFFF)]),
  const Wallpaper(id:'2',title:'Gece Ufku',category:'Uzay',tags:['uzay','karanlık'],gradient:[Color(0xFF131733),Color(0xFF6A5AAE)]),
  const Wallpaper(id:'3',title:'Mor Zirve',category:'Doğa',tags:['dağ','manzara'],gradient:[Color(0xFF6C4EB0),Color(0xFFEEB2D9)]),
  const Wallpaper(id:'4',title:'Sessiz Yol',category:'Minimal',tags:['sade','minimal'],gradient:[Color(0xFF1E2539),Color(0xFF8E9CBC)]),
  const Wallpaper(id:'5',title:'Neon Şehir',category:'Şehir',tags:['neon','şehir'],gradient:[Color(0xFF24165F),Color(0xFFE138BB)]),
  const Wallpaper(id:'6',title:'Ay Çiçeği',category:'Doğa',tags:['çiçek','mor'],gradient:[Color(0xFF2D1A4B),Color(0xFFAC82DC)]),
];

List<Wallpaper> get _publishedWallpapers =>
    _demoWallpapers.where((item) => item.published).toList();
