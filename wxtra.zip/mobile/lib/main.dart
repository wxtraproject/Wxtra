import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://10.0.2.2:8000/api',
);

void main() => runApp(const WallpaperApp());

class WallpaperApp extends StatelessWidget {
  const WallpaperApp({super.key});

  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF5E2DEB);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Duvar Kağıtları',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: primary),
        scaffoldBackgroundColor: const Color(0xFFF9F8FC),
        fontFamily: 'Roboto',
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: Colors.white,
          indicatorColor: primary.withOpacity(.10),
          labelTextStyle: WidgetStatePropertyAll(
            TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
          ),
        ),
      ),
      home: const Shell(),
    );
  }
}

class ApiClient {
  Future<List<Wallpaper>> wallpapers() async {
    try {
      final r = await http.get(Uri.parse('$apiBaseUrl/wallpapers'));
      if (r.statusCode != 200) throw Exception();
      final data = jsonDecode(r.body) as Map<String, dynamic>;
      return (data['items'] as List)
          .map((e) => Wallpaper.fromJson(e))
          .toList();
    } catch (_) {
      // UI'yi API kapalıyken de test edebilmek için güvenli demo verisi.
      return const [
        Wallpaper(
          id: 'demo-1', title: 'Mor Işık', category: 'Soyut',
          imageUrl: '', tags: ['mor', 'minimal'],
        ),
        Wallpaper(
          id: 'demo-2', title: 'Gece', category: 'Uzay',
          imageUrl: '', tags: ['uzay', 'karanlık'],
        ),
      ];
    }
  }
}

class Wallpaper {
  final String id, title, category, imageUrl;
  final List<String> tags;
  const Wallpaper({
    required this.id, required this.title, required this.category,
    required this.imageUrl, required this.tags,
  });
  factory Wallpaper.fromJson(Map<String, dynamic> j) => Wallpaper(
    id: j['id'], title: j['title'], category: j['category'],
    imageUrl: j['image_url'] ?? '', tags: List<String>.from(j['tags'] ?? []),
  );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int index = 0;
  final pages = const [
    HomePage(), CategoriesPage(), DiscoverPage(), FavoritesPage(), SettingsPage()
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: pages[index]),
    bottomNavigationBar: NavigationBar(
      selectedIndex: index,
      onDestinationSelected: (i) => setState(() => index = i),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana Sayfa'),
        NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Kategoriler'),
        NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Keşfet'),
        NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Favoriler'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Ayarlar'),
      ],
    ),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => CustomScrollView(
    slivers: [
      SliverPadding(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
        sliver: SliverToBoxAdapter(
          child: Row(children: [
            Image.asset('assets/logo.png', width: 46, height: 46),
            const SizedBox(width: 12),
            const Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Merhaba, Wxtra 👋', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                SizedBox(height: 3),
                Text('Bugün hangi tarzı keşfetmek istersin?', style: TextStyle(color: Colors.black54)),
              ],
            )),
            const CircleAvatar(child: Icon(Icons.person_outline)),
          ]),
        ),
      ),
      const SliverToBoxAdapter(child: SectionTitle('Günün Duvar Kağıtları')),
      SliverToBoxAdapter(child: SizedBox(height: 250, child: FutureBuilder(
        future: ApiClient().wallpapers(),
        builder: (context, snapshot) {
          final items = snapshot.data ?? const <Wallpaper>[];
          return ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            scrollDirection: Axis.horizontal,
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(width: 14),
            itemBuilder: (_, i) => WallpaperCard(item: items[i], width: 170),
          );
        },
      ))),
      const SliverToBoxAdapter(child: SectionTitle('Popüler Kategoriler')),
      SliverPadding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
        sliver: SliverGrid.count(
          crossAxisCount: 2,
          childAspectRatio: 2.7,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          children: const [
            CategoryTile('AMOLED', Icons.brightness_3_outlined),
            CategoryTile('Minimal', Icons.auto_awesome_outlined),
            CategoryTile('Doğa', Icons.park_outlined),
            CategoryTile('Uzay', Icons.star_outline),
            CategoryTile('Arabalar', Icons.directions_car_outlined),
            CategoryTile('Soyut', Icons.blur_on_outlined),
          ],
        ),
      ),
    ],
  );
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 28, 20, 14),
    child: Text(text, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
  );
}

class WallpaperCard extends StatelessWidget {
  final Wallpaper item;
  final double width;
  const WallpaperCard({super.key, required this.item, this.width = 160});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: item))),
    child: SizedBox(
      width: width,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(fit: StackFit.expand, children: [
          item.imageUrl.isNotEmpty
            ? Image.network(item.imageUrl, fit: BoxFit.cover)
            : Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: [Color(0xFFF8F7FF), Color(0xFFDCCBFF), Color(0xFF6030E8)],
                  ),
                ),
                child: const Center(child: Icon(Icons.auto_awesome, size: 48, color: Colors.white)),
              ),
          Positioned(
            left: 12, right: 12, bottom: 12,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.88),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
          ),
        ]),
      ),
    ),
  );
}

class CategoryTile extends StatelessWidget {
  final String title; final IconData icon;
  const CategoryTile(this.title, this.icon, {super.key});
  @override Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      boxShadow: [BoxShadow(color: Colors.black.withOpacity(.04), blurRadius: 18, offset: const Offset(0, 7))],
    ),
    child: Row(children: [Icon(icon, color: const Color(0xFF5E2DEB)), const SizedBox(width: 10),
      Text(title, style: const TextStyle(fontWeight: FontWeight.w700))]),
  );
}

class CategoriesPage extends StatelessWidget {
  const CategoriesPage({super.key});
  @override Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('Kategoriler', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      const Text('Tarzına uygun koleksiyonu keşfet.', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 22),
      ...['AMOLED','Minimal','Doğa','Uzay','Arabalar','Anime','Soyut','Şehir','Karanlık','Teknoloji','Manzara','Hayvanlar']
        .map((x) => Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
          child: Row(children: [
            const CircleAvatar(child: Icon(Icons.auto_awesome)),
            const SizedBox(width: 14),
            Expanded(child: Text(x, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
            const Icon(Icons.chevron_right),
          ]),
        )),
    ],
  );
}

class DiscoverPage extends StatefulWidget {
  const DiscoverPage({super.key});
  @override State<DiscoverPage> createState() => _DiscoverPageState();
}
class _DiscoverPageState extends State<DiscoverPage> {
  final controller = TextEditingController();
  List<Wallpaper> items = [];
  bool loading = false;

  Future<void> search() async {
    setState(() => loading = true);
    items = await ApiClient().wallpapers();
    final q = controller.text.trim().toLowerCase();
    if (q.isNotEmpty) {
      items = items.where((x) =>
        x.title.toLowerCase().contains(q) ||
        x.category.toLowerCase().contains(q) ||
        x.tags.any((t) => t.toLowerCase().contains(q))).toList();
    }
    if (mounted) setState(() => loading = false);
  }

  @override Widget build(BuildContext context) => Column(children: [
    Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
      child: TextField(
        controller: controller,
        onSubmitted: (_) => search(),
        decoration: InputDecoration(
          hintText: 'Duvar kağıdı ara...',
          prefixIcon: const Icon(Icons.search),
          filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
        ),
      ),
    ),
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: ['Yeni','Popüler','Trend','En çok favorilenen','Editör seçimi']
          .map((x) => Padding(padding: const EdgeInsets.only(right: 8),
            child: FilterChip(label: Text(x), onSelected: (_) => search()))).toList()),
      ),
    ),
    Expanded(child: FutureBuilder(
      future: search(),
      builder: (_, __) => loading
        ? const Center(child: CircularProgressIndicator())
        : GridView.builder(
            padding: const EdgeInsets.all(20),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .66),
            itemCount: items.length,
            itemBuilder: (_, i) => WallpaperCard(item: items[i]),
          ),
    )),
  ]);
}

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key});
  @override Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: const [
      Text('Favoriler', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      SizedBox(height: 8),
      Text('Beğendiğin duvar kağıtları burada.', style: TextStyle(color: Colors.black54)),
      SizedBox(height: 60),
      Center(child: Column(children: [
        Icon(Icons.favorite_border, size: 58, color: Color(0xFF5E2DEB)),
        SizedBox(height: 14),
        Text('Henüz favorin yok', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        SizedBox(height: 6),
        Text('Keşfet ekranından koleksiyonuna ekleyebilirsin.'),
      ])),
    ],
  );
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('Ayarlar', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 22),
      _group('Profil', [Icons.person_outline, Icons.email_outlined, Icons.favorite_border, Icons.history], ['Profil bilgileri','E-posta','Favoriler','Görüntüleme geçmişi']),
      _group('Görünüm', [Icons.view_agenda_outlined], ['Kart dizilimi']),
      _group('Bildirimler', [Icons.notifications_none], ['Yeni duvar kağıtları']),
      _group('Gizlilik', [Icons.privacy_tip_outlined, Icons.description_outlined, Icons.delete_outline], ['Gizlilik politikası','Kullanım şartları','Hesabı sil']),
      _group('Hesap', [Icons.manage_accounts_outlined, Icons.logout], ['Profil düzenle','Oturum kapat']),
      _group('Uygulama', [Icons.info_outline, Icons.cloud_outlined, Icons.cleaning_services_outlined, Icons.support_agent_outlined], ['Uygulama sürümü','API durumu','Önbelleği temizle','Destek']),
    ],
  );

  Widget _group(String title, List<IconData> icons, List<String> labels) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(padding: const EdgeInsets.only(bottom: 10, top: 12), child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: Colors.black54))),
      Container(
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
        child: Column(children: List.generate(labels.length, (i) => ListTile(
          leading: Icon(icons[i]),
          title: Text(labels[i], style: const TextStyle(fontWeight: FontWeight.w600)),
          trailing: const Icon(Icons.chevron_right),
        ))),
      ),
    ],
  );
}

class DetailPage extends StatelessWidget {
  final Wallpaper item;
  const DetailPage({super.key, required this.item});
  @override Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.black,
    body: Stack(children: [
      Positioned.fill(child: item.imageUrl.isNotEmpty
        ? Image.network(item.imageUrl, fit: BoxFit.contain)
        : Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: [Color(0xFFFBF9FF), Color(0xFFDACBFF), Color(0xFF4E20D7)],
              ),
            ),
            child: const Center(child: Icon(Icons.auto_awesome, size: 100, color: Colors.white)),
          )),
      Positioned(top: 18, left: 16, child: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: const Icon(Icons.arrow_back, color: Colors.white),
      )),
      Positioned(top: 18, right: 16, child: Row(children: [
        IconButton(onPressed: () {}, icon: const Icon(Icons.favorite_border, color: Colors.white)),
        IconButton(onPressed: () {}, icon: const Icon(Icons.share_outlined, color: Colors.white)),
      ])),
      Positioned(left: 20, right: 20, bottom: 24, child: SafeArea(child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Colors.black.withOpacity(.45), borderRadius: BorderRadius.circular(22)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(item.title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text(item.category, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text(item.tags.map((x) => '#$x').join('  '), style: const TextStyle(color: Colors.white70)),
        ]),
      ))),
    ]),
  );
}
