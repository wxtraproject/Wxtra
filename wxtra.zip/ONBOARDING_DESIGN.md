# WXTRA Onboarding

- 4-screen onboarding
- White premium visual language with purple/blue/cyan accents
- Cinematic slide transitions between onboarding screens
- Swipe left/right navigation
- `Atla` skips onboarding
- Final `Hadi Başlayalım` enters Home
- Onboarding completion is stored in SharedPreferences
- Global page transitions use slide + fade + subtle scale
