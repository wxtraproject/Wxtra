import 'package:flutter_test/flutter_test.dart';
import 'package:wxtra_wallpaper/main.dart';

void main() {
  testWidgets('Wxtra home opens', (tester) async {
    await tester.pumpWidget(const WxtraApp());
    expect(find.text('Günün Duvar Kağıtları'), findsOneWidget);
    expect(find.text('Wxtra'), findsWidgets);
  });
}
